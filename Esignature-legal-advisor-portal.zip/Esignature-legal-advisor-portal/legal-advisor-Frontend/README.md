# Legal Advisor Frontend

A modern React.js application for AI-powered legal document generation and analysis, built with Vite and Tailwind CSS.

## Features

- **Authentication System**: Secure login/signup with JWT tokens
- **Document Generation**: AI-powered legal document creation
- **Document Analysis**: Comprehensive legal document analysis and issue identification
- **Profile Management**: User profile management with verification
- **Responsive Design**: Mobile-first responsive design
- **Modern UI**: Clean and professional interface using Tailwind CSS

## Tech Stack

- **React 18**: Modern React with hooks
- **Vite**: Fast build tool and development server
- **Tailwind CSS**: Utility-first CSS framework
- **React Router**: Client-side routing
- **Axios**: HTTP client for API communication
- **Lucide React**: Beautiful icons
- **Headless UI**: Accessible UI components

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- Backend server running on `http://localhost:8080`

### Installation

1. Navigate to the frontend directory:
   ```bash
   cd legal-advisor-frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open your browser and visit `http://localhost:5173`

### Building for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── LoadingSpinner.jsx
│   └── Navbar.jsx
├── context/            # React context providers
│   └── AuthContext.jsx
├── pages/              # Page components
│   ├── Dashboard.jsx
│   ├── DocumentAnalyzer.jsx
│   ├── DocumentGenerator.jsx
│   ├── Login.jsx
│   ├── Profile.jsx
│   └── Signup.jsx
├── services/           # API services
│   └── api.js
├── App.jsx            # Main app component
├── index.css          # Global styles
└── main.jsx          # App entry point
```

## API Integration

The frontend connects to the Spring Boot backend with the following endpoints:

### Authentication
- `POST /api/auth/signup` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `POST /api/auth/refresh` - Token refresh

### AI Services
- `POST /api/ai/generate` - Generate legal documents
- `POST /api/ai/analyze` - Analyze documents
- `GET /api/ai/status` - Check AI service status

### Profile Management
- `GET /api/profile` - Get user profile
- `POST /api/profile` - Update user profile
- `POST /api/profile/verify` - Verify profile

## Features in Detail

### 1. Authentication
- Secure JWT-based authentication
- Automatic token refresh
- Protected routes
- Persistent login state

### 2. Document Generation
- Multiple agreement types (Employment, Service, Partnership, etc.)
- Customizable party information
- Specific terms and conditions
- Download and copy functionality

### 3. Document Analysis
- Comprehensive legal analysis
- Issue identification and highlighting
- Risk assessment
- Downloadable reports

### 4. Profile Management
- Personal and business information
- PAN and GST verification
- Multiple verification methods
- Real-time status updates

## Styling

The application uses Tailwind CSS with a custom design system:

- **Primary Colors**: Blue shades for main actions
- **Secondary Colors**: Gray shades for text and backgrounds
- **Components**: Pre-built component classes for consistency
- **Responsive**: Mobile-first responsive design

## Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

### Environment Variables

Create a `.env` file in the root directory:

```env
VITE_API_BASE_URL=http://localhost:8080/api
```

## Deployment

The application can be deployed to any static hosting service:

1. Build the application: `npm run build`
2. Upload the `dist` folder to your hosting service
3. Configure your hosting service to serve the `index.html` file for all routes

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions, please contact the development team.
