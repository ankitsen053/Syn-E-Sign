import { useNavigate } from 'react-router-dom';

// Utility function to redirect to signin page
export const redirectToSignin = (navigate, reason = '') => {
  const params = reason ? `?reason=${encodeURIComponent(reason)}` : '';
  navigate(`/login${params}`);
};

// Utility function to redirect to dashboard
export const redirectToDashboard = (navigate) => {
  navigate('/dashboard');
};

// Utility function to redirect with return URL
export const redirectToSigninWithReturn = (navigate, returnUrl) => {
  const params = returnUrl ? `?returnUrl=${encodeURIComponent(returnUrl)}` : '';
  navigate(`/login${params}`);
};

// Hook for redirect utilities
export const useRedirect = () => {
  const navigate = useNavigate();
  
  return {
    toSignin: (reason) => redirectToSignin(navigate, reason),
    toDashboard: () => redirectToDashboard(navigate),
    toSigninWithReturn: (returnUrl) => redirectToSigninWithReturn(navigate, returnUrl)
  };
};
