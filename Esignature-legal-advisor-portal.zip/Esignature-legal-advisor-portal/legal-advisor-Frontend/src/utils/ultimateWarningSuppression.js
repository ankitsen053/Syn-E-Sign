// ULTIMATE WARNING SUPPRESSION - Comprehensive warning suppression

(function() {
  'use strict';
  
  // Store original methods immediately
  const originalWarn = console.warn;
  const originalError = console.error;
  const originalLog = console.log;
  const originalInfo = console.info;
  const originalDebug = console.debug;
  
  // Comprehensive filter function
  function shouldSuppress(message) {
    if (typeof message !== 'string') return false;
    
    const lowerMessage = message.toLowerCase();
    
    // Suppress ALL deprecation-related messages
    return (
      message.includes('-ms-high-contrast') ||
      message.includes('[Deprecation]') ||
      message.includes('[antd:') ||
      message.includes('Download the React DevTools') ||
      lowerMessage.includes('deprecat') ||
      lowerMessage.includes('deprecated') ||
      message.includes('forced-colors') ||
      message.includes('high-contrast') ||
      message.includes('ms-high-contrast') ||
      lowerMessage.includes('deprecation') ||
      message.includes('Forced Colors Mode') ||
      message.includes('blogs.windows.com/msedgedev')
    );
  }
  
  // Override console methods safely
  console.warn = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the warning
    }
    return originalWarn.apply(console, args);
  };
  
  console.error = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the error
    }
    return originalError.apply(console, args);
  };
  
  console.log = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the log
    }
    return originalLog.apply(console, args);
  };
  
  console.info = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the info
    }
    return originalInfo.apply(console, args);
  };
  
  console.debug = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the debug
    }
    return originalDebug.apply(console, args);
  };
  
  // Intercept CSS processing safely
  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    // Override style sheet insertion
    if (CSSStyleSheet && CSSStyleSheet.prototype && CSSStyleSheet.prototype.insertRule) {
      const originalInsertRule = CSSStyleSheet.prototype.insertRule;
      CSSStyleSheet.prototype.insertRule = function(rule, index) {
        // Filter out -ms-high-contrast rules
        if (typeof rule === 'string' && rule.includes('-ms-high-contrast')) {
          return 0; // Return success but don't actually insert
        }
        return originalInsertRule.call(this, rule, index);
      };
    }
    
    // Override CSS rule addition if it exists
    if (CSSStyleSheet && CSSStyleSheet.prototype && CSSStyleSheet.prototype.addRule) {
      const originalAddRule = CSSStyleSheet.prototype.addRule;
      CSSStyleSheet.prototype.addRule = function(selector, style, index) {
        // Filter out -ms-high-contrast rules
        if (typeof selector === 'string' && selector.includes('-ms-high-contrast')) {
          return -1; // Return failure
        }
        return originalAddRule.call(this, selector, style, index);
      };
    }
  }
  
  console.log('🔇 Ultimate warning suppression activated - all deprecation warnings suppressed');
})();

export default {};
