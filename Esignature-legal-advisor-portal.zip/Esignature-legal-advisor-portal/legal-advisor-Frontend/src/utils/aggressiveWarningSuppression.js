// Aggressive warning suppression for development
if (process.env.NODE_ENV === 'development') {
  // Store original console methods
  const originalWarn = console.warn;
  const originalError = console.error;
  const originalLog = console.log;
  const originalInfo = console.info;
  
  // Suppress all deprecation warnings
  console.warn = (...args) => {
    const message = args[0];
    if (typeof message === 'string') {
      // Suppress -ms-high-contrast deprecation warnings
      if (message.includes('-ms-high-contrast')) {
        return;
      }
      // Suppress other common deprecation warnings
      if (message.includes('[Deprecation]')) {
        return;
      }
      // Suppress Ant Design deprecation warnings
      if (message.includes('[antd:')) {
        return;
      }
      // Suppress React DevTools warnings
      if (message.includes('Download the React DevTools')) {
        return;
      }
      // Suppress any other deprecation-related warnings
      if (message.toLowerCase().includes('deprecat')) {
        return;
      }
    }
    originalWarn.apply(console, args);
  };
  
  console.error = (...args) => {
    const message = args[0];
    if (typeof message === 'string') {
      // Suppress -ms-high-contrast deprecation errors
      if (message.includes('-ms-high-contrast')) {
        return;
      }
      // Suppress other deprecation errors
      if (message.includes('[Deprecation]')) {
        return;
      }
      // Suppress any other deprecation-related errors
      if (message.toLowerCase().includes('deprecat')) {
        return;
      }
    }
    originalError.apply(console, args);
  };
  
  // Also suppress some logs that might contain deprecation info
  console.log = (...args) => {
    const message = args[0];
    if (typeof message === 'string') {
      // Suppress deprecation logs
      if (message.includes('-ms-high-contrast') || 
          message.includes('[Deprecation]') ||
          message.toLowerCase().includes('deprecat')) {
        return;
      }
    }
    originalLog.apply(console, args);
  };
  
  console.info = (...args) => {
    const message = args[0];
    if (typeof message === 'string') {
      // Suppress deprecation info
      if (message.includes('-ms-high-contrast') || 
          message.includes('[Deprecation]') ||
          message.toLowerCase().includes('deprecat')) {
        return;
      }
    }
    originalInfo.apply(console, args);
  };
  
  // Override window.console to ensure our suppression works
  const originalConsole = window.console;
  window.console = {
    ...originalConsole,
    warn: console.warn,
    error: console.error,
    log: console.log,
    info: console.info
  };
  
  // Also try to suppress warnings at the browser level
  if (typeof window !== 'undefined') {
    // Override any global error handlers that might show deprecation warnings
    const originalAddEventListener = window.addEventListener;
    window.addEventListener = function(type, listener, options) {
      if (type === 'error' || type === 'unhandledrejection') {
        // Wrap the listener to filter out deprecation warnings
        const wrappedListener = function(event) {
          const message = event.message || event.reason || '';
          if (typeof message === 'string' && 
              (message.includes('-ms-high-contrast') || 
               message.includes('[Deprecation]') ||
               message.toLowerCase().includes('deprecat'))) {
            return; // Suppress the event
          }
          return listener.call(this, event);
        };
        return originalAddEventListener.call(this, type, wrappedListener, options);
      }
      return originalAddEventListener.call(this, type, listener, options);
    };
  }
}

export default {};
