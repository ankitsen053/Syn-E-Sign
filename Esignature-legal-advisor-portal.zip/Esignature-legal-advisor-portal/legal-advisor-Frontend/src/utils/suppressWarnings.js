// Comprehensive warning suppression for development
if (process.env.NODE_ENV === 'development') {
  const originalWarn = console.warn;
  const originalError = console.error;
  const originalLog = console.log;
  
  // Suppress all deprecation warnings
  console.warn = (...args) => {
    const message = args[0];
    if (typeof message === 'string') {
      // Suppress -ms-high-contrast deprecation warnings
      if (message.includes('-ms-high-contrast')) {
        return;
      }
      // Suppress other common deprecation warnings
      if (message.includes('[Deprecation]')) {
        return;
      }
      // Suppress Ant Design deprecation warnings
      if (message.includes('[antd:')) {
        return;
      }
      // Suppress React DevTools warnings
      if (message.includes('Download the React DevTools')) {
        return;
      }
    }
    originalWarn.apply(console, args);
  };
  
  console.error = (...args) => {
    const message = args[0];
    if (typeof message === 'string') {
      // Suppress -ms-high-contrast deprecation errors
      if (message.includes('-ms-high-contrast')) {
        return;
      }
      // Suppress other deprecation errors
      if (message.includes('[Deprecation]')) {
        return;
      }
    }
    originalError.apply(console, args);
  };
  
  // Also suppress some logs that might contain deprecation info
  console.log = (...args) => {
    const message = args[0];
    if (typeof message === 'string') {
      // Suppress deprecation logs
      if (message.includes('-ms-high-contrast') || message.includes('[Deprecation]')) {
        return;
      }
    }
    originalLog.apply(console, args);
  };
}

export default {};
