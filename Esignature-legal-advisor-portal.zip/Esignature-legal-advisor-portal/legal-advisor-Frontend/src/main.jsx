import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './nuclear-js-fix.js'
import './clean-styles.css'
import './index.css'
import './utils/ultimateWarningSuppression.js'
import './utils/suppressWarnings.js'
import './utils/aggressiveWarningSuppression.js'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
