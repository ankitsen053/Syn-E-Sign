import { createContext, useContext, useState, useEffect } from 'react';
import { authAPI } from '../services/api';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchUserProfile = async () => {
    try {
      const token = localStorage.getItem('accessToken');
      if (!token) {
        console.warn('No access token found for profile fetch');
        return null;
      }
      
      const response = await authAPI.getUserProfile();
      const userProfile = response.data;
      setUser(prevUser => ({
        ...prevUser,
        ...userProfile
      }));
      return userProfile;
    } catch (error) {
      console.error('Failed to fetch user profile:', error);
      // If profile fetch fails, clear invalid tokens
      if (error.response?.status === 401 || error.response?.status === 500) {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        localStorage.removeItem('tokenType');
        setUser(null);
      }
      return null;
    }
  };

  useEffect(() => {
    // Check if user is logged in on app start
    const token = localStorage.getItem('accessToken');
    if (token) {
      // Simple validation - check if token looks valid (has 3 parts separated by dots)
      const tokenParts = token.split('.');
      if (tokenParts.length !== 3) {
        // Invalid token format, clear it
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        localStorage.removeItem('tokenType');
        setLoading(false);
        return;
      }
      
      // Fetch user profile if token exists
      fetchUserProfile().finally(() => {
        setLoading(false);
      });
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (credentials) => {
    try {
      const response = await authAPI.login(credentials);
      const { token, refreshToken, username, roles } = response.data;
      
      // Store tokens first
      localStorage.setItem('accessToken', token);
      localStorage.setItem('refreshToken', refreshToken);
      
      // Set basic user info immediately
      setUser({
        username,
        roles,
        token: token
      });
      
      // Add a small delay to ensure token is properly set before fetching profile
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Fetch complete user profile after delay
      try {
        const userProfile = await fetchUserProfile();
        if (userProfile) {
          setUser(prevUser => ({
            ...prevUser,
            ...userProfile
          }));
        }
      } catch (profileError) {
        console.warn('Failed to fetch user profile, but login was successful:', profileError);
        // Don't fail the login if profile fetch fails
      }
      
      return { success: true };
    } catch (error) {
      console.error('Login error:', error);
      const errorMessage = error.response?.data?.message || error.message || 'Login failed';
      throw new Error(errorMessage);
    }
  };

  const loginWithToken = (userData) => {
    try {
      const { token, type, username, email, id } = userData;
      
      localStorage.setItem('accessToken', token);
      localStorage.setItem('tokenType', type);
      
      setUser({
        id,
        username,
        email,
        roles: ['ROLE_USER'], // Default role for OAuth users
        token: token
      });
      
      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: 'Failed to complete OAuth authentication'
      };
    }
  };

  const signup = async (userData) => {
    try {
      const response = await authAPI.signup(userData);
      return { success: true, message: response.data.message };
    } catch (error) {
      console.error('Signup error:', error);
      const errorMessage = error.response?.data?.message || error.message || 'Signup failed';
      throw new Error(errorMessage);
    }
  };

  const logout = async () => {
    try {
      const refreshToken = localStorage.getItem('refreshToken');
      if (refreshToken) {
        await authAPI.logout(refreshToken);
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('tokenType');
      setUser(null);
    }
  };

  const updateUser = (updatedUserData) => {
    setUser(prevUser => ({
      ...prevUser,
      ...updatedUserData
    }));
  };

  const isAuthenticated = !!user && !!localStorage.getItem('accessToken');

  const value = {
    user,
    login,
    loginWithToken,
    signup,
    logout,
    isAuthenticated,
    loading,
    fetchUserProfile,
    updateUser
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
