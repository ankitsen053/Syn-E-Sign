import axios from 'axios';

const API_BASE_URL = 'http://localhost:8081/api';

// Create axios instance with default config
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    // Add timestamp to prevent caching issues
    config.headers['Cache-Control'] = 'no-cache';
    config.headers['Pragma'] = 'no-cache';
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        const refreshToken = localStorage.getItem('refreshToken');
        if (refreshToken) {
          const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
            refreshToken: refreshToken
          });
          
          const { token } = response.data;
          localStorage.setItem('accessToken', token);
          
          originalRequest.headers.Authorization = `Bearer ${token}`;
          return api(originalRequest);
        }
      } catch {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login?error=session_expired';
      }
    }
    
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  signup: (userData) => api.post('/auth/signup', userData),
  login: (credentials) => api.post('/auth/login', credentials),
  logout: (refreshToken) => api.post('/auth/logout', { refreshToken }),
  refreshToken: (refreshToken) => api.post('/auth/refresh', { refreshToken }),
  verifyEmail: (email, otp) => api.post('/auth/verify-email', { email, otp }),
  resendOtp: (email) => api.post('/auth/resend-otp', { email }),
  getUserProfile: () => api.get('/auth/profile'),
  updateProfile: (profileData) => api.put('/auth/profile', profileData),
  changePassword: (passwordData) => api.put('/auth/change-password', passwordData),
  uploadProfilePicture: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/auth/upload-profile-picture', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },
  getUserPreferences: () => api.get('/auth/preferences'),
  updateUserPreferences: (preferencesData) => api.put('/auth/preferences', preferencesData),
};

// Verification API
export const verificationAPI = {
  getStatus: () => api.get('/verification/status'),
  submitPan: (panData) => api.post('/verification/pan', panData),
  submitAadhar: (aadharData) => api.post('/verification/aadhar', aadharData),
  submitVideo: (formData) => api.post('/verification/video', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  }),
};

// Verification Refresh API
export const verificationRefreshAPI = {
  generateRefreshToken: () => api.post('/verification-refresh/generate-token'),
  refreshVerificationStatus: (refreshToken) => api.post('/verification-refresh/refresh', { refreshToken }),
  getUserVerificationProfile: () => api.get('/verification-refresh/profile'),
  getVerificationStatusByUserId: (userId) => api.get(`/verification-refresh/status/${userId}`),
  refreshSpecificVerification: (verificationType, refreshToken) => 
    api.post(`/verification-refresh/refresh/${verificationType}`, { refreshToken }),
  getVerificationTermsExplanation: () => api.get('/verification-refresh/terms-explanation'),
};

// AI API
export const aiAPI = {
  // Agreement generation endpoints
  createAgreement: (params) => api.post('/ai/create', params),
  createAndDownloadAgreement: (params) => api.post('/ai/create-and-download', params, { 
    responseType: 'blob'
  }),
  generateAndSaveAgreement: (params) => api.post('/ai/generate-and-save', params),
  downloadAgreementTxt: (params) => api.post('/ai/download-txt', params, { responseType: 'blob' }),
  downloadAgreementDocx: (params) => api.post('/ai/download-docx', params, { responseType: 'blob' }),
  
  // Document analysis endpoints - these expect file uploads
  analyzeDocument: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/ai/analyze', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },
  
  // Text-based document analysis endpoint
  analyzeDocumentText: (content) => {
    return api.post('/ai/analyze-text', { content });
  },
  
  // File-based analysis endpoints
  highlightIssues: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/ai/highlight-issues', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },
  
  performRiskAnalysis: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/ai/risk-analysis', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },
  
  assessCompliance: (file, jurisdiction = 'IN') => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('jurisdiction', jurisdiction);
    return api.post('/ai/compliance-assessment', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },
  
  // Text-based analysis endpoints (for when content is provided as text)
  highlightIssuesText: (content) => {
    return api.post('/ai/highlight-issues-text', { content });
  },
  
  performRiskAnalysisText: (content) => {
    return api.post('/ai/risk-analysis-text', { content });
  },
  
  assessComplianceText: (content, jurisdiction = 'IN') => {
    return api.post('/ai/compliance-assessment-text', { content, jurisdiction });
  },
  
  // Status endpoint
  getStatus: () => api.get('/ai/status'),
  
  // Legacy endpoints for backward compatibility
  generateAgreement: (params) => api.post('/ai/generate', null, { params }),
  analyzeDocumentComprehensive: (content) => api.post('/ai/analyze-comprehensive', content),
};

// Document API
export const documentAPI = {
  saveDocument: (documentData) => api.post('/documents/save', documentData),
  updateDocument: (documentId, documentData) => api.put(`/documents/${documentId}`, documentData),
  getDocument: (documentId) => api.get(`/documents/${documentId}`),
  getUserDocuments: () => api.get('/documents/user'),
  deleteDocument: (documentId) => api.delete(`/documents/${documentId}`),
  deleteBulkDocuments: (documentIds) => api.delete('/documents/bulk', { data: { documentIds } }),
  confirmDelete: (documentId) => api.post(`/documents/${documentId}/confirm-delete`),
  downloadDocument: (documentId) => api.get(`/documents/${documentId}/download`, { responseType: 'blob' }),
  getStatus: () => api.get('/documents/status'),
};

// Signature API
export const signatureAPI = {
  signAgreement: (signatureRequest) => api.post('/signature/sign', signatureRequest),
  getSignedAgreement: (agreementId) => api.get(`/signature/${agreementId}`),
  getUserAgreements: () => api.get('/signature/user/agreements'),
  getAllAgreements: () => api.get('/signature/admin/all'),
  downloadAgreement: (agreementId) => api.get(`/signature/${agreementId}/download`, { responseType: 'blob' }),
  verifyAgreement: (agreementId) => api.get(`/signature/${agreementId}/verify`),
  getSignatureImage: (agreementId) => api.get(`/signature/${agreementId}/signature`),
  completeAgreement: (agreementId) => api.post(`/signature/${agreementId}/complete`),
  deleteAgreement: (agreementId) => api.delete(`/signature/${agreementId}`),
  getStats: () => api.get('/signature/stats'),
  
  // Multi-party signature endpoints
  createMultiPartyAgreement: (agreementData) => api.post('/signature/create-multi-party', agreementData),
  getMultiPartyAgreementStatus: (agreementId) => api.get(`/signature/multi-party/${agreementId}/status`),
  addSignatureToMultiPartyAgreement: (agreementId, signatureData) => api.post(`/signature/multi-party/${agreementId}/sign`, signatureData),
  sendSigningInvitation: (agreementId, invitationData) => api.post(`/signature/multi-party/${agreementId}/send-invitation`, invitationData),
};

// Admin API
export const adminAPI = {
  getDashboard: () => api.get('/admin/dashboard'),
  getAllUsers: (params) => api.get('/admin/users', { params }),
  getUserDetails: (userId) => api.get(`/admin/users/${userId}`),
  updateUserVerification: (userId, verificationData) => api.put(`/admin/users/${userId}/verification`, verificationData),
  getAllVerificationRequests: (params) => api.get('/admin/verifications', { params }),
  approveVerification: (userId, approvalData) => api.post(`/admin/verifications/${userId}/approve`, approvalData),
  rejectVerification: (userId, rejectionData) => api.post(`/admin/verifications/${userId}/reject`, rejectionData),
  getAllAgreements: (params) => api.get('/admin/agreements', { params }),
  getAgreementDetails: (agreementId) => api.get(`/admin/agreements/${agreementId}`),
  getSystemStatistics: () => api.get('/admin/statistics'),
};

// Enhanced AI API
export const enhancedAIAPI = {
  ...aiAPI,
  performComprehensiveAnalysis: (content) => api.post('/ai/comprehensive-analysis', { content }),
};

// Professional Legal Analysis API for Lawyers
export const professionalLegalAPI = {
  // File-based professional analysis
  performProfessionalAnalysis: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/ai/professional-analyze', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },
  
  // Text-based professional analysis
  performProfessionalTextAnalysis: (content) => api.post('/ai/professional-analyze-text', { content }),
  
  // Enhanced issue detection for lawyers
  highlightProfessionalIssues: (content) => api.post('/ai/highlight-issues-text', { content }),
  
  // Professional risk analysis
  performProfessionalRiskAnalysis: (content) => api.post('/ai/risk-analysis-text', { content }),
  
  // Professional compliance assessment
  assessProfessionalCompliance: (content, jurisdiction = 'IN') => 
    api.post('/ai/compliance-assessment-text', { content, jurisdiction }),
};

// Dashboard API
export const dashboardAPI = {
  getStats: () => api.get('/dashboard/stats'),
  getMetrics: () => api.get('/dashboard/metrics'),
  getActivity: () => api.get('/dashboard/activity'),
  getProgress: () => api.get('/dashboard/progress'),
  getPreferences: () => api.get('/dashboard/preferences'),
};

// Document Upload API
export const documentUploadAPI = {
  uploadDocument: (formData) => api.post('/documents/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  }),
  analyzeDocument: (documentId) => api.post(`/documents/analyze/${documentId}`),
  getUploadedDocuments: () => api.get('/documents/uploaded'),
  deleteUploadedDocument: (documentId) => api.delete(`/documents/uploaded/${documentId}`),
  downloadDocument: (documentId) => api.get(`/documents/download/${documentId}`, {
    responseType: 'blob'
  }),
};

export default api;
