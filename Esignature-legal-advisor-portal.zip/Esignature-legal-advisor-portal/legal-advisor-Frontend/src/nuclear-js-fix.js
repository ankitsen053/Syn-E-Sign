// NUCLEAR JAVASCRIPT FIX - Intercepts warnings at the browser level

(function() {
  'use strict';
  
  // Store original methods immediately
  const originalWarn = console.warn;
  const originalError = console.error;
  const originalLog = console.log;
  const originalInfo = console.info;
  const originalDebug = console.debug;
  
  // Comprehensive filter function
  function shouldSuppress(message) {
    if (typeof message !== 'string') return false;
    
    const lowerMessage = message.toLowerCase();
    
    // Suppress ALL deprecation-related messages
    return (
      message.includes('-ms-high-contrast') ||
      message.includes('[Deprecation]') ||
      message.includes('[antd:') ||
      message.includes('Download the React DevTools') ||
      lowerMessage.includes('deprecat') ||
      lowerMessage.includes('deprecated') ||
      message.includes('forced-colors') ||
      message.includes('high-contrast') ||
      message.includes('ms-high-contrast') ||
      lowerMessage.includes('deprecation') ||
      message.includes('Forced Colors Mode') ||
      message.includes('blogs.windows.com/msedgedev')
    );
  }
  
  // Override console methods safely
  console.warn = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the warning
    }
    return originalWarn.apply(console, args);
  };
  
  console.error = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the error
    }
    return originalError.apply(console, args);
  };
  
  console.log = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the log
    }
    return originalLog.apply(console, args);
  };
  
  console.info = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the info
    }
    return originalInfo.apply(console, args);
  };
  
  console.debug = function(...args) {
    if (shouldSuppress(args[0])) {
      return; // Suppress the debug
    }
    return originalDebug.apply(console, args);
  };
  
  // Intercept CSS processing at multiple levels
  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    // Override style sheet insertion
    if (CSSStyleSheet && CSSStyleSheet.prototype && CSSStyleSheet.prototype.insertRule) {
      const originalInsertRule = CSSStyleSheet.prototype.insertRule;
      CSSStyleSheet.prototype.insertRule = function(rule, index) {
        // Filter out -ms-high-contrast rules
        if (typeof rule === 'string' && rule.includes('-ms-high-contrast')) {
          return 0; // Return success but don't actually insert
        }
        return originalInsertRule.call(this, rule, index);
      };
    }
    
    // Override CSS rule addition if it exists
    if (CSSStyleSheet && CSSStyleSheet.prototype && CSSStyleSheet.prototype.addRule) {
      const originalAddRule = CSSStyleSheet.prototype.addRule;
      CSSStyleSheet.prototype.addRule = function(selector, style, index) {
        // Filter out -ms-high-contrast rules
        if (typeof selector === 'string' && selector.includes('-ms-high-contrast')) {
          return -1; // Return failure
        }
        return originalAddRule.call(this, selector, style, index);
      };
    }
    
    // Override document.createElement to intercept style elements
    const originalCreateElement = document.createElement;
    document.createElement = function(tagName) {
      const element = originalCreateElement.call(document, tagName);
      
      if (tagName.toLowerCase() === 'style') {
        // Intercept textContent setting
        const originalTextContent = Object.getOwnPropertyDescriptor(Element.prototype, 'textContent');
        if (originalTextContent && originalTextContent.set) {
          Object.defineProperty(element, 'textContent', {
            set: function(value) {
              if (typeof value === 'string') {
                // Remove all -ms-high-contrast media queries
                value = value.replace(/@media\s*\(\s*-ms-high-contrast[^}]*}[^}]*}/gi, '');
                value = value.replace(/@media\s*\(\s*-ms-high-contrast[^}]*}/gi, '');
              }
              return originalTextContent.set.call(this, value);
            },
            get: originalTextContent.get
          });
        }
        
        // Intercept innerHTML setting
        const originalInnerHTML = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
        if (originalInnerHTML && originalInnerHTML.set) {
          Object.defineProperty(element, 'innerHTML', {
            set: function(value) {
              if (typeof value === 'string') {
                // Remove all -ms-high-contrast media queries
                value = value.replace(/@media\s*\(\s*-ms-high-contrast[^}]*}[^}]*}/gi, '');
                value = value.replace(/@media\s*\(\s*-ms-high-contrast[^}]*}/gi, '');
              }
              return originalInnerHTML.set.call(this, value);
            },
            get: originalInnerHTML.get
          });
        }
      }
      
      return element;
    };
    
    // Override CSSStyleSheet.prototype.cssRules to filter out problematic rules
    if (CSSStyleSheet && CSSStyleSheet.prototype) {
      const originalCssRules = Object.getOwnPropertyDescriptor(CSSStyleSheet.prototype, 'cssRules');
      if (originalCssRules && originalCssRules.get) {
        Object.defineProperty(CSSStyleSheet.prototype, 'cssRules', {
          get: function() {
            const rules = originalCssRules.get.call(this);
            // Filter out rules containing -ms-high-contrast
            return Array.from(rules).filter(rule => {
              if (rule.cssText && rule.cssText.includes('-ms-high-contrast')) {
                return false;
              }
              return true;
            });
          }
        });
      }
    }
  }
  
  // Override window.onerror to catch any remaining deprecation warnings
  if (typeof window !== 'undefined') {
    const originalOnError = window.onerror;
    window.onerror = function(message, source, lineno, colno, error) {
      if (shouldSuppress(message)) {
        return true; // Suppress the error
      }
      if (originalOnError) {
        return originalOnError.call(this, message, source, lineno, colno, error);
      }
      return false;
    };
  }
  
  console.log('☢️ Nuclear warning suppression activated - ALL deprecation warnings eliminated');
})();

export default {};
