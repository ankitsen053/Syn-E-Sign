import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './components/Dashboard';
import OAuthCallback from './pages/OAuthCallback';
import DocumentGenerator from './pages/DocumentGenerator';
import DocumentAnalyzer from './pages/DocumentAnalyzer';
import DocumentManager from './pages/DocumentManager';
import DocumentUpload from './pages/DocumentUpload';
import Verification from './pages/Verification';
import ProfileSettings from './pages/ProfileSettings';
import AdminDashboard from './pages/AdminDashboard';
import LoadingSpinner from './components/LoadingSpinner';

const PrivateRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  
  if (loading) {
    return <LoadingSpinner />;
  }
  
  return isAuthenticated ? children : <Navigate to="/login" />;
};

const AppContent = () => {
  const { isAuthenticated } = useAuth();

  return (
    <Router>
      <div className="min-h-screen bg-secondary-50 flex flex-col">
        {isAuthenticated && <Navbar />}
        <main className={`flex-1 ${isAuthenticated ? 'pt-16' : ''}`}>
          <Routes>
            <Route path="/login" element={
              isAuthenticated ? <Navigate to="/dashboard" /> : <Login />
            } />
            <Route path="/signup" element={
              isAuthenticated ? <Navigate to="/dashboard" /> : <Signup />
            } />
            <Route path="/oauth-callback" element={<OAuthCallback />} />
            <Route path="/dashboard" element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            } />
            <Route path="/generate" element={
              <PrivateRoute>
                <DocumentGenerator />
              </PrivateRoute>
            } />
            <Route path="/analyze" element={
              <PrivateRoute>
                <DocumentAnalyzer />
              </PrivateRoute>
            } />
            <Route path="/documents" element={
              <PrivateRoute>
                <DocumentManager />
              </PrivateRoute>
            } />
            <Route path="/upload" element={
              <PrivateRoute>
                <DocumentUpload />
              </PrivateRoute>
            } />

            <Route path="/verification" element={
              <PrivateRoute>
                <Verification />
              </PrivateRoute>
            } />
            <Route path="/profile" element={
              <PrivateRoute>
                <ProfileSettings />
              </PrivateRoute>
            } />
            <Route path="/admin" element={
              <PrivateRoute>
                <AdminDashboard />
              </PrivateRoute>
            } />
            <Route path="/" element={
              isAuthenticated ? <Navigate to="/dashboard" /> : <Navigate to="/login" />
            } />
          </Routes>
        </main>

      </div>
    </Router>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
