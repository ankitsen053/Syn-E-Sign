import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { Scale, Eye, EyeOff, Mail, Lock, User, Sparkles } from 'lucide-react';
import { Form, Input, Button, Card, Typography, Divider, Alert, Space } from 'antd';

const { Title, Text, Paragraph } = Typography;

const Login = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const onFinish = async (values) => {
    setLoading(true);
    setError('');

    try {
      await login(values);
      navigate('/dashboard');
    } catch (error) {
      console.error('Login error:', error);
      setError(error.message || 'Login failed. Please try again.');
    }
    
    setLoading(false);
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  const formVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        delay: 0.2,
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="w-full max-w-md"
      >
        {/* Logo and Header */}
        <motion.div 
          className="text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="inline-block mb-4"
          >
            <Sparkles className="h-12 w-12 text-yellow-500" />
          </motion.div>
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-xl">
              <Scale className="h-10 w-10 text-white" />
            </div>
            <div>
              <Title level={1} className="!mb-0 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Legal Advisor
              </Title>
              <Text type="secondary" className="text-sm">AI-Powered Legal Assistant</Text>
            </div>
          </div>
          <Title level={2} className="!mb-2">Welcome Back</Title>
          <Paragraph type="secondary">
            Sign in to your account to continue
          </Paragraph>
        </motion.div>

        {/* Login Form */}
        <motion.div variants={formVariants}>
          <Card 
            className="shadow-2xl border-0"
            styles={{ body: { padding: '40px' } }}
            style={{ 
              background: 'rgba(255, 255, 255, 0.9)',
              backdropFilter: 'blur(10px)',
              borderRadius: '20px'
            }}
          >
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6"
              >
                <Alert
                  message="Login Failed"
                  description={error}
                  type="error"
                  showIcon
                  closable
                  onClose={() => setError('')}
                />
              </motion.div>
            )}

            <Form
              name="login"
              onFinish={onFinish}
              layout="vertical"
              size="large"
            >
              <Form.Item
                name="username"
                label="Username"
                rules={[
                  { required: true, message: 'Please enter your username!' }
                ]}
              >
                <Input
                  prefix={<User className="h-4 w-4 text-gray-400" />}
                  placeholder="Enter your username"
                  className="rounded-lg"
                />
              </Form.Item>

              <Form.Item
                name="password"
                label="Password"
                rules={[
                  { required: true, message: 'Please enter your password!' }
                ]}
              >
                <Input.Password
                  prefix={<Lock className="h-4 w-4 text-gray-400" />}
                  placeholder="Enter your password"
                  className="rounded-lg"
                  iconRender={(visible) => (
                    visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />
                  )}
                />
              </Form.Item>

              <Form.Item className="mb-6">
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button
                    type="primary"
                    htmlType="submit"
                    loading={loading}
                    className="w-full h-12 rounded-lg bg-gradient-to-r from-blue-600 to-purple-600 border-0 text-white font-medium text-base shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    {loading ? 'Signing In...' : 'Sign In'}
                  </Button>
                </motion.div>
              </Form.Item>
            </Form>

            <Divider plain>
              <Text type="secondary">Or</Text>
            </Divider>

            <Space direction="vertical" className="w-full">
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  className="w-full h-12 rounded-lg border-gray-300 text-gray-700 font-medium hover:border-blue-500 hover:text-blue-600 transition-all duration-300"
                  icon={<Mail className="h-4 w-4" />}
                >
                  Continue with Google
                </Button>
              </motion.div>
            </Space>

            <div className="mt-8 text-center">
              <Text type="secondary">
                Don't have an account?{' '}
                <Link 
                  to="/signup" 
                  className="text-blue-600 hover:text-blue-700 font-medium transition-colors"
                >
                  Sign up here
                </Link>
              </Text>
            </div>
          </Card>
        </motion.div>

        {/* Footer */}
        <motion.div 
          className="text-center mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Text type="secondary" className="text-sm">
            © 2024 Legal Advisor. All rights reserved.
          </Text>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Login;
