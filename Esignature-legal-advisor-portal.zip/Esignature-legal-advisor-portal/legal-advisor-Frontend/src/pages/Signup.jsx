import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { Scale, Eye, EyeOff, Mail, Lock, User, Sparkles, CheckCircle } from 'lucide-react';
import { Form, Input, Button, Card, Typography, Divider, Alert, Space, Steps } from 'antd';
import EmailVerification from '../components/EmailVerification';

const { Title, Text, Paragraph } = Typography;

const Signup = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showEmailVerification, setShowEmailVerification] = useState(false);
  const [signupEmail, setSignupEmail] = useState('');
  const [signupOtp, setSignupOtp] = useState('');
  const { signup } = useAuth();
  const navigate = useNavigate();

  const onFinish = async (values) => {
    setLoading(true);
    setError('');
    setSuccess('');

    const userData = {
      username: values.username,
      fullName: values.fullName,
      email: values.email,
      password: values.password
    };

    try {
      const result = await signup(userData);
      
      if (result.message.includes('verification OTP') || 
          result.message.includes('check your email') || 
          result.message.includes('Email verification failed') ||
          result.message.includes('Email service temporarily unavailable') ||
          result.message.includes('OTP for verification')) {
        setSignupEmail(values.email);
        
        // Extract OTP from the message if present
        const otpMatch = result.message.match(/OTP for verification: (\d{6})/);
        if (otpMatch) {
          setSignupOtp(otpMatch[1]);
        }
        
        setShowEmailVerification(true);
        setSuccess('Account created successfully! Please verify your email.');
      } else {
        setSuccess(result.message || 'Account created successfully! Please log in.');
        setTimeout(() => {
          navigate('/login');
        }, 2000);
      }
    } catch (error) {
      console.error('Signup error:', error);
      setError(error.message || 'Signup failed. Please try again.');
    }
    
    setLoading(false);
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  const formVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        delay: 0.2,
        duration: 0.5
      }
    }
  };

  const steps = [
    {
      title: 'Account Details',
      description: 'Basic information',
      icon: <User className="h-4 w-4" />
    },
    {
      title: 'Email Verification',
      description: 'Verify your email',
      icon: <Mail className="h-4 w-4" />
    },
    {
      title: 'Complete',
      description: 'Ready to use',
      icon: <CheckCircle className="h-4 w-4" />
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="w-full max-w-lg"
      >
        {/* Logo and Header */}
        <motion.div 
          className="text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="inline-block mb-4"
          >
            <Sparkles className="h-12 w-12 text-yellow-500" />
          </motion.div>
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-xl">
              <Scale className="h-10 w-10 text-white" />
            </div>
            <div>
              <Title level={1} className="!mb-0 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Legal Advisor
              </Title>
              <Text type="secondary" className="text-sm">AI-Powered Legal Assistant</Text>
            </div>
          </div>
          <Title level={2} className="!mb-2">Create Account</Title>
          <Paragraph type="secondary">
            Join Legal Advisor to get started with AI-powered legal assistance
          </Paragraph>
        </motion.div>

        {/* Progress Steps */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Steps
            current={showEmailVerification ? 1 : 0}
            items={steps}
            className="bg-white/50 backdrop-blur-sm rounded-lg p-4"
          />
        </motion.div>

        {/* Signup Form */}
        <motion.div variants={formVariants}>
          <Card 
            className="shadow-2xl border-0"
            bodyStyle={{ padding: '40px' }}
            style={{ 
              background: 'rgba(255, 255, 255, 0.9)',
              backdropFilter: 'blur(10px)',
              borderRadius: '20px'
            }}
          >
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6"
              >
                <Alert
                  message="Registration Failed"
                  description={error}
                  type="error"
                  showIcon
                  closable
                  onClose={() => setError('')}
                />
              </motion.div>
            )}

            {success && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6"
              >
                <Alert
                  message="Success"
                  description={success}
                  type="success"
                  showIcon
                  closable
                  onClose={() => setSuccess('')}
                />
              </motion.div>
            )}

            <Form
              name="signup"
              onFinish={onFinish}
              layout="vertical"
              size="large"
            >
              <Form.Item
                name="fullName"
                label="Full Name"
                rules={[
                  { required: true, message: 'Please enter your full name!' },
                  { min: 2, message: 'Name must be at least 2 characters!' }
                ]}
              >
                <Input
                  prefix={<User className="h-4 w-4 text-gray-400" />}
                  placeholder="Enter your full name"
                  className="rounded-lg"
                />
              </Form.Item>

              <Form.Item
                name="username"
                label="Username"
                rules={[
                  { required: true, message: 'Please enter a username!' },
                  { min: 3, message: 'Username must be at least 3 characters!' }
                ]}
              >
                <Input
                  prefix={<User className="h-4 w-4 text-gray-400" />}
                  placeholder="Choose a username"
                  className="rounded-lg"
                />
              </Form.Item>

              <Form.Item
                name="email"
                label="Email"
                rules={[
                  { required: true, message: 'Please enter your email!' },
                  { type: 'email', message: 'Please enter a valid email!' }
                ]}
              >
                <Input
                  prefix={<Mail className="h-4 w-4 text-gray-400" />}
                  placeholder="Enter your email"
                  className="rounded-lg"
                />
              </Form.Item>

              <Form.Item
                name="password"
                label="Password"
                rules={[
                  { required: true, message: 'Please enter a password!' },
                  { min: 6, message: 'Password must be at least 6 characters!' }
                ]}
              >
                <Input.Password
                  prefix={<Lock className="h-4 w-4 text-gray-400" />}
                  placeholder="Create a password"
                  className="rounded-lg"
                  iconRender={(visible) => (
                    visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />
                  )}
                />
              </Form.Item>

              <Form.Item
                name="confirmPassword"
                label="Confirm Password"
                dependencies={['password']}
                rules={[
                  { required: true, message: 'Please confirm your password!' },
                  ({ getFieldValue }) => ({
                    validator(_, value) {
                      if (!value || getFieldValue('password') === value) {
                        return Promise.resolve();
                      }
                      return Promise.reject(new Error('Passwords do not match!'));
                    },
                  }),
                ]}
              >
                <Input.Password
                  prefix={<Lock className="h-4 w-4 text-gray-400" />}
                  placeholder="Confirm your password"
                  className="rounded-lg"
                  iconRender={(visible) => (
                    visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />
                  )}
                />
              </Form.Item>

              <Form.Item className="mb-6">
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button
                    type="primary"
                    htmlType="submit"
                    loading={loading}
                    className="w-full h-12 rounded-lg bg-gradient-to-r from-blue-600 to-purple-600 border-0 text-white font-medium text-base shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    {loading ? 'Creating Account...' : 'Create Account'}
                  </Button>
                </motion.div>
              </Form.Item>
            </Form>

            <Divider plain>
              <Text type="secondary">Already have an account?</Text>
            </Divider>

            <div className="text-center">
              <Link 
                to="/login" 
                className="text-blue-600 hover:text-blue-700 font-medium transition-colors"
              >
                Sign in here
              </Link>
            </div>
          </Card>
        </motion.div>

        {/* Footer */}
        <motion.div 
          className="text-center mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Text type="secondary" className="text-sm">
            © 2024 Legal Advisor. All rights reserved.
          </Text>
        </motion.div>

        {/* Email Verification Modal */}
        {showEmailVerification && (
          <EmailVerification
            email={signupEmail}
            providedOtp={signupOtp}
            onVerificationSuccess={() => {
              setShowEmailVerification(false);
              setSuccess('Email verified successfully! You can now log in.');
              setTimeout(() => {
                navigate('/login');
              }, 2000);
            }}
            onClose={() => {
              setShowEmailVerification(false);
              setError('Email verification cancelled. Please try signing up again.');
            }}
          />
        )}
      </motion.div>
    </div>
  );
};

export default Signup;
