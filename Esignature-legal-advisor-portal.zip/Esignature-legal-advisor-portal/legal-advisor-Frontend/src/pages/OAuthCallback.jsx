import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Scale, CheckCircle, AlertCircle } from 'lucide-react';
import OTPVerification from '../components/OTPVerification';

const OAuthCallback = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { loginWithToken } = useAuth();
  const [status, setStatus] = useState('processing');
  const [error, setError] = useState('');
  const [otpData, setOtpData] = useState(null);

  useEffect(() => {
    const token = searchParams.get('token');
    const type = searchParams.get('type');
    const username = searchParams.get('username');
    const email = searchParams.get('email');
    const id = searchParams.get('id');
    const errorParam = searchParams.get('error');
    const reasonParam = searchParams.get('reason');

    console.log('OAuth Callback - Received params:', { token: !!token, type, username, email, id, errorParam, reasonParam });

    if (errorParam) {
      setStatus('error');
      const errorMessage = reasonParam ? 
        `OAuth authentication failed: ${decodeURIComponent(reasonParam)}` : 
        'OAuth authentication failed. Please try again.';
      setError(errorMessage);
      return;
    }

    if (type === 'OTP_REQUIRED' && username && email) {
      // OTP verification required
      setStatus('otp_required');
      setOtpData({ username, email });
      return;
    }

    if (token && type && username && email) {
      // Process successful OAuth login
      const userData = {
        token,
        type,
        username,
        email,
        id
      };

      console.log('Processing OAuth login for user:', { username, email, id });

      try {
        const result = loginWithToken(userData);
        if (result.success) {
          setStatus('success');
          console.log('OAuth login successful, redirecting to dashboard...');
          
          // Redirect to dashboard after a short delay
          setTimeout(() => {
            navigate('/dashboard');
          }, 2000);
        } else {
          setStatus('error');
          setError(result.error || 'Failed to complete authentication. Please try again.');
        }
      } catch (err) {
        console.error('OAuth login error:', err);
        setStatus('error');
        setError('Failed to complete authentication. Please try again.');
      }
    } else {
      console.error('Invalid OAuth response - missing required parameters');
      setStatus('error');
      setError('Invalid OAuth response. Please try again.');
    }
  }, [searchParams, navigate, loginWithToken]);

  const renderContent = () => {
    switch (status) {
      case 'processing':
        return (
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">
              Completing Authentication
            </h2>
            <p className="text-secondary-600">
              Please wait while we complete your Google sign-in...
            </p>
          </div>
        );

      case 'success':
        return (
          <div className="text-center">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">
              Authentication Successful!
            </h2>
            <p className="text-secondary-600">
              Redirecting you to the dashboard...
            </p>
          </div>
        );

      case 'otp_required':
        return (
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">
              Verify Your Email
            </h2>
            <p className="text-secondary-600 mb-4">
              We've sent a verification code to {otpData?.email}
            </p>
            <OTPVerification 
              email={otpData?.email}
              username={otpData?.username}
              onSuccess={(userData) => {
                loginWithToken(userData);
                setStatus('success');
                setTimeout(() => navigate('/dashboard'), 2000);
              }}
              onError={(error) => {
                setStatus('error');
                setError(error);
              }}
            />
          </div>
        );

      case 'error':
        return (
          <div className="text-center">
            <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <AlertCircle className="h-8 w-8 text-red-600" />
            </div>
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">
              Authentication Failed
            </h2>
            <p className="text-secondary-600 mb-4">
              {error}
            </p>
            <button
              onClick={() => navigate('/login')}
              className="btn-primary"
            >
              Back to Login
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 to-secondary-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="flex justify-center">
            <Scale className="h-12 w-12 text-primary-600" />
          </div>
          <h1 className="mt-6 text-3xl font-bold text-secondary-900">
            Legal Advisor
          </h1>
        </div>

        <div className="card">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default OAuthCallback;
