import { useState } from 'react';
import { aiAPI } from '../services/api';
import { Search, FileText, AlertTriangle, CheckCircle, AlertCircle, Download, Copy, Shield, Scale, Target } from 'lucide-react';

const DocumentAnalyzer = () => {
  const [documentContent, setDocumentContent] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState({ analysis: false, issues: false, risk: false, compliance: false });
  const [analysisType, setAnalysisType] = useState('basic'); // basic, comprehensive, risk, compliance
  

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!documentContent.trim()) {
      setError('Please enter document content to analyze');
      return;
    }

    setLoading(true);
    setError('');
    setAnalysis(null);

    try {
      let response;
      
      switch (analysisType) {
        case 'comprehensive':
          response = await aiAPI.analyzeDocumentComprehensive(documentContent);
          break;
        case 'risk':
          response = await aiAPI.performRiskAnalysisText(documentContent);
          break;
        case 'compliance':
          response = await aiAPI.assessComplianceText(documentContent, 'IN');
          break;
        default:
          response = await aiAPI.analyzeDocumentText(documentContent);
      }
      
      // Handle different response structures
      const responseData = response.data;
      
      if (responseData.success || responseData.analysis) {
        setAnalysis({
          analysis: responseData.analysis || '',
          issues: responseData.issues || '',
          riskAnalysis: responseData.riskAnalysis || '',
          complianceAssessment: responseData.complianceAssessment || '',
          contentLength: responseData.contentLength || documentContent.length
        });
      } else {
        setError('Failed to analyze document: Invalid response format');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to analyze document');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async (text, type) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied({ ...copied, [type]: true });
      setTimeout(() => setCopied({ ...copied, [type]: false }), 2000);
    } catch (error) {
      console.error('Failed to copy text:', error);
    }
  };

  const downloadReport = (content, filename) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getRiskLevel = (analysis) => {
    if (!analysis || typeof analysis !== 'string') {
      return { level: 'Unknown', color: 'text-gray-600', bgColor: 'bg-gray-100' };
    }
    
    const analysisLower = analysis.toLowerCase();
    if (analysisLower.includes('high risk') || analysisLower.includes('critical')) {
      return { level: 'High', color: 'text-red-600', bgColor: 'bg-red-100' };
    } else if (analysisLower.includes('medium risk') || analysisLower.includes('moderate')) {
      return { level: 'Medium', color: 'text-yellow-600', bgColor: 'bg-yellow-100' };
    } else {
      return { level: 'Low', color: 'text-green-600', bgColor: 'bg-green-100' };
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-secondary-900 mb-2">
          Document Analysis
        </h1>
        <p className="text-secondary-600">
          Get comprehensive analysis and identify potential issues in your business documents
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <div className="card">
          <h2 className="text-xl font-bold text-secondary-900 mb-6">
            Document Content
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center space-x-2">
                <AlertCircle className="h-5 w-5" />
                <span>{error}</span>
              </div>
            )}

            {/* Analysis Type Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="analysisType" className="block text-sm font-medium text-secondary-700 mb-2">
                  Analysis Type
                </label>
                <select
                  id="analysisType"
                  value={analysisType}
                  onChange={(e) => setAnalysisType(e.target.value)}
                  className="input-field"
                >
                  <option value="basic">Basic Analysis</option>
                  <option value="comprehensive">Comprehensive Analysis</option>
                  <option value="risk">Risk Analysis</option>
                  <option value="compliance">Compliance Assessment</option>
                </select>
              </div>
              

            </div>

            <div>
              <label htmlFor="documentContent" className="block text-sm font-medium text-secondary-700 mb-2">
                Paste your document content here
              </label>
              <textarea
                id="documentContent"
                rows={12}
                value={documentContent}
                onChange={(e) => setDocumentContent(e.target.value)}
                className="input-field resize-none"
                placeholder="Paste your legal document content here for analysis..."
              />
              <p className="text-xs text-secondary-500 mt-1">
                {documentContent.length} characters
              </p>
            </div>

            <button
              type="submit"
              disabled={loading || !documentContent.trim()}
              className="btn-primary w-full flex justify-center py-3"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                <>
                  <Search className="h-5 w-5 mr-2" />
                  Analyze Document
                </>
              )}
            </button>
          </form>
        </div>

        {/* Analysis Results */}
        <div className="space-y-6">
          {analysis ? (
            <>
              {/* Overall Analysis */}
              {analysis.analysis && (
                <div className="card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-secondary-900">
                      Document Analysis
                    </h3>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => copyToClipboard(analysis.analysis, 'analysis')}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        {copied.analysis ? (
                          <CheckCircle className="h-4 w-4" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                        <span>{copied.analysis ? 'Copied!' : 'Copy'}</span>
                      </button>
                      <button
                        onClick={() => downloadReport(analysis.analysis, 'document_analysis.txt')}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        <Download className="h-4 w-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>

                  <div className="bg-secondary-50 border border-secondary-200 rounded-lg p-4">
                    <pre className="whitespace-pre-wrap text-sm text-secondary-800">
                      {analysis.analysis}
                    </pre>
                  </div>
                </div>
              )}

              {/* Issues Highlighted */}
              {analysis.issues && (
                <div className="card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-secondary-900">
                      Issues Highlighted
                    </h3>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => copyToClipboard(analysis.issues, 'issues')}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        {copied.issues ? (
                          <CheckCircle className="h-4 w-4" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                        <span>{copied.issues ? 'Copied!' : 'Copy'}</span>
                      </button>
                      <button
                        onClick={() => downloadReport(analysis.issues, 'document_issues.txt')}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        <Download className="h-4 w-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>

                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <pre className="whitespace-pre-wrap text-sm text-red-800">
                      {analysis.issues}
                    </pre>
                  </div>
                </div>
              )}

              {/* Risk Analysis */}
              {analysis.riskAnalysis && (
                <div className="card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-secondary-900">
                      Risk Analysis
                    </h3>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => copyToClipboard(analysis.riskAnalysis, 'risk')}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        {copied.risk ? (
                          <CheckCircle className="h-4 w-4" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                        <span>{copied.risk ? 'Copied!' : 'Copy'}</span>
                      </button>
                      <button
                        onClick={() => downloadReport(analysis.riskAnalysis, 'risk_analysis.txt')}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        <Download className="h-4 w-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>

                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <pre className="whitespace-pre-wrap text-sm text-orange-800">
                      {analysis.riskAnalysis}
                    </pre>
                  </div>
                </div>
              )}

              {/* Compliance Assessment */}
              {analysis.complianceAssessment && (
                <div className="card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-secondary-900">
                      Compliance Assessment
                    </h3>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => copyToClipboard(analysis.complianceAssessment, 'compliance')}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        {copied.compliance ? (
                          <CheckCircle className="h-4 w-4" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                        <span>{copied.compliance ? 'Copied!' : 'Copy'}</span>
                      </button>
                      <button
                        onClick={() => downloadReport(analysis.complianceAssessment, 'compliance_assessment.txt')}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        <Download className="h-4 w-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <pre className="whitespace-pre-wrap text-sm text-green-800">
                      {analysis.complianceAssessment}
                    </pre>
                  </div>
                </div>
              )}

              {/* Risk Assessment */}
              <div className="card">
                <h3 className="text-lg font-semibold text-secondary-900 mb-4">
                  Risk Assessment
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-secondary-50 rounded-lg">
                    <div className="text-2xl font-bold text-secondary-900">
                      {analysis?.contentLength || 0}
                    </div>
                    <div className="text-sm text-secondary-600">Characters</div>
                  </div>
                  <div className="text-center p-4 bg-secondary-50 rounded-lg">
                    <div className={`text-2xl font-bold ${getRiskLevel(analysis?.analysis).color}`}>
                      {getRiskLevel(analysis?.analysis).level}
                    </div>
                    <div className="text-sm text-secondary-600">Risk Level</div>
                  </div>
                  <div className="text-center p-4 bg-secondary-50 rounded-lg">
                    <div className="text-2xl font-bold text-secondary-900">
                      {analysis?.issues ? analysis.issues.split('ISSUE').length - 1 : 0}
                    </div>
                    <div className="text-sm text-secondary-600">Issues Found</div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="card">
              <div className="text-center py-12">
                <FileText className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-secondary-900 mb-2">
                  No Analysis Yet
                </h3>
                <p className="text-secondary-600">
                  Paste your document content and click "Analyze Document" to get started
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Information */}
      <div className="mt-8 card">
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">
          What Our Analysis Covers
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-secondary-600">
          <div>
            <h4 className="font-medium text-secondary-900 mb-2">Analysis Includes:</h4>
            <ul className="space-y-1">
              <li>• Overall legal soundness assessment</li>
              <li>• Key terms and conditions review</li>
              <li>• Potential risks and concerns</li>
              <li>• Missing important clauses</li>
              <li>• Recommendations for improvement</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-secondary-900 mb-2">Issues Identified:</h4>
            <ul className="space-y-1">
              <li>• Ambiguous or unclear language</li>
              <li>• Missing essential legal clauses</li>
              <li>• Unfair or one-sided terms</li>
              <li>• Compliance and regulatory issues</li>
              <li>• Potential legal conflicts</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentAnalyzer;
