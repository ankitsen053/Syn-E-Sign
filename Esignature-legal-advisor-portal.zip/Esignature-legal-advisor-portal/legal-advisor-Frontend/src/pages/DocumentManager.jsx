import { useState, useEffect } from 'react';
import { documentAPI } from '../services/api';
import { FileText, Edit, Trash2, Eye, Download, Save, X, AlertCircle, CheckCircle, Search, Filter, RefreshCw } from 'lucide-react';
import ConfirmationDialog from '../components/ConfirmationDialog';
import EnhancedDeleteDialog from '../components/EnhancedDeleteDialog';

const DocumentManager = () => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState('');
  const [editedTitle, setEditedTitle] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [documentToDelete, setDocumentToDelete] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [selectedDocuments, setSelectedDocuments] = useState(new Set());
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [showBulkDeleteDialog, setShowBulkDeleteDialog] = useState(false);

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      setLoading(true);
      const response = await documentAPI.getUserDocuments();
      if (response.data.success) {
        setDocuments(response.data.documents);
      } else {
        setError('Failed to load documents');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  const viewDocument = (document) => {
    setSelectedDocument(document);
    setIsEditing(false);
  };

  const editDocument = (document) => {
    setSelectedDocument(document);
    setEditedContent(document.content);
    setEditedTitle(document.title);
    setIsEditing(true);
  };

  const saveDocument = async () => {
    if (!selectedDocument) return;

    setSaving(true);
    setError('');

    try {
      const documentData = {
        title: editedTitle,
        content: editedContent,
        type: selectedDocument.type,
        partyA: selectedDocument.partyA,
        partyB: selectedDocument.partyB,
        terms: selectedDocument.terms
      };

      const response = await documentAPI.updateDocument(selectedDocument.id, documentData);

      if (response.data.success) {
        // Update the document in the list
        setDocuments(documents.map(doc => 
          doc.id === selectedDocument.id ? response.data.document : doc
        ));
        setSelectedDocument(response.data.document);
        setIsEditing(false);
        setError('');
      } else {
        setError('Failed to save document');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to save document');
    } finally {
      setSaving(false);
    }
  };

  const cancelEditing = () => {
    setIsEditing(false);
    setEditedContent(selectedDocument.content);
    setEditedTitle(selectedDocument.title);
  };

  const handleDeleteClick = (documentId, documentTitle) => {
    setDocumentToDelete({ id: documentId, title: documentTitle });
    setShowDeleteDialog(true);
  };

  const deleteDocument = async () => {
    if (!documentToDelete) return;

    setDeleting(true);
    setError('');

    try {
      const response = await documentAPI.deleteDocument(documentToDelete.id);

      if (response.data.success) {
        // Reload documents to ensure consistency
        await loadDocuments();
        if (selectedDocument && selectedDocument.id === documentToDelete.id) {
          setSelectedDocument(null);
          setIsEditing(false);
        }
        setSuccess(`Document "${documentToDelete.title}" deleted successfully`);
        setError('');
        // Clear success message after 3 seconds
        setTimeout(() => setSuccess(''), 3000);
      } else {
        setError('Failed to delete document');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to delete document');
    } finally {
      setDeleting(false);
      setShowDeleteDialog(false);
      setDocumentToDelete(null);
    }
  };

  const downloadDocument = async (doc) => {
    try {
      const response = await documentAPI.downloadDocument(doc.id);
      
      // Create blob from response
      const blob = new Blob([response.data], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      
      // Create download link
      const a = document.createElement('a');
      a.href = url;
      a.download = `${doc.title.replace(/\s+/g, '_')}_v${doc.version}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
      // Fallback to client-side download
      const blob = new Blob([doc.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${doc.title.replace(/\s+/g, '_')}_v${doc.version}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Filter and sort documents
  const filteredDocuments = documents
    .filter(doc => {
      const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           doc.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           doc.type.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = selectedType === 'all' || doc.type === selectedType;
      return matchesSearch && matchesType;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt) - new Date(a.createdAt);
        case 'oldest':
          return new Date(a.createdAt) - new Date(b.createdAt);
        case 'title':
          return a.title.localeCompare(b.title);
        case 'type':
          return a.type.localeCompare(b.type);
        default:
          return 0;
      }
    });

  // Get unique document types for filter
  const documentTypes = ['all', ...new Set(documents.map(doc => doc.type))];

  // Bulk selection handlers
  const toggleSelectMode = () => {
    setIsSelectMode(!isSelectMode);
    setSelectedDocuments(new Set());
  };

  const toggleDocumentSelection = (documentId) => {
    const newSelected = new Set(selectedDocuments);
    if (newSelected.has(documentId)) {
      newSelected.delete(documentId);
    } else {
      newSelected.add(documentId);
    }
    setSelectedDocuments(newSelected);
  };

  const selectAllVisible = () => {
    setSelectedDocuments(new Set(filteredDocuments.map(doc => doc.id)));
  };

  const clearSelection = () => {
    setSelectedDocuments(new Set());
  };

  const bulkDelete = async () => {
    if (selectedDocuments.size === 0) return;
    setShowBulkDeleteDialog(true);
  };

  const executeBulkDelete = async () => {
    setDeleting(true);
    setError('');

    try {
      const documentIds = Array.from(selectedDocuments);
      const response = await documentAPI.deleteBulkDocuments(documentIds);

      if (response.data.success) {
        await loadDocuments();
        setSelectedDocuments(new Set());
        setIsSelectMode(false);
        setShowBulkDeleteDialog(false);
        if (selectedDocument && selectedDocuments.has(selectedDocument.id)) {
          setSelectedDocument(null);
          setIsEditing(false);
        }
        setSuccess(`${documentIds.length} documents deleted successfully`);
        setTimeout(() => setSuccess(''), 3000);
      } else {
        setError('Failed to delete documents');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to delete documents');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-secondary-900 mb-2">
          Document Manager
        </h1>
        <p className="text-secondary-600">
          View, edit, and manage your saved legal documents
        </p>
      </div>

      {/* Search and Filter Controls */}
      <div className="mb-6 card p-4">
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-3 flex-1">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search documents..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent w-full sm:w-64"
              />
            </div>

            {/* Type Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400 h-4 w-4" />
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="pl-10 pr-8 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent appearance-none bg-white"
              >
                {documentTypes.map(type => (
                  <option key={type} value={type}>
                    {type === 'all' ? 'All Types' : type}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="title">By Title</option>
              <option value="type">By Type</option>
            </select>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <button
              onClick={toggleSelectMode}
              className={`btn-secondary flex items-center space-x-2 ${isSelectMode ? 'bg-primary-100 border-primary-300' : ''}`}
            >
              <CheckCircle className="h-4 w-4" />
              <span>{isSelectMode ? 'Cancel Select' : 'Select Multiple'}</span>
            </button>
            
            <button
              onClick={loadDocuments}
              disabled={loading}
              className="btn-secondary flex items-center space-x-2"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>
        </div>

        {/* Results Count and Bulk Actions */}
        <div className="mt-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div className="text-sm text-secondary-600">
            Showing {filteredDocuments.length} of {documents.length} documents
            {isSelectMode && ` (${selectedDocuments.size} selected)`}
          </div>
          
          {isSelectMode && (
            <div className="flex gap-2">
              <button
                onClick={selectAllVisible}
                className="text-sm text-primary-600 hover:text-primary-700"
              >
                Select All
              </button>
              <button
                onClick={clearSelection}
                className="text-sm text-secondary-600 hover:text-secondary-700"
              >
                Clear
              </button>
              {selectedDocuments.size > 0 && (
                <button
                  onClick={bulkDelete}
                  disabled={deleting}
                  className="text-sm text-red-600 hover:text-red-700"
                >
                  Delete Selected ({selectedDocuments.size})
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <AlertCircle className="h-5 w-5" />
            <span>{error}</span>
          </div>
          <button
            onClick={() => setError('')}
            className="text-red-400 hover:text-red-600"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <CheckCircle className="h-5 w-5" />
            <span>{success}</span>
          </div>
          <button
            onClick={() => setSuccess('')}
            className="text-green-400 hover:text-green-600"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Document List */}
        <div className="lg:col-span-1">
          <div className="card">
            <h2 className="text-xl font-bold text-secondary-900 mb-6">
              Your Documents ({filteredDocuments.length})
            </h2>

            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
              </div>
            ) : filteredDocuments.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                <p className="text-secondary-600">No documents found</p>
                <p className="text-sm text-secondary-500 mt-2">
                  {documents.length === 0 ? 'Generate and save documents to see them here' : 'No documents match your search criteria.'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredDocuments.map((doc) => (
                  <div
                    key={doc.id}
                    className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                      selectedDocument?.id === doc.id
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-secondary-200 hover:border-secondary-300'
                    }`}
                    onClick={(e) => {
                      if (isSelectMode) {
                        e.preventDefault();
                        toggleDocumentSelection(doc.id);
                      } else {
                        viewDocument(doc);
                      }
                    }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3 flex-1 min-w-0">
                        {isSelectMode && (
                          <input
                            type="checkbox"
                            checked={selectedDocuments.has(doc.id)}
                            onChange={() => toggleDocumentSelection(doc.id)}
                            onClick={(e) => e.stopPropagation()}
                            className="mt-1 h-4 w-4 text-primary-600 focus:ring-primary-500 border-secondary-300 rounded"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-secondary-900 truncate">
                          {doc.title}
                        </h3>
                        <p className="text-sm text-secondary-600 mt-1">
                          {doc.type}
                        </p>
                        <p className="text-xs text-secondary-500 mt-1">
                          {formatDate(doc.createdAt)}
                          {doc.isEdited && (
                            <span className="ml-2 text-primary-600">
                              • Edited (v{doc.version})
                            </span>
                          )}
                        </p>
                        </div>
                      </div>
                      {!isSelectMode && (
                        <div className="flex space-x-1 ml-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            editDocument(doc);
                          }}
                          className="p-1 text-secondary-600 hover:text-primary-600"
                          title="Edit"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            downloadDocument(doc);
                          }}
                          className="p-1 text-secondary-600 hover:text-primary-600"
                          title="Download"
                        >
                          <Download className="h-4 w-4" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteClick(doc.id, doc.title);
                          }}
                          className="p-1 text-secondary-600 hover:text-red-600"
                          title="Delete"
                          disabled={deleting}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Document Viewer/Editor */}
        <div className="lg:col-span-2">
          <div className="card">
            {selectedDocument ? (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-secondary-900">
                    {isEditing ? 'Edit Document' : 'View Document'}
                  </h2>
                  {!isEditing && (
                    <div className="flex space-x-2">
                      <button
                        onClick={() => editDocument(selectedDocument)}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        <Edit className="h-4 w-4" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => downloadDocument(selectedDocument)}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        <Download className="h-4 w-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  )}
                </div>

                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        Document Title
                      </label>
                      <input
                        type="text"
                        value={editedTitle}
                        onChange={(e) => setEditedTitle(e.target.value)}
                        className="input-field"
                        placeholder="Enter document title"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        Document Content
                      </label>
                      <textarea
                        value={editedContent}
                        onChange={(e) => setEditedContent(e.target.value)}
                        className="input-field resize-none h-96 font-mono text-sm"
                        placeholder="Edit document content..."
                      />
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={saveDocument}
                        disabled={saving}
                        className="btn-primary flex items-center space-x-1"
                      >
                        {saving ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        ) : (
                          <Save className="h-4 w-4" />
                        )}
                        <span>{saving ? 'Saving...' : 'Save Changes'}</span>
                      </button>
                      <button
                        onClick={cancelEditing}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        <X className="h-4 w-4" />
                        <span>Cancel</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="bg-secondary-50 border border-secondary-200 rounded-lg p-4">
                      <div className="mb-4">
                        <h3 className="font-semibold text-secondary-900">{selectedDocument.title}</h3>
                        <p className="text-sm text-secondary-600 mt-1">
                          Type: {selectedDocument.type} | 
                          Parties: {selectedDocument.partyA} & {selectedDocument.partyB} |
                          Version: {selectedDocument.version}
                        </p>
                        <p className="text-xs text-secondary-500 mt-1">
                          Created: {formatDate(selectedDocument.createdAt)}
                          {selectedDocument.isEdited && (
                            <span className="ml-2">
                              • Last updated: {formatDate(selectedDocument.updatedAt)}
                            </span>
                          )}
                        </p>
                      </div>
                      <pre className="whitespace-pre-wrap text-sm text-secondary-800 font-mono bg-white p-4 rounded border">
                        {selectedDocument.content}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText className="h-16 w-16 text-secondary-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-secondary-900 mb-2">
                  No Document Selected
                </h3>
                <p className="text-secondary-600">
                  Select a document from the list to view or edit it
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Enhanced Delete Dialog */}
      <EnhancedDeleteDialog
        isOpen={showDeleteDialog}
        onClose={() => {
          setShowDeleteDialog(false);
          setDocumentToDelete(null);
        }}
        onConfirm={deleteDocument}
        documentId={documentToDelete?.id}
        documentTitle={documentToDelete?.title}
        type="single"
      />

      {/* Bulk Delete Dialog */}
      <EnhancedDeleteDialog
        isOpen={showBulkDeleteDialog}
        onClose={() => {
          setShowBulkDeleteDialog(false);
        }}
        onConfirm={executeBulkDelete}
        type="bulk"
      />
    </div>
  );
};

export default DocumentManager;
