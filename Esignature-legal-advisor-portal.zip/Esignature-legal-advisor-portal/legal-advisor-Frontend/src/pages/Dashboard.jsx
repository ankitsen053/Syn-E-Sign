import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { 
  FileText, 
  Search, 
  User, 
  TrendingUp, 
  Clock, 
  CheckCircle,
  AlertCircle,
  Scale,
  FolderOpen,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { Card, Row, Col, Statistic, Progress, Tag, Button, Avatar, List, Typography } from 'antd';
import { aiAPI } from '../services/api';

const { Title, Text, Paragraph } = Typography;

const Dashboard = () => {
  const [aiStatus, setAiStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    const checkAIStatus = async () => {
      try {
        const response = await aiAPI.getStatus();
        setAiStatus(response.data);
      } catch (error) {
        console.error('Failed to check AI status:', error);
      } finally {
        setLoading(false);
      }
    };

    checkAIStatus();
  }, []);

  const features = [
    {
      title: 'Generate Legal Documents',
      description: 'Create professional legal agreements and contracts with AI assistance and digital signatures',
      icon: FileText,
      href: '/generate',
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600'
    },
    {
      title: 'My Documents',
      description: 'View, edit, and manage your saved legal documents',
      icon: FolderOpen,
      href: '/documents',
      color: 'from-indigo-500 to-indigo-600',
      bgColor: 'bg-indigo-50',
      iconColor: 'text-indigo-600'
    },
    {
      title: 'Analyze Documents',
      description: 'Get comprehensive analysis and identify potential legal issues',
      icon: Search,
      href: '/analyze',
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50',
      iconColor: 'text-green-600'
    },
  ];

  const stats = [
    {
      title: 'Documents Generated',
      value: 12,
      icon: FileText,
      color: '#3B82F6',
      bgColor: '#EFF6FF',
      trend: '+15%',
      trendUp: true
    },
    {
      title: 'Documents Analyzed',
      value: 8,
      icon: Search,
      color: '#10B981',
      bgColor: '#ECFDF5',
      trend: '+8%',
      trendUp: true
    },
    {
      title: 'Active Sessions',
      value: 3,
      icon: Clock,
      color: '#F59E0B',
      bgColor: '#FFFBEB',
      trend: '+2',
      trendUp: true
    },
    {
      title: 'Verification Status',
      value: 'Verified',
      icon: CheckCircle,
      color: '#10B981',
      bgColor: '#ECFDF5',
      trend: 'Active',
      trendUp: true
    }
  ];

  const recentActivities = [
    {
      title: 'Employment Agreement Generated',
      description: 'Created a new employment contract for TechCorp Inc.',
      time: '2 hours ago',
      type: 'generated'
    },
    {
      title: 'NDA Document Analyzed',
      description: 'Completed risk analysis for confidential agreement',
      time: '4 hours ago',
      type: 'analyzed'
    },
    {
      title: 'Contract Signed',
      description: 'Digital signature completed for service agreement',
      time: '1 day ago',
      type: 'signed'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Header */}
          <motion.div variants={itemVariants} className="mb-8">
            <div className="flex items-center space-x-3 mb-4">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="h-8 w-8 text-yellow-500" />
              </motion.div>
              <div>
                <Title level={2} className="!mb-1">
                  Welcome back, {user?.fullName || user?.username || 'User'}! 👋
                </Title>
                <Text type="secondary" className="text-lg">
                  Your AI-powered legal document assistant is ready to help you
                </Text>
              </div>
            </div>
          </motion.div>

          {/* AI Status */}
          {!loading && aiStatus && (
            <motion.div variants={itemVariants} className="mb-8">
              <Card 
                className={`${aiStatus.features?.geminiIntegration ? 'border-green-200' : 'border-yellow-200'}`}
                style={{ 
                  background: aiStatus.features?.geminiIntegration ? 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)' : 'linear-gradient(135deg, #fefce8 0%, #fef3c7 100%)'
                }}
              >
                <div className="flex items-center space-x-4">
                  {aiStatus.features?.geminiIntegration ? (
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  ) : (
                    <AlertCircle className="h-8 w-8 text-yellow-600" />
                  )}
                  <div>
                    <Title level={4} className="!mb-1">
                      AI Service Status: {aiStatus.status}
                    </Title>
                    <Text type="secondary">
                      {aiStatus.features?.geminiIntegration 
                        ? 'Full AI integration is active' 
                        : 'Using mock responses (Gemini API not configured)'}
                    </Text>
                  </div>
                </div>
              </Card>
            </motion.div>
          )}

          {/* Stats */}
          <motion.div variants={itemVariants} className="mb-8">
            <Row gutter={[16, 16]}>
              {stats.map((stat, index) => (
                <Col xs={24} sm={12} lg={6} key={index}>
                  <motion.div
                    whileHover={{ y: -5, scale: 1.02 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Card className="h-full shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between">
                        <div>
                          <Statistic
                            title={stat.title}
                            value={stat.value}
                            valueStyle={{ color: stat.color, fontSize: '24px', fontWeight: 'bold' }}
                          />
                          <div className="flex items-center space-x-2 mt-2">
                            <Tag color={stat.trendUp ? 'green' : 'red'} className="!text-xs">
                              {stat.trend}
                            </Tag>
                          </div>
                        </div>
                        <div 
                          className="p-3 rounded-lg"
                          style={{ backgroundColor: stat.bgColor }}
                        >
                          <stat.icon className="h-8 w-8" style={{ color: stat.color }} />
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                </Col>
              ))}
            </Row>
          </motion.div>

          {/* Features */}
          <motion.div variants={itemVariants} className="mb-8">
            <Title level={3} className="mb-6">Quick Actions</Title>
            <Row gutter={[16, 16]}>
              {features.map((feature, index) => (
                <Col xs={24} md={8} key={index}>
                  <motion.div
                    whileHover={{ y: -8, scale: 1.02 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Link to={feature.href}>
                      <Card 
                        className="h-full cursor-pointer shadow-sm hover:shadow-lg transition-all duration-300"
                        bodyStyle={{ padding: '24px' }}
                      >
                        <div className={`w-16 h-16 rounded-xl bg-gradient-to-r ${feature.color} flex items-center justify-center mb-6`}>
                          <feature.icon className="h-8 w-8 text-white" />
                        </div>
                        <Title level={4} className="!mb-3">
                          {feature.title}
                        </Title>
                        <Paragraph type="secondary" className="!mb-4">
                          {feature.description}
                        </Paragraph>
                        <div className="flex items-center text-blue-600 font-medium">
                          Get Started
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </div>
                      </Card>
                    </Link>
                  </motion.div>
                </Col>
              ))}
            </Row>
          </motion.div>

          {/* Recent Activities */}
          <motion.div variants={itemVariants}>
            <Row gutter={[16, 16]}>
              <Col xs={24} lg={16}>
                <Card title="Recent Activities" className="shadow-sm">
                  <List
                    dataSource={recentActivities}
                    renderItem={(item, index) => (
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <List.Item className="!px-0 !py-4">
                          <List.Item.Meta
                            avatar={
                              <Avatar 
                                size={40}
                                style={{ 
                                  backgroundColor: item.type === 'generated' ? '#3B82F6' : 
                                                 item.type === 'analyzed' ? '#10B981' : '#8B5CF6'
                                }}
                              >
                                {item.type === 'generated' ? <FileText className="h-5 w-5" /> :
                                 item.type === 'analyzed' ? <Search className="h-5 w-5" /> :
                                 <CheckCircle className="h-5 w-5" />}
                              </Avatar>
                            }
                            title={
                              <div className="flex items-center justify-between">
                                <Text strong>{item.title}</Text>
                                <Text type="secondary" className="text-sm">{item.time}</Text>
                              </div>
                            }
                            description={item.description}
                          />
                        </List.Item>
                      </motion.div>
                    )}
                  />
                </Card>
              </Col>
              <Col xs={24} lg={8}>
                <Card title="Progress Overview" className="shadow-sm">
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <Text>Document Generation</Text>
                        <Text strong>75%</Text>
                      </div>
                      <Progress percent={75} strokeColor="#3B82F6" />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <Text>Analysis Completion</Text>
                        <Text strong>60%</Text>
                      </div>
                      <Progress percent={60} strokeColor="#10B981" />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <Text>Verification Status</Text>
                        <Text strong>100%</Text>
                      </div>
                      <Progress percent={100} strokeColor="#8B5CF6" />
                    </div>
                  </div>
                </Card>
              </Col>
            </Row>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
