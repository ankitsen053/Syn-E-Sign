import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Scale, CreditCard, Upload, Video, ArrowLeft, RefreshCw } from 'lucide-react';
import VerificationStatus from '../components/VerificationStatus';
import VerificationRefreshStatus from '../components/VerificationRefreshStatus';
import VideoVerification from '../components/VideoVerification';
import { verificationAPI } from '../services/api';

const Verification = () => {
  const [activeTab, setActiveTab] = useState('status');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  const navigate = useNavigate();

  // PAN Verification Form
  const [panForm, setPanForm] = useState({
    panNumber: '',
    documentUrl: ''
  });

  // Aadhar Verification Form
  const [aadharForm, setAadharForm] = useState({
    aadharNumber: '',
    documentUrl: ''
  });

  // Video Verification Form
  const [videoForm, setVideoForm] = useState({
    videoUrl: '',
    notes: ''
  });

  const handleVideoComplete = () => {
    setActiveTab('status');
    setSuccess('Video verification completed successfully!');
  };

  const handlePanSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await verificationAPI.submitPan(panForm);
      setSuccess(response.data.message);
      setPanForm({ panNumber: '', documentUrl: '' });
      setActiveTab('status');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit PAN verification');
    } finally {
      setLoading(false);
    }
  };

  const handleAadharSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await verificationAPI.submitAadhar(aadharForm);
      setSuccess(response.data.message);
      setAadharForm({ aadharNumber: '', documentUrl: '' });
      setActiveTab('status');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit Aadhar verification');
    } finally {
      setLoading(false);
    }
  };



  const tabs = [
    { id: 'status', label: 'Verification Status', icon: Scale },
    { id: 'refresh', label: 'Refresh Status', icon: RefreshCw },
    { id: 'pan', label: 'PAN Verification', icon: CreditCard },
    { id: 'aadhar', label: 'Aadhar Verification', icon: Upload },
    { id: 'video', label: 'Video Verification', icon: Video }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-secondary-600 hover:text-secondary-800 mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </button>
          <h1 className="text-3xl font-bold text-secondary-900">Identity Verification</h1>
          <p className="text-secondary-600 mt-2">
            Complete your verification to access all features
          </p>
        </div>

        {/* Success/Error Messages */}
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
            {success}
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6" aria-label="Tabs">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                      activeTab === tab.id
                        ? 'border-primary-500 text-primary-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {activeTab === 'status' && <VerificationStatus />}

            {activeTab === 'refresh' && (
              <VerificationRefreshStatus />
            )}

            {activeTab === 'pan' && (
              <div className="max-w-md">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">PAN Verification</h3>
                <form onSubmit={handlePanSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      PAN Number
                    </label>
                    <input
                      type="text"
                      value={panForm.panNumber}
                      onChange={(e) => setPanForm({ ...panForm, panNumber: e.target.value.toUpperCase() })}
                      className="input-field"
                      placeholder="ABCDE1234F"
                      pattern="^[A-Z]{5}[0-9]{4}[A-Z]{1}$"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Format: ABCDE1234F (5 letters + 4 digits + 1 letter)
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Document URL
                    </label>
                    <input
                      type="url"
                      value={panForm.documentUrl}
                      onChange={(e) => setPanForm({ ...panForm, documentUrl: e.target.value })}
                      className="input-field"
                      placeholder="https://example.com/pan-document.pdf"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Upload your PAN card image/document to a cloud service and provide the URL
                    </p>
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary w-full"
                  >
                    {loading ? 'Submitting...' : 'Submit PAN Verification'}
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'aadhar' && (
              <div className="max-w-md">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Aadhar Verification</h3>
                <form onSubmit={handleAadharSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Aadhar Number
                    </label>
                    <input
                      type="text"
                      value={aadharForm.aadharNumber}
                      onChange={(e) => setAadharForm({ ...aadharForm, aadharNumber: e.target.value.replace(/\D/g, '') })}
                      className="input-field"
                      placeholder="123456789012"
                      pattern="^[0-9]{12}$"
                      maxLength="12"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      12-digit Aadhar number
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Document URL
                    </label>
                    <input
                      type="url"
                      value={aadharForm.documentUrl}
                      onChange={(e) => setAadharForm({ ...aadharForm, documentUrl: e.target.value })}
                      className="input-field"
                      placeholder="https://example.com/aadhar-document.pdf"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Upload your Aadhar card image/document to a cloud service and provide the URL
                    </p>
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary w-full"
                  >
                    {loading ? 'Submitting...' : 'Submit Aadhar Verification'}
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'video' && (
              <VideoVerification onComplete={handleVideoComplete} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Verification;
