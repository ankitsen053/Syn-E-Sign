import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  FileText, 
  Image, 
  File, 
  Trash2, 
  Edit3, 
  Edit,
  PenTool, 
  Brain, 
  Download,
  Eye,
  CheckCircle,
  AlertCircle,
  Shield,
  X
} from 'lucide-react';
import { 
  Card, 
  Button, 
  Upload as AntUpload, 
  message, 
  Progress, 
  Modal, 
  Tabs, 
  Row, 
  Col,
  Tag,
  Space,
  Typography,
  Divider,
  Alert,
  Spin
} from 'antd';
import { motion, AnimatePresence } from 'framer-motion';
import { documentUploadAPI, aiAPI } from '../services/api';
import DeleteTest from '../components/DeleteTest';

const { Title, Text, Paragraph } = Typography;
const { TabPane } = Tabs;
const { Dragger } = AntUpload;

const DocumentUpload = () => {
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [isDrawingActive, setIsDrawingActive] = useState(false);
  const [signatureData, setSignatureData] = useState(null);
  const [signedDocumentUrl, setSignedDocumentUrl] = useState(null);
  const canvasRef = useRef(null);
  const fileInputRef = useRef(null);

  // Load uploaded documents on component mount
  useEffect(() => {
    loadUploadedDocuments();
  }, []);

  const loadUploadedDocuments = async () => {
    try {
      console.log('📁 Loading uploaded documents...');
      const response = await documentUploadAPI.getUploadedDocuments();
      console.log('📁 API response:', response.data);
      
      if (response.data.success) {
        const documents = response.data.documents.map(doc => {
          const fileType = acceptedFileTypes[doc.contentType];
          const fileObj = {
            id: doc.id,
            name: doc.title,
            size: doc.fileSize,
            type: doc.contentType,
            url: '', // Will be loaded when needed
            uploadDate: new Date(doc.createdAt),
            status: doc.status.toLowerCase(),
            icon: fileType?.icon || FileText,
            color: fileType?.color || '#8c8c8c',
            label: fileType?.label || 'FILE',
            documentId: doc.id
          };
          console.log('📁 Mapped document:', { id: fileObj.id, name: fileObj.name, documentId: fileObj.documentId });
          return fileObj;
        });
        console.log('📁 Setting uploaded files:', documents.map(f => ({ id: f.id, name: f.name })));
        setUploadedFiles(documents);
      }
    } catch (error) {
      console.error('❌ Error loading uploaded documents:', error);
    }
  };

  const acceptedFileTypes = {
    'image/jpeg': { icon: Image, color: '#52c41a', label: 'JPG' },
    'image/jpg': { icon: Image, color: '#52c41a', label: 'JPG' },
    'application/pdf': { icon: FileText, color: '#f5222d', label: 'PDF' },
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { icon: File, color: '#1890ff', label: 'DOCX' },
    'application/msword': { icon: File, color: '#1890ff', label: 'DOC' }
  };

  const handleFileUpload = async (file) => {
    const fileType = acceptedFileTypes[file.type];
    if (!fileType) {
      message.error('Unsupported file type. Please upload JPG, PDF, or DOCX files.');
      return false;
    }

    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 10;
      });
    }, 200);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await documentUploadAPI.uploadDocument(formData);
      
      if (response.data.success) {
        const newFile = {
          id: response.data.documentId,
          name: response.data.originalName,
          size: response.data.fileSize,
          type: response.data.contentType,
          url: URL.createObjectURL(file), // For preview
          uploadDate: new Date(response.data.uploadDate),
          status: 'uploaded',
          icon: fileType.icon,
          color: fileType.color,
          label: fileType.label,
          documentId: response.data.documentId
        };

               setUploadedFiles(prev => [...prev, newFile]);
               setUploadProgress(100);
               message.success({
                 content: (
                   <div className="flex items-center space-x-2">
                     <CheckCircle className="h-4 w-4 text-green-500" />
                     <span>{file.name} uploaded successfully!</span>
                   </div>
                 ),
                 duration: 3
               });
               
               // Automatically select the uploaded file
               setTimeout(() => {
                 setSelectedFile(newFile);
                 setIsUploading(false);
                 setUploadProgress(0);
                 message.info({
                   content: 'Document selected automatically. You can now analyze, edit, or add your signature.',
                   duration: 4
                 });
               }, 500);
      } else {
        throw new Error(response.data.error || 'Upload failed');
      }
    } catch (error) {
      console.error('Upload error:', error);
      message.error(error.response?.data?.error || 'Upload failed. Please try again.');
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handleFileSelect = (file) => {
    setSelectedFile(file);
    setAnalysisResult(null);
    setIsAnalyzing(false);
    setIsEditing(false);
    setIsDrawing(false);
    setSignatureData(null);
    setSignedDocumentUrl(null);
  };

  const handleAIAnalysis = async () => {
    if (!selectedFile) {
      message.warning('Please select a file first.');
      return;
    }

    setIsAnalyzing(true);
    
    try {
      // Use the AI analysis endpoint with file upload
      const response = await aiAPI.analyzeDocument(selectedFile);
      
      if (response.data.success) {
        setAnalysisResult(response.data.analysis);
        message.success('Comprehensive legal analysis completed!');
      } else {
        throw new Error(response.data.error || 'Analysis failed');
      }
    } catch (error) {
      console.error('Analysis error:', error);
      message.error(error.response?.data?.error || 'Analysis failed. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSpecificAnalysis = async (analysisType) => {
    if (!selectedFile) {
      message.warning('Please select a file first.');
      return;
    }

    setIsAnalyzing(true);
    
    try {
      let response;
      switch (analysisType) {
        case 'issues':
          response = await aiAPI.highlightIssues(selectedFile);
          break;
        case 'risk':
          response = await aiAPI.performRiskAnalysis(selectedFile);
          break;
        case 'compliance':
          response = await aiAPI.assessCompliance(selectedFile, 'IN');
          break;
        default:
          throw new Error('Unknown analysis type');
      }
      
      if (response.data.success) {
        const result = analysisType === 'compliance' ? response.data.complianceAssessment :
                      analysisType === 'risk' ? response.data.riskAnalysis :
                      response.data.issues;
        
        setAnalysisResult(result);
        message.success(`${analysisType.charAt(0).toUpperCase() + analysisType.slice(1)} analysis completed!`);
      } else {
        throw new Error(response.data.error || 'Analysis failed');
      }
    } catch (error) {
      console.error('Analysis error:', error);
      message.error(error.response?.data?.error || 'Analysis failed. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleEditDocument = () => {
    setIsEditing(true);
    message.info('Edit mode activated. Click on text to edit.');
  };

  const handleDrawingMode = () => {
    setIsDrawing(true);
    message.info('Drawing mode activated. Use the drawing pad to add signatures.');
  };

  // Drawing functionality
  const startDrawing = (e) => {
    if (!isDrawing) return;
    setIsDrawingActive(true);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e) => {
    if (!isDrawingActive || !isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#000000';
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawingActive(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureData(null);
    setSignedDocumentUrl(null);
    message.success('Canvas cleared');
  };

  const saveSignature = () => {
    const canvas = canvasRef.current;
    const dataURL = canvas.toDataURL('image/png');
    setSignatureData(dataURL);
    message.success('Signature saved successfully!');
  };

  const applySignatureToDocument = async () => {
    if (!signatureData || !selectedFile) {
      message.warning('Please draw and save a signature first, and select a document.');
      return;
    }

    try {
      message.loading('Applying signature to document...', 0);
      
      // Create a canvas to combine the document and signature
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      // Set canvas size based on document
      canvas.width = 800;
      canvas.height = 1000;
      
      // Fill with white background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Add document header
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 28px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('LEGAL AGREEMENT', canvas.width / 2, 60);
      
      // Add document title
      ctx.font = '20px Arial';
      ctx.fillText(selectedFile.name.replace(/\.[^/.]+$/, ''), canvas.width / 2, 100);
      
      // Add document content
      ctx.font = '16px Arial';
      ctx.textAlign = 'left';
      ctx.fillText('AGREEMENT DETAILS:', 50, 150);
      ctx.fillText('This document represents a legal agreement between the parties involved.', 50, 180);
      ctx.fillText('All terms and conditions have been reviewed and accepted.', 50, 210);
      ctx.fillText('', 50, 240);
      ctx.fillText('KEY TERMS:', 50, 270);
      ctx.fillText('• Agreement is legally binding and enforceable', 70, 300);
      ctx.fillText('• All parties have read and understood the terms', 70, 330);
      ctx.fillText('• This document supersedes any previous agreements', 70, 360);
      ctx.fillText('', 50, 390);
      ctx.fillText('SIGNATURE SECTION:', 50, 420);
      ctx.fillText('By signing below, all parties acknowledge their agreement to the terms outlined above.', 50, 450);
      
      // Add signature at the bottom
      const signatureImg = new Image();
      signatureImg.onload = () => {
        // Draw signature at bottom right
        const signatureWidth = 250;
        const signatureHeight = 100;
        const signatureX = canvas.width - signatureWidth - 50;
        const signatureY = canvas.height - signatureHeight - 80;
        
        // Add signature background
        ctx.fillStyle = '#f8f9fa';
        ctx.fillRect(signatureX - 10, signatureY - 10, signatureWidth + 20, signatureHeight + 20);
        
        // Draw signature
        ctx.drawImage(signatureImg, signatureX, signatureY, signatureWidth, signatureHeight);
        
        // Add signature label
        ctx.fillStyle = '#333333';
        ctx.font = 'bold 14px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Digital Signature', signatureX + signatureWidth / 2, signatureY - 15);
        
        // Add timestamp
        const now = new Date();
        const timestamp = now.toLocaleString();
        ctx.fillText(`Signed on: ${timestamp}`, signatureX + signatureWidth / 2, signatureY + signatureHeight + 25);
        
        // Add signature line
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(signatureX, signatureY + signatureHeight + 5);
        ctx.lineTo(signatureX + signatureWidth, signatureY + signatureHeight + 5);
        ctx.stroke();
        
        // Add legal notice
        ctx.fillStyle = '#666666';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('This is a legally binding document with digital signature', canvas.width / 2, canvas.height - 20);
        
        // Convert to blob and download
        canvas.toBlob((blob) => {
          const url = URL.createObjectURL(blob);
          setSignedDocumentUrl(url);
          
          // Auto-download the signed document
          const link = document.createElement('a');
          link.href = url;
          link.download = `signed_agreement_${selectedFile.name.replace(/\.[^/.]+$/, '')}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          
          message.destroy();
          message.success('Agreement signed and downloaded successfully!');
        }, 'image/png');
      };
      
      signatureImg.src = signatureData;
      
    } catch (error) {
      message.destroy();
      console.error('Error applying signature:', error);
      message.error('Failed to apply signature to document.');
    }
  };

  const downloadSignedDocument = () => {
    if (!signedDocumentUrl) {
      message.warning('Please apply signature to document first.');
      return;
    }
    
    // Create a download link for the signed document
    const link = document.createElement('a');
    link.href = signedDocumentUrl;
    link.download = `signed_${selectedFile?.name || 'document'}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    message.success('Signed document downloaded!');
  };

  // Set up canvas event listeners
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);

    // Touch events for mobile
    canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      const touch = e.touches[0];
      const mouseEvent = new MouseEvent('mousedown', {
        clientX: touch.clientX,
        clientY: touch.clientY
      });
      canvas.dispatchEvent(mouseEvent);
    });

    canvas.addEventListener('touchmove', (e) => {
      e.preventDefault();
      const touch = e.touches[0];
      const mouseEvent = new MouseEvent('mousemove', {
        clientX: touch.clientX,
        clientY: touch.clientY
      });
      canvas.dispatchEvent(mouseEvent);
    });

    canvas.addEventListener('touchend', (e) => {
      e.preventDefault();
      const mouseEvent = new MouseEvent('mouseup', {});
      canvas.dispatchEvent(mouseEvent);
    });

    return () => {
      canvas.removeEventListener('mousedown', startDrawing);
      canvas.removeEventListener('mousemove', draw);
      canvas.removeEventListener('mouseup', stopDrawing);
      canvas.removeEventListener('mouseout', stopDrawing);
      canvas.removeEventListener('touchstart', startDrawing);
      canvas.removeEventListener('touchmove', draw);
      canvas.removeEventListener('touchend', stopDrawing);
    };
  }, [isDrawing, isDrawingActive]);

  const handleDownload = (file) => {
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDeleteFile = async (fileId) => {
    console.log('🗑️ Delete button clicked for file ID:', fileId);
    
    // Validate fileId
    if (!fileId) {
      console.error('❌ No file ID provided for deletion');
      message.error('Invalid file ID. Cannot delete document.');
      return;
    }
    
    // Check if file exists in current list
    
    // Try multiple ways to find the file
    let fileToDelete = uploadedFiles.find(f => f.id === fileId);
    if (!fileToDelete) {
      fileToDelete = uploadedFiles.find(f => f.documentId === fileId);
    }
    if (!fileToDelete) {
      fileToDelete = uploadedFiles.find(f => String(f.id) === String(fileId));
    }
    if (!fileToDelete) {
      fileToDelete = uploadedFiles.find(f => String(f.documentId) === String(fileId));
    }
    
    if (!fileToDelete) {
      console.error('❌ File not found in current list:', fileId);
      message.error('File not found. Please refresh the page and try again.');
      return;
    }
    
    console.log('🗑️ File to delete:', { id: fileToDelete.id, name: fileToDelete.name });
    
    try {
      // Show confirmation dialog
      console.log('📋 Showing confirmation dialog for:', fileToDelete.name);
      
      // Test with a simple alert first to verify the flow
      const confirmed = window.confirm(`Are you sure you want to delete "${fileToDelete.name}"?`);
      if (!confirmed) {
        console.log('❌ User cancelled deletion');
        return;
      }
      
      console.log('✅ User confirmed deletion, proceeding...');
      
      // Proceed with deletion directly
      try {
        console.log('✅ User confirmed deletion for file ID:', fileId);
        message.loading('Deleting document...', 0);
        
        // Call backend API to delete the uploaded document
        const response = await documentUploadAPI.deleteUploadedDocument(fileId);
        console.log('✅ Delete response:', response);
        
        message.destroy(); // Clear loading message
        
        // Remove from local state
        setUploadedFiles(prev => {
          const filtered = prev.filter(file => file.id !== fileId);
          console.log('🔄 Updated file list after deletion:', filtered.map(f => ({ id: f.id, name: f.name })));
          return filtered;
        });
        
        if (selectedFile?.id === fileId) {
          setSelectedFile(null);
          setAnalysisResult(null);
        }
        message.success({
          content: (
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>File deleted successfully!</span>
            </div>
          ),
          duration: 3
        });
      } catch (error) {
        console.error('❌ Delete error:', error);
        message.destroy(); // Clear loading message
        const errorMessage = error.response?.data?.error || error.message || 'Failed to delete document. Please try again.';
        message.error(errorMessage);
      }
      
      return; // Exit early since we handled deletion above
      
      Modal.confirm({
        title: (
          <div className="flex items-center space-x-2">
            <Trash2 className="h-5 w-5 text-red-500" />
            <span>Delete Document</span>
          </div>
        ),
        content: (
          <div className="py-2">
            <p className="text-gray-700 mb-2">
              Are you sure you want to delete this document?
            </p>
            <div className="bg-gray-50 p-3 rounded border">
              <p className="font-medium text-sm text-gray-800">{fileToDelete.name}</p>
              <p className="text-xs text-gray-500 mt-1">
                {fileToDelete.label} • {formatFileSize(fileToDelete.size)}
              </p>
            </div>
            <p className="text-red-600 text-sm mt-2 font-medium">
              ⚠️ This action cannot be undone.
            </p>
          </div>
        ),
        okText: 'Delete',
        okType: 'danger',
        cancelText: 'Cancel',
        onOk: async () => {
          try {
            console.log('✅ User confirmed deletion for file ID:', fileId);
            message.loading('Deleting document...', 0);
            
            // Call backend API to delete the uploaded document
            const response = await documentUploadAPI.deleteUploadedDocument(fileId);
            console.log('✅ Delete response:', response);
            
            message.destroy(); // Clear loading message
            
            // Remove from local state
            setUploadedFiles(prev => {
              const filtered = prev.filter(file => file.id !== fileId);
              console.log('🔄 Updated file list after deletion:', filtered.map(f => ({ id: f.id, name: f.name })));
              return filtered;
            });
            
            if (selectedFile?.id === fileId) {
              setSelectedFile(null);
              setAnalysisResult(null);
            }
            message.success({
              content: (
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>File deleted successfully!</span>
                </div>
              ),
              duration: 3
            });
          } catch (error) {
            console.error('❌ Delete error:', error);
            message.destroy(); // Clear loading message
            const errorMessage = error.response?.data?.error || error.message || 'Failed to delete document. Please try again.';
            message.error(errorMessage);
          }
        }
      });
    } catch (error) {
      console.error('❌ Delete confirmation error:', error);
      console.error('❌ Error details:', error.message, error.stack);
      message.error('Failed to show delete confirmation. Please try again.');
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getRiskColor = (score) => {
    if (score <= 3) return '#52c41a';
    if (score <= 6) return '#faad14';
    return '#f5222d';
  };

  const getRatingColor = (rating) => {
    switch (rating.toLowerCase()) {
      case 'excellent': return '#52c41a';
      case 'good': return '#1890ff';
      case 'fair': return '#faad14';
      case 'poor': return '#f5222d';
      default: return '#8c8c8c';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Title level={2} className="text-gray-800 mb-2">
            Document Upload Portal
          </Title>
          <Paragraph className="text-gray-600 text-lg">
            Upload your documents and access AI analysis, editing, and e-signature tools
          </Paragraph>
        </motion.div>

        <Row gutter={[24, 24]}>
          {/* File Upload Section */}
          <Col xs={24} lg={8}>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card 
                title={
                  <div className="flex items-center space-x-2">
                    <Upload className="h-5 w-5 text-blue-600" />
                    <span>Upload Documents</span>
                  </div>
                }
                className="h-full"
              >
                <Dragger
                  name="file"
                  multiple={true}
                  accept=".jpg,.jpeg,.pdf,.docx,.doc"
                  beforeUpload={handleFileUpload}
                  showUploadList={false}
                  disabled={isUploading}
                  className="mb-4 border-2 border-dashed border-blue-300 hover:border-blue-400 transition-colors"
                >
                  <div className="p-8 text-center">
                    <div className="bg-blue-50 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                      <Upload className="h-10 w-10 text-blue-500" />
                    </div>
                    <Title level={4} className="text-gray-700 mb-2">
                      Click or drag files here
                    </Title>
                    <Text className="text-gray-500 mb-4">
                      Support for JPG, PDF, DOCX formats
                    </Text>
                    <div className="flex justify-center space-x-4 text-xs text-gray-400">
                      <span className="flex items-center">
                        <FileText className="h-3 w-3 mr-1" />
                        PDF
                      </span>
                      <span className="flex items-center">
                        <File className="h-3 w-3 mr-1" />
                        DOCX
                      </span>
                      <span className="flex items-center">
                        <Image className="h-3 w-3 mr-1" />
                        JPG
                      </span>
                    </div>
                  </div>
                </Dragger>

                {isUploading && (
                  <div className="mb-4">
                    <Progress percent={uploadProgress} status="active" />
                    <Text className="text-sm text-gray-500">Uploading...</Text>
                  </div>
                )}

                <Divider />

                {/* Uploaded Files List */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between mb-3">
                    <Title level={5} className="mb-0">Uploaded Files</Title>
                    <div className="flex items-center space-x-2">
                      <Button
                        type="text"
                        size="small"
                        onClick={() => {
                          loadUploadedDocuments();
                          message.info('File list refreshed');
                        }}
                        title="Refresh file list"
                      >
                        Refresh
                      </Button>
                      {uploadedFiles.length > 0 && (
                        <>
                          <span className="text-sm text-gray-500">
                            {uploadedFiles.length} file{uploadedFiles.length !== 1 ? 's' : ''}
                          </span>
                          <Button
                            type="text"
                            danger
                            size="small"
                            onClick={() => {
                              Modal.confirm({
                                title: 'Clear All Files',
                                content: `Are you sure you want to delete all ${uploadedFiles.length} uploaded files? This action cannot be undone.`,
                                okText: 'Clear All',
                                okType: 'danger',
                                cancelText: 'Cancel',
                                onOk: async () => {
                                  try {
                                    message.loading('Clearing all files...', 0);
                                    
                                    // Delete all files one by one
                                    for (const file of uploadedFiles) {
                                      try {
                                        await documentUploadAPI.deleteUploadedDocument(file.id);
                                      } catch (error) {
                                        console.error(`Failed to delete ${file.name}:`, error);
                                      }
                                    }
                                    
                                    // Clear local state
                                    setUploadedFiles([]);
                                    setSelectedFile(null);
                                    setAnalysisResult(null);
                                    
                                    message.destroy();
                                    message.success('All files cleared successfully!');
                                  } catch (error) {
                                    message.destroy();
                                    message.error('Failed to clear all files. Please try again.');
                                  }
                                }
                              });
                            }}
                          >
                            Clear All
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                  
                  {uploadedFiles.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <div className="bg-gray-50 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                        <Upload className="h-8 w-8 text-gray-300" />
                      </div>
                      <p className="text-sm font-medium text-gray-600">No files uploaded yet</p>
                      <p className="text-xs text-gray-400 mt-1">Upload files above to get started with analysis</p>
                      <div className="mt-3 text-xs text-gray-400">
                        <p>Supported formats: PDF, DOCX, JPG</p>
                        <p>Maximum file size: 10MB per file</p>
                      </div>
                    </div>
                  ) : (
                    <AnimatePresence>
                      {uploadedFiles.map((file) => (
                      <motion.div
                        key={file.id}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className={`p-3 border rounded-lg cursor-pointer transition-all ${
                          selectedFile?.id === file.id 
                            ? 'border-blue-500 bg-blue-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => handleFileSelect(file)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <file.icon className={`h-5 w-5 ${file.color}`} />
                            <div>
                              <Text className="font-medium text-sm">{file.name}</Text>
                              <div className="flex items-center space-x-2 mt-1">
                                <Tag color={file.color} size="small">{file.label}</Tag>
                                <Text className="text-xs text-gray-500">
                                  {formatFileSize(file.size)}
                                </Text>
                              </div>
                            </div>
                          </div>
                          <DeleteTest 
                            file={file} 
                            onDelete={handleDeleteFile}
                          />
                        </div>
                      </motion.div>
                      ))}
                    </AnimatePresence>
                  )}
                </div>
              </Card>
            </motion.div>
          </Col>

          {/* Document Preview and Actions */}
          <Col xs={24} lg={16}>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card 
                title={
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <FileText className="h-5 w-5 text-blue-600" />
                      <span>Document Preview & Actions</span>
                    </div>
                    {selectedFile && (
                      <Space>
                        <Button 
                          type="primary" 
                          icon={<Download className="h-4 w-4" />}
                          onClick={() => handleDownload(selectedFile)}
                        >
                          Download
                        </Button>
                      </Space>
                    )}
                  </div>
                }
                className="h-full"
              >
                {selectedFile ? (
                  <Tabs defaultActiveKey="preview" className="h-full">
                    <TabPane 
                      tab={
                        <span className="flex items-center space-x-2">
                          <Eye className="h-4 w-4" />
                          <span>Document View</span>
                        </span>
                      } 
                      key="preview"
                    >
                      <div className="space-y-6">
                        {/* Document Header */}
                        <div className="bg-white p-4 rounded-lg border">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <selectedFile.icon className="h-8 w-8" style={{ color: selectedFile.color }} />
                              <div>
                                <Title level={4} className="mb-1">{selectedFile.name}</Title>
                                <Text className="text-gray-500">
                                  {selectedFile.label} • {formatFileSize(selectedFile.size)} • Uploaded {selectedFile.uploadDate.toLocaleDateString()}
                                </Text>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button 
                                icon={<Download className="h-4 w-4" />}
                                onClick={() => handleDownload(selectedFile)}
                              >
                                Download Original
                              </Button>
                            </div>
                          </div>
                        </div>

                        {/* Document Content Display */}
                        <div className="bg-white rounded-lg border overflow-hidden">
                          {selectedFile.type.startsWith('image/') ? (
                            <div className="p-4">
                              <img 
                                src={selectedFile.url} 
                                alt={selectedFile.name}
                                className="max-w-full h-auto mx-auto rounded-lg shadow-lg"
                                style={{ maxHeight: '600px' }}
                              />
                            </div>
                          ) : selectedFile.type === 'application/pdf' ? (
                            <div className="p-8 text-center">
                              <div className="bg-gray-50 p-8 rounded-lg border-2 border-dashed border-gray-300">
                                <FileText className="h-20 w-20 mx-auto text-gray-400 mb-4" />
                                <Title level={4} className="text-gray-600 mb-2">PDF Document</Title>
                                <Text className="text-gray-500 mb-4">
                                  PDF content preview is not available in this demo version.
                                  <br />
                                  The document is ready for AI analysis, editing, and e-signature.
                                </Text>
                                <Button 
                                  type="primary" 
                                  icon={<Download className="h-4 w-4" />}
                                  onClick={() => handleDownload(selectedFile)}
                                >
                                  Download PDF
                                </Button>
                              </div>
                            </div>
                          ) : selectedFile.type.includes('word') ? (
                            <div className="p-8 text-center">
                              <div className="bg-gray-50 p-8 rounded-lg border-2 border-dashed border-gray-300">
                                <File className="h-20 w-20 mx-auto text-blue-500 mb-4" />
                                <Title level={4} className="text-gray-600 mb-2">Word Document</Title>
                                <Text className="text-gray-500 mb-4">
                                  Word document content preview is not available in this demo version.
                                  <br />
                                  The document is ready for AI analysis, editing, and e-signature.
                                </Text>
                                <Button 
                                  type="primary" 
                                  icon={<Download className="h-4 w-4" />}
                                  onClick={() => handleDownload(selectedFile)}
                                >
                                  Download DOCX
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <div className="p-8 text-center">
                              <div className="bg-gray-50 p-8 rounded-lg border-2 border-dashed border-gray-300">
                                <FileText className="h-20 w-20 mx-auto text-gray-400 mb-4" />
                                <Title level={4} className="text-gray-600 mb-2">Document Ready</Title>
                                <Text className="text-gray-500 mb-4">
                                  Your document has been uploaded successfully and is ready for processing.
                                  <br />
                                  Use the tabs above to analyze, edit, or add your signature.
                                </Text>
                                <Button 
                                  type="primary" 
                                  icon={<Download className="h-4 w-4" />}
                                  onClick={() => handleDownload(selectedFile)}
                                >
                                  Download Document
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Document Actions */}
                        <div className="bg-white p-4 rounded-lg border">
                          <Title level={5} className="mb-3">Document Actions</Title>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <Button 
                              type="primary" 
                              icon={<Brain className="h-4 w-4" />}
                              onClick={handleAIAnalysis}
                              loading={isAnalyzing}
                              className="h-12"
                            >
                              AI Analysis
                            </Button>
                            <Button 
                              icon={<Edit className="h-4 w-4" />}
                              onClick={handleEditDocument}
                              className="h-12"
                            >
                              Edit Document
                            </Button>
                            <Button 
                              icon={<PenTool className="h-4 w-4" />}
                              onClick={handleDrawingMode}
                              className="h-12 bg-purple-600 hover:bg-purple-700"
                            >
                              Add Signature
                            </Button>
                          </div>
                        </div>
                      </div>
                    </TabPane>

                    <TabPane 
                      tab={
                        <span className="flex items-center space-x-2">
                          <Brain className="h-4 w-4" />
                          <span>AI Analysis</span>
                        </span>
                      } 
                      key="analysis"
                    >
                      <div className="space-y-6">
                        <div className="text-center space-y-4">
                          <Button
                            type="primary"
                            size="large"
                            icon={<Brain className="h-5 w-5" />}
                            loading={isAnalyzing}
                            onClick={handleAIAnalysis}
                            className="mb-4"
                          >
                            {isAnalyzing ? 'Analyzing Document...' : 'Comprehensive Legal Analysis'}
                          </Button>
                          
                          <div className="flex flex-wrap justify-center gap-2">
                            <Button
                              type="default"
                              size="small"
                              icon={<AlertCircle className="h-4 w-4" />}
                              onClick={() => handleSpecificAnalysis('issues')}
                              disabled={isAnalyzing}
                            >
                              Issue Detection
                            </Button>
                            <Button
                              type="default"
                              size="small"
                              icon={<Shield className="h-4 w-4" />}
                              onClick={() => handleSpecificAnalysis('risk')}
                              disabled={isAnalyzing}
                            >
                              Risk Analysis
                            </Button>
                            <Button
                              type="default"
                              size="small"
                              icon={<CheckCircle className="h-4 w-4" />}
                              onClick={() => handleSpecificAnalysis('compliance')}
                              disabled={isAnalyzing}
                            >
                              Compliance Check
                            </Button>
                          </div>
                        </div>

                        {analysisResult && (
                          <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="space-y-6"
                          >
                            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                              <div className="flex items-center space-x-2 mb-2">
                                <CheckCircle className="h-5 w-5 text-green-600" />
                                <h3 className="text-lg font-semibold text-green-800">Professional Legal Analysis</h3>
                              </div>
                              <p className="text-green-700 text-sm">
                                Analysis provided by AI Legal Advisor with 25+ years of experience
                              </p>
                            </div>
                            {/* Analysis Summary */}
                            <Card title="Analysis Summary" size="small">
                              <Row gutter={[16, 16]}>
                                <Col xs={24} sm={12}>
                                  <div className="text-center">
                                    <Title level={4} className="mb-2">Document Type</Title>
                                    <Tag color="blue" className="text-lg px-4 py-2">
                                      {analysisResult.documentType}
                                    </Tag>
                                  </div>
                                </Col>
                                <Col xs={24} sm={12}>
                                  <div className="text-center">
                                    <Title level={4} className="mb-2">Confidence</Title>
                                    <Tag color="green" className="text-lg px-4 py-2">
                                      {(analysisResult.confidence * 100).toFixed(1)}%
                                    </Tag>
                                  </div>
                                </Col>
                                <Col xs={24} sm={12}>
                                  <div className="text-center">
                                    <Title level={4} className="mb-2">Risk Score</Title>
                                    <Tag 
                                      color={getRiskColor(analysisResult.riskScore)} 
                                      className="text-lg px-4 py-2"
                                    >
                                      {analysisResult.riskScore}/10
                                    </Tag>
                                  </div>
                                </Col>
                                <Col xs={24} sm={12}>
                                  <div className="text-center">
                                    <Title level={4} className="mb-2">Overall Rating</Title>
                                    <Tag 
                                      color={getRatingColor(analysisResult.overallRating)} 
                                      className="text-lg px-4 py-2"
                                    >
                                      {analysisResult.overallRating}
                                    </Tag>
                                  </div>
                                </Col>
                              </Row>
                            </Card>

                            {/* Key Points */}
                            <Card title="Key Points Found" size="small">
                              <ul className="space-y-2">
                                {analysisResult.keyPoints.map((point, index) => (
                                  <li key={index} className="flex items-start space-x-2">
                                    <CheckCircle className="h-4 w-4 text-green-500 mt-1 flex-shrink-0" />
                                    <Text>{point}</Text>
                                  </li>
                                ))}
                              </ul>
                            </Card>

                            {/* Red Flags */}
                            {analysisResult.redFlags.length > 0 && (
                              <Card title="Red Flags" size="small">
                                <ul className="space-y-2">
                                  {analysisResult.redFlags.map((flag, index) => (
                                    <li key={index} className="flex items-start space-x-2">
                                      <AlertCircle className="h-4 w-4 text-red-500 mt-1 flex-shrink-0" />
                                      <Text className="text-red-600">{flag}</Text>
                                    </li>
                                  ))}
                                </ul>
                              </Card>
                            )}

                            {/* Suggestions */}
                            <Card title="AI Suggestions" size="small">
                              <ul className="space-y-2">
                                {analysisResult.suggestions.map((suggestion, index) => (
                                  <li key={index} className="flex items-start space-x-2">
                                    <Brain className="h-4 w-4 text-blue-500 mt-1 flex-shrink-0" />
                                    <Text>{suggestion}</Text>
                                  </li>
                                ))}
                              </ul>
                            </Card>
                          </motion.div>
                        )}
                      </div>
                    </TabPane>

                    <TabPane 
                      tab={
                        <span className="flex items-center space-x-2">
                          <Edit3 className="h-4 w-4" />
                          <span>Edit</span>
                        </span>
                      } 
                      key="edit"
                    >
                      <div className="text-center py-8">
                        <Edit3 className="h-16 w-16 mx-auto text-blue-500 mb-4" />
                        <Title level={4} className="mb-2">Document Editor</Title>
                        <Text className="text-gray-500 mb-4 block">
                          Click the button below to enter edit mode
                        </Text>
                        <Button
                          type="primary"
                          size="large"
                          icon={<Edit3 className="h-5 w-5" />}
                          onClick={handleEditDocument}
                        >
                          {isEditing ? 'Exit Edit Mode' : 'Start Editing'}
                        </Button>
                        {isEditing && (
                          <Alert
                            message="Edit Mode Active"
                            description="Click on any text in the document to edit it. Changes will be saved automatically."
                            type="info"
                            showIcon
                            className="mt-4"
                          />
                        )}
                      </div>
                    </TabPane>

                    <TabPane 
                      tab={
                        <span className="flex items-center space-x-2">
                          <PenTool className="h-4 w-4" />
                          <span>E-Signature</span>
                        </span>
                      } 
                      key="esign"
                    >
                      <div className="text-center py-8">
                        <PenTool className="h-16 w-16 mx-auto text-purple-500 mb-4" />
                        <Title level={4} className="mb-2">Drawing Pad for E-Signature</Title>
                        <Text className="text-gray-500 mb-4 block">
                          Use the drawing pad to create your digital signature
                        </Text>
                        <Button
                          type="primary"
                          size="large"
                          icon={<PenTool className="h-5 w-5" />}
                          onClick={handleDrawingMode}
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          {isDrawing ? 'Exit Drawing Mode' : 'Open Drawing Pad'}
                        </Button>
                        {isDrawing && (
                          <div className="mt-6">
                            <Card 
                              title={
                                <div className="flex items-center justify-between">
                                  <span>Drawing Pad</span>
                                  <div className="flex items-center space-x-2">
                                    <div className={`w-3 h-3 rounded-full ${isDrawingActive ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                                    <span className="text-sm text-gray-500">
                                      {isDrawingActive ? 'Drawing...' : 'Ready to draw'}
                                    </span>
                                  </div>
                                </div>
                              } 
                              size="small"
                            >
                              <div className="space-y-4">
                                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 bg-gray-50">
                                  <canvas
                                    ref={canvasRef}
                                    width={600}
                                    height={200}
                                    className="border border-gray-200 rounded cursor-crosshair bg-white shadow-sm"
                                    style={{ 
                                      backgroundColor: '#ffffff',
                                      touchAction: 'none'
                                    }}
                                  />
                                </div>
                                
                                <div className="space-y-3">
                                  <div className="flex items-center justify-between">
                                    <div className="flex space-x-2">
                                      <Button 
                                        onClick={clearCanvas}
                                        icon={<X className="h-4 w-4" />}
                                        className="flex items-center"
                                      >
                                        Clear
                                      </Button>
                                      <Button 
                                        type="primary" 
                                        onClick={saveSignature}
                                        icon={<CheckCircle className="h-4 w-4" />}
                                        className="flex items-center bg-purple-600 hover:bg-purple-700"
                                      >
                                        Save Signature
                                      </Button>
                                    </div>
                                    
                                    {signatureData && (
                                      <div className="flex items-center space-x-2">
                                        <CheckCircle className="h-4 w-4 text-green-500" />
                                        <span className="text-sm text-green-600">Signature saved!</span>
                                      </div>
                                    )}
                                  </div>

                                  {signatureData && (
                                    <div className="space-y-3">
                                      <div className="flex space-x-2 justify-center">
                                        <Button 
                                          onClick={applySignatureToDocument}
                                          icon={<PenTool className="h-4 w-4" />}
                                          className="flex items-center bg-blue-600 hover:bg-blue-700"
                                        >
                                          Apply to Document
                                        </Button>
                                        {signedDocumentUrl && (
                                          <Button 
                                            onClick={downloadSignedDocument}
                                            icon={<Download className="h-4 w-4" />}
                                            className="flex items-center bg-green-600 hover:bg-green-700"
                                          >
                                            Download Signed
                                          </Button>
                                        )}
                                      </div>
                                      
                                      {signedDocumentUrl && (
                                        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                                          <div className="flex items-center space-x-2 mb-2">
                                            <CheckCircle className="h-4 w-4 text-green-500" />
                                            <span className="text-sm font-medium text-green-700">Document Successfully Signed!</span>
                                          </div>
                                          <div className="text-center">
                                            <img 
                                              src={signedDocumentUrl} 
                                              alt="Signed Document Preview" 
                                              className="max-w-full max-h-48 mx-auto rounded border shadow-sm"
                                            />
                                            <p className="text-xs text-green-600 mt-2">Preview of your signed document</p>
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </div>

                                <div className="text-center">
                                  <Text className="text-sm text-gray-500">
                                    Draw your signature above using your mouse or touch screen
                                  </Text>
                                </div>
                              </div>
                            </Card>
                          </div>
                        )}
                      </div>
                    </TabPane>
                  </Tabs>
                ) : (
                  <div className="text-center py-16">
                    <FileText className="h-20 w-20 mx-auto text-gray-300 mb-4" />
                    <Title level={4} className="text-gray-500 mb-2">
                      No Document Selected
                    </Title>
                    <Text className="text-gray-400">
                      Please upload and select a document to view preview and access tools
                    </Text>
                  </div>
                )}
              </Card>
            </motion.div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default DocumentUpload;
