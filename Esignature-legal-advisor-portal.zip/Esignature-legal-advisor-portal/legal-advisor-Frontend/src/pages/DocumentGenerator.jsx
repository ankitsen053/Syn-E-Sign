import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { aiAPI, documentAPI, signatureAPI } from '../services/api';
import { FileText, Download, Copy, CheckCircle, AlertCircle, AlertTriangle, Edit, Save, X, PenTool, Eye, Trash2, Clock, Shield, BarChart3, Plus, Search, Filter, RefreshCw, LogIn, Scale } from 'lucide-react';
import SignaturePad from '../components/SignaturePad';

const DocumentGenerator = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('generate'); // 'generate' or 'esign'
  
  // Document Generation State
  const [formData, setFormData] = useState({
    type: 'General Agreement',
    partyA: '',
    partyB: '',
    terms: ''
  });
  const [generatedDocument, setGeneratedDocument] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState('');
  const [saving, setSaving] = useState(false);
  const [savedDocumentId, setSavedDocumentId] = useState(null);
  const [documentTitle, setDocumentTitle] = useState('');

  // E-Sign State
  const [agreements, setAgreements] = useState([]);
  const [selectedAgreement, setSelectedAgreement] = useState(null);
  const [showSignaturePad, setShowSignaturePad] = useState(false);
  const [signatureImage, setSignatureImage] = useState(null);
  const [esignLoading, setEsignLoading] = useState(false);
  const [esignError, setEsignError] = useState('');
  const [esignSuccess, setEsignSuccess] = useState('');
  const [stats, setStats] = useState({});
  const [searchTerm] = useState('');
  const [filterStatus] = useState('all');
  
  // AI Analysis Modal State
  const [showAnalysisModal, setShowAnalysisModal] = useState(false);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [analysisError, setAnalysisError] = useState('');
  const [selectedAnalysisType, setSelectedAnalysisType] = useState('comprehensive');
  const [analysisResults, setAnalysisResults] = useState({});

  // Signature Verification State
  const [showSignatureModal, setShowSignatureModal] = useState(false);
  const [verificationData, setVerificationData] = useState(null);
  const [verificationLoading, setVerificationLoading] = useState(false);

  // Agreement generation form for E-Sign
  const [esignFormData, setEsignFormData] = useState({
    type: 'Service Agreement',
    partyA: '',
    partyB: '',
    terms: ''
  });

  const agreementTypes = [
    'Master Service Agreement',
    'Employment Contract',
    'Independent Contractor Agreement',
    'Non-Disclosure Agreement (NDA)',
    'Intellectual Property Assignment Agreement',
    'Software Development Agreement',
    'Consulting Services Agreement',
    'Partnership Agreement',
    'Joint Venture Agreement',
    'Licensing Agreement',
    'Distribution Agreement',
    'Franchise Agreement',
    'Real Estate Lease Agreement',
    'Equipment Lease Agreement',
    'Purchase and Sale Agreement',
    'Merger and Acquisition Agreement',
    'Shareholder Agreement',
    'Board Resolution',
    'Corporate Bylaws',
    'Terms of Service Agreement',
    'Privacy Policy Agreement'
  ];

  // Load E-Sign data when tab is active
  useEffect(() => {
    if (activeTab === 'esign') {
      // Only load data if user is authenticated
      const token = localStorage.getItem('accessToken');
      if (token) {
        loadUserAgreements();
        loadStats();
      }
    }
  }, [activeTab]);

  const loadUserAgreements = async () => {
    try {
      setEsignLoading(true);
      const response = await signatureAPI.getUserAgreements();
      if (response.data.success) {
        setAgreements(response.data.agreements);
      }
    } catch (error) {
      setEsignError('Failed to load agreements: ' + error.message);
    } finally {
      setEsignLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const response = await signatureAPI.getStats();
      if (response.data.success) {
        setStats(response.data);
      }
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const generateAgreement = async () => {
    if (!esignFormData.type || !esignFormData.partyA || !esignFormData.partyB) {
      setEsignError('Please fill in all required fields (Type, Party A, and Party B)');
      return;
    }

    try {
      setEsignLoading(true);
      setEsignError('');
      setEsignSuccess('');
      
      console.log('Generating agreement with data:', esignFormData);

      const response = await aiAPI.createAgreement({
        type: esignFormData.type,
        partyA: esignFormData.partyA,
        partyB: esignFormData.partyB,
        terms: esignFormData.terms || 'Standard terms and conditions apply'
      });

      if (response.data && response.data.success) {
        setSelectedAgreement({
          title: `${esignFormData.type} - ${esignFormData.partyA} & ${esignFormData.partyB}`,
          content: response.data.document,
          type: esignFormData.type,
          partyA: esignFormData.partyA,
          partyB: esignFormData.partyB,
          terms: esignFormData.terms
        });
        setEsignSuccess('Agreement generated successfully! You can now sign it.');
        
        // Clear success message after 5 seconds
        setTimeout(() => {
          setEsignSuccess('');
        }, 5000);
      } else {
        setEsignError('Failed to generate agreement. Please try again.');
      }
    } catch (error) {
      console.error('Error generating agreement:', error);
      const errorMessage = error.response?.data?.message || 
                          error.response?.data?.error || 
                          error.message || 
                          'An unexpected error occurred while generating the agreement.';
      setEsignError('Failed to generate agreement: ' + errorMessage);
    } finally {
      setEsignLoading(false);
    }
  };

  const handleSignatureSave = (signatureData) => {
    console.log('Signature saved:', signatureData ? 'Signature data received' : 'No signature data');
    setSignatureImage(signatureData);
    setShowSignaturePad(false);
    setEsignSuccess('Signature captured successfully! You can now sign the agreement.');
    setTimeout(() => setEsignSuccess(''), 3000);
  };

  const signAgreement = async () => {
    if (!selectedAgreement) {
      setEsignError('No agreement selected. Please generate an agreement first.');
      return;
    }

    if (!signatureImage) {
      setEsignError('Please add your signature before signing the agreement.');
      return;
    }

    console.log('Signing agreement with signature:', signatureImage ? 'Signature present' : 'No signature');

    if (!user) {
      setEsignError('User not authenticated. Please log in again.');
      return;
    }

    try {
      setEsignLoading(true);
      setEsignError('');
      setEsignSuccess('');

      const signatureRequest = {
        agreementTitle: selectedAgreement.title,
        agreementContent: selectedAgreement.content,
        agreementType: selectedAgreement.type,
        partyA: selectedAgreement.partyA,
        partyB: selectedAgreement.partyB,
        terms: selectedAgreement.terms || '',
        signatureImageBase64: signatureImage,
        signerName: user?.fullName || user?.username || 'Current User',
        signerEmail: user?.email || 'user@example.com'
      };

      console.log('Signing agreement with request:', signatureRequest);

      const response = await signatureAPI.signAgreement(signatureRequest);

      if (response.data && response.data.success) {
        setEsignSuccess('Agreement signed and saved successfully!');
        setSelectedAgreement(null);
        setSignatureImage(null);
        setShowSignaturePad(false);
        
        // Refresh the agreements list
        setTimeout(() => {
          loadUserAgreements();
        }, 1000);
        
        // Clear success message after 5 seconds
        setTimeout(() => {
          setEsignSuccess('');
        }, 5000);
      } else {
        setEsignError('Failed to sign agreement. Please try again.');
      }
    } catch (error) {
      console.error('Error signing agreement:', error);
      const errorMessage = error.response?.data?.message || 
                          error.response?.data?.error || 
                          error.message || 
                          'An unexpected error occurred while signing the agreement.';
      setEsignError('Failed to sign agreement: ' + errorMessage);
    } finally {
      setEsignLoading(false);
    }
  };

  const downloadSignedAgreement = async (agreementId) => {
    try {
      const response = await signatureAPI.downloadAgreement(agreementId);
      const blob = new Blob([response.data], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `signed_agreement_${agreementId}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setEsignSuccess('Agreement downloaded successfully! The file contains your digital signature.');
    } catch (error) {
      console.error('Download error:', error);
      setEsignError('Failed to download agreement: ' + (error.response?.data?.message || error.message));
    }
  };

  const deleteAgreement = async (agreementId) => {
    if (!window.confirm('Are you sure you want to delete this agreement? This action cannot be undone.')) {
      return;
    }

    try {
      setEsignLoading(true);
      setEsignError('');
      setEsignSuccess('');

      // Validate agreement ID on frontend
      if (!agreementId || agreementId.length < 10) {
        setEsignError('Invalid agreement ID. Please refresh the page and try again.');
        return;
      }

      const response = await signatureAPI.deleteAgreement(agreementId);
      
      if (response.data && response.data.success) {
        setEsignSuccess('Agreement deleted successfully!');
        
        // Remove from local state immediately for better UX
        setAgreements(prev => prev.filter(agreement => agreement.id !== agreementId));
        
        // Refresh the list after a short delay
        setTimeout(() => {
          loadUserAgreements();
        }, 1000);
      } else {
        setEsignError('Failed to delete agreement. Please try again.');
      }
    } catch (error) {
      console.error('Delete agreement error:', error);
      
      let errorMessage = 'Failed to delete agreement. Please try again.';
      
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.status === 400) {
        errorMessage = 'Invalid agreement data. Please refresh the page and try again.';
      } else if (error.response?.status === 401) {
        errorMessage = 'Session expired. Please refresh the page and log in again.';
      } else if (error.response?.status === 404) {
        errorMessage = 'Agreement not found. It may have already been deleted.';
        // Remove from local state if not found
        setAgreements(prev => prev.filter(agreement => agreement.id !== agreementId));
      } else if (error.response?.status === 403) {
        errorMessage = 'You do not have permission to delete this agreement.';
      } else if (error.response?.status === 500) {
        errorMessage = 'Server error occurred. Please try again later.';
      } else if (error.message === 'Network Error') {
        errorMessage = 'Network connection failed. Please check your connection.';
      }
      
      setEsignError(errorMessage);
    } finally {
      setEsignLoading(false);
    }
  };

  // Signature verification and authentication
  const showSignatureVerification = async (agreementId) => {
    setVerificationLoading(true);
    setShowSignatureModal(true);
    setVerificationData(null);

    try {
      // Get signature verification data
      const verifyResponse = await signatureAPI.verifyAgreement(agreementId);
      const signatureResponse = await signatureAPI.getSignatureImage(agreementId);

      setVerificationData({
        ...verifyResponse.data,
        signatureImage: signatureResponse.data.signatureImage
      });
    } catch (error) {
      console.error('Error loading signature verification:', error);
      setEsignError('Failed to load signature verification: ' + (error.response?.data?.message || error.message));
      setShowSignatureModal(false);
    } finally {
      setVerificationLoading(false);
    }
  };

  // Document Generation Functions (existing)
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');
    setGeneratedDocument('');

    try {
      const params = {
        type: formData.type,
        partyA: formData.partyA || 'Party A',
        partyB: formData.partyB || 'Party B',
        terms: formData.terms || 'Standard terms and conditions apply'
      };

      const response = await aiAPI.createAgreement(params);
      
      if (response.data.success) {
        setGeneratedDocument(response.data.document);
        setEditedContent(response.data.document);
        setDocumentTitle(`${formData.type} - ${formData.partyA} & ${formData.partyB}`);
        setSavedDocumentId(null); // Reset saved document ID for new generation
        setSuccess('Agreement created successfully!');
      } else {
        setError('Failed to create agreement');
      }
    } catch (error) {
      console.error('Agreement generation error:', error);
      
      // Extract meaningful error message
      let errorMessage = 'Failed to create agreement. Please try again.';
      
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error.message === 'Network Error') {
        errorMessage = 'Unable to connect to server. Please check your connection and try again.';
      } else if (error.code === 'ERR_NETWORK') {
        errorMessage = 'Network connection failed. Please ensure the server is running.';
      } else if (error.response?.status === 500) {
        errorMessage = 'Server error occurred. The service may be temporarily unavailable.';
      } else if (error.response?.status === 429) {
        errorMessage = 'Too many requests. Please wait a moment and try again.';
      } else if (error.response?.status === 401) {
        errorMessage = 'Session expired. Please refresh the page and try again.';
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async () => {
    try {
      const content = isEditing ? editedContent : generatedDocument;
      if (!content) {
        setError('No document content to copy');
        return;
      }
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setSuccess('Document content copied to clipboard!');
      setTimeout(() => {
        setCopied(false);
        setSuccess('');
      }, 2000);
    } catch (error) {
      console.error('Failed to copy text:', error);
      setError('Failed to copy document content');
    }
  };

  const downloadDocument = async () => {
    try {
      const content = isEditing ? editedContent : generatedDocument;
      if (!content) {
        setError('No document content to download');
        return;
      }

      setLoading(true);
      const params = {
        type: formData.type,
        partyA: formData.partyA || 'Party A',
        partyB: formData.partyB || 'Party B',
        terms: formData.terms || 'Standard terms and conditions apply',
        content: content
      };

      const response = await aiAPI.downloadAgreementTxt(params);
      
      // Create blob from response data
      const blob = new Blob([response.data], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${formData.type.replace(/\s+/g, '_')}_Agreement_${Date.now()}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setSuccess('Document downloaded as TXT successfully!');
    } catch (error) {
      console.error('TXT Download error:', error);
      
      let errorMessage = 'Failed to download document as TXT. Please try again.';
      
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.message === 'Network Error') {
        errorMessage = 'Unable to connect to server. Please check your connection.';
      } else if (error.response?.status === 404) {
        errorMessage = 'Download service not found. Please contact support.';
      } else if (error.response?.status === 500) {
        errorMessage = 'Server error during download. Please try again later.';
      } else if (error.response?.status === 413) {
        errorMessage = 'Document too large to download. Try reducing content size.';
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const downloadDocx = async () => {
    try {
      setLoading(true);
      const params = {
        type: formData.type,
        partyA: formData.partyA || 'Party A',
        partyB: formData.partyB || 'Party B',
        terms: formData.terms || 'Standard terms and conditions apply'
      };

      const content = isEditing ? editedContent : generatedDocument;
      if (!content) {
        setError('No document content to download');
        return;
      }

      // Add content to params
      params.content = content;

      const response = await aiAPI.downloadAgreementDocx(params);
      
      // Create blob from response data
      const blob = new Blob([response.data], { 
        type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' 
      });
      
      // Create download link
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${formData.type.replace(/\s+/g, '_')}_Agreement_${(formData.partyA || 'PartyA').replace(/\s+/g, '_')}_${(formData.partyB || 'PartyB').replace(/\s+/g, '_')}.docx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setSuccess('DOCX document downloaded successfully!');
    } catch (error) {
      console.error('DOCX Download error:', error);
      
      let errorMessage = 'Failed to download document as DOCX. Please try again.';
      
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.message === 'Network Error') {
        errorMessage = 'Unable to connect to server. Please check your connection.';
      } else if (error.response?.status === 404) {
        errorMessage = 'DOCX download service not found. Please contact support.';
      } else if (error.response?.status === 500) {
        errorMessage = 'Server error during DOCX conversion. Please try TXT download instead.';
      } else if (error.response?.status === 413) {
        errorMessage = 'Document too large for DOCX conversion. Try TXT download instead.';
      } else if (error.response?.status === 422) {
        errorMessage = 'Document format incompatible with DOCX. Please try TXT download.';
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const startEditing = () => {
    setIsEditing(true);
    setEditedContent(generatedDocument);
  };

  const cancelEditing = () => {
    setIsEditing(false);
    setEditedContent(generatedDocument);
  };

  const saveDocument = async () => {
    setSaving(true);
    setError('');
    setSuccess('');

    try {
      const documentData = {
        title: documentTitle,
        content: editedContent,
        type: formData.type,
        partyA: formData.partyA,
        partyB: formData.partyB,
        terms: formData.terms
      };

      let response;
      if (savedDocumentId) {
        // Update existing document
        response = await documentAPI.updateDocument(savedDocumentId, documentData);
      } else {
        // Save new document
        response = await documentAPI.saveDocument(documentData);
      }

      if (response.data.success) {
        setSavedDocumentId(response.data.document.id);
        setGeneratedDocument(editedContent);
        setIsEditing(false);
        setError('');
      } else {
        setError('Failed to save document');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to save document');
    } finally {
      setSaving(false);
    }
  };

  const generateAndSave = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');
    setGeneratedDocument('');

    try {
      const params = {
        type: formData.type,
        partyA: formData.partyA || 'Party A',
        partyB: formData.partyB || 'Party B',
        terms: formData.terms || 'Standard terms and conditions apply'
      };

      const response = await aiAPI.generateAndSaveAgreement(params);
      
      if (response.data.success) {
        setGeneratedDocument(response.data.document.content);
        setEditedContent(response.data.document.content);
        setDocumentTitle(response.data.document.title);
        setSavedDocumentId(response.data.document.id);
        setIsEditing(false);
        
        // Show appropriate message based on whether document was saved
        if (response.data.message && response.data.message.includes('login required')) {
          setSuccess('Document generated successfully! Login to save it to your documents.');
        } else {
          setSuccess('Document generated and saved successfully!');
        }
      } else {
        setError('Failed to generate and save document');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to generate and save document');
    } finally {
      setLoading(false);
    }
  };

  const filteredAgreements = agreements.filter(agreement => {
    if (!agreement) return false;
    
    const title = agreement.title || '';
    const type = agreement.type || '';
    const status = agreement.status || 'draft';
    
    const matchesSearch = title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  // AI Analysis Functions
  const analyzeDocument = async (analysisType = 'comprehensive') => {
    if (!generatedDocument) {
      setAnalysisError('No document to analyze');
      return;
    }

    try {
      setAnalysisLoading(true);
      setAnalysisError('');
      setAnalysisResult(null);

      let response;
      switch (analysisType) {
        case 'compliance':
          response = await aiAPI.assessComplianceText(generatedDocument, 'IN');
          break;
        case 'risk':
          response = await aiAPI.performRiskAnalysisText(generatedDocument);
          break;
        case 'issues':
          response = await aiAPI.highlightIssuesText(generatedDocument);
          break;
        case 'comprehensive':
        default:
          response = await aiAPI.analyzeDocumentText(generatedDocument);
          break;
      }
      
      if (response.data.success) {
        const result = analysisType === 'compliance' ? response.data.complianceAssessment :
                      analysisType === 'risk' ? response.data.riskAnalysis :
                      analysisType === 'issues' ? response.data.issues :
                      response.data.analysis;
        
        setAnalysisResult(result);
        setAnalysisResults(prev => ({ ...prev, [analysisType]: result }));
      } else {
        setAnalysisError('Failed to analyze document');
      }
    } catch (error) {
      setAnalysisError('Analysis failed: ' + (error.response?.data?.message || error.message));
    } finally {
      setAnalysisLoading(false);
    }
  };

  const runAllAnalyses = async () => {
    const analyses = ['comprehensive', 'compliance', 'risk', 'issues'];
    for (const analysisType of analyses) {
      await analyzeDocument(analysisType);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-secondary-900 mb-2">
          Document Generation & E-Sign Portal
        </h1>
        <p className="text-secondary-600">
          Generate professional business documents and sign them digitally
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="border-b border-secondary-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('generate')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'generate'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-secondary-500 hover:text-secondary-700 hover:border-secondary-300'
              }`}
            >
              <FileText className="h-5 w-5 inline mr-2" />
              Generate Documents
            </button>
            <button
              onClick={() => setActiveTab('esign')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'esign'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-secondary-500 hover:text-secondary-700 hover:border-secondary-300'
              }`}
            >
              <PenTool className="h-5 w-5 inline mr-2" />
              E-Sign Portal
            </button>
          </nav>
        </div>
      </div>

      {/* Document Generation Tab */}
      {activeTab === 'generate' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Form */}
          <div className="card">
            <h2 className="text-xl font-bold text-secondary-900 mb-6">
              Document Details
            </h2>

            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center space-x-2">
                  <AlertCircle className="h-5 w-5" />
                  <span>{error}</span>
                </div>
              )}
              
              {success && (
                <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>{success}</span>
                </div>
              )}

              <div>
                <label htmlFor="type" className="block text-sm font-medium text-secondary-700 mb-2">
                  Agreement Type
                </label>
                <select
                  id="type"
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                  className="input-field"
                >
                  {agreementTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="partyA" className="block text-sm font-medium text-secondary-700 mb-2">
                  Party A (First Party)
                </label>
                <input
                  id="partyA"
                  name="partyA"
                  type="text"
                  value={formData.partyA}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="Enter Party A name or organization"
                />
              </div>

              <div>
                <label htmlFor="partyB" className="block text-sm font-medium text-secondary-700 mb-2">
                  Party B (Second Party)
                </label>
                <input
                  id="partyB"
                  name="partyB"
                  type="text"
                  value={formData.partyB}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="Enter Party B name or organization"
                />
              </div>

              <div>
                <label htmlFor="terms" className="block text-sm font-medium text-secondary-700 mb-2">
                  Specific Terms & Conditions
                </label>
                <textarea
                  id="terms"
                  name="terms"
                  rows={4}
                  value={formData.terms}
                  onChange={handleChange}
                  className="input-field resize-none"
                  placeholder="Enter specific terms, conditions, or requirements for this agreement..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <button
                  type="submit"
                  disabled={loading}
                  className="btn-primary flex items-center justify-center py-3"
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <FileText className="h-5 w-5 mr-2 p-" />
                      Create Agreement
                    </>
                  )}
                </button>
                
                <button
                  type="button"
                  onClick={generateAndSave}
                  disabled={loading}
                  className="flex justify-center py-3 px-6 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-medium rounded-lg border border-indigo-600 hover:border-indigo-700 transition-colors"
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <Save className="h-5 w-5 mr-2" />
                      Create & Save
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Generated Document */}
          <div className="card">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-secondary-900">
                Generated Document
              </h2>
              {generatedDocument && (
                <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                  <div className="flex flex-wrap gap-3">
                    {/* Copy and Edit Actions */}
                    <div className="flex gap-2">
                      <button
                        onClick={copyToClipboard}
                        className={`flex items-center space-x-2 px-4 py-2 border rounded-lg font-medium transition-colors ${
                          copied 
                            ? 'bg-green-100 border-green-300 text-green-700 hover:bg-green-200' 
                            : 'bg-cyan-50 border-cyan-200 text-cyan-700 hover:bg-cyan-100'
                        }`}
                        title="Copy document content to clipboard"
                      >
                        {copied ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                        <span className="font-medium">{copied ? 'Copied!' : 'Copy'}</span>
                      </button>
                      <button
                        onClick={isEditing ? () => setGeneratedDocument(editedContent) : startEditing}
                        className={`flex items-center space-x-2 px-4 py-2 border rounded-lg font-medium transition-colors ${
                          isEditing 
                            ? 'bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100' 
                            : 'bg-amber-50 border-amber-200 text-amber-700 hover:bg-amber-100'
                        }`}
                        title={isEditing ? "Apply changes" : "Edit document content"}
                      >
                        <Edit className="h-4 w-4" />
                        <span className="font-medium">{isEditing ? 'Apply' : 'Edit'}</span>
                      </button>
                    </div>
                    
                    {/* Download Actions */}
                    <div className="flex gap-2">
                      <button
                        onClick={downloadDocument}
                        className="btn-primary flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700"
                        title="Download as formatted text file"
                        disabled={loading}
                      >
                        {loading ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        ) : (
                          <Download className="h-4 w-4" />
                        )}
                        <span className="font-medium">Txt</span>
                      </button>
                      <button
                        onClick={downloadDocx}
                        className="btn-primary flex items-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700"
                        title="Download as Microsoft Word document"
                        disabled={loading}
                      >
                        {loading ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        ) : (
                          <Download className="h-4 w-4" />
                        )}
                        <span className="font-medium">Docx</span>
                      </button>
                    </div>
                    
                    {/* Analysis and Signature Actions */}
                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowAnalysisModal(true)}
                        className="btn-secondary flex items-center space-x-2 px-4 py-2"
                        title="Analyze document with AI"
                      >
                        <BarChart3 className="h-4 w-4" />
                        <span className="font-medium">Analyze</span>
                      </button>
                      <button
                        onClick={() => {
                          const content = isEditing ? editedContent : generatedDocument;
                          setSelectedAgreement({
                            title: `${formData.type} - ${formData.partyA || 'Party A'} & ${formData.partyB || 'Party B'}`,
                            content: content,
                            type: formData.type,
                            partyA: formData.partyA || 'Party A',
                            partyB: formData.partyB || 'Party B',
                            terms: formData.terms || 'Standard terms and conditions'
                          });
                          setShowSignaturePad(true);
                        }}
                        className="btn-primary flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700"
                        title="Sign this document digitally"
                      >
                        <PenTool className="h-4 w-4" />
                        <span className="font-medium">Sign Document</span>
                      </button>
                    </div>
                  </div>
                  
                  {/* Action descriptions */}
                  <div className="mt-3 text-xs text-gray-600 border-t border-gray-200 pt-2">
                    <span className="font-medium">Actions:</span> Copy content • Edit manually • Download in TXT/DOCX formats • AI analysis • Digital signature
                  </div>
                </div>
              )}
            </div>

            {generatedDocument ? (
              <div className="bg-secondary-50 border border-secondary-200 rounded-lg p-4">
                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        Document Title
                      </label>
                      <input
                        type="text"
                        value={documentTitle}
                        onChange={(e) => setDocumentTitle(e.target.value)}
                        className="input-field"
                        placeholder="Enter document title"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        Document Content
                      </label>
                      <textarea
                        value={editedContent}
                        onChange={(e) => setEditedContent(e.target.value)}
                        className="input-field resize-none h-64 font-mono text-sm"
                        placeholder="Edit document content..."
                      />
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={saveDocument}
                        disabled={saving}
                        className="btn-primary flex items-center space-x-1"
                      >
                        {saving ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        ) : (
                          <Save className="h-4 w-4" />
                        )}
                        <span>{saving ? 'Saving...' : 'Save Changes'}</span>
                      </button>
                      <button
                        onClick={cancelEditing}
                        className="btn-secondary flex items-center space-x-1"
                      >
                        <X className="h-4 w-4" />
                        <span>Cancel</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <pre className="whitespace-pre-wrap text-sm text-secondary-800 font-mono">
                    {generatedDocument}
                  </pre>
                )}
              </div>
            ) : (
              <div className="bg-secondary-50 border border-secondary-200 rounded-lg p-8 text-center">
                <FileText className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                <p className="text-secondary-600">
                  Fill out the form and click "Generate Document" to create your legal agreement
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Simplified E-Sign Portal Tab */}
      {activeTab === 'esign' && (
        <div className="space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="card">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-secondary-600">Total Agreements</p>
                  <p className="text-2xl font-bold text-secondary-900">{stats.totalAgreements || 0}</p>
                </div>
              </div>
            </div>
            <div className="card">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-secondary-600">Signed</p>
                  <p className="text-2xl font-bold text-secondary-900">{stats.signedAgreements || 0}</p>
                </div>
              </div>
            </div>
            <div className="card">
              <div className="flex items-center">
                <div className="p-2 bg-yellow-100 rounded-lg">
                  <Clock className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-secondary-600">Pending</p>
                  <p className="text-2xl font-bold text-secondary-900">{stats.pendingAgreements || 0}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Simplified Agreement Generation */}
            <div className="card">
              <h2 className="text-xl font-bold text-secondary-900 mb-6">
                Create & Sign Agreement
              </h2>

              {esignError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center space-x-2 mb-4">
                  <AlertCircle className="h-5 w-5" />
                  <span>{esignError}</span>
                </div>
              )}
              
              {esignSuccess && (
                <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg flex items-center space-x-2 mb-4">
                  <CheckCircle className="h-5 w-5" />
                  <span>{esignSuccess}</span>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Agreement Type
                  </label>
                  <select
                    value={esignFormData.type}
                    onChange={(e) => setEsignFormData({...esignFormData, type: e.target.value})}
                    className="input-field"
                  >
                    {agreementTypes.slice(0, 10).map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Party A
                  </label>
                  <input
                    type="text"
                    value={esignFormData.partyA}
                    onChange={(e) => setEsignFormData({...esignFormData, partyA: e.target.value})}
                    className="input-field"
                    placeholder="Enter Party A name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Party B
                  </label>
                  <input
                    type="text"
                    value={esignFormData.partyB}
                    onChange={(e) => setEsignFormData({...esignFormData, partyB: e.target.value})}
                    className="input-field"
                    placeholder="Enter Party B name"
                  />
                </div>

                <button
                  onClick={generateAgreement}
                  disabled={esignLoading}
                  className="btn-primary w-full flex justify-center py-3"
                >
                  {esignLoading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <FileText className="h-5 w-5 mr-2" />
                      Create Agreement
                    </>
                  )}
                </button>
              </div>

              {/* Direct Signature Section */}
              {selectedAgreement && (
                <div className="mt-6 pt-6 border-t border-secondary-200">
                  <h3 className="text-lg font-semibold text-secondary-900 mb-4">
                    Sign Your Agreement
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="bg-secondary-50 border border-secondary-200 rounded-lg p-4">
                      <h4 className="font-medium text-secondary-900 mb-2">
                        {selectedAgreement.title}
                      </h4>
                      <p className="text-sm text-secondary-600 mb-4">
                        Type: {selectedAgreement.type}
                      </p>
                      <div className="max-h-32 overflow-y-auto">
                        <pre className="text-xs text-secondary-700 whitespace-pre-wrap">
                          {selectedAgreement.content.substring(0, 300)}...
                        </pre>
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <button
                        onClick={() => setShowSignaturePad(true)}
                        className="btn-secondary flex-1 flex justify-center py-3"
                      >
                        <PenTool className="h-5 w-5 mr-2" />
                        Draw Signature
                      </button>
                      <button
                        onClick={signAgreement}
                        disabled={esignLoading || !signatureImage}
                        className="btn-primary flex-1 flex justify-center py-3"
                      >
                        {esignLoading ? (
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        ) : (
                          <>
                            <CheckCircle className="h-5 w-5 mr-2" />
                            Sign & Save
                          </>
                        )}
                      </button>
                    </div>

                    {signatureImage && (
                      <div className="bg-white border border-secondary-200 rounded-lg p-4">
                        <p className="text-sm font-medium text-secondary-700 mb-2">Your Signature:</p>
                        <img 
                          src={signatureImage} 
                          alt="Signature" 
                          className="max-w-full h-16 object-contain border border-secondary-200 rounded"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Simplified Agreements List */}
            <div className="card">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-secondary-900">
                  Your Signed Agreements
                </h2>
                <button
                  onClick={loadUserAgreements}
                  className="btn-secondary flex items-center space-x-1"
                >
                  <RefreshCw className="h-4 w-4" />
                  <span>Refresh</span>
                </button>
              </div>

              {esignLoading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
                </div>
              ) : (
                <>
                  {filteredAgreements.length > 0 ? (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {filteredAgreements.map((agreement) => {
                        if (!agreement) return null;
                        
                        const title = agreement.title || 'Untitled Document';
                        const type = agreement.type || 'Unknown Type';
                        const status = agreement.status || 'draft';
                        const createdAt = agreement.createdAt || new Date().toISOString();
                        
                        return (
                          <div key={agreement.id || Math.random()} className="bg-secondary-50 border border-secondary-200 rounded-lg p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className="font-medium text-secondary-900 mb-1">
                                  {title}
                                </h4>
                                <p className="text-sm text-secondary-600 mb-2">
                                  Type: {type}
                                </p>
                                <div className="flex items-center space-x-4 text-xs text-secondary-500">
                                  <span className={`px-2 py-1 rounded-full ${
                                    status === 'signed' ? 'bg-green-100 text-green-800' :
                                    status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                    'bg-blue-100 text-blue-800'
                                  }`}>
                                    {status}
                                  </span>
                                  <span>
                                    {new Date(createdAt).toLocaleDateString()}
                                  </span>
                                </div>
                              </div>
                              <div className="flex space-x-2">
                                <button
                                  onClick={() => showSignatureVerification(agreement.id)}
                                  className="btn-secondary p-2"
                                  title="View Signature"
                                  disabled={!agreement.id}
                                >
                                  <PenTool className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => downloadSignedAgreement(agreement.id)}
                                  className="btn-secondary p-2"
                                  title="Download"
                                  disabled={!agreement.id}
                                >
                                  <Download className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => deleteAgreement(agreement.id)}
                                  className="btn-secondary p-2 text-red-600 hover:text-red-700"
                                  title="Delete"
                                  disabled={!agreement.id}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <FileText className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                      <p className="text-secondary-600">
                        No agreements found. Create a new agreement to get started.
                      </p>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Information */}
      <div className="mt-8 card">
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">
          About AI-Generated Documents & E-Signatures
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-secondary-600">
          <div>
            <h4 className="font-medium text-secondary-900 mb-2">Document Templates:</h4>
            <ul className="space-y-1">
              <li>• Professional business structure and formatting</li>
              <li>• Standard clauses and business language</li>
              <li>• Confidentiality and termination provisions</li>
              <li>• Basic dispute resolution frameworks</li>
              <li>• Standard terms and conditions</li>
            </ul>
            <p className="text-xs text-amber-600 mt-2 font-medium">
              ⚠️ Templates only - Professional review required
            </p>
          </div>
          <div>
            <h4 className="font-medium text-secondary-900 mb-2">E-Signatures:</h4>
            <ul className="space-y-1">
              <li>• Digital signature functionality</li>
              <li>• Secure document storage and verification</li>
              <li>• Basic audit trail and tracking</li>
              <li>• PDF generation with embedded signatures</li>
              <li>• Document integrity verification</li>
            </ul>
            <p className="text-xs text-amber-600 mt-2 font-medium">
              ⚠️ Consult professionals for legal validity
            </p>
          </div>
        </div>
      </div>

      {/* Enhanced Signature Pad Modal */}
      {showSignaturePad && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                    <PenTool className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Electronic Signature Portal</h3>
                    <p className="text-blue-100 text-sm">Create your digital signature for legal documents</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowSignaturePad(false)}
                  className="text-white hover:text-blue-200 transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <SignaturePad 
                onSave={handleSignatureSave} 
                onCancel={() => setShowSignaturePad(false)} 
              />
            </div>
          </div>
        </div>
      )}

      {/* Professional Lawyer-Style AI Analysis Modal */}
      {showAnalysisModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-6xl w-full max-h-[95vh] overflow-hidden">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-slate-800 to-slate-900 text-white p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="w-14 h-14 bg-white bg-opacity-10 rounded-full flex items-center justify-center">
                      <Scale className="h-8 w-8" />
                    </div>
                    {analysisLoading && (
                      <div className="absolute inset-0 w-14 h-14 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
                    )}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold">Legal Document Analysis</h3>
                    <p className="text-slate-300 text-sm">Professional AI-powered legal review and assessment</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setShowAnalysisModal(false);
                    setAnalysisResult(null);
                    setAnalysisError('');
                    setAnalysisResults({});
                  }}
                  className="text-white hover:text-slate-300 transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto max-h-[calc(95vh-140px)]">
              {!analysisResult && !analysisLoading && !analysisError && (
                <div className="space-y-8">
                  {/* Analysis Options */}
                  <div className="text-center">
                    <h4 className="text-xl font-semibold text-secondary-900 mb-2">
                      Choose Your Legal Analysis
                    </h4>
                    <p className="text-secondary-600 mb-6">
                      Select the type of legal analysis you need for your document
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <button
                      onClick={() => {
                        setSelectedAnalysisType('comprehensive');
                        analyzeDocument('comprehensive');
                      }}
                      className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-xl hover:border-blue-400 transition-all group"
                    >
                      <div className="text-center">
                        <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                          <FileText className="h-6 w-6 text-white" />
                        </div>
                        <h5 className="font-semibold text-secondary-900 mb-2">Comprehensive Review</h5>
                        <p className="text-sm text-secondary-600">Complete legal document analysis</p>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedAnalysisType('compliance');
                        analyzeDocument('compliance');
                      }}
                      className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200 rounded-xl hover:border-green-400 transition-all group"
                    >
                      <div className="text-center">
                        <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                          <CheckCircle className="h-6 w-6 text-white" />
                        </div>
                        <h5 className="font-semibold text-secondary-900 mb-2">Compliance Check</h5>
                        <p className="text-sm text-secondary-600">Legal compliance assessment</p>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedAnalysisType('risk');
                        analyzeDocument('risk');
                      }}
                      className="p-6 bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-200 rounded-xl hover:border-red-400 transition-all group"
                    >
                      <div className="text-center">
                        <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                          <Shield className="h-6 w-6 text-white" />
                        </div>
                        <h5 className="font-semibold text-secondary-900 mb-2">Risk Analysis</h5>
                        <p className="text-sm text-secondary-600">Legal risk assessment</p>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedAnalysisType('issues');
                        analyzeDocument('issues');
                      }}
                      className="p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-200 rounded-xl hover:border-yellow-400 transition-all group"
                    >
                      <div className="text-center">
                        <div className="w-12 h-12 bg-yellow-600 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                          <AlertCircle className="h-6 w-6 text-white" />
                        </div>
                        <h5 className="font-semibold text-secondary-900 mb-2">Issue Detection</h5>
                        <p className="text-sm text-secondary-600">Identify potential problems</p>
                      </div>
                    </button>
                  </div>

                  <div className="text-center">
                    <button
                      onClick={runAllAnalyses}
                      className="btn-primary px-8 py-3 text-lg bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    >
                      <BarChart3 className="h-5 w-5 mr-2 inline" />
                      Run All Analyses
                    </button>
                  </div>
                </div>
              )}

              {analysisLoading && (
                <div className="text-center py-12">
                  <div className="relative w-32 h-32 mx-auto mb-6">
                    <div className="w-32 h-32 border-4 border-slate-200 border-t-slate-600 rounded-full animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Scale className="h-12 w-12 text-slate-600" />
                    </div>
                  </div>
                  <h4 className="text-2xl font-semibold text-secondary-900 mb-2">
                    AI Legal Analysis in Progress
                  </h4>
                  <p className="text-secondary-600 mb-4">
                    Our AI is performing {selectedAnalysisType} analysis of your document...
                  </p>
                  <div className="flex justify-center space-x-2">
                    <div className="w-3 h-3 bg-slate-600 rounded-full animate-bounce"></div>
                    <div className="w-3 h-3 bg-slate-600 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-3 h-3 bg-slate-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  </div>
                </div>
              )}

              {analysisError && (
                <div className="text-center py-12">
                  <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <AlertCircle className="h-12 w-12 text-red-600" />
                  </div>
                  <h4 className="text-xl font-semibold text-secondary-900 mb-2">
                    Analysis Failed
                  </h4>
                  <p className="text-red-600 mb-6">{analysisError}</p>
                  <button
                    onClick={() => analyzeDocument(selectedAnalysisType)}
                    className="btn-primary px-6 py-2"
                  >
                    Try Again
                  </button>
                </div>
              )}

              {analysisResult && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold text-secondary-900 capitalize">
                          {selectedAnalysisType} Analysis Complete
                        </h4>
                        <p className="text-sm text-secondary-600">
                          AI has finished analyzing your document
                        </p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(analysisResult);
                        }}
                        className="btn-secondary flex items-center space-x-2"
                      >
                        <Copy className="h-4 w-4" />
                        <span>Copy</span>
                      </button>
                      <button
                        onClick={() => {
                          setAnalysisResult(null);
                          setAnalysisError('');
                        }}
                        className="btn-secondary"
                      >
                        New Analysis
                      </button>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-slate-50 to-blue-50 border border-slate-200 rounded-lg p-6">
                    <h5 className="font-semibold text-secondary-900 mb-4 flex items-center">
                      <Scale className="h-5 w-5 mr-2 text-slate-600" />
                      Legal Analysis Results
                    </h5>
                    <div className="prose prose-sm max-w-none">
                      <pre className="whitespace-pre-wrap text-sm text-secondary-700 leading-relaxed bg-white p-4 rounded border">
                        {analysisResult}
                      </pre>
                    </div>
                  </div>

                  {/* Show other analysis results if available */}
                  {Object.keys(analysisResults).length > 1 && (
                    <div className="space-y-4">
                      <h5 className="font-semibold text-secondary-900">Other Analysis Results</h5>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(analysisResults).map(([type, result]) => (
                          type !== selectedAnalysisType && (
                            <div key={type} className="bg-gray-50 border rounded-lg p-4">
                              <h6 className="font-medium text-secondary-900 capitalize mb-2">{type} Analysis</h6>
                              <p className="text-sm text-secondary-600 line-clamp-3">
                                {result.substring(0, 200)}...
                              </p>
                              <button
                                onClick={() => setAnalysisResult(result)}
                                className="text-blue-600 text-sm mt-2 hover:underline"
                              >
                                View Full Analysis
                              </button>
                            </div>
                          )
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Signature Verification Modal */}
      {showSignatureModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[95vh] overflow-hidden">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-blue-800 to-blue-900 text-white p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="w-14 h-14 bg-white bg-opacity-10 rounded-full flex items-center justify-center">
                      <PenTool className="h-8 w-8" />
                    </div>
                    {verificationLoading && (
                      <div className="absolute inset-0 w-14 h-14 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
                    )}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold">Digital Signature Verification</h3>
                    <p className="text-blue-300 text-sm">Cryptographic authentication and verification</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowSignatureModal(false)}
                  className="text-white hover:bg-white hover:bg-opacity-10 rounded-full p-2 transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-6 max-h-[calc(95vh-140px)] overflow-y-auto">
              {verificationLoading ? (
                <div className="flex justify-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
              ) : verificationData ? (
                <div className="space-y-6">
                  {/* Verification Status */}
                  <div className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      {verificationData.overallValid ? (
                        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                          <CheckCircle className="h-8 w-8 text-green-600" />
                        </div>
                      ) : (
                        <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                          <AlertTriangle className="h-8 w-8 text-red-600" />
                        </div>
                      )}
                      <div>
                        <h4 className="text-xl font-bold text-gray-900">
                          {verificationData.overallValid ? 'Signature Verified ✓' : 'Verification Failed ✗'}
                        </h4>
                        <p className="text-gray-600">
                          {verificationData.overallValid 
                            ? 'This document has been successfully verified and is authentic.'
                            : 'This document verification failed. The document may have been tampered with.'
                          }
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center space-x-2">
                        {verificationData.documentValid ? (
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        ) : (
                          <X className="h-5 w-5 text-red-600" />
                        )}
                        <span className="text-sm font-medium">Document Integrity</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {verificationData.signatureValid ? (
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        ) : (
                          <X className="h-5 w-5 text-red-600" />
                        )}
                        <span className="text-sm font-medium">Signature Authenticity</span>
                      </div>
                    </div>
                  </div>

                  {/* Agreement Information */}
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                    <h5 className="text-lg font-semibold text-gray-900 mb-4">Agreement Details</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm font-medium text-gray-600">Title:</span>
                        <p className="text-gray-900">{verificationData.agreementTitle}</p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">Type:</span>
                        <p className="text-gray-900">{verificationData.agreementType}</p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">Status:</span>
                        <span className="inline-block px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                          {verificationData.status}
                        </span>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">Agreement ID:</span>
                        <p className="text-gray-900 font-mono text-sm">{verificationData.agreementId}</p>
                      </div>
                    </div>
                  </div>

                  {/* Signer Information */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                    <h5 className="text-lg font-semibold text-gray-900 mb-4">Signer Authentication</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                      <div>
                        <span className="text-sm font-medium text-gray-600">Signer Name:</span>
                        <p className="text-gray-900 font-medium">{verificationData.signerName}</p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">Email:</span>
                        <p className="text-gray-900">{verificationData.signerEmail}</p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">Signed Date:</span>
                        <p className="text-gray-900">{verificationData.signedAtFormatted}</p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">IP Address:</span>
                        <p className="text-gray-900 font-mono text-sm">{verificationData.ipAddress}</p>
                      </div>
                    </div>

                    {/* Digital Signature */}
                    {verificationData.signatureImage && (
                      <div className="border-t border-blue-200 pt-4">
                        <span className="text-sm font-medium text-gray-600 block mb-2">Digital Signature:</span>
                        <div className="bg-white border border-gray-300 rounded-lg p-4 inline-block">
                          <img 
                            src={verificationData.signatureImage} 
                            alt="Digital Signature" 
                            className="max-w-xs max-h-24 border border-gray-200 rounded"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Cryptographic Verification */}
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                    <h5 className="text-lg font-semibold text-gray-900 mb-4">Cryptographic Verification</h5>
                    <div className="space-y-3">
                      <div>
                        <span className="text-sm font-medium text-gray-600">Document Hash (SHA-256):</span>
                        <p className="text-gray-900 font-mono text-xs break-all bg-white p-2 border rounded mt-1">
                          {verificationData.documentHash}
                        </p>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-600">Signature Hash (SHA-256):</span>
                        <p className="text-gray-900 font-mono text-xs break-all bg-white p-2 border rounded mt-1">
                          {verificationData.signatureHash}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <Shield className="h-4 w-4 text-green-600" />
                        <span className="text-gray-600">
                          Encryption Algorithm: SHA-256 | Tamper Detection: {verificationData.authentication?.tamperDetected ? 'DETECTED' : 'NONE'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <AlertTriangle className="h-12 w-12 text-red-400 mx-auto mb-4" />
                  <p className="text-gray-600">Failed to load verification data</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DocumentGenerator;
