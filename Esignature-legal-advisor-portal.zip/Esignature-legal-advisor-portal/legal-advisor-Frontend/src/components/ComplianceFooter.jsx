import { Info } from 'lucide-react';

const ComplianceFooter = () => {
  return (
    <footer className="bg-gradient-to-r from-slate-50 to-blue-50 border-t border-slate-200 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-2 sm:space-y-0">
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <Info className="h-3.5 w-3.5 text-blue-500 flex-shrink-0" />
              <span className="w-1 h-1 bg-blue-400 rounded-full"></span>
            </div>
            <p className="text-xs text-slate-600">
              <span className="font-semibold text-blue-700">Document Assistant Pro:</span> Professional document template platform. 
              <span className="text-slate-500">Templates require expert review • Not professional advice services.</span>
            </p>
          </div>
          <div className="flex items-center space-x-1 text-xs text-slate-500">
            <span className="w-1 h-1 bg-slate-400 rounded-full"></span>
            <span>Always consult qualified professionals for important matters</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default ComplianceFooter;
