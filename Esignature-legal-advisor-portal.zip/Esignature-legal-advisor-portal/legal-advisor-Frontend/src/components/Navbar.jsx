import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, 
  X, 
  Home, 
  FileText, 
  Search, 
  User, 
  LogOut,
  Scale,
  FolderOpen,
  Upload,
  Shield,
  Bell,
  Settings
} from 'lucide-react';
import { Avatar, Badge, Dropdown, Button, Space } from 'antd';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { logout, user } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const navItems = [
    { name: 'Dashboard', href: '/dashboard', icon: Home },
    { name: 'Generate Document', href: '/generate', icon: FileText },
    { name: 'Document Upload', href: '/upload', icon: Upload },
    { name: 'My Documents', href: '/documents', icon: FolderOpen },
    { name: 'Analyze Document', href: '/analyze', icon: Search },
    { name: 'Verification', href: '/verification', icon: Shield },
  ];

  // Add admin link if user is admin
  if (user?.roles?.some(role => role.name === 'ADMIN')) {
    navItems.push({ name: 'Admin Panel', href: '/admin', icon: Shield });
  }

  const userMenuItems = [
    {
      key: 'profile',
      label: 'Profile Settings',
      icon: <User className="h-4 w-4" />,
      onClick: () => navigate('/profile'),
    },
    {
      key: 'settings',
      label: 'Settings',
      icon: <Settings className="h-4 w-4" />,
      onClick: () => navigate('/profile'),
    },
    {
      type: 'divider',
    },
    {
      key: 'logout',
      label: 'Logout',
      icon: <LogOut className="h-4 w-4" />,
      onClick: handleLogout,
    },
  ];

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-100 fixed top-0 w-full z-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/dashboard" className="flex items-center space-x-3 hover:opacity-90 transition-opacity">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2.5 rounded-lg shadow-sm">
              <Scale className="h-7 w-7 text-white" />
            </div>
            <div className="flex flex-col">
              <div className="flex items-baseline space-x-1">
                <span className="text-xl font-bold text-blue-600">Legal</span>
                <span className="text-xl font-bold text-purple-600">Advisor</span>
              </div>
              <p className="text-xs text-gray-500 leading-tight">AI-Powered Legal Assistant</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-1">
            {navItems.map((item, index) => (
              <Link
                key={item.name}
                to={item.href}
                className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover:bg-blue-50 group whitespace-nowrap"
              >
                <item.icon className="h-4 w-4 group-hover:scale-110 transition-transform flex-shrink-0" />
                <span className="hidden xl:inline">{item.name}</span>
              </Link>
            ))}
          </div>

          {/* User Section */}
          <div className="flex items-center space-x-2">
            {/* Notifications */}
            <Badge count={3} size="small">
              <Button 
                type="text" 
                icon={<Bell className="h-4 w-4" />}
                className="flex items-center justify-center w-8 h-8 rounded-full hover:bg-gray-100"
              />
            </Badge>

            {/* User Profile */}
            <Dropdown
              menu={{ items: userMenuItems }}
              placement="bottomRight"
              trigger={['click']}
            >
              <div className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 p-1 rounded-lg transition-colors">
                <Avatar 
                  size={32}
                  className="bg-gradient-to-r from-blue-500 to-purple-500"
                >
                  {user?.fullName?.charAt(0) || user?.username?.charAt(0) || 'U'}
                </Avatar>
                <div className="hidden md:block text-left">
                  <p className="text-sm font-medium text-gray-900 leading-tight">
                    {user?.fullName || user?.username || 'User'}
                  </p>
                  <p className="text-xs text-gray-500 leading-tight">Legal Advisor</p>
                </div>
              </div>
            </Dropdown>

            {/* Mobile menu button */}
            <div className="lg:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="text-gray-600 hover:text-gray-900 focus:outline-none focus:text-gray-900 p-2 rounded-lg hover:bg-gray-100"
              >
                {isOpen ? (
                  <X className="h-5 w-5" />
                ) : (
                  <Menu className="h-5 w-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white border-t border-gray-100"
          >
            <div className="px-4 py-3 space-y-2">
              {/* Mobile User Profile */}
              <motion.div 
                className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg mb-4"
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.1 }}
              >
                <Avatar 
                  size={40}
                  className="bg-gradient-to-r from-blue-500 to-purple-500"
                >
                  {user?.fullName?.charAt(0) || user?.username?.charAt(0) || 'U'}
                </Avatar>
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {user?.fullName || user?.username || 'User'}
                  </p>
                  <p className="text-xs text-gray-500">Legal Advisor</p>
                </div>
              </motion.div>
              
              {navItems.map((item, index) => (
                <motion.div
                  key={item.name}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.1 + index * 0.05 }}
                >
                  <Link
                    to={item.href}
                    className="flex items-center space-x-3 text-gray-600 hover:text-blue-600 px-3 py-3 rounded-lg text-base font-medium transition-colors hover:bg-blue-50"
                    onClick={() => setIsOpen(false)}
                  >
                    <item.icon className="h-5 w-5" />
                    <span>{item.name}</span>
                  </Link>
                </motion.div>
              ))}
              
              <motion.div
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <button
                  onClick={() => {
                    handleLogout();
                    setIsOpen(false);
                  }}
                  className="flex items-center space-x-3 text-gray-600 hover:text-red-600 w-full text-left px-3 py-3 rounded-lg text-base font-medium transition-colors hover:bg-red-50"
                >
                  <LogOut className="h-5 w-5" />
                  <span>Logout</span>
                </button>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default Navbar;
