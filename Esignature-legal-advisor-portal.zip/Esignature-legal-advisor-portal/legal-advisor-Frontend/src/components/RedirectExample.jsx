import React from 'react';
import { useRedirect } from '../utils/redirect';

const RedirectExample = () => {
  const { toSignin, toDashboard, toSigninWithReturn } = useRedirect();

  const handleRedirectToSignin = () => {
    toSignin('You need to sign in to access this feature');
  };

  const handleRedirectWithReturn = () => {
    toSigninWithReturn('/dashboard');
  };

  return (
    <div className="p-4 space-y-4">
      <h3 className="text-lg font-semibold">Redirect Examples</h3>
      
      <div className="space-y-2">
        <button
          onClick={handleRedirectToSignin}
          className="btn-secondary"
        >
          Redirect to Signin with Reason
        </button>
        
        <button
          onClick={handleRedirectWithReturn}
          className="btn-secondary"
        >
          Redirect to Signin with Return URL
        </button>
        
        <button
          onClick={toDashboard}
          className="btn-secondary"
        >
          Redirect to Dashboard
        </button>
      </div>
    </div>
  );
};

export default RedirectExample;
