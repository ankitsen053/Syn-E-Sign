import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Progress, List, Avatar, Tag, Spin, Alert } from 'antd';
import { 
  FileTextOutlined, 
  SearchOutlined, 
  ClockCircleOutlined, 
  CheckCircleOutlined,
  RiseOutlined,
  UserOutlined,
  CalendarOutlined,
  BarChartOutlined
} from '@ant-design/icons';
import { useAuth } from '../context/AuthContext';
import { dashboardAPI } from '../services/api';

const Dashboard = () => {
  const { user } = useAuth();
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const response = await dashboardAPI.getStats();
      setDashboardData(response.data);
      setError(null);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
      setError('Failed to load dashboard data');
      // Set mock data for demonstration
      setDashboardData(getMockDashboardData());
    } finally {
      setLoading(false);
    }
  };

  const getMockDashboardData = () => ({
    documentsGenerated: {
      title: "Documents Generated",
      value: 12,
      change: "+15%",
      changeType: "positive",
      icon: "document",
      color: "blue"
    },
    documentsAnalyzed: {
      title: "Documents Analyzed",
      value: 8,
      change: "+8%",
      changeType: "positive",
      icon: "analyze",
      color: "green"
    },
    activeSessions: {
      title: "Active Sessions",
      value: 3,
      change: "+2",
      changeType: "positive",
      icon: "session",
      color: "orange"
    },
    verificationStatus: {
      title: "Verification Status",
      status: "Verified",
      subStatus: "Active",
      changeType: "positive",
      icon: "verified",
      color: "green"
    },
    progressOverview: {
      monthlyGeneratedGoal: 20,
      monthlyGenerated: 12,
      generatedProgress: 60,
      monthlyAnalyzedGoal: 15,
      monthlyAnalyzed: 8,
      analyzedProgress: 53,
      weeklyTrend: [
        { date: '2024-01-15', generated: 2, analyzed: 1, total: 3 },
        { date: '2024-01-16', generated: 1, analyzed: 2, total: 3 },
        { date: '2024-01-17', generated: 3, analyzed: 1, total: 4 },
        { date: '2024-01-18', generated: 2, analyzed: 2, total: 4 },
        { date: '2024-01-19', generated: 1, analyzed: 1, total: 2 },
        { date: '2024-01-20', generated: 2, analyzed: 0, total: 2 },
        { date: '2024-01-21', generated: 1, analyzed: 1, total: 2 }
      ]
    },
    recentActivities: [
      {
        id: '1',
        type: 'GENERATED',
        title: 'Contract Agreement',
        description: 'Generated new legal document: Contract Agreement',
        timestamp: new Date().toISOString(),
        icon: 'document',
        color: 'blue'
      },
      {
        id: '2',
        type: 'ANALYZED',
        title: 'Legal Brief',
        description: 'Analyzed document: Legal Brief',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        icon: 'analyze',
        color: 'green'
      },
      {
        id: '3',
        type: 'LOGIN',
        title: 'User Login',
        description: 'Successfully logged into the system',
        timestamp: new Date(Date.now() - 7200000).toISOString(),
        icon: 'login',
        color: 'purple'
      }
    ],
    userPreferences: {
      preferredDocumentTypes: ['Contracts', 'Agreements', 'Legal Briefs'],
      activityPatterns: {
        mostActiveHours: [9, 10, 14, 15],
        mostActiveDays: ['Monday', 'Wednesday', 'Friday']
      },
      usageStats: {
        totalDocuments: 45,
        monthlyDocuments: 12,
        averagePerMonth: 15
      }
    }
  });

  const getIcon = (iconName, color) => {
    const iconStyle = { fontSize: '24px', color: getColorValue(color) };
    
    switch (iconName) {
      case 'document':
        return <FileTextOutlined style={iconStyle} />;
      case 'analyze':
        return <SearchOutlined style={iconStyle} />;
      case 'session':
        return <ClockCircleOutlined style={iconStyle} />;
      case 'verified':
        return <CheckCircleOutlined style={iconStyle} />;
      case 'login':
        return <UserOutlined style={iconStyle} />;
      default:
        return <BarChartOutlined style={iconStyle} />;
    }
  };

  const getColorValue = (color) => {
    switch (color) {
      case 'blue':
        return '#1890ff';
      case 'green':
        return '#52c41a';
      case 'orange':
        return '#fa8c16';
      case 'red':
        return '#f5222d';
      case 'purple':
        return '#722ed1';
      default:
        return '#8c8c8c';
    }
  };

  const getActivityIcon = (iconName, color) => {
    const iconStyle = { fontSize: '16px', color: getColorValue(color) };
    
    switch (iconName) {
      case 'document':
        return <FileTextOutlined style={iconStyle} />;
      case 'analyze':
        return <SearchOutlined style={iconStyle} />;
      case 'login':
        return <UserOutlined style={iconStyle} />;
      default:
        return <BarChartOutlined style={iconStyle} />;
    }
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" />
        <p>Loading dashboard...</p>
      </div>
    );
  }

  if (error && !dashboardData) {
    return (
      <Alert
        message="Error"
        description={error}
        type="error"
        showIcon
        style={{ margin: '20px' }}
      />
    );
  }

  return (
    <div style={{ padding: '24px', backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{ margin: 0, color: '#262626' }}>Dashboard</h1>
        <p style={{ margin: '8px 0 0 0', color: '#8c8c8c' }}>
          Welcome back, {user?.username || 'User'}! Here's your activity overview.
        </p>
      </div>

      {/* Metrics Cards */}
      <Row gutter={[16, 16]} style={{ marginBottom: '24px' }}>
        <Col xs={24} sm={12} lg={6}>
          <Card 
            style={{ 
              borderRadius: '12px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              border: 'none'
            }}
            bodyStyle={{ padding: '20px' }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ margin: 0, color: '#8c8c8c', fontSize: '14px' }}>
                  {dashboardData?.documentsGenerated?.title || 'Documents Generated'}
                </p>
                <h2 style={{ margin: '8px 0', color: getColorValue('blue'), fontSize: '28px', fontWeight: 'bold' }}>
                  {dashboardData?.documentsGenerated?.value || 0}
                </h2>
                <Tag 
                  color={dashboardData?.documentsGenerated?.changeType === 'positive' ? 'green' : 'red'}
                  style={{ margin: 0, borderRadius: '12px' }}
                >
                  {dashboardData?.documentsGenerated?.change || '+0%'}
                </Tag>
              </div>
              <div style={{ 
                backgroundColor: '#e6f7ff', 
                padding: '12px', 
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                {getIcon('document', 'blue')}
              </div>
            </div>
          </Card>
        </Col>

        <Col xs={24} sm={12} lg={6}>
          <Card 
            style={{ 
              borderRadius: '12px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              border: 'none'
            }}
            bodyStyle={{ padding: '20px' }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ margin: 0, color: '#8c8c8c', fontSize: '14px' }}>
                  {dashboardData?.documentsAnalyzed?.title || 'Documents Analyzed'}
                </p>
                <h2 style={{ margin: '8px 0', color: getColorValue('green'), fontSize: '28px', fontWeight: 'bold' }}>
                  {dashboardData?.documentsAnalyzed?.value || 0}
                </h2>
                <Tag 
                  color={dashboardData?.documentsAnalyzed?.changeType === 'positive' ? 'green' : 'red'}
                  style={{ margin: 0, borderRadius: '12px' }}
                >
                  {dashboardData?.documentsAnalyzed?.change || '+0%'}
                </Tag>
              </div>
              <div style={{ 
                backgroundColor: '#f6ffed', 
                padding: '12px', 
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                {getIcon('analyze', 'green')}
              </div>
            </div>
          </Card>
        </Col>

        <Col xs={24} sm={12} lg={6}>
          <Card 
            style={{ 
              borderRadius: '12px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              border: 'none'
            }}
            bodyStyle={{ padding: '20px' }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ margin: 0, color: '#8c8c8c', fontSize: '14px' }}>
                  {dashboardData?.activeSessions?.title || 'Active Sessions'}
                </p>
                <h2 style={{ margin: '8px 0', color: getColorValue('orange'), fontSize: '28px', fontWeight: 'bold' }}>
                  {dashboardData?.activeSessions?.value || 0}
                </h2>
                <Tag 
                  color={dashboardData?.activeSessions?.changeType === 'positive' ? 'green' : 'red'}
                  style={{ margin: 0, borderRadius: '12px' }}
                >
                  {dashboardData?.activeSessions?.change || '+0'}
                </Tag>
              </div>
              <div style={{ 
                backgroundColor: '#fff7e6', 
                padding: '12px', 
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                {getIcon('session', 'orange')}
              </div>
            </div>
          </Card>
        </Col>

        <Col xs={24} sm={12} lg={6}>
          <Card 
            style={{ 
              borderRadius: '12px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              border: 'none'
            }}
            bodyStyle={{ padding: '20px' }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ margin: 0, color: '#8c8c8c', fontSize: '14px' }}>
                  {dashboardData?.verificationStatus?.title || 'Verification Status'}
                </p>
                <h2 style={{ 
                  margin: '8px 0', 
                  color: getColorValue(dashboardData?.verificationStatus?.color || 'green'), 
                  fontSize: '20px', 
                  fontWeight: 'bold' 
                }}>
                  {dashboardData?.verificationStatus?.status || 'Verified'}
                </h2>
                <Tag 
                  color={dashboardData?.verificationStatus?.changeType === 'positive' ? 'green' : 'red'}
                  style={{ margin: 0, borderRadius: '12px' }}
                >
                  {dashboardData?.verificationStatus?.subStatus || 'Active'}
                </Tag>
              </div>
              <div style={{ 
                backgroundColor: dashboardData?.verificationStatus?.color === 'green' ? '#f6ffed' : '#fff2f0', 
                padding: '12px', 
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                {getIcon('verified', dashboardData?.verificationStatus?.color || 'green')}
              </div>
            </div>
          </Card>
        </Col>
      </Row>

      {/* Progress Overview and Recent Activities */}
      <Row gutter={[16, 16]}>
        <Col xs={24} lg={12}>
          <Card 
            title={
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <RiseOutlined style={{ color: '#1890ff' }} />
                <span>Progress Overview</span>
              </div>
            }
            style={{ 
              borderRadius: '12px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              border: 'none'
            }}
          >
            <div style={{ marginBottom: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span>Documents Generated</span>
                <span>{dashboardData?.progressOverview?.monthlyGenerated || 0}/{dashboardData?.progressOverview?.monthlyGeneratedGoal || 20}</span>
              </div>
              <Progress 
                percent={dashboardData?.progressOverview?.generatedProgress || 0} 
                strokeColor="#1890ff"
                showInfo={false}
              />
            </div>
            
            <div style={{ marginBottom: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span>Documents Analyzed</span>
                <span>{dashboardData?.progressOverview?.monthlyAnalyzed || 0}/{dashboardData?.progressOverview?.monthlyAnalyzedGoal || 15}</span>
              </div>
              <Progress 
                percent={dashboardData?.progressOverview?.analyzedProgress || 0} 
                strokeColor="#52c41a"
                showInfo={false}
              />
            </div>

            <div style={{ marginTop: '20px' }}>
              <h4 style={{ marginBottom: '12px' }}>Weekly Activity Trend</h4>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#8c8c8c' }}>
                {dashboardData?.progressOverview?.weeklyTrend?.map((day, index) => (
                  <div key={index} style={{ textAlign: 'center' }}>
                    <div style={{ fontWeight: 'bold', color: '#262626' }}>{day.total}</div>
                    <div>{new Date(day.date).toLocaleDateString('en-US', { weekday: 'short' })}</div>
                  </div>
                )) || Array.from({ length: 7 }, (_, i) => (
                  <div key={i} style={{ textAlign: 'center' }}>
                    <div style={{ fontWeight: 'bold', color: '#262626' }}>0</div>
                    <div>Day {i + 1}</div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </Col>

        <Col xs={24} lg={12}>
          <Card 
            title={
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <CalendarOutlined style={{ color: '#1890ff' }} />
                <span>Recent Activities</span>
              </div>
            }
            style={{ 
              borderRadius: '12px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              border: 'none'
            }}
          >
            <List
              dataSource={dashboardData?.recentActivities || []}
              renderItem={(activity) => (
                <List.Item style={{ padding: '12px 0', borderBottom: '1px solid #f0f0f0' }}>
                  <List.Item.Meta
                    avatar={
                      <Avatar 
                        style={{ 
                          backgroundColor: getColorValue(activity.color),
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        {getActivityIcon(activity.icon, activity.color)}
                      </Avatar>
                    }
                    title={
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontWeight: '500' }}>{activity.title}</span>
                        <span style={{ fontSize: '12px', color: '#8c8c8c' }}>
                          {formatTime(activity.timestamp)}
                        </span>
                      </div>
                    }
                    description={
                      <div style={{ color: '#8c8c8c', fontSize: '13px' }}>
                        {activity.description}
                      </div>
                    }
                  />
                </List.Item>
              )}
            />
          </Card>
        </Col>
      </Row>

      {/* User Preferences */}
      <Row gutter={[16, 16]} style={{ marginTop: '16px' }}>
        <Col xs={24}>
          <Card 
            title={
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <UserOutlined style={{ color: '#1890ff' }} />
                <span>User Preferences & Usage</span>
              </div>
            }
            style={{ 
              borderRadius: '12px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              border: 'none'
            }}
          >
            <Row gutter={[16, 16]}>
              <Col xs={24} md={8}>
                <h4>Preferred Document Types</h4>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {dashboardData?.userPreferences?.preferredDocumentTypes?.map((type, index) => (
                    <Tag key={index} color="blue" style={{ borderRadius: '12px' }}>
                      {type}
                    </Tag>
                  )) || ['Contracts', 'Agreements'].map((type, index) => (
                    <Tag key={index} color="blue" style={{ borderRadius: '12px' }}>
                      {type}
                    </Tag>
                  ))}
                </div>
              </Col>
              
              <Col xs={24} md={8}>
                <h4>Most Active Hours</h4>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {dashboardData?.userPreferences?.activityPatterns?.mostActiveHours?.map((hour, index) => (
                    <Tag key={index} color="green" style={{ borderRadius: '12px' }}>
                      {hour}:00
                    </Tag>
                  )) || [9, 10, 14, 15].map((hour, index) => (
                    <Tag key={index} color="green" style={{ borderRadius: '12px' }}>
                      {hour}:00
                    </Tag>
                  ))}
                </div>
              </Col>
              
              <Col xs={24} md={8}>
                <h4>Usage Statistics</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Total Documents:</span>
                    <span style={{ fontWeight: 'bold' }}>
                      {dashboardData?.userPreferences?.usageStats?.totalDocuments || 0}
                    </span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Monthly Average:</span>
                    <span style={{ fontWeight: 'bold' }}>
                      {dashboardData?.userPreferences?.usageStats?.averagePerMonth || 0}
                    </span>
                  </div>
                </div>
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default Dashboard;
