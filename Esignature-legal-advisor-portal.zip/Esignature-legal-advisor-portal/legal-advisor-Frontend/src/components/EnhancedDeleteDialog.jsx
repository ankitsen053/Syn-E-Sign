import { useState, useEffect } from 'react';
import { AlertTriangle, FileText, Calendar, Edit, Hash, X, Trash2 } from 'lucide-react';
import { documentAPI } from '../services/api';

const EnhancedDeleteDialog = ({ 
  isOpen, 
  onClose, 
  onConfirm, 
  documentId, 
  documentTitle,
  type = "single" // "single" or "bulk"
}) => {
  const [documentDetails, setDocumentDetails] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [confirmText, setConfirmText] = useState('');
  const [isConfirmEnabled, setIsConfirmEnabled] = useState(false);

  const requiredConfirmText = type === "single" ? "DELETE" : "DELETE ALL";

  useEffect(() => {
    if (isOpen && type === "single" && documentId) {
      loadDocumentDetails();
    }
  }, [isOpen, documentId, type]);

  useEffect(() => {
    setIsConfirmEnabled(confirmText.toUpperCase() === requiredConfirmText);
  }, [confirmText, requiredConfirmText]);

  const loadDocumentDetails = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await documentAPI.confirmDelete(documentId);
      if (response.data.success) {
        setDocumentDetails(response.data);
      } else {
        setError('Failed to load document details');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to load document details');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setDocumentDetails(null);
    setError('');
    setConfirmText('');
    onClose();
  };

  const handleConfirm = () => {
    onConfirm();
    handleClose();
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={handleClose}></div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen">&#8203;</span>

        <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
          <div className="sm:flex sm:items-start">
            <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10">
              <AlertTriangle className="h-6 w-6 text-red-600" />
            </div>
            <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left flex-1">
              <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                {type === "single" ? "Delete Document" : "Delete Multiple Documents"}
              </h3>

              {type === "single" && loading && (
                <div className="flex justify-center py-4">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-red-600"></div>
                </div>
              )}

              {type === "single" && error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-3 py-2 rounded-lg mb-4">
                  {error}
                </div>
              )}

              {type === "single" && documentDetails && (
                <div className="space-y-4">
                  {/* Document Details */}
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <FileText className="h-5 w-5 text-gray-600 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-gray-900 truncate">
                          {documentDetails.document.title}
                        </h4>
                        <p className="text-sm text-gray-600">
                          Type: {documentDetails.document.type}
                        </p>
                        <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-3 w-3" />
                            <span>{formatDate(documentDetails.document.createdAt)}</span>
                          </div>
                          {documentDetails.document.isEdited && (
                            <div className="flex items-center space-x-1">
                              <Edit className="h-3 w-3" />
                              <span>Modified</span>
                            </div>
                          )}
                          <div className="flex items-center space-x-1">
                            <Hash className="h-3 w-3" />
                            <span>v{documentDetails.document.version}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Content Preview */}
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <p className="text-xs text-gray-500 mb-1">Content Preview:</p>
                      <p className="text-sm text-gray-700 font-mono bg-white p-2 rounded border">
                        {documentDetails.document.contentPreview}
                      </p>
                    </div>
                  </div>

                  {/* Warnings */}
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h5 className="font-medium text-red-900 mb-2">⚠️ Warning</h5>
                    <ul className="list-disc list-inside space-y-1 text-sm text-red-700">
                      {documentDetails.warnings.map((warning, index) => (
                        <li key={index}>{warning}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {type === "bulk" && (
                <div className="space-y-4">
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h5 className="font-medium text-red-900 mb-2">⚠️ Bulk Delete Warning</h5>
                    <ul className="list-disc list-inside space-y-1 text-sm text-red-700">
                      <li>You are about to delete multiple documents</li>
                      <li>This action cannot be undone</li>
                      <li>All selected documents and their data will be permanently removed</li>
                    </ul>
                  </div>
                </div>
              )}

              {/* Confirmation Input */}
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type <span className="font-bold text-red-600">{requiredConfirmText}</span> to confirm:
                </label>
                <input
                  type="text"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 ${
                    isConfirmEnabled
                      ? 'border-red-300 focus:ring-red-500 focus:border-red-500'
                      : 'border-gray-300 focus:ring-gray-500 focus:border-gray-500'
                  }`}
                  placeholder={`Type "${requiredConfirmText}" here`}
                />
              </div>
            </div>
          </div>

          <div className="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse">
            <button
              type="button"
              onClick={handleConfirm}
              disabled={!isConfirmEnabled || loading}
              className={`w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 text-base font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm ${
                isConfirmEnabled && !loading
                  ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500'
                  : 'bg-gray-400 cursor-not-allowed'
              }`}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              {loading ? 'Loading...' : `Delete ${type === "bulk" ? "All" : "Document"}`}
            </button>
            <button
              type="button"
              onClick={handleClose}
              className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:w-auto sm:text-sm"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedDeleteDialog;
