import React, { useState, useEffect } from 'react';
import { 
  Card, 
  Form, 
  Button, 
  Alert, 
  InputGroup, 
  Row, 
  Col, 
  Modal,
  Badge,
  Spinner,
  Table,
  Toast,
  ToastContainer
} from 'react-bootstrap';
import { 
  FaShieldAlt, 
  FaIdCard, 
  FaUser, 
  FaCar, 
  FaPassport, 
  FaCheck, 
  FaTimes, 
  FaEye,
  FaSync,
  FaCloudDownloadAlt
} from 'react-icons/fa';

const DigiLockerVerification = () => {
  const [digiLockerId, setDigiLockerId] = useState('');
  const [isValidId, setIsValidId] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [previewData, setPreviewData] = useState(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [fetchOptions, setFetchOptions] = useState({
    fetchAadhaar: true,
    fetchPan: true,
    fetchDrivingLicense: false,
    fetchPassport: false
  });

  // Format DigiLocker ID with hyphens
  const formatDigiLockerId = (value) => {
    const cleaned = value.replace(/[^a-fA-F0-9]/g, '');
    if (cleaned.length <= 8) return cleaned;
    if (cleaned.length <= 12) return `${cleaned.slice(0, 8)}-${cleaned.slice(8)}`;
    if (cleaned.length <= 16) return `${cleaned.slice(0, 8)}-${cleaned.slice(8, 12)}-${cleaned.slice(12)}`;
    if (cleaned.length <= 20) return `${cleaned.slice(0, 8)}-${cleaned.slice(8, 12)}-${cleaned.slice(12, 16)}-${cleaned.slice(16)}`;
    return `${cleaned.slice(0, 8)}-${cleaned.slice(8, 12)}-${cleaned.slice(12, 16)}-${cleaned.slice(16, 20)}-${cleaned.slice(20, 32)}`;
  };

  // Validate DigiLocker ID format
  const validateDigiLockerId = (id) => {
    const pattern = /^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$/;
    return pattern.test(id) && id.length === 36;
  };

  // Handle DigiLocker ID input change
  const handleDigiLockerIdChange = (e) => {
    const formatted = formatDigiLockerId(e.target.value);
    setDigiLockerId(formatted);
    setIsValidId(validateDigiLockerId(formatted));
  };

  // Get current user's verification status
  const fetchVerificationStatus = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8081/api/digilocker/status', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setVerificationStatus(data);
      }
    } catch (error) {
      console.error('Error fetching verification status:', error);
    }
  };

  // Preview DigiLocker documents without saving
  const previewDocuments = async () => {
    if (!isValidId) {
      setError('Please enter a valid DigiLocker ID');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8081/api/digilocker/preview', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          digiLockerId,
          ...fetchOptions
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setPreviewData(data);
        setShowPreview(true);
      } else {
        setError(data.message || 'Preview failed');
      }
    } catch (error) {
      setError('Error connecting to DigiLocker service');
      console.error('Preview error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Submit DigiLocker verification
  const submitVerification = async () => {
    if (!isValidId) {
      setError('Please enter a valid DigiLocker ID');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8081/api/digilocker/verify', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          digiLockerId,
          ...fetchOptions,
          consent: 'Y',
          consentText: 'I hereby give my consent to fetch my documents from DigiLocker for verification purposes'
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess(data.message);
        setToastMessage('DigiLocker verification completed successfully!');
        setShowToast(true);
        fetchVerificationStatus();
        setShowPreview(false);
      } else {
        setError(data.message || 'Verification failed');
      }
    } catch (error) {
      setError('Error connecting to DigiLocker service');
      console.error('Verification error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchVerificationStatus();
  }, []);

  const DocumentIcon = ({ type }) => {
    switch (type?.toUpperCase()) {
      case 'AADHAAR': return <FaIdCard className="text-primary" />;
      case 'PAN': return <FaUser className="text-success" />;
      case 'DRIVING_LICENSE': return <FaCar className="text-warning" />;
      case 'PASSPORT': return <FaPassport className="text-info" />;
      default: return <FaShieldAlt className="text-secondary" />;
    }
  };

  return (
    <div className="container mt-4">
      <Card className="shadow-sm">
        <Card.Header className="bg-primary text-white">
          <h4 className="mb-0">
            <FaShieldAlt className="me-2" />
            DigiLocker Verification
          </h4>
          <small>Verify your identity using your 36-character DigiLocker ID</small>
        </Card.Header>

        <Card.Body>
          {/* Current Status */}
          {verificationStatus && (
            <Alert variant={verificationStatus.verified ? 'success' : 'info'} className="mb-4">
              <Row>
                <Col md={6}>
                  <strong>Status:</strong> {verificationStatus.status || 'PENDING'}
                </Col>
                <Col md={6}>
                  <strong>Documents Found:</strong> {verificationStatus.documentsFound || 0}
                </Col>
              </Row>
              {verificationStatus.verified && (
                <Row className="mt-2">
                  <Col>
                    <Badge bg="success" className="me-2">
                      <FaCheck className="me-1" />
                      Aadhaar: {verificationStatus.aadhaarAvailable ? 'Available' : 'Not Found'}
                    </Badge>
                    <Badge bg="success" className="me-2">
                      <FaCheck className="me-1" />
                      PAN: {verificationStatus.panAvailable ? 'Available' : 'Not Found'}
                    </Badge>
                    <Badge bg="secondary" className="me-2">
                      DL: {verificationStatus.drivingLicenseAvailable ? 'Available' : 'Not Found'}
                    </Badge>
                    <Badge bg="secondary">
                      Passport: {verificationStatus.passportAvailable ? 'Available' : 'Not Found'}
                    </Badge>
                  </Col>
                </Row>
              )}
            </Alert>
          )}

          {/* DigiLocker ID Input */}
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>
                <strong>DigiLocker ID (36 characters)</strong>
              </Form.Label>
              <InputGroup>
                <Form.Control
                  type="text"
                  value={digiLockerId}
                  onChange={handleDigiLockerIdChange}
                  placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                  maxLength={36}
                  className={isValidId ? 'is-valid' : (digiLockerId ? 'is-invalid' : '')}
                  disabled={verificationStatus?.verified}
                />
                <InputGroup.Text>
                  {isValidId ? (
                    <FaCheck className="text-success" />
                  ) : (
                    <FaTimes className="text-danger" />
                  )}
                </InputGroup.Text>
              </InputGroup>
              <Form.Text className="text-muted">
                Format: 8 chars - 4 chars - 4 chars - 4 chars - 12 chars (hexadecimal)
              </Form.Text>
            </Form.Group>

            {/* Document Selection */}
            <Form.Group className="mb-3">
              <Form.Label><strong>Documents to Fetch</strong></Form.Label>
              <Row>
                <Col md={6}>
                  <Form.Check
                    type="checkbox"
                    label={<><FaIdCard className="me-2 text-primary" />Aadhaar Card</>}
                    checked={fetchOptions.fetchAadhaar}
                    onChange={(e) => setFetchOptions({...fetchOptions, fetchAadhaar: e.target.checked})}
                    disabled={verificationStatus?.verified}
                  />
                </Col>
                <Col md={6}>
                  <Form.Check
                    type="checkbox"
                    label={<><FaUser className="me-2 text-success" />PAN Card</>}
                    checked={fetchOptions.fetchPan}
                    onChange={(e) => setFetchOptions({...fetchOptions, fetchPan: e.target.checked})}
                    disabled={verificationStatus?.verified}
                  />
                </Col>
                <Col md={6}>
                  <Form.Check
                    type="checkbox"
                    label={<><FaCar className="me-2 text-warning" />Driving License</>}
                    checked={fetchOptions.fetchDrivingLicense}
                    onChange={(e) => setFetchOptions({...fetchOptions, fetchDrivingLicense: e.target.checked})}
                    disabled={verificationStatus?.verified}
                  />
                </Col>
                <Col md={6}>
                  <Form.Check
                    type="checkbox"
                    label={<><FaPassport className="me-2 text-info" />Passport</>}
                    checked={fetchOptions.fetchPassport}
                    onChange={(e) => setFetchOptions({...fetchOptions, fetchPassport: e.target.checked})}
                    disabled={verificationStatus?.verified}
                  />
                </Col>
              </Row>
            </Form.Group>

            {/* Action Buttons */}
            <Row>
              <Col md={6}>
                <Button
                  variant="outline-primary"
                  onClick={previewDocuments}
                  disabled={!isValidId || isLoading || verificationStatus?.verified}
                  className="w-100 mb-2"
                >
                  {isLoading ? (
                    <><Spinner size="sm" className="me-2" />Previewing...</>
                  ) : (
                    <><FaEye className="me-2" />Preview Documents</>
                  )}
                </Button>
              </Col>
              <Col md={6}>
                <Button
                  variant="primary"
                  onClick={submitVerification}
                  disabled={!isValidId || isLoading || verificationStatus?.verified}
                  className="w-100 mb-2"
                >
                  {isLoading ? (
                    <><Spinner size="sm" className="me-2" />Verifying...</>
                  ) : (
                    <><FaCloudDownloadAlt className="me-2" />Verify & Fetch Documents</>
                  )}
                </Button>
              </Col>
            </Row>

            {/* Status Refresh */}
            <div className="text-center mt-3">
              <Button
                variant="link"
                onClick={fetchVerificationStatus}
                className="text-decoration-none"
              >
                <FaSync className="me-1" />
                Refresh Status
              </Button>
            </div>
          </Form>

          {/* Error/Success Messages */}
          {error && (
            <Alert variant="danger" className="mt-3">
              <FaTimes className="me-2" />
              {error}
            </Alert>
          )}

          {success && (
            <Alert variant="success" className="mt-3">
              <FaCheck className="me-2" />
              {success}
            </Alert>
          )}
        </Card.Body>
      </Card>

      {/* Preview Modal */}
      <Modal show={showPreview} onHide={() => setShowPreview(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>
            <FaEye className="me-2" />
            DigiLocker Documents Preview
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {previewData && (
            <>
              <Alert variant="info">
                <strong>Total Documents Found:</strong> {previewData.totalDocuments}
              </Alert>
              
              {previewData.documents && previewData.documents.length > 0 && (
                <Table striped bordered hover responsive>
                  <thead>
                    <tr>
                      <th>Document</th>
                      <th>Type</th>
                      <th>Issuer</th>
                      <th>Issue Date</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {previewData.documents.map((doc, index) => (
                      <tr key={index}>
                        <td>
                          <DocumentIcon type={doc.documentType} />
                          <span className="ms-2">{doc.documentName}</span>
                        </td>
                        <td><Badge bg="secondary">{doc.documentType}</Badge></td>
                        <td>{doc.issuer}</td>
                        <td>{doc.issueDate}</td>
                        <td>
                          <Badge bg={doc.verified ? "success" : "warning"}>
                            {doc.verified ? "Verified" : "Pending"}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              )}

              <hr />
              
              {/* Document Summary */}
              <Row>
                <Col md={6}>
                  <h6>Available Documents:</h6>
                  <ul className="list-unstyled">
                    <li>
                      <Badge bg={previewData.aadhaarDocument ? "success" : "secondary"} className="me-2">
                        <FaIdCard />
                      </Badge>
                      Aadhaar: {previewData.aadhaarDocument ? "Available" : "Not Found"}
                    </li>
                    <li>
                      <Badge bg={previewData.panDocument ? "success" : "secondary"} className="me-2">
                        <FaUser />
                      </Badge>
                      PAN: {previewData.panDocument ? "Available" : "Not Found"}
                    </li>
                    <li>
                      <Badge bg={previewData.drivingLicenseDocument ? "success" : "secondary"} className="me-2">
                        <FaCar />
                      </Badge>
                      Driving License: {previewData.drivingLicenseDocument ? "Available" : "Not Found"}
                    </li>
                    <li>
                      <Badge bg={previewData.passportDocument ? "success" : "secondary"} className="me-2">
                        <FaPassport />
                      </Badge>
                      Passport: {previewData.passportDocument ? "Available" : "Not Found"}
                    </li>
                  </ul>
                </Col>
                <Col md={6}>
                  <h6>Verification Time:</h6>
                  <p className="text-muted">
                    {new Date(previewData.verificationTime).toLocaleString()}
                  </p>
                </Col>
              </Row>
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowPreview(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={submitVerification} disabled={isLoading}>
            {isLoading ? (
              <><Spinner size="sm" className="me-2" />Processing...</>
            ) : (
              <><FaCloudDownloadAlt className="me-2" />Proceed with Verification</>
            )}
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Toast Notifications */}
      <ToastContainer position="top-end" className="p-3">
        <Toast show={showToast} onClose={() => setShowToast(false)} delay={5000} autohide>
          <Toast.Header>
            <FaCheck className="text-success me-2" />
            <strong className="me-auto">Success</strong>
          </Toast.Header>
          <Toast.Body>{toastMessage}</Toast.Body>
        </Toast>
      </ToastContainer>
    </div>
  );
};

export default DigiLockerVerification;
