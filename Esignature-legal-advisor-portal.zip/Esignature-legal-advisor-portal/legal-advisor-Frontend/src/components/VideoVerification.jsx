import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Camera, RotateCcw, Video, VideoOff, CheckCircle, XCircle, Upload, AlertTriangle, Settings, RefreshCw, FileVideo } from 'lucide-react';
import { verificationAPI } from '../services/api';

const VideoVerification = ({ onComplete }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [useFrontCamera, setUseFrontCamera] = useState(true);
  const [recordedBlob, setRecordedBlob] = useState(null);
  const [recordedUrl, setRecordedUrl] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState('prompt'); // 'checking', 'granted', 'denied', 'prompt'

  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const recordingIntervalRef = useRef(null);



  // Camera constraints with ternary operator for front/back camera
  const getCameraConstraints = useCallback(() => ({
    video: {
      facingMode: useFrontCamera ? 'user' : 'environment',
      width: { ideal: 1280 },
      height: { ideal: 720 }
    },
    audio: true
  }), [useFrontCamera]);

  // Check browser support for camera
  const checkBrowserSupport = () => {
    // Check for HTTPS (required for camera access in most browsers)
    const isSecure = window.location.protocol === 'https:' || window.location.hostname === 'localhost';
    
    // Check for navigator.mediaDevices support
    const hasMediaDevices = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
    
    // Check for older getUserMedia support as fallback
    const hasLegacyUserMedia = !!(navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia);
    
    return {
      isSecure,
      hasMediaDevices,
      hasLegacyUserMedia,
      isSupported: hasMediaDevices || hasLegacyUserMedia
    };
  };

  // Get legacy getUserMedia if modern API is not available
  const getLegacyUserMedia = () => {
    return navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;
  };

  // Start camera with comprehensive browser support
  const startCamera = useCallback(async () => {
    try {
      setLoading(true);
      setError('');

      if (streamRef.current) {
        stopCamera();
      }

      // Check browser support
      const support = checkBrowserSupport();
      
      if (!support.isSupported) {
        throw new Error('BROWSER_NOT_SUPPORTED');
      }

      if (!support.isSecure) {
        throw new Error('INSECURE_CONTEXT');
      }

      let stream;

      // Try modern API first
      if (support.hasMediaDevices) {
        stream = await navigator.mediaDevices.getUserMedia(getCameraConstraints());
      } else if (support.hasLegacyUserMedia) {
        // Fallback to legacy API
        const legacyGetUserMedia = getLegacyUserMedia();
        stream = await new Promise((resolve, reject) => {
          legacyGetUserMedia.call(navigator, getCameraConstraints(), resolve, reject);
        });
      }

      if (!stream) {
        throw new Error('NO_STREAM');
      }

      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      
      setIsCameraOn(true);
      setPermissionStatus('granted');
      setError('');
    } catch (err) {
      console.error('Camera access error:', err);
      setIsCameraOn(false);
      
      // Provide specific error messages based on error type
      let errorMessage = 'Camera access failed. ';
      
      if (err.message === 'BROWSER_NOT_SUPPORTED') {
        errorMessage = 'Your browser does not support camera access. Please use Chrome, Firefox, Safari, or Edge.';
        setPermissionStatus('denied');
      } else if (err.message === 'INSECURE_CONTEXT') {
        errorMessage = 'Camera access requires HTTPS. Please access this page over HTTPS or use localhost.';
        setPermissionStatus('denied');
      } else if (err.name === 'NotAllowedError') {
        errorMessage = 'Camera permission denied. Please click "Allow" when prompted or enable camera permissions in your browser settings.';
        setPermissionStatus('prompt');
      } else if (err.name === 'NotFoundError') {
        errorMessage = 'No camera device found. Please connect a camera and refresh the page.';
        setPermissionStatus('denied');
      } else if (err.name === 'NotReadableError') {
        errorMessage = 'Camera is already in use by another application. Please close other apps using the camera and try again.';
        setPermissionStatus('denied');
      } else if (err.name === 'OverconstrainedError') {
        errorMessage = 'Camera does not support the requested settings. Trying with basic settings...';
        setPermissionStatus('granted');
        // Try with basic constraints
        setTimeout(() => {
          tryBasicCamera();
        }, 1000);
        return;
      } else if (err.name === 'SecurityError') {
        errorMessage = 'Camera access blocked due to security restrictions. Please ensure you are using HTTPS.';
        setPermissionStatus('denied');
      } else if (err.name === 'TypeError' && err.message.includes('getUserMedia')) {
        errorMessage = 'Camera API is not available. Please use a modern browser or check your browser settings.';
        setPermissionStatus('denied');
      } else {
        errorMessage = 'Unable to access camera. Please check your device, browser settings, and try refreshing the page.';
        setPermissionStatus('prompt');
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  }, [getCameraConstraints]);

  // Fallback function to try basic camera settings
  const tryBasicCamera = async () => {
    try {
      setLoading(true);
      setError('Trying with basic camera settings...');
      
      const basicConstraints = {
        video: true,
        audio: true
      };
      
      // Check browser support again
      const support = checkBrowserSupport();
      let stream;

      if (support.hasMediaDevices) {
        stream = await navigator.mediaDevices.getUserMedia(basicConstraints);
      } else if (support.hasLegacyUserMedia) {
        const legacyGetUserMedia = getLegacyUserMedia();
        stream = await new Promise((resolve, reject) => {
          legacyGetUserMedia.call(navigator, basicConstraints, resolve, reject);
        });
      }

      if (stream) {
        streamRef.current = stream;
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        
        setIsCameraOn(true);
        setPermissionStatus('granted');
        setError('');
        setSuccess('Camera started with basic settings.');
      } else {
        throw new Error('Failed to get camera stream');
      }
    } catch (err) {
      console.error('Basic camera access error:', err);
      setError('Unable to access camera with any settings. Please check your device and permissions.');
      setPermissionStatus('denied');
    } finally {
      setLoading(false);
    }
  };

  // Add retry mechanism
  const retryCamera = async () => {
    setError('');
    setSuccess('');
    await startCamera();
  };

  // Stop camera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraOn(false);
    setIsRecording(false);
  };

  // Switch camera using ternary operator
  const switchCamera = () => {
    setUseFrontCamera(!useFrontCamera);
  };

  // Start recording
  const startRecording = () => {
    if (!streamRef.current) return;

    const mediaRecorder = new MediaRecorder(streamRef.current, {
      mimeType: 'video/webm;codecs=vp9'
    });

    const chunks = [];
    
    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        chunks.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      setRecordedBlob(blob);
      setRecordedUrl(URL.createObjectURL(blob));
    };

    mediaRecorder.start();
    mediaRecorderRef.current = mediaRecorder;
    setIsRecording(true);
    setRecordingTime(0);

    // Start recording timer
    recordingIntervalRef.current = setInterval(() => {
      setRecordingTime(prev => prev + 1);
    }, 1000);
  };

  // Stop recording
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
      }
    }
  };

  // Upload video with improved error handling
  const uploadVideo = async (blob = recordedBlob, filename = 'verification-video.webm') => {
    if (!blob) {
      setError('No video to upload. Please record a video first.');
      return;
    }

    setIsUploading(true);
    setError('');
    setSuccess('');

    try {
      // Validate video size
      const maxSize = 100 * 1024 * 1024; // 100MB
      if (blob.size > maxSize) {
        throw new Error('Video file is too large. Maximum size is 100MB.');
      }

      // Create FormData for file upload
      const formData = new FormData();
      formData.append('video', blob, filename);
      formData.append('notes', recordedBlob === blob ? 'Live video verification completed' : 'Video file uploaded for verification');
      formData.append('timestamp', new Date().toISOString());

      const response = await verificationAPI.submitVideo(formData);
      
      // Enhanced success handling
      setSuccess('✅ Video verification submitted successfully! Your verification is now being processed.');
      
      // Call completion callback with response data
      if (onComplete) {
        onComplete(response?.data);
      }
    } catch (err) {
      console.error('Upload error:', err);
      
      // Enhanced error handling
      let errorMessage = 'Failed to upload video verification. ';
      
      if (err.message && err.message.includes('too large')) {
        errorMessage = err.message;
      } else if (err.response?.status === 413) {
        errorMessage = 'Video file is too large. Please record a shorter video.';
      } else if (err.response?.status === 400) {
        errorMessage = err.response?.data?.message || 'Invalid video format. Please try recording again.';
      } else if (err.response?.status === 401) {
        errorMessage = 'Authentication failed. Please log in again.';
      } else if (err.response?.status === 500) {
        errorMessage = 'Server error. Please try again later.';
      } else if (err.code === 'NETWORK_ERROR' || !navigator.onLine) {
        errorMessage = 'Network error. Please check your internet connection and try again.';
      } else {
        errorMessage += err.response?.data?.message || err.message || 'Please try again.';
      }
      
      setError(errorMessage);
    } finally {
      setIsUploading(false);
    }
  };



  // Format recording time
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
      }
    };
  }, []);

  // Auto-start camera on mount for professional experience
  useEffect(() => {
    startCamera();
  }, [startCamera]);

  // Restart camera when switching between front/back
  useEffect(() => {
    if (isCameraOn) {
      startCamera();
    }
  }, [useFrontCamera, isCameraOn, startCamera]);

  // Get browser info for display
  const getBrowserInfo = () => {
    const support = checkBrowserSupport();
    const userAgent = navigator.userAgent;
    let browserName = 'Unknown';
    
    if (userAgent.includes('Chrome')) browserName = 'Chrome';
    else if (userAgent.includes('Firefox')) browserName = 'Firefox';
    else if (userAgent.includes('Safari')) browserName = 'Safari';
    else if (userAgent.includes('Edge')) browserName = 'Edge';
    
    return { ...support, browserName };
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Live Video Verification</h2>
        <p className="text-gray-600">
          Please record a short video for identity verification
        </p>
        
        {/* Browser compatibility info */}
        <div className="mt-4 p-3 bg-blue-50 rounded-lg text-sm">
          <div className="flex items-center justify-center space-x-2 text-blue-800">
            <Camera className="h-4 w-4" />
            <span>Browser: {getBrowserInfo().browserName}</span>
            <span>•</span>
            <span>Secure: {getBrowserInfo().isSecure ? '✅' : '❌'}</span>
            <span>•</span>
            <span>Camera API: {getBrowserInfo().hasMediaDevices ? '✅' : getBrowserInfo().hasLegacyUserMedia ? '⚠️' : '❌'}</span>
          </div>
        </div>
      </div>

      {/* Permission Status */}
      {loading && !isCameraOn && (
        <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-lg mb-4 flex items-center space-x-2">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
          <span>Starting camera...</span>
        </div>
      )}

      {permissionStatus === 'prompt' && !isCameraOn && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-4">
          <div className="flex items-start space-x-3">
            <Camera className="h-5 w-5 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="font-semibold mb-1">🎥 Camera Permission Required</h4>
              <p className="text-sm mb-3">Please click "Allow" when prompted to enable camera access for video verification.</p>
              <button
                onClick={startCamera}
                disabled={loading}
                className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors flex items-center space-x-2 disabled:opacity-50"
              >
                <Camera className="h-4 w-4" />
                <span>{loading ? 'Starting...' : 'Enable Camera'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {isCameraOn && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-4 flex items-center space-x-2">
          <CheckCircle className="h-5 w-5 text-green-600" />
          <span className="font-medium">Camera Active - Ready to Record</span>
        </div>
      )}

      {/* Error Messages */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
          <div className="flex items-start space-x-3">
            <XCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="font-semibold mb-1">Camera Error</h4>
              <p className="text-sm mb-3">{error}</p>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={retryCamera}
                  disabled={loading}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors disabled:opacity-50 flex items-center space-x-2"
                >
                  <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                  <span>Retry Camera</span>
                </button>
                {permissionStatus === 'denied' && (
                  <button
                    onClick={() => window.location.reload()}
                    className="bg-gray-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors flex items-center space-x-2"
                  >
                    <RefreshCw className="h-4 w-4" />
                    <span>Refresh Page</span>
                  </button>
                )}
                {error.includes('HTTPS') && (
                  <button
                    onClick={() => window.location.href = window.location.href.replace('http:', 'https:')}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Settings className="h-4 w-4" />
                    <span>Switch to HTTPS</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 flex items-center space-x-2">
          <CheckCircle className="h-5 w-5" />
          <span>{success}</span>
        </div>
      )}

      {/* Video Preview */}
      <div className="relative mb-6">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-64 bg-gray-900 rounded-lg object-cover"
          style={{ display: isCameraOn ? 'block' : 'none' }}
        />
        
        {/* Placeholder when camera is off */}
        {!isCameraOn && (
          <div className="w-full h-64 bg-gradient-to-br from-gray-800 to-gray-900 rounded-lg flex items-center justify-center">
            <div className="text-center text-gray-300">
              <Camera className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">Camera Preview</p>
              <p className="text-sm opacity-75">Click "Start Camera" to begin</p>
            </div>
          </div>
        )}
        
        {/* Recording indicator */}
        {isRecording && (
          <div className="absolute top-4 left-4 bg-red-500 text-white px-4 py-2 rounded-full text-sm font-bold flex items-center space-x-2 animate-pulse shadow-lg">
            <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
            <span>🔴 RECORDING {formatTime(recordingTime)}</span>
          </div>
        )}

        {/* Camera status */}
        {isCameraOn && (
          <div className="absolute top-4 right-4 bg-black bg-opacity-80 text-white px-3 py-1 rounded-full text-sm flex items-center space-x-2 shadow-lg">
            <Camera className="h-4 w-4" />
            <span>{useFrontCamera ? 'Front Camera' : 'Back Camera'}</span>
          </div>
        )}

        {/* Video ready indicator */}
        {recordedBlob && !isRecording && (
          <div className="absolute bottom-4 left-4 bg-green-500 text-white px-4 py-2 rounded-full text-sm font-medium flex items-center space-x-2 shadow-lg">
            <CheckCircle className="h-4 w-4" />
            <span>Video Ready for Upload</span>
          </div>
        )}
      </div>

      {/* Camera Controls */}
      <div className="flex justify-center space-x-4 mb-6">
        {/* Camera Toggle */}
        <button
          onClick={() => isCameraOn ? stopCamera() : startCamera()}
          disabled={loading}
          className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
            isCameraOn 
              ? 'bg-red-500 text-white hover:bg-red-600' 
              : 'bg-green-500 text-white hover:bg-green-600'
          }`}
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
          ) : isCameraOn ? (
            <VideoOff className="h-5 w-5" />
          ) : (
            <Video className="h-5 w-5" />
          )}
          <span className="font-semibold">
            {loading ? 'Starting Camera...' : isCameraOn ? 'Stop Camera' : 'Start Camera'}
          </span>
        </button>

        {/* Switch Camera */}
        <button
          onClick={switchCamera}
          disabled={!isCameraOn}
          className="flex items-center space-x-2 px-6 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <RotateCcw className="h-5 w-5" />
          <span className="font-semibold">Switch Camera</span>
        </button>
      </div>

      {/* Recording Controls */}
      <div className="flex justify-center space-x-4 mb-6">
        {!isRecording ? (
          <button
            onClick={startRecording}
            disabled={!isCameraOn}
            className="flex items-center space-x-2 px-6 py-3 bg-red-500 text-white rounded-lg font-medium hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Camera className="h-5 w-5" />
            <span>Start Recording</span>
          </button>
        ) : (
          <button
            onClick={stopRecording}
            className="flex items-center space-x-2 px-6 py-3 bg-gray-500 text-white rounded-lg font-medium hover:bg-gray-600 transition-colors"
          >
            <VideoOff className="h-5 w-5" />
            <span>Stop Recording</span>
          </button>
        )}
      </div>

      {/* Recorded Video Preview */}
      {recordedUrl && (
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Recorded Video Preview</h3>
          <video
            src={recordedUrl}
            controls
            className="w-full h-48 bg-gray-900 rounded-lg object-cover"
          />
          
          {/* Upload Button */}
          <div className="mt-4 flex justify-center space-x-3">
            <button
              onClick={uploadVideo}
              disabled={isUploading}
              className="flex items-center space-x-2 px-6 py-3 bg-green-500 text-white rounded-lg font-medium hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isUploading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Uploading Video...</span>
                </>
              ) : (
                <>
                  <Upload className="h-5 w-5" />
                  <span>Submit Video Verification</span>
                </>
              )}
            </button>
            
            {/* Re-record button */}
            <button
              onClick={() => {
                setRecordedBlob(null);
                setRecordedUrl('');
                setSuccess('');
                setError('');
              }}
              disabled={isUploading}
              className="flex items-center space-x-2 px-4 py-3 bg-gray-500 text-white rounded-lg font-medium hover:bg-gray-600 disabled:opacity-50 transition-colors"
            >
              <Camera className="h-4 w-4" />
              <span>Record Again</span>
            </button>
          </div>
        </div>
      )}

      {/* Instructions */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-semibold text-blue-900 mb-2">Verification Instructions:</h4>
        <ul className="text-blue-800 text-sm space-y-1">
          <li>• Ensure good lighting and clear visibility</li>
          <li>• Hold your ID document clearly in the video</li>
          <li>• State your full name and date of birth</li>
          <li>• Record for at least 10-15 seconds</li>
          <li>• Keep your face clearly visible throughout</li>
        </ul>
      </div>
    </div>
  );
};

export default VideoVerification;
