import { useState, useEffect } from 'react';
import { signatureAPI } from '../services/api';
import { 
  Users, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Mail, 
  PenTool, 
  Eye, 
  Download,
  RefreshCw,
  Plus,
  Trash2,
  Send
} from 'lucide-react';

const MultiPartySignature = () => {
  const [agreements, setAgreements] = useState([]);
  const [selectedAgreement, setSelectedAgreement] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteEmails, setInviteEmails] = useState('');
  const [inviteMessage, setInviteMessage] = useState('');

  // Create agreement form
  const [createForm, setCreateForm] = useState({
    agreementTitle: '',
    agreementContent: '',
    agreementType: 'Service Agreement',
    partyA: '',
    partyB: '',
    terms: '',
    requiredSigners: [],
    signingInstructions: '',
    expirationDays: 30
  });

  const agreementTypes = [
    'Master Service Agreement',
    'Employment Contract',
    'Independent Contractor Agreement',
    'Non-Disclosure Agreement (NDA)',
    'Partnership Agreement',
    'Joint Venture Agreement',
    'Licensing Agreement',
    'Distribution Agreement',
    'Franchise Agreement',
    'Real Estate Lease Agreement',
    'Equipment Lease Agreement',
    'Purchase and Sale Agreement',
    'Merger and Acquisition Agreement',
    'Shareholder Agreement',
    'Terms of Service Agreement'
  ];

  useEffect(() => {
    loadAgreements();
  }, []);

  const loadAgreements = async () => {
    try {
      setLoading(true);
      const response = await signatureAPI.getUserAgreements();
      if (response.data.success) {
        setAgreements(response.data.agreements);
      }
    } catch (error) {
      setError('Failed to load agreements: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const createMultiPartyAgreement = async () => {
    if (!createForm.agreementTitle || !createForm.agreementContent || createForm.requiredSigners.length === 0) {
      setError('Please fill in all required fields and add at least one signer');
      return;
    }

    try {
      setLoading(true);
      setError('');
      setSuccess('');

      const response = await signatureAPI.createMultiPartyAgreement(createForm);
      
      if (response.data.success) {
        setSuccess('Multi-party agreement created successfully!');
        setShowCreateModal(false);
        setCreateForm({
          agreementTitle: '',
          agreementContent: '',
          agreementType: 'Service Agreement',
          partyA: '',
          partyB: '',
          terms: '',
          requiredSigners: [],
          signingInstructions: '',
          expirationDays: 30
        });
        loadAgreements();
      } else {
        setError('Failed to create agreement');
      }
    } catch (error) {
      setError('Failed to create agreement: ' + (error.response?.data?.message || error.message));
    } finally {
      setLoading(false);
    }
  };

  const sendInvitations = async () => {
    if (!selectedAgreement || !inviteEmails.trim()) {
      setError('Please select an agreement and enter signer emails');
      return;
    }

    try {
      setLoading(true);
      setError('');
      setSuccess('');

      const emails = inviteEmails.split(',').map(email => email.trim()).filter(email => email);
      
      const response = await signatureAPI.sendSigningInvitation(selectedAgreement.id, {
        signerEmails: emails,
        customMessage: inviteMessage
      });
      
      if (response.data.success) {
        setSuccess('Signing invitations sent successfully!');
        setShowInviteModal(false);
        setInviteEmails('');
        setInviteMessage('');
        loadAgreements();
      } else {
        setError('Failed to send invitations');
      }
    } catch (error) {
      setError('Failed to send invitations: ' + (error.response?.data?.message || error.message));
    } finally {
      setLoading(false);
    }
  };

  const addSignerEmail = () => {
    const email = prompt('Enter signer email:');
    if (email && email.includes('@')) {
      setCreateForm(prev => ({
        ...prev,
        requiredSigners: [...prev.requiredSigners, email]
      }));
    }
  };

  const removeSignerEmail = (index) => {
    setCreateForm(prev => ({
      ...prev,
      requiredSigners: prev.requiredSigners.filter((_, i) => i !== index)
    }));
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'FULLY_SIGNED':
      case 'COMPLETED':
        return 'bg-green-100 text-green-800';
      case 'PARTIALLY_SIGNED':
        return 'bg-yellow-100 text-yellow-800';
      case 'PENDING_SIGNATURES':
        return 'bg-blue-100 text-blue-800';
      case 'CANCELLED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'FULLY_SIGNED':
      case 'COMPLETED':
        return <CheckCircle className="h-4 w-4" />;
      case 'PARTIALLY_SIGNED':
        return <Clock className="h-4 w-4" />;
      case 'PENDING_SIGNATURES':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-secondary-900 mb-2">
          Multi-Party E-Signature Portal
        </h1>
        <p className="text-secondary-600">
          Create agreements that require multiple signatures and manage the signing workflow
        </p>
      </div>

      {/* Error/Success Messages */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6 flex items-center space-x-2">
          <AlertCircle className="h-5 w-5" />
          <span>{error}</span>
        </div>
      )}
      
      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6 flex items-center space-x-2">
          <CheckCircle className="h-5 w-5" />
          <span>{success}</span>
        </div>
      )}

      {/* Action Buttons */}
      <div className="mb-6 flex space-x-4">
        <button
          onClick={() => setShowCreateModal(true)}
          className="btn-primary flex items-center space-x-2"
        >
          <Plus className="h-5 w-5" />
          <span>Create Multi-Party Agreement</span>
        </button>
        
        <button
          onClick={loadAgreements}
          className="btn-secondary flex items-center space-x-2"
        >
          <RefreshCw className="h-5 w-5" />
          <span>Refresh</span>
        </button>
      </div>

      {/* Agreements List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          </div>
        ) : agreements.length > 0 ? (
          agreements.map((agreement) => (
            <div key={agreement.id} className="card hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-secondary-900 mb-2">
                    {agreement.agreementTitle || 'Untitled Agreement'}
                  </h3>
                  <p className="text-sm text-secondary-600 mb-2">
                    Type: {agreement.agreementType || 'Unknown'}
                  </p>
                  <div className="flex items-center space-x-2 mb-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getStatusColor(agreement.workflowStatus || agreement.status)}`}>
                      {getStatusIcon(agreement.workflowStatus || agreement.status)}
                      <span>{agreement.workflowStatus || agreement.status}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Agreement Details */}
              <div className="space-y-2 text-sm text-secondary-600 mb-4">
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4" />
                  <span>
                    {agreement.requiredSigners?.length || 0} required signers
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4" />
                  <span>
                    {agreement.completedSigners?.length || 0} completed
                  </span>
                </div>
                {agreement.expiresAt && (
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4" />
                    <span>
                      Expires: {new Date(agreement.expiresAt).toLocaleDateString()}
                    </span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-2">
                <button
                  onClick={() => setSelectedAgreement(agreement)}
                  className="btn-secondary flex-1 flex items-center justify-center space-x-1 text-sm"
                >
                  <Eye className="h-4 w-4" />
                  <span>View</span>
                </button>
                
                {agreement.workflowStatus !== 'FULLY_SIGNED' && agreement.workflowStatus !== 'COMPLETED' && (
                  <button
                    onClick={() => {
                      setSelectedAgreement(agreement);
                      setShowInviteModal(true);
                    }}
                    className="btn-primary flex-1 flex items-center justify-center space-x-1 text-sm"
                  >
                    <Send className="h-4 w-4" />
                    <span>Invite</span>
                  </button>
                )}
                
                <button
                  onClick={() => signatureAPI.downloadAgreement(agreement.id)}
                  className="btn-secondary p-2"
                  title="Download"
                >
                  <Download className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <Users className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-secondary-900 mb-2">
              No Multi-Party Agreements
            </h3>
            <p className="text-secondary-600 mb-4">
              Create your first multi-party agreement to get started
            </p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="btn-primary"
            >
              Create Agreement
            </button>
          </div>
        )}
      </div>

      {/* Create Agreement Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold">Create Multi-Party Agreement</h3>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="text-white hover:text-blue-200 transition-colors"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-2">
                      Agreement Title *
                    </label>
                    <input
                      type="text"
                      value={createForm.agreementTitle}
                      onChange={(e) => setCreateForm({...createForm, agreementTitle: e.target.value})}
                      className="input-field"
                      placeholder="Enter agreement title"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-2">
                      Agreement Type
                    </label>
                    <select
                      value={createForm.agreementType}
                      onChange={(e) => setCreateForm({...createForm, agreementType: e.target.value})}
                      className="input-field"
                    >
                      {agreementTypes.map((type) => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-2">
                      Party A
                    </label>
                    <input
                      type="text"
                      value={createForm.partyA}
                      onChange={(e) => setCreateForm({...createForm, partyA: e.target.value})}
                      className="input-field"
                      placeholder="Enter Party A name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-2">
                      Party B
                    </label>
                    <input
                      type="text"
                      value={createForm.partyB}
                      onChange={(e) => setCreateForm({...createForm, partyB: e.target.value})}
                      className="input-field"
                      placeholder="Enter Party B name"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Agreement Content *
                  </label>
                  <textarea
                    value={createForm.agreementContent}
                    onChange={(e) => setCreateForm({...createForm, agreementContent: e.target.value})}
                    className="input-field resize-none h-32"
                    placeholder="Enter the full agreement content..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Terms & Conditions
                  </label>
                  <textarea
                    value={createForm.terms}
                    onChange={(e) => setCreateForm({...createForm, terms: e.target.value})}
                    className="input-field resize-none h-24"
                    placeholder="Enter specific terms and conditions..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Required Signers *
                  </label>
                  <div className="space-y-2">
                    <div className="flex space-x-2">
                      <input
                        type="email"
                        placeholder="Enter signer email"
                        className="input-field flex-1"
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            addSignerEmail();
                          }
                        }}
                      />
                      <button
                        type="button"
                        onClick={addSignerEmail}
                        className="btn-secondary px-4"
                      >
                        Add
                      </button>
                    </div>
                    <div className="space-y-1">
                      {createForm.requiredSigners.map((email, index) => (
                        <div key={index} className="flex items-center justify-between bg-gray-50 px-3 py-2 rounded">
                          <span className="text-sm text-gray-700">{email}</span>
                          <button
                            type="button"
                            onClick={() => removeSignerEmail(index)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-2">
                      Signing Instructions
                    </label>
                    <textarea
                      value={createForm.signingInstructions}
                      onChange={(e) => setCreateForm({...createForm, signingInstructions: e.target.value})}
                      className="input-field resize-none h-20"
                      placeholder="Instructions for signers..."
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-2">
                      Expiration (Days)
                    </label>
                    <input
                      type="number"
                      value={createForm.expirationDays}
                      onChange={(e) => setCreateForm({...createForm, expirationDays: parseInt(e.target.value) || 30})}
                      className="input-field"
                      min="1"
                      max="365"
                    />
                  </div>
                </div>
              </div>

              <div className="flex space-x-4 mt-6">
                <button
                  onClick={createMultiPartyAgreement}
                  disabled={loading}
                  className="btn-primary flex-1"
                >
                  {loading ? 'Creating...' : 'Create Agreement'}
                </button>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="btn-secondary flex-1"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Send Invitations Modal */}
      {showInviteModal && selectedAgreement && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full">
            <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold">Send Signing Invitations</h3>
                <button
                  onClick={() => setShowInviteModal(false)}
                  className="text-white hover:text-green-200 transition-colors"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="mb-4">
                <h4 className="font-semibold text-secondary-900 mb-2">
                  {selectedAgreement.agreementTitle}
                </h4>
                <p className="text-sm text-secondary-600">
                  Type: {selectedAgreement.agreementType}
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Signer Emails (comma-separated) *
                  </label>
                  <textarea
                    value={inviteEmails}
                    onChange={(e) => setInviteEmails(e.target.value)}
                    className="input-field resize-none h-20"
                    placeholder="email1@example.com, email2@example.com, email3@example.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Custom Message (Optional)
                  </label>
                  <textarea
                    value={inviteMessage}
                    onChange={(e) => setInviteMessage(e.target.value)}
                    className="input-field resize-none h-24"
                    placeholder="Add a personal message for the signers..."
                  />
                </div>
              </div>

              <div className="flex space-x-4 mt-6">
                <button
                  onClick={sendInvitations}
                  disabled={loading}
                  className="btn-primary flex-1"
                >
                  {loading ? 'Sending...' : 'Send Invitations'}
                </button>
                <button
                  onClick={() => setShowInviteModal(false)}
                  className="btn-secondary flex-1"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MultiPartySignature;



