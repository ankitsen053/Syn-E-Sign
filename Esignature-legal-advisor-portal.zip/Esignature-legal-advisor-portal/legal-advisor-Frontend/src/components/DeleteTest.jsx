import React from 'react';
import { Trash2 } from 'lucide-react';

const DeleteTest = ({ file, onDelete }) => {
  const handleClick = (e) => {
    console.log('🔴 Delete button clicked!', { fileId: file.id, fileName: file.name });
    e.stopPropagation();
    e.preventDefault();
    
    if (onDelete) {
      // Use the file ID for deletion
      const idToUse = file.id || file.documentId;
      onDelete(idToUse);
    }
  };

  return (
    <button
      type="button"
      className="text-red-500 hover:text-red-700 hover:bg-red-50 p-2 rounded-full transition-all duration-200 flex items-center justify-center opacity-70 hover:opacity-100"
      onClick={handleClick}
      style={{ 
        background: 'none', 
        border: 'none', 
        cursor: 'pointer',
        zIndex: 10,
        position: 'relative',
        minWidth: '32px',
        minHeight: '32px'
      }}
      title={`Delete ${file.name}`}
    >
      <Trash2 className="h-4 w-4" />
    </button>
  );
};

export default DeleteTest;
