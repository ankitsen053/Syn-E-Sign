import { AlertTriangle, Info, X } from 'lucide-react';
import { useState } from 'react';

const ComplianceDisclaimer = () => {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) {
    return null;
  }

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3 flex-1">
          <Info className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-sm font-medium text-blue-800 mb-2">
              Professional Document Management Platform
            </h3>
            <div className="text-sm text-blue-700 space-y-3">
              <p>
                <strong>Document Assistant Pro</strong> provides professional document templates and management tools. 
                All generated content requires expert review before use.
              </p>
              <div className="bg-blue-25 rounded-md p-3 border border-blue-100">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <p className="flex items-center space-x-2">
                      <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                      <span>Templates require professional review</span>
                    </p>
                    <p className="flex items-center space-x-2">
                      <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                      <span>Informational and educational purposes</span>
                    </p>
                    <p className="flex items-center space-x-2">
                      <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                      <span>User assumes full responsibility</span>
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="flex items-center space-x-2">
                      <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                      <span>Consult qualified professionals</span>
                    </p>
                    <p className="flex items-center space-x-2">
                      <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                      <span>Not professional advice or services</span>
                    </p>
                    <p className="flex items-center space-x-2">
                      <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                      <span>Expert consultation recommended</span>
                    </p>
                  </div>
                </div>
              </div>
              <p className="text-xs text-blue-600 font-medium text-center">
                Always verify compliance with applicable laws and seek professional guidance for important matters.
              </p>
            </div>
          </div>
        </div>
        <button
          onClick={() => setIsVisible(false)}
          className="text-blue-600 hover:text-blue-800 ml-2"
          aria-label="Close disclaimer"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

const ShortDisclaimer = () => {
  return (
    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-3 mb-4">
      <div className="flex items-center space-x-2">
        <Info className="h-4 w-4 text-blue-600 flex-shrink-0" />
        <p className="text-sm text-blue-800">
          <span className="font-semibold">Document Assistant Pro:</span> Professional document templates and management platform. 
          <span className="text-blue-700">Templates require expert review • Not professional advice • Consult qualified professionals.</span>
        </p>
      </div>
    </div>
  );
};

export { ComplianceDisclaimer, ShortDisclaimer };
export default ComplianceDisclaimer;

