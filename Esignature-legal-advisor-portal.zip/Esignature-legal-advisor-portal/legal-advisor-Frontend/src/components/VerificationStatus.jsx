import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Clock, AlertCircle, Upload, Video, CreditCard, UserCheck } from 'lucide-react';
import { verificationAPI } from '../services/api';

const VerificationStatus = () => {
  const [verificationStatus, setVerificationStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchVerificationStatus();
  }, []);

  const fetchVerificationStatus = async () => {
    try {
      setLoading(true);
      const response = await verificationAPI.getStatus();
      setVerificationStatus(response.data);
      setError('');
    } catch (err) {
      setError('Failed to load verification status');
      console.error('Error fetching verification status:', err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (verified, status) => {
    if (verified) {
      return <CheckCircle className="h-6 w-6 text-green-500" />;
    }
    if (status === 'PENDING') {
      return <Clock className="h-6 w-6 text-yellow-500" />;
    }
    if (status === 'REJECTED') {
      return <XCircle className="h-6 w-6 text-red-500" />;
    }
    return <AlertCircle className="h-6 w-6 text-gray-400" />;
  };

  const getStatusText = (verified, status) => {
    if (verified) {
      return 'Verified';
    }
    if (status === 'PENDING') {
      return 'Pending Review';
    }
    if (status === 'REJECTED') {
      return 'Rejected';
    }
    return 'Not Submitted';
  };

  const getStatusColor = (verified, status) => {
    if (verified) {
      return 'text-green-600 bg-green-50 border-green-200';
    }
    if (status === 'PENDING') {
      return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    }
    if (status === 'REJECTED') {
      return 'text-red-600 bg-red-50 border-red-200';
    }
    return 'text-gray-600 bg-gray-50 border-gray-200';
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
        {error}
      </div>
    );
  }

  if (!verificationStatus) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 text-yellow-700 px-4 py-3 rounded-lg">
        No verification status found. Please complete your verification.
      </div>
    );
  }

  const overallProgress = [
    verificationStatus.emailVerified,
    verificationStatus.panVerified,
    verificationStatus.aadharVerified,
    verificationStatus.videoVerified
  ].filter(Boolean).length;

  const progressPercentage = (overallProgress / 4) * 100;

  return (
    <div className="space-y-6">
      {/* Overall Progress */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Verification Progress</h3>
        <div className="mb-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Overall Progress</span>
            <span>{overallProgress}/4 Complete</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
        </div>
        <div className="text-sm text-gray-600">
          {verificationStatus.fullyVerified ? (
            <span className="text-green-600 font-medium">✅ Fully Verified</span>
          ) : (
            <span className="text-yellow-600 font-medium">⏳ Verification in Progress</span>
          )}
        </div>
      </div>

      {/* Individual Verification Items */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Email Verification */}
        <div className={`bg-white rounded-lg shadow p-6 border-2 ${getStatusColor(verificationStatus.emailVerified, 'COMPLETED')}`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <UserCheck className="h-6 w-6 text-blue-500" />
              <h4 className="font-semibold">Email Verification</h4>
            </div>
            {getStatusIcon(verificationStatus.emailVerified, 'COMPLETED')}
          </div>
          <p className="text-sm text-gray-600 mb-2">
            {getStatusText(verificationStatus.emailVerified, 'COMPLETED')}
          </p>
          {verificationStatus.emailVerifiedAt && (
            <p className="text-xs text-gray-500">
              Verified on: {new Date(verificationStatus.emailVerifiedAt).toLocaleDateString()}
            </p>
          )}
        </div>

        {/* PAN Verification */}
        <div className={`bg-white rounded-lg shadow p-6 border-2 ${getStatusColor(verificationStatus.panVerified, verificationStatus.panVerificationStatus)}`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <CreditCard className="h-6 w-6 text-purple-500" />
              <h4 className="font-semibold">PAN Verification</h4>
            </div>
            {getStatusIcon(verificationStatus.panVerified, verificationStatus.panVerificationStatus)}
          </div>
          <p className="text-sm text-gray-600 mb-2">
            {getStatusText(verificationStatus.panVerified, verificationStatus.panVerificationStatus)}
          </p>
          {verificationStatus.panNumber && (
            <p className="text-xs text-gray-500 mb-1">
              PAN: {verificationStatus.panNumber}
            </p>
          )}
          {verificationStatus.panVerifiedAt && (
            <p className="text-xs text-gray-500">
              Verified on: {new Date(verificationStatus.panVerifiedAt).toLocaleDateString()}
            </p>
          )}
        </div>

        {/* Aadhar Verification */}
        <div className={`bg-white rounded-lg shadow p-6 border-2 ${getStatusColor(verificationStatus.aadharVerified, verificationStatus.aadharVerificationStatus)}`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <Upload className="h-6 w-6 text-orange-500" />
              <h4 className="font-semibold">Aadhar Verification</h4>
            </div>
            {getStatusIcon(verificationStatus.aadharVerified, verificationStatus.aadharVerificationStatus)}
          </div>
          <p className="text-sm text-gray-600 mb-2">
            {getStatusText(verificationStatus.aadharVerified, verificationStatus.aadharVerificationStatus)}
          </p>
          {verificationStatus.aadharNumber && (
            <p className="text-xs text-gray-500 mb-1">
              Aadhar: {verificationStatus.aadharNumber}
            </p>
          )}
          {verificationStatus.aadharVerifiedAt && (
            <p className="text-xs text-gray-500">
              Verified on: {new Date(verificationStatus.aadharVerifiedAt).toLocaleDateString()}
            </p>
          )}
        </div>

        {/* Video Verification */}
        <div className={`bg-white rounded-lg shadow p-6 border-2 ${getStatusColor(verificationStatus.videoVerified, verificationStatus.videoVerificationStatus)}`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <Video className="h-6 w-6 text-red-500" />
              <h4 className="font-semibold">Video Verification</h4>
            </div>
            {getStatusIcon(verificationStatus.videoVerified, verificationStatus.videoVerificationStatus)}
          </div>
          <p className="text-sm text-gray-600 mb-2">
            {getStatusText(verificationStatus.videoVerified, verificationStatus.videoVerificationStatus)}
          </p>
          {verificationStatus.videoVerifiedAt && (
            <p className="text-xs text-gray-500">
              Verified on: {new Date(verificationStatus.videoVerifiedAt).toLocaleDateString()}
            </p>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Complete Your Verification</h3>
        <div className="grid gap-3 md:grid-cols-3">
          <button className="btn-secondary flex items-center justify-center space-x-2">
            <CreditCard className="h-4 w-4" />
            <span>Submit PAN</span>
          </button>
          <button className="btn-secondary flex items-center justify-center space-x-2">
            <Upload className="h-4 w-4" />
            <span>Submit Aadhar</span>
          </button>
          <button className="btn-secondary flex items-center justify-center space-x-2">
            <Video className="h-4 w-4" />
            <span>Start Video Call</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default VerificationStatus;
