import React, { useState, useEffect } from 'react';
import { verificationRefreshAPI } from '../services/api';
import { 
  RefreshCw, 
  CheckCircle, 
  Clock, 
  XCircle, 
  AlertCircle, 
  User, 
  Building, 
  Building2,
  CreditCard,
  FileText,
  Video,
  Mail,
  Receipt,
  Eye,
  EyeOff
} from 'lucide-react';

const VerificationRefreshStatus = ({ userId = null }) => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [refreshToken, setRefreshToken] = useState('');
  const [showRefreshToken, setShowRefreshToken] = useState(false);
  const [termsExplanation, setTermsExplanation] = useState(null);

  useEffect(() => {
    loadVerificationProfile();
    loadTermsExplanation();
  }, [userId]);

  const loadVerificationProfile = async () => {
    try {
      setLoading(true);
      setError('');
      
      const response = userId 
        ? await verificationRefreshAPI.getVerificationStatusByUserId(userId)
        : await verificationRefreshAPI.getUserVerificationProfile();
      
      if (response.data.success) {
        setProfile(userId ? response.data.profile : response.data.profile);
      } else {
        setError('Failed to load verification profile');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to load verification profile');
    } finally {
      setLoading(false);
    }
  };

  const loadTermsExplanation = async () => {
    try {
      const response = await verificationRefreshAPI.getVerificationTermsExplanation();
      if (response.data.success) {
        setTermsExplanation(response.data.explanation);
      }
    } catch (error) {
      console.warn('Failed to load terms explanation:', error);
    }
  };

  const generateRefreshToken = async () => {
    try {
      setError('');
      const response = await verificationRefreshAPI.generateRefreshToken();
      if (response.data.success) {
        setRefreshToken(response.data.refreshToken);
        setSuccess('Refresh token generated successfully');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        setError('Failed to generate refresh token');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to generate refresh token');
    }
  };

  const refreshVerificationStatus = async () => {
    try {
      setRefreshing(true);
      setError('');
      
      const response = await verificationRefreshAPI.refreshVerificationStatus(refreshToken);
      if (response.data.success) {
        // Update the profile with refreshed data
        const refreshedData = response.data.data;
        setProfile(prev => ({
          ...prev,
          ...refreshedData,
          currentStatuses: refreshedData.verificationStatuses
        }));
        setSuccess('Verification status refreshed successfully');
        setTimeout(() => setSuccess(''), 3000);
      } else {
        setError('Failed to refresh verification status');
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to refresh verification status');
    } finally {
      setRefreshing(false);
    }
  };

  const refreshSpecificVerification = async (verificationType) => {
    try {
      setError('');
      const response = await verificationRefreshAPI.refreshSpecificVerification(verificationType, refreshToken);
      if (response.data.success) {
        // Update specific verification in profile
        setProfile(prev => ({
          ...prev,
          currentStatuses: {
            ...prev.currentStatuses,
            [verificationType]: response.data.verificationData
          }
        }));
        setSuccess(`${verificationType} verification refreshed successfully`);
        setTimeout(() => setSuccess(''), 3000);
      } else {
        setError(`Failed to refresh ${verificationType} verification`);
      }
    } catch (error) {
      setError(error.response?.data?.error || `Failed to refresh ${verificationType} verification`);
    }
  };

  const getVerificationIcon = (verificationType) => {
    switch (verificationType.toUpperCase()) {
      case 'EMAIL': return <Mail className="h-5 w-5" />;
      case 'PAN': return <CreditCard className="h-5 w-5" />;
      case 'AADHAAR': return <FileText className="h-5 w-5" />;
      case 'VIDEO': return <Video className="h-5 w-5" />;
      case 'GST': return <Receipt className="h-5 w-5" />;
      default: return <FileText className="h-5 w-5" />;
    }
  };

  const getStatusIcon = (status) => {
    switch (status?.toUpperCase()) {
      case 'VERIFIED':
      case 'APPROVED':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'PENDING':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      case 'REJECTED':
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return <AlertCircle className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status?.toUpperCase()) {
      case 'VERIFIED':
      case 'APPROVED':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'PENDING':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'REJECTED':
        return 'text-red-600 bg-red-50 border-red-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getUserTermsIcon = (terms) => {
    switch (terms) {
      case 'INDIVIDUAL': return <User className="h-6 w-6" />;
      case 'BUSINESS': return <Building className="h-6 w-6" />;
      case 'CORPORATE': return <Building2 className="h-6 w-6" />;
      default: return <User className="h-6 w-6" />;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
        <span className="ml-3 text-gray-600">Loading verification status...</span>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-8">
        <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">No verification profile found</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-gray-900">Verification Status</h2>
          <div className="flex items-center space-x-2">
            {getUserTermsIcon(profile.userVerificationTerms)}
            <span className="text-lg font-medium text-gray-700">
              {profile.userVerificationTerms} Profile
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">
              Verification Progress
            </span>
            <span className="text-sm text-gray-600">
              {profile.completed} of {profile.totalRequired} completed
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-primary-600 h-3 rounded-full transition-all duration-300"
              style={{ width: `${profile.completionPercentage}%` }}
            ></div>
          </div>
          <div className="text-right mt-1">
            <span className="text-sm font-medium text-primary-600">
              {Math.round(profile.completionPercentage)}%
            </span>
          </div>
        </div>

        {/* Business Type Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
          <h3 className="font-medium text-blue-900 mb-2">Profile Information</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-blue-700 font-medium">Business Type:</span>
              <span className="ml-2 text-blue-800">{profile.businessType}</span>
            </div>
            <div>
              <span className="text-blue-700 font-medium">User ID:</span>
              <span className="ml-2 text-blue-800 font-mono">{profile.userId}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Error/Success Messages */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center">
          <XCircle className="h-5 w-5 mr-2" />
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg flex items-center">
          <CheckCircle className="h-5 w-5 mr-2" />
          {success}
        </div>
      )}

      {/* Refresh Token Section */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Refresh Token Management</h3>
        
        <div className="space-y-4">
          <button
            onClick={generateRefreshToken}
            className="btn-primary flex items-center space-x-2"
          >
            <RefreshCw className="h-4 w-4" />
            <span>Generate New Refresh Token</span>
          </button>

          {refreshToken && (
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Generated Refresh Token:
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type={showRefreshToken ? "text" : "password"}
                  value={refreshToken}
                  readOnly
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 font-mono text-sm"
                />
                <button
                  onClick={() => setShowRefreshToken(!showRefreshToken)}
                  className="p-2 text-gray-500 hover:text-gray-700"
                >
                  {showRefreshToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
          )}

          <button
            onClick={refreshVerificationStatus}
            disabled={refreshing || !refreshToken}
            className={`btn-primary flex items-center space-x-2 ${
              (!refreshToken) ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {refreshing ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
            <span>{refreshing ? 'Refreshing...' : 'Refresh All Verifications'}</span>
          </button>
        </div>
      </div>

      {/* Verification Details */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Verification Details</h3>
        
        <div className="grid gap-4">
          {profile.requiredVerifications.map((verificationType) => {
            const status = profile.currentStatuses[verificationType];
            const explanation = termsExplanation?.[profile.userVerificationTerms]?.[verificationType] || 
                             profile.verificationExplanation?.[verificationType];
            
            return (
              <div 
                key={verificationType}
                className={`border rounded-lg p-4 ${getStatusColor(status?.status)}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    {getVerificationIcon(verificationType)}
                    <h4 className="font-medium">{verificationType} Verification</h4>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(status?.status)}
                    <span className="font-medium text-sm">
                      {status?.status || 'UNKNOWN'}
                    </span>
                  </div>
                </div>
                
                {explanation && (
                  <p className="text-sm mb-3 opacity-80">
                    {explanation}
                  </p>
                )}
                
                <div className="flex items-center justify-between">
                  <div className="text-sm opacity-75">
                    {status?.verified ? (
                      <span>✓ Verified</span>
                    ) : (
                      <span>⏳ Pending verification</span>
                    )}
                  </div>
                  
                  <button
                    onClick={() => refreshSpecificVerification(verificationType)}
                    disabled={!refreshToken}
                    className={`text-sm px-3 py-1 rounded-md border transition-colors ${
                      refreshToken 
                        ? 'border-current hover:bg-current hover:text-white' 
                        : 'opacity-50 cursor-not-allowed'
                    }`}
                  >
                    Refresh
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Terms Explanation */}
      {termsExplanation && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Verification Requirements Explanation</h3>
          
          <div className="grid gap-4">
            {Object.entries(termsExplanation).map(([termType, termData]) => (
              <div key={termType} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  {getUserTermsIcon(termType)}
                  <h4 className="font-medium text-gray-900">{termType} Profile</h4>
                </div>
                <p className="text-sm text-gray-600 mb-3">{termData.description}</p>
                <div className="space-y-1">
                  <span className="text-sm font-medium text-gray-700">Required Verifications:</span>
                  <div className="flex flex-wrap gap-2">
                    {termData.required.map((req) => (
                      <span key={req} className="text-xs px-2 py-1 bg-gray-100 rounded-full">
                        {req}
                      </span>
                    ))}
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Purpose: {termData.purpose}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VerificationRefreshStatus;
