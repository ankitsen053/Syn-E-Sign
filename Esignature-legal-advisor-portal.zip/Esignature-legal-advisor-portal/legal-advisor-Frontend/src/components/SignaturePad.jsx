import React, { useRef, useEffect, useState } from 'react';
import { X, RotateCcw, Download, Upload } from 'lucide-react';

const SignaturePad = ({ onSave, onCancel }) => {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [signatureData, setSignatureData] = useState(null);
  const [penColor, setPenColor] = useState('#000000');
  const [penWidth, setPenWidth] = useState(2);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // Set canvas size
    canvas.width = 500;
    canvas.height = 200;
    
    // Set initial styles
    ctx.strokeStyle = penColor;
    ctx.lineWidth = penWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    // Clear canvas
    clearCanvas();
  }, []);

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureData(null);
  };

  const startDrawing = (e) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e) => {
    if (!isDrawing) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    saveSignature();
  };

  const saveSignature = () => {
    const canvas = canvasRef.current;
    const signatureImage = canvas.toDataURL('image/png');
    setSignatureData(signatureImage);
  };

  const downloadSignature = () => {
    if (!signatureData) return;
    
    const link = document.createElement('a');
    link.download = 'signature.png';
    link.href = signatureData;
    link.click();
  };

  const uploadSignature = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = canvasRef.current;
          const ctx = canvas.getContext('2d');
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          setSignatureData(canvas.toDataURL('image/png'));
        };
        img.src = event.target.result;
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePenColorChange = (color) => {
    setPenColor(color);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.strokeStyle = color;
  };

  const handlePenWidthChange = (width) => {
    setPenWidth(width);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.lineWidth = width;
  };

  return (
    <div className="w-full">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Digital Signature</h3>
        <p className="text-sm text-gray-600">Draw your signature in the canvas below</p>
      </div>

        <div className="mb-4">
          <div className="flex items-center space-x-4 mb-2">
            <label className="text-sm font-medium text-gray-700">Pen Color:</label>
            <input
              type="color"
              value={penColor}
              onChange={(e) => handlePenColorChange(e.target.value)}
              className="w-10 h-8 border border-gray-300 rounded cursor-pointer"
            />
            
            <label className="text-sm font-medium text-gray-700">Pen Width:</label>
            <input
              type="range"
              min="1"
              max="10"
              value={penWidth}
              onChange={(e) => handlePenWidthChange(parseInt(e.target.value))}
              className="w-20"
            />
            <span className="text-sm text-gray-600">{penWidth}px</span>
          </div>
        </div>

        <div className="border-2 border-gray-300 rounded-lg mb-4">
          <canvas
            ref={canvasRef}
            className="w-full h-48 cursor-crosshair"
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={(e) => {
              e.preventDefault();
              const touch = e.touches[0];
              const mouseEvent = new MouseEvent('mousedown', {
                clientX: touch.clientX,
                clientY: touch.clientY
              });
              startDrawing(mouseEvent);
            }}
            onTouchMove={(e) => {
              e.preventDefault();
              const touch = e.touches[0];
              const mouseEvent = new MouseEvent('mousemove', {
                clientX: touch.clientX,
                clientY: touch.clientY
              });
              draw(mouseEvent);
            }}
            onTouchEnd={(e) => {
              e.preventDefault();
              stopDrawing();
            }}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex space-x-2">
            <button
              onClick={clearCanvas}
              className="btn-secondary flex items-center space-x-1"
            >
              <RotateCcw className="h-4 w-4" />
              <span>Clear</span>
            </button>
            
            <button
              onClick={downloadSignature}
              disabled={!signatureData}
              className="btn-secondary flex items-center space-x-1 disabled:opacity-50"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
            
            <label className="btn-secondary flex items-center space-x-1 cursor-pointer">
              <Upload className="h-4 w-4" />
              <span>Upload</span>
              <input
                type="file"
                accept="image/*"
                onChange={uploadSignature}
                className="hidden"
              />
            </label>
          </div>

          <div className="flex space-x-2">
            <button
              onClick={onCancel}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                // Ensure we save the current canvas state before using signature
                const canvas = canvasRef.current;
                const currentSignature = canvas.toDataURL('image/png');
                
                // Check if canvas has any content (not just empty/white)
                const ctx = canvas.getContext('2d');
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const hasContent = imageData.data.some((channel, index) => {
                  // Check if any pixel is not white (255, 255, 255, 255)
                  return index % 4 !== 3 && channel !== 255;
                });
                
                if (hasContent) {
                  setSignatureData(currentSignature);
                  onSave(currentSignature);
                } else {
                  alert('Please draw a signature before using it.');
                }
              }}
              className="btn-primary"
            >
              Use Signature
            </button>
          </div>
        </div>

      <div className="mt-4 text-sm text-gray-600">
        <p>• Draw your signature in the box above</p>
        <p>• Use the color and width controls to customize your signature</p>
        <p>• You can also upload an existing signature image</p>
      </div>
    </div>
  );
};

export default SignaturePad;
