import { useState, useEffect } from 'react';
import { authAPI } from '../services/api';
import { MailOutlined, CheckCircleOutlined, ExclamationCircleOutlined, ReloadOutlined } from '@ant-design/icons';

const EmailVerification = ({ email, providedOtp, onVerificationSuccess, onClose }) => {
  const [otp, setOtp] = useState(providedOtp || '');
  const [loading, setLoading] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [timeLeft, setTimeLeft] = useState(0);
  const [canResend, setCanResend] = useState(false);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [timeLeft]);

  useEffect(() => {
    // Start 60-second countdown for resend
    setTimeLeft(60);
  }, []);

  const handleVerify = async (e) => {
    e.preventDefault();
    if (!otp || otp.length !== 6) {
      setError('Please enter a valid 6-digit OTP');
      return;
    }

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await authAPI.verifyEmail(email, otp);
      
      if (response.data.message.includes('Error:')) {
        setError(response.data.message);
      } else {
        setSuccess(response.data.message);
        setTimeout(() => {
          onVerificationSuccess();
        }, 2000);
      }
    } catch (error) {
      setError(error.response?.data?.message || 'Failed to verify email');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setResendLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await authAPI.resendOtp(email);
      
      if (response.data.message.includes('Error:')) {
        setError(response.data.message);
      } else {
        setSuccess(response.data.message);
        setCanResend(false);
        setTimeLeft(60);
        setOtp('');
      }
    } catch (error) {
      setError(error.response?.data?.message || 'Failed to resend OTP');
    } finally {
      setResendLoading(false);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
        <div className="text-center mb-6">
          <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
            <MailOutlined style={{ fontSize: '32px', color: '#1890ff' }} />
          </div>
          <h2 className="text-2xl font-bold text-secondary-900 mb-2">
            Verify Your Email
          </h2>
          <p className="text-secondary-600">
            We've sent a 6-digit verification code to
          </p>
          <p className="text-secondary-900 font-medium">{email}</p>
          
          {providedOtp && (
            <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-700 mb-2">
                <strong>For testing purposes, your OTP is:</strong>
              </p>
              <p className="text-lg font-mono font-bold text-blue-800 text-center">
                {providedOtp}
              </p>
            </div>
          )}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center space-x-2 mb-4">
            <ExclamationCircleOutlined style={{ fontSize: '20px' }} />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg flex items-center space-x-2 mb-4">
            <CheckCircleOutlined style={{ fontSize: '20px' }} />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleVerify} className="space-y-4">
          <div>
            <label htmlFor="otp" className="block text-sm font-medium text-secondary-700 mb-2">
              Enter Verification Code
            </label>
            <input
              id="otp"
              type="text"
              value={otp}
              onChange={(e) => {
                const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                setOtp(value);
              }}
              className="input-field text-center text-2xl font-mono tracking-widest"
              placeholder="000000"
              maxLength={6}
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading || !otp || otp.length !== 6}
            className="btn-primary w-full flex justify-center py-3"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
            ) : (
              <>
                <CheckCircleOutlined style={{ fontSize: '20px', marginRight: '8px' }} />
                Verify Email
              </>
            )}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-secondary-600 mb-2">
            Didn't receive the code?
          </p>
          {canResend ? (
            <button
              onClick={handleResendOtp}
              disabled={resendLoading}
              className="text-primary-600 hover:text-primary-700 font-medium flex items-center justify-center w-full"
            >
              {resendLoading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-600"></div>
              ) : (
                <>
                  <ReloadOutlined style={{ fontSize: '16px', marginRight: '4px' }} />
                  Resend Code
                </>
              )}
            </button>
          ) : (
            <p className="text-sm text-secondary-500">
              Resend available in {formatTime(timeLeft)}
            </p>
          )}
        </div>

        <div className="mt-6 text-center">
          <button
            onClick={onClose}
            className="text-secondary-600 hover:text-secondary-700 text-sm"
          >
            Use a different email
          </button>
        </div>
      </div>
    </div>
  );
};

export default EmailVerification;
