# MongoDB Local Installation Guide
Write-Host "=== MongoDB Local Installation Guide ===" -ForegroundColor Green
Write-Host ""

Write-Host "Step 1: Download MongoDB Community Server" -ForegroundColor Yellow
Write-Host "  - Go to: https://www.mongodb.com/try/download/community" -ForegroundColor White
Write-Host "  - Select: Windows x64" -ForegroundColor White
Write-Host "  - Choose: msi installer" -ForegroundColor White
Write-Host "  - Download and run the installer" -ForegroundColor White

Write-Host "`nStep 2: Install MongoDB" -ForegroundColor Yellow
Write-Host "  - Run the downloaded .msi file" -ForegroundColor White
Write-Host "  - Choose 'Complete' installation" -ForegroundColor White
Write-Host "  - Install MongoDB Compass (optional but recommended)" -ForegroundColor White
Write-Host "  - Complete the installation" -ForegroundColor White

Write-Host "`nStep 3: Start MongoDB Service" -ForegroundColor Yellow
Write-Host "  - Open PowerShell as Administrator" -ForegroundColor White
Write-Host "  - Run: Start-Service MongoDB" -ForegroundColor White
Write-Host "  - Or: net start MongoDB" -ForegroundColor White

Write-Host "`nStep 4: Verify Installation" -ForegroundColor Yellow
Write-Host "  - Check service status: Get-Service MongoDB" -ForegroundColor White
Write-Host "  - Test connection: mongo --version" -ForegroundColor White

Write-Host "`nStep 5: Test Application with Local Profile" -ForegroundColor Yellow
Write-Host "  - Run: mvn spring-boot:run -Dspring.profiles.active=local" -ForegroundColor White

Write-Host "`nAlternative: Use MongoDB Atlas (Cloud)" -ForegroundColor Cyan
Write-Host "  - Go to: https://cloud.mongodb.com" -ForegroundColor White
Write-Host "  - Create free account" -ForegroundColor White
Write-Host "  - Create new cluster" -ForegroundColor White
Write-Host "  - Get connection string" -ForegroundColor White
Write-Host "  - Update application.properties" -ForegroundColor White

Write-Host "`n=== Quick Commands ===" -ForegroundColor Green
Write-Host "Check MongoDB service: Get-Service MongoDB" -ForegroundColor Cyan
Write-Host "Start MongoDB: Start-Service MongoDB" -ForegroundColor Cyan
Write-Host "Stop MongoDB: Stop-Service MongoDB" -ForegroundColor Cyan
Write-Host "Test connection: mongo --version" -ForegroundColor Cyan
Write-Host "Run app locally: mvn spring-boot:run -Dspring.profiles.active=local" -ForegroundColor Cyan

Write-Host "`nInstallation guide complete! Follow the steps above to get MongoDB running locally." -ForegroundColor Green
