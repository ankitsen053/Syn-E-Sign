# Ollama Setup Script for Legal Advisor Application
# This script helps set up Ollama for local AI processing

Write-Host "OLLAMA SETUP FOR LEGAL ADVISOR" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan
Write-Host ""

# Check if Ollama is installed
Write-Host "1. Checking Ollama installation..." -ForegroundColor Yellow
try {
    $ollamaVersion = ollama --version
    Write-Host "   [OK] Ollama is installed: $ollamaVersion" -ForegroundColor Green
} catch {
    Write-Host "   [ERROR] Ollama is not installed" -ForegroundColor Red
    Write-Host "   [INFO] Please install Ollama from: https://ollama.ai/download" -ForegroundColor Cyan
    Write-Host "   [TIP] After installation, run this script again" -ForegroundColor Cyan
    exit 1
}

Write-Host ""

# Check if Ollama service is running
Write-Host "2. Checking Ollama service status..." -ForegroundColor Yellow
try {
    $ollamaStatus = Invoke-RestMethod -Uri "http://localhost:11434/api/tags" -Method GET -TimeoutSec 5
    Write-Host "   [OK] Ollama service is running on port 11434" -ForegroundColor Green
} catch {
    Write-Host "   [ERROR] Ollama service is not running" -ForegroundColor Red
    Write-Host "   [INFO] Starting Ollama service..." -ForegroundColor Yellow
    
    try {
        Start-Process -FilePath "ollama" -ArgumentList "serve" -WindowStyle Hidden
        Start-Sleep -Seconds 3
        
        # Check again
        $ollamaStatus = Invoke-RestMethod -Uri "http://localhost:11434/api/tags" -Method GET -TimeoutSec 5
        Write-Host "   [OK] Ollama service started successfully" -ForegroundColor Green
    } catch {
        Write-Host "   [ERROR] Failed to start Ollama service" -ForegroundColor Red
        Write-Host "   [TIP] Please start Ollama manually: ollama serve" -ForegroundColor Cyan
        exit 1
    }
}

Write-Host ""

# Check available models
Write-Host "3. Checking available models..." -ForegroundColor Yellow
try {
    $models = Invoke-RestMethod -Uri "http://localhost:11434/api/tags" -Method GET -TimeoutSec 5
    $modelNames = $models.models | ForEach-Object { $_.name }
    
    if ($modelNames -contains "llama3.1") {
        Write-Host "   [OK] llama3.1 model is available" -ForegroundColor Green
    } else {
        Write-Host "   [WARNING] llama3.1 model not found" -ForegroundColor Yellow
        Write-Host "   [INFO] Available models: $($modelNames -join ', ')" -ForegroundColor Gray
        
        Write-Host "   [INFO] Downloading llama3.1 model..." -ForegroundColor Yellow
        try {
            ollama pull llama3.1
            Write-Host "   [OK] llama3.1 model downloaded successfully" -ForegroundColor Green
        } catch {
            Write-Host "   [ERROR] Failed to download llama3.1 model" -ForegroundColor Red
            Write-Host "   [TIP] Please download manually: ollama pull llama3.1" -ForegroundColor Cyan
        }
    }
} catch {
    Write-Host "   [ERROR] Failed to check models" -ForegroundColor Red
}

Write-Host ""

# Test Spring AI integration
Write-Host "4. Testing Spring AI integration..." -ForegroundColor Yellow
try {
    $springAiStatus = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/status" -Method GET -TimeoutSec 10
    if ($springAiStatus.springAiAvailable) {
        Write-Host "   [OK] Spring AI integration is working" -ForegroundColor Green
    } else {
        Write-Host "   [WARNING] Spring AI integration not available" -ForegroundColor Yellow
        Write-Host "   [TIP] Make sure the backend is running and Ollama is accessible" -ForegroundColor Cyan
    }
} catch {
    Write-Host "   [ERROR] Backend not running or Spring AI not configured" -ForegroundColor Red
    Write-Host "   [TIP] Start the backend first: .\mvnw.cmd spring-boot:run" -ForegroundColor Cyan
}

Write-Host ""

# Test document analysis
Write-Host "5. Testing document analysis..." -ForegroundColor Yellow
try {
    $testContent = @{
        content = "This is a test legal document for analysis."
    } | ConvertTo-Json

    $analysisResult = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/analyze" -Method POST -ContentType "application/json" -Body $testContent -TimeoutSec 15
    
    if ($analysisResult.success) {
        Write-Host "   [OK] Document analysis is working" -ForegroundColor Green
        Write-Host "   [INFO] Analysis preview: $($analysisResult.analysis.Substring(0, [Math]::Min(100, $analysisResult.analysis.Length)))..." -ForegroundColor Gray
    } else {
        Write-Host "   [ERROR] Document analysis failed" -ForegroundColor Red
    }
} catch {
    Write-Host "   [ERROR] Document analysis test failed" -ForegroundColor Red
    Write-Host "   [TIP] Make sure both backend and Ollama are running" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "OLLAMA SETUP COMPLETED!" -ForegroundColor Green
Write-Host ""

Write-Host "SUMMARY:" -ForegroundColor Cyan
Write-Host "   - Ollama Service: Running on http://localhost:11434" -ForegroundColor White
Write-Host "   - Model: llama3.1 (recommended)" -ForegroundColor White
Write-Host "   - Spring AI: Integrated with backend" -ForegroundColor White
Write-Host "   - Document Analysis: Ready for use" -ForegroundColor White

Write-Host ""
Write-Host "NEXT STEPS:" -ForegroundColor Cyan
Write-Host "   1. Start the backend: .\mvnw.cmd spring-boot:run" -ForegroundColor White
Write-Host "   2. Start the frontend: cd legal-advisor-frontend" -ForegroundColor White
Write-Host "   3. Run: npm run dev" -ForegroundColor White
Write-Host "   4. Access: http://localhost:5173" -ForegroundColor White

Write-Host ""
Write-Host "TIPS:" -ForegroundColor Cyan
Write-Host "   - Keep Ollama running: ollama serve" -ForegroundColor White
Write-Host "   - Monitor Ollama logs for any issues" -ForegroundColor White
Write-Host "   - Use different models: ollama pull <model-name>" -ForegroundColor White
Write-Host "   - Check model list: ollama list" -ForegroundColor White

Write-Host ""
Write-Host "READY FOR AI-POWERED LEGAL ANALYSIS!" -ForegroundColor Green

