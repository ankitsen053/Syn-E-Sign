# Google OAuth2 Integration Test Guide

## Setup Instructions

### 1. Google Cloud Console Setup
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the Google+ API and Google OAuth2 API
4. Go to "APIs & Services" → "Credentials"
5. Create OAuth 2.0 Client ID
6. Set authorized redirect URI: `http://localhost:8081/login/oauth2/code/google`
7. Copy the Client ID and Client Secret

### 2. Update Configuration
Update the following in `application.properties`:
```properties
google.oauth.client.id=YOUR_ACTUAL_GOOGLE_CLIENT_ID_HERE
google.oauth.client.secret=YOUR_ACTUAL_GOOGLE_CLIENT_SECRET_HERE
```

### 3. Test the Integration

#### Test 1: Homepage
```bash
curl http://localhost:8081/
```
Should return the index.html page

#### Test 2: Login Page
```bash
curl http://localhost:8081/login
```
Should return the login.html page with Google OAuth button

#### Test 3: OAuth2 Authorization URL
```bash
curl http://localhost:8081/oauth2/authorization/google
```
Should redirect to Google's OAuth consent screen

#### Test 4: API Endpoints
```bash
# Test OAuth2 status
curl http://localhost:8081/api/auth/oauth2/status

# Test Google login URL
curl http://localhost:8081/api/auth/oauth2/google-login-url
```

### 4. Frontend Integration

The OAuth2 flow is designed to work with your React frontend:

1. **Initiate Login**: Redirect user to `/oauth2/authorization/google`
2. **Handle Callback**: After Google authentication, user is redirected to `/home` with user data
3. **API Integration**: Use the existing `/api/auth/oauth2/*` endpoints for programmatic access

### 5. Expected Flow

1. User clicks "Continue with Google" on login page
2. Redirected to Google OAuth consent screen
3. User authorizes the application
4. Google redirects back to `/login/oauth2/code/google`
5. Spring Security processes the OAuth2 response
6. User is redirected to `/home` with their profile information
7. JWT token is generated and can be used for API calls

### 6. Troubleshooting

#### Common Issues:
1. **Invalid redirect URI**: Ensure the redirect URI in Google Console matches exactly
2. **Client ID/Secret mismatch**: Double-check the credentials in application.properties
3. **CORS issues**: The CORS configuration should handle cross-origin requests
4. **Template not found**: Ensure Thymeleaf dependency is added to pom.xml

#### Debug Endpoints:
- `/api/test/health` - Check if the application is running
- `/api/auth/oauth2/status` - Check OAuth2 configuration
- `/api/auth/signup-status` - Check authentication system status

### 7. Security Notes

- The OAuth2 integration uses Spring Security's built-in OAuth2 client
- JWT tokens are generated for authenticated users
- User data is stored in MongoDB with proper role-based access control
- All OAuth2 endpoints are properly secured and CORS-enabled

### 8. Production Considerations

For production deployment:
1. Use environment variables for sensitive configuration
2. Update redirect URIs to match your production domain
3. Enable HTTPS for secure OAuth2 flow
4. Configure proper CORS origins
5. Set up proper logging and monitoring













