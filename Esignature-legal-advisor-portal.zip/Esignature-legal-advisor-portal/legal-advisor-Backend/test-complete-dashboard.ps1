# Test Complete Dashboard System
Write-Host "=== Complete Dashboard System Test ===" -ForegroundColor Green

# Get fresh token
Write-Host "`n1. Getting fresh token..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/login" -Method POST -Headers @{"Content-Type"="application/json"} -Body '{"username":"testuser2","password":"testpass123"}' -UseBasicParsing
    $token = ($response.Content | ConvertFrom-Json).token
    Write-Host "✅ Token received successfully" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed to get token" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test dashboard stats endpoint
Write-Host "`n2. Testing dashboard stats endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/dashboard/stats" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Dashboard stats endpoint successful" -ForegroundColor Green
    $statsData = $response.Content | ConvertFrom-Json
    Write-Host "   - Documents Generated: $($statsData.documentsGenerated.value)" -ForegroundColor Gray
    Write-Host "   - Documents Analyzed: $($statsData.documentsAnalyzed.value)" -ForegroundColor Gray
    Write-Host "   - Active Sessions: $($statsData.activeSessions.value)" -ForegroundColor Gray
    Write-Host "   - Verification Status: $($statsData.verificationStatus.status)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Dashboard stats endpoint failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test dashboard metrics endpoint
Write-Host "`n3. Testing dashboard metrics endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/dashboard/metrics" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Dashboard metrics endpoint successful" -ForegroundColor Green
    $metricsData = $response.Content | ConvertFrom-Json
    Write-Host "   - User ID: $($metricsData.userId)" -ForegroundColor Gray
    Write-Host "   - Timestamp: $($metricsData.timestamp)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Dashboard metrics endpoint failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test dashboard activity endpoint
Write-Host "`n4. Testing dashboard activity endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/dashboard/activity" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Dashboard activity endpoint successful" -ForegroundColor Green
    $activityData = $response.Content | ConvertFrom-Json
    Write-Host "   - Activities count: $($activityData.Count)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Dashboard activity endpoint failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test dashboard progress endpoint
Write-Host "`n5. Testing dashboard progress endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/dashboard/progress" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Dashboard progress endpoint successful" -ForegroundColor Green
    $progressData = $response.Content | ConvertFrom-Json
    Write-Host "   - Progress data retrieved successfully" -ForegroundColor Gray
} catch {
    Write-Host "❌ Dashboard progress endpoint failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test dashboard preferences endpoint
Write-Host "`n6. Testing dashboard preferences endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/dashboard/preferences" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Dashboard preferences endpoint successful" -ForegroundColor Green
    $preferencesData = $response.Content | ConvertFrom-Json
    Write-Host "   - Preferences data retrieved successfully" -ForegroundColor Gray
} catch {
    Write-Host "❌ Dashboard preferences endpoint failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test profile endpoint
Write-Host "`n7. Testing profile endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/profile" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Profile endpoint successful" -ForegroundColor Green
    $profileData = $response.Content | ConvertFrom-Json
    Write-Host "   - Username: $($profileData.username)" -ForegroundColor Gray
    Write-Host "   - Email: $($profileData.email)" -ForegroundColor Gray
    Write-Host "   - Email Verified: $($profileData.emailVerified)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Profile endpoint failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n=== Dashboard System Test Complete ===" -ForegroundColor Green
Write-Host "✅ All core dashboard functionality is working!" -ForegroundColor Green
