# Quick API Test Script for Legal Advisor
param(
    [string]$BackendUrl = "http://localhost:8081",
    [string]$FrontendUrl = "http://localhost:5173"
)

Write-Host "Quick API Testing - Legal Advisor" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan

# Test backend health
Write-Host "Testing Backend Health..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/test/health" -Method GET -TimeoutSec 5
    Write-Host "Backend is running - Status: $($response.status)" -ForegroundColor Green
} catch {
    Write-Host "Backend is not responding: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test frontend connectivity
Write-Host "Testing Frontend Connectivity..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$FrontendUrl" -Method GET -TimeoutSec 5
    Write-Host "Frontend is accessible - Status: $($response.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "Frontend is not accessible: $($_.Exception.Message)" -ForegroundColor Red
}

# Test authentication endpoints
Write-Host "Testing Authentication APIs..." -ForegroundColor Yellow

# Test signup
$testUser = @{
    username = "quicktest_$(Get-Random)"
    email = "quicktest_$(Get-Random)@example.com"
    password = "TestPass123!"
    roles = @("user")
}

try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/signup" -Method POST -Body ($testUser | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
    Write-Host "User signup successful" -ForegroundColor Green
} catch {
    Write-Host "User signup failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test login
try {
    $loginData = @{
        username = $testUser.username
        password = $testUser.password
    }
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/login" -Method POST -Body ($loginData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
    Write-Host "User login successful" -ForegroundColor Green
    $accessToken = $response.accessToken
} catch {
    Write-Host "User login failed: $($_.Exception.Message)" -ForegroundColor Red
    $accessToken = $null
}

# Test AI endpoints
Write-Host "Testing AI Service APIs..." -ForegroundColor Yellow

if ($accessToken) {
    $headers = @{ Authorization = "Bearer $accessToken" }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/status" -Method GET -Headers $headers -TimeoutSec 10
        Write-Host "AI service status check successful" -ForegroundColor Green
    } catch {
        Write-Host "AI service status check failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    try {
        $analysisData = @{ content = "Test legal document for quick analysis." }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/analyze" -Method POST -Body ($analysisData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 30
        Write-Host "Document analysis successful" -ForegroundColor Green
    } catch {
        Write-Host "Document analysis failed: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "Skipping AI tests - no access token" -ForegroundColor Yellow
}

# Test document endpoints
Write-Host "Testing Document Management APIs..." -ForegroundColor Yellow

if ($accessToken) {
    $headers = @{ Authorization = "Bearer $accessToken" }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/status" -Method GET -Headers $headers -TimeoutSec 10
        Write-Host "Document service status check successful" -ForegroundColor Green
    } catch {
        Write-Host "Document service status check failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    try {
        $docData = @{
            title = "Quick Test Document"
            content = "This is a quick test document."
            type = "CONTRACT"
            status = "DRAFT"
        }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/save" -Method POST -Body ($docData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 10
        Write-Host "Document save successful" -ForegroundColor Green
    } catch {
        Write-Host "Document save failed: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "Skipping document tests - no access token" -ForegroundColor Yellow
}

# Test OAuth endpoints
Write-Host "Testing OAuth APIs..." -ForegroundColor Yellow

try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/google/url" -Method GET -TimeoutSec 5
    Write-Host "Google OAuth URL generation successful" -ForegroundColor Green
} catch {
    Write-Host "Google OAuth URL generation failed: $($_.Exception.Message)" -ForegroundColor Red
}

try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/gmail/oauth/url" -Method GET -TimeoutSec 5
    Write-Host "Gmail OAuth URL generation successful" -ForegroundColor Green
} catch {
    Write-Host "Gmail OAuth URL generation failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "Quick API testing completed!" -ForegroundColor Green
