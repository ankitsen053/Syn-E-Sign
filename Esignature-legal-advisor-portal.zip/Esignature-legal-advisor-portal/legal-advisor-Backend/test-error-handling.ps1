# Error Handling Test Script
Write-Host "=== TESTING IMPROVED ERROR HANDLING ===" -ForegroundColor Green

$testsPassed = 0
$testsTotal = 0

function Test-ErrorEndpoint {
    param(
        [string]$Name,
        [string]$Method,
        [string]$Url,
        [object]$Body = $null,
        [string]$ExpectedError = $null
    )
    
    $global:testsTotal++
    Write-Host "Testing: $Name" -ForegroundColor Yellow
    
    try {
        $params = @{
            Uri = $Url
            Method = $Method
            ContentType = "application/json"
            TimeoutSec = 10
        }
        
        if ($Body) {
            $params.Body = ($Body | ConvertTo-Json)
        }
        
        $response = Invoke-RestMethod @params -ErrorAction Stop
        
        if ($ExpectedError) {
            Write-Host "  ✗ FAILED: Expected error but got success" -ForegroundColor Red
            return $false
        } else {
            Write-Host "  ✓ PASSED: $Name" -ForegroundColor Green
            $global:testsPassed++
            return $true
        }
        
    } catch {
        $statusCode = $_.Exception.Response.StatusCode.value__
        $errorResponse = $null
        
        try {
            $errorStream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($errorStream)
            $errorBody = $reader.ReadToEnd()
            $errorResponse = $errorBody | ConvertFrom-Json
        } catch {
            # Ignore JSON parsing errors
        }
        
        if ($ExpectedError) {
            if ($errorResponse -and $errorResponse.message -like "*$ExpectedError*") {
                Write-Host "  ✓ PASSED: Got expected error - $($errorResponse.message)" -ForegroundColor Green
                $global:testsPassed++
                return $true
            } else {
                Write-Host "  ✗ FAILED: Expected '$ExpectedError' but got '$($errorResponse.message)'" -ForegroundColor Red
                return $false
            }
        } else {
            Write-Host "  ✗ FAILED: Unexpected error - Status: $statusCode" -ForegroundColor Red
            if ($errorResponse) {
                Write-Host "    Message: $($errorResponse.message)" -ForegroundColor Red
            }
            return $false
        }
    }
}

# Test 1: Health Check
Write-Host "`n1. Testing Health Endpoints..." -ForegroundColor Cyan
Test-ErrorEndpoint -Name "Health Check" -Method "GET" -Url "http://localhost:8081/api/health/simple"
Test-ErrorEndpoint -Name "Detailed Health" -Method "GET" -Url "http://localhost:8081/api/health"

# Test 2: Invalid Agreement Generation
Write-Host "`n2. Testing Invalid Agreement Requests..." -ForegroundColor Cyan
Test-ErrorEndpoint -Name "Empty Agreement Type" -Method "POST" -Url "http://localhost:8081/api/ai/create" -Body @{
    type = ""
    partyA = "Company A"
    partyB = "Company B"
} -ExpectedError "required"

Test-ErrorEndpoint -Name "Missing Content for TXT Download" -Method "POST" -Url "http://localhost:8081/api/ai/download-txt" -Body @{
    type = "Service Agreement"
    content = ""
} -ExpectedError "required"

# Test 3: Content Size Limits
Write-Host "`n3. Testing Content Size Limits..." -ForegroundColor Cyan
$largeContent = "A" * 1000001  # Over 1MB
Test-ErrorEndpoint -Name "TXT Content Too Large" -Method "POST" -Url "http://localhost:8081/api/ai/download-txt" -Body @{
    type = "Service Agreement"
    content = $largeContent
} -ExpectedError "too large"

$mediumContent = "A" * 500001  # Over 500KB
Test-ErrorEndpoint -Name "DOCX Content Too Large" -Method "POST" -Url "http://localhost:8081/api/ai/download-docx" -Body @{
    type = "Service Agreement"
    content = $mediumContent
} -ExpectedError "too large"

# Test 4: Valid Small Downloads
Write-Host "`n4. Testing Valid Downloads..." -ForegroundColor Cyan
$smallContent = "This is a small test agreement content for validation purposes."
Test-ErrorEndpoint -Name "Valid TXT Download" -Method "POST" -Url "http://localhost:8081/api/ai/download-txt" -Body @{
    type = "Service Agreement"
    partyA = "Company A"
    partyB = "Company B"
    content = $smallContent
}

Test-ErrorEndpoint -Name "Valid DOCX Download" -Method "POST" -Url "http://localhost:8081/api/ai/download-docx" -Body @{
    type = "Service Agreement"
    partyA = "Company A"
    partyB = "Company B"
    content = $smallContent
}

# Test 5: Authentication Errors
Write-Host "`n5. Testing Authentication..." -ForegroundColor Cyan
Test-ErrorEndpoint -Name "Invalid Login" -Method "POST" -Url "http://localhost:8081/api/auth/login" -Body @{
    username = "nonexistent"
    password = "wrongpassword"
} -ExpectedError "Invalid"

# Test 6: Agreement Generation with Fallbacks
Write-Host "`n6. Testing Agreement Generation..." -ForegroundColor Cyan
Test-ErrorEndpoint -Name "Basic Agreement Generation" -Method "POST" -Url "http://localhost:8081/api/ai/create" -Body @{
    type = "Service Agreement"
    partyA = "Company A"
    partyB = "Company B"
    terms = "Basic terms"
}

# Test Results Summary
Write-Host "`n=== ERROR HANDLING TEST RESULTS ===" -ForegroundColor Green
Write-Host "Tests Passed: $testsPassed / $testsTotal" -ForegroundColor $(if ($testsPassed -eq $testsTotal) { 'Green' } else { 'Yellow' })

$successRate = [math]::Round(($testsPassed / $testsTotal) * 100, 1)
Write-Host "Success Rate: $successRate%" -ForegroundColor $(if ($successRate -ge 90) { 'Green' } elseif ($successRate -ge 70) { 'Yellow' } else { 'Red' })

Write-Host "`n🛡️ ERROR HANDLING IMPROVEMENTS:" -ForegroundColor Yellow
Write-Host "✅ Global Exception Handler" -ForegroundColor Green
Write-Host "✅ Business Logic Exception Class" -ForegroundColor Green
Write-Host "✅ Input Validation Utils" -ForegroundColor Green
Write-Host "✅ User-Friendly Error Messages" -ForegroundColor Green
Write-Host "✅ Content Size Limits" -ForegroundColor Green
Write-Host "✅ Proper HTTP Status Codes" -ForegroundColor Green
Write-Host "✅ Health Check Endpoints" -ForegroundColor Green
Write-Host "✅ Frontend Error Message Enhancement" -ForegroundColor Green

if ($testsPassed -eq $testsTotal) {
    Write-Host "`n🎉 ALL ERROR HANDLING TESTS PASSED!" -ForegroundColor Green
    Write-Host "The application now has robust error handling!" -ForegroundColor Green
} else {
    Write-Host "`n⚠️ Some tests failed. Please check the server status." -ForegroundColor Yellow
}
