# 🔐 Google OAuth Setup Guide

## 📋 **Prerequisites**
- Google Cloud Console account
- Valid Gmail account
- Backend server running on port 8080
- Frontend running on port 5174

## 🚀 **Step 1: Create Google Cloud Project**

1. **Go to Google Cloud Console**: https://console.cloud.google.com/
2. **Create a new project** or select existing project
3. **Enable Google+ API** (if not already enabled)

## 🔧 **Step 2: Configure OAuth 2.0 Credentials**

1. **Navigate to APIs & Services > Credentials**
2. **Click "Create Credentials" > "OAuth 2.0 Client IDs"**
3. **Configure OAuth consent screen**:
   - User Type: External
   - App name: Legal Advisor
   - User support email: your-email@gmail.com
   - Developer contact information: your-email@gmail.com

4. **Create OAuth 2.0 Client ID**:
   - Application type: Web application
   - Name: Legal Advisor Web Client
   - Authorized JavaScript origins:
     ```
     http://localhost:5174
     http://localhost:3000
     ```
   - Authorized redirect URIs:
     ```
     http://localhost:8080/api/auth/oauth2/callback/google
     http://localhost:8080/login/oauth2/code/google
     ```

5. **Copy the credentials**:
   - Client ID
   - Client Secret

## ⚙️ **Step 3: Update Application Configuration**

### **Backend Configuration**
Update `src/main/resources/application.properties`:

```properties
# Google OAuth Configuration
spring.security.oauth2.client.registration.google.client-id=YOUR_ACTUAL_CLIENT_ID
spring.security.oauth2.client.registration.google.client-secret=YOUR_ACTUAL_CLIENT_SECRET
spring.security.oauth2.client.registration.google.scope=openid,email,profile
spring.security.oauth2.client.registration.google.redirect-uri={baseUrl}/api/auth/oauth2/callback/google
```

### **Frontend Configuration**
The frontend is already configured to work with the backend OAuth endpoints.

## 🧪 **Step 4: Test the Integration**

### **Start the Servers**
```bash
# Backend (in backend directory)
.\mvnw.cmd spring-boot:run

# Frontend (in frontend directory)
npm run dev
```

### **Test OAuth Flow**
1. **Go to**: http://localhost:5174/login
2. **Click**: "Continue with Google"
3. **Complete**: Google OAuth flow
4. **Verify**: Redirect to dashboard with JWT token

## 🔍 **Step 5: Verify OAuth Integration**

### **Check User Creation**
- New users are automatically created in MongoDB
- Email verification is automatically set to true
- Google ID is stored for future logins

### **Check JWT Token**
- Valid JWT token is generated
- User can access protected endpoints
- Token contains user information

## 🛠️ **Troubleshooting**

### **Common Issues**

1. **"Invalid redirect URI"**
   - Ensure redirect URI matches exactly in Google Console
   - Check for trailing slashes

2. **"Client ID not found"**
   - Verify client ID in application.properties
   - Check Google Cloud Console credentials

3. **"CORS errors"**
   - Ensure CORS is properly configured
   - Check frontend and backend ports

4. **"OAuth consent screen not configured"**
   - Complete OAuth consent screen setup
   - Add test users if needed

### **Debug Steps**

1. **Check browser console** for JavaScript errors
2. **Check backend logs** for OAuth processing errors
3. **Verify Google Cloud Console** settings
4. **Test with different browsers** or incognito mode

## 📱 **Frontend Integration**

### **Components Added**
- `GoogleLogin.jsx`: Google OAuth button component
- `OAuthCallback.jsx`: Handles OAuth redirect
- Updated `Login.jsx`: Includes Google OAuth option

### **Routes Added**
- `/oauth-callback`: Handles OAuth redirect with JWT token

## 🔒 **Security Features**

### **OAuth Security**
- Secure token exchange
- User data validation
- Automatic account creation
- JWT token generation

### **User Management**
- Automatic email verification
- Google ID linking
- Profile picture import
- Username generation

## 🎯 **Features Implemented**

✅ **Google OAuth Login** - Users can sign in with Gmail  
✅ **Automatic User Creation** - New users are created automatically  
✅ **JWT Token Generation** - Secure authentication tokens  
✅ **Profile Data Import** - Name, email, and profile picture  
✅ **Email Verification** - Automatically verified for OAuth users  
✅ **Frontend Integration** - Seamless UI integration  
✅ **Error Handling** - Proper error messages and redirects  

## 🚀 **Next Steps**

1. **Deploy to production** with proper domain configuration
2. **Add additional OAuth providers** (Facebook, GitHub, etc.)
3. **Implement account linking** for existing users
4. **Add OAuth logout** functionality
5. **Enhance security** with additional validation

## 📞 **Support**

If you encounter issues:
1. Check the troubleshooting section above
2. Verify Google Cloud Console settings
3. Review backend and frontend logs
4. Test with the provided test scripts

**Your Google OAuth integration is now ready!** 🎉


