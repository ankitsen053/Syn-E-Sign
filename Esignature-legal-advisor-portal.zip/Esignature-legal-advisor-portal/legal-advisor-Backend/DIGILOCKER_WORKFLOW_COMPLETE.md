# 🔐 DigiLocker Verification Workflow - Complete Implementation

## 📋 Overview

This document details the complete DigiLocker verification workflow implementation that mirrors the Cashfree/merchant dashboard approach. The system enables merchants to create verification requests and share links with customers for seamless document verification.

## 🎯 **Workflow Implementation - Exact Match to Your Requirements**

### **Merchant Side (Dashboard):**

1. **Log in to the Merchant Dashboard** ✅
   - Existing authentication system
   - Role-based access control

2. **Go to Secure ID Dashboard > Aadhaar/PAN > DigiLocker – Aadhaar** ✅
   - New merchant dashboard endpoint: `/api/merchant/digilocker/dashboard`
   - Document type selection interface

3. **Select Verify Document** ✅
   - Create verification request: `POST /api/merchant/digilocker/verification-request`
   - Support for multiple document types

4. **Select verification type (Aadhaar, PAN, Driving License) and Verify Now** ✅
   - Dynamic document selection
   - Validation and request creation

5. **Share generated DigiLocker link with customer** ✅
   - Automatic link generation with unique tokens
   - Email integration for link sharing

### **Customer Side (Verification Flow):**

6. **Customer opens the DigiLocker link** ✅
   - Public endpoint: `/api/customer/digilocker/verification/{token}`
   - Link validation and expiry checks

7. **Enter Aadhaar-linked mobile number** ✅
   - Mobile number validation
   - OTP generation and sending

8. **Enter OTP and sign in** ✅
   - OTP verification: `POST /api/customer/digilocker/verification/{token}/verify-otp`
   - Authentication state management

9. **Review consent screen and approve** ✅
   - Consent management: `POST /api/customer/digilocker/verification/{token}/consent`
   - Document sharing approval

10. **System retrieves verified documents and shares with merchant** ✅
    - Automatic DigiLocker integration
    - Webhook notifications to merchant
    - Real-time status updates

## 🏗️ **System Architecture**

### **Database Schema**

#### DigiLocker Verification Request Entity
```java
@Document(collection = "digilocker_verification_requests")
public class DigiLockerVerificationRequest {
    private String id;
    private String verificationToken;        // Unique 32-char token
    private String merchantUserId;           // Merchant who created request
    private String customerEmail;            // Customer email (optional)
    private String customerMobile;           // Customer mobile number
    private String customerName;             // Customer name (optional)
    
    // Verification Configuration
    private List<String> requestedDocuments; // [AADHAAR, PAN, etc.]
    private String verificationPurpose;      // Purpose of verification
    private boolean consentRequired;         // Consent requirement flag
    
    // Link Management
    private String verificationLink;         // Generated customer link
    private LocalDateTime linkExpiresAt;     // Link expiration
    private boolean linkActive;              // Link status
    
    // Customer Journey Tracking
    private boolean linkOpened;              // Link opened by customer
    private boolean otpSent;                 // OTP sent to mobile
    private boolean customerAuthenticated;   // Customer authenticated
    private boolean consentGiven;            // Consent provided
    
    // Results
    private String digiLockerId;             // Customer's DigiLocker ID
    private String verificationResult;       // JSON verification results
    private VerificationRequestStatus status; // Current status
    
    // Webhook
    private String webhookUrl;               // Merchant notification URL
    private boolean webhookSent;             // Webhook delivery status
}
```

### **API Endpoints**

#### **Merchant Dashboard APIs**
```
# Dashboard Overview
GET /api/merchant/digilocker/dashboard
- Returns: Statistics, recent requests, status breakdown

# Create Verification Request  
POST /api/merchant/digilocker/verification-request
Body: {
  "requestedDocuments": ["AADHAAR", "PAN"],
  "customerEmail": "customer@example.com",
  "customerMobile": "+919876543210",
  "customerName": "John Doe",
  "verificationPurpose": "KYC for loan application",
  "webhookUrl": "https://merchant.com/webhook",
  "linkExpiryHours": 24
}
Response: {
  "success": true,
  "verificationRequestId": "req_123",
  "verificationToken": "abcd1234...",
  "verificationLink": "http://frontend.com/verify/abcd1234...",
  "expiresAt": "2024-01-16T10:30:00"
}

# Get Request Details
GET /api/merchant/digilocker/verification-request/{requestId}

# Cancel Request
POST /api/merchant/digilocker/verification-request/{requestId}/cancel

# Resend Link
POST /api/merchant/digilocker/verification-request/{requestId}/resend
```

#### **Customer Verification APIs**
```
# Get Verification Details (Customer opens link)
GET /api/customer/digilocker/verification/{token}
Response: {
  "success": true,
  "requestedDocuments": ["AADHAAR", "PAN"],
  "verificationPurpose": "KYC for loan application",
  "currentStep": "MOBILE_ENTRY",
  "progress": 0.0
}

# Send OTP to Mobile
POST /api/customer/digilocker/verification/{token}/send-otp
Body: { "mobileNumber": "+919876543210" }

# Verify OTP
POST /api/customer/digilocker/verification/{token}/verify-otp
Body: { "mobileNumber": "+919876543210", "otp": "123456" }

# Submit Consent
POST /api/customer/digilocker/verification/{token}/consent
Body: { "consentGiven": true, "consentText": "I consent..." }
Response: {
  "success": true,
  "status": "COMPLETED",
  "progress": 100.0,
  "verifiedDocuments": ["AADHAAR", "PAN"]
}
```

## 🔄 **Complete Workflow Steps**

### **Step 1: Merchant Creates Verification Request**
```bash
# Merchant logs into dashboard and creates request
curl -X POST http://localhost:8081/api/merchant/digilocker/verification-request \
  -H "Authorization: Bearer MERCHANT_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "requestedDocuments": ["AADHAAR", "PAN"],
    "customerEmail": "customer@example.com",
    "customerMobile": "+919876543210",
    "customerName": "John Doe",
    "verificationPurpose": "Document verification for legal services",
    "webhookUrl": "https://merchant.com/webhook"
  }'
```

**Response:**
```json
{
  "success": true,
  "verificationRequestId": "507f1f77bcf86cd799439011",
  "verificationToken": "a1b2c3d4e5f6789012345678901234567890abcd",
  "verificationLink": "http://localhost:3000/verify/a1b2c3d4e5f6789012345678901234567890abcd",
  "status": "PENDING",
  "expiresAt": "2024-01-16T10:30:00",
  "message": "Verification request created successfully. Share the link with your customer."
}
```

### **Step 2: Customer Opens Verification Link**
```bash
# Customer clicks the shared link
curl -X GET http://localhost:8081/api/customer/digilocker/verification/a1b2c3d4e5f6789012345678901234567890abcd
```

**Response:**
```json
{
  "success": true,
  "verificationToken": "a1b2c3d4e5f6789012345678901234567890abcd",
  "requestedDocuments": ["AADHAAR", "PAN"],
  "verificationPurpose": "Document verification for legal services",
  "customerName": "John Doe",
  "currentStep": "MOBILE_ENTRY",
  "progress": 20.0,
  "expiresAt": "2024-01-16T10:30:00"
}
```

### **Step 3: Customer Enters Mobile Number & Gets OTP**
```bash
# Customer enters mobile number
curl -X POST http://localhost:8081/api/customer/digilocker/verification/a1b2c3d4e5f6789012345678901234567890abcd/send-otp \
  -H "Content-Type: application/json" \
  -d '{ "mobileNumber": "+919876543210" }'
```

**Response:**
```json
{
  "message": "OTP sent to your mobile number ending with 3210"
}
```

### **Step 4: Customer Verifies OTP**
```bash
# Customer enters received OTP
curl -X POST http://localhost:8081/api/customer/digilocker/verification/a1b2c3d4e5f6789012345678901234567890abcd/verify-otp \
  -H "Content-Type: application/json" \
  -d '{
    "mobileNumber": "+919876543210",
    "otp": "123456"
  }'
```

**Response:**
```json
{
  "message": "OTP verified successfully. Please proceed to consent."
}
```

### **Step 5: Customer Reviews & Provides Consent**
```bash
# Customer approves document sharing
curl -X POST http://localhost:8081/api/customer/digilocker/verification/a1b2c3d4e5f6789012345678901234567890abcd/consent \
  -H "Content-Type: application/json" \
  -d '{
    "consentGiven": true,
    "consentText": "I hereby consent to share my documents from DigiLocker for verification purposes"
  }'
```

**Response:**
```json
{
  "success": true,
  "status": "COMPLETED",
  "progress": 100.0,
  "message": "Document verification completed successfully!",
  "verifiedDocuments": ["AADHAAR", "PAN"],
  "verificationTime": "2024-01-15T15:45:30"
}
```

### **Step 6: Merchant Receives Webhook Notification**
```json
# Webhook sent to merchant's configured URL
POST https://merchant.com/webhook
{
  "event": "verification.completed",
  "timestamp": "2024-01-15T15:45:30",
  "webhook_id": "wh_12345678",
  "verification_request": {
    "id": "507f1f77bcf86cd799439011",
    "verification_token": "a1b2c3d4e5f6789012345678901234567890abcd",
    "merchant_user_id": "merchant123",
    "status": "COMPLETED",
    "requested_documents": ["AADHAAR", "PAN"],
    "created_at": "2024-01-15T10:30:00",
    "completed_at": "2024-01-15T15:45:30",
    "customer": {
      "name": "John Doe",
      "email": "customer@example.com",
      "mobile": "+9****3210"
    }
  },
  "verification_results": {
    "success": true,
    "digilocker_id": "12345678****9abc",
    "total_documents": 2,
    "documents": {
      "aadhaar_available": true,
      "pan_available": true
    },
    "aadhaar_document": {
      "document_type": "AADHAAR",
      "issuer": "UIDAI",
      "verified": true,
      "issue_date": "2020-01-15"
    },
    "pan_document": {
      "document_type": "PAN", 
      "issuer": "Income Tax Department",
      "verified": true,
      "issue_date": "2019-05-10"
    }
  }
}
```

## 🎨 **Frontend Components**

### **Merchant Dashboard Component**
```jsx
// MerchantDashboard.jsx - Overview and management
// VerificationRequestForm.jsx - Create new requests
// RequestList.jsx - View and manage requests
// RequestDetails.jsx - Individual request details
// WebhookSettings.jsx - Webhook configuration
```

### **Customer Verification Component**
```jsx
// CustomerVerification.jsx - Main verification flow
// MobileEntry.jsx - Mobile number input
// OtpVerification.jsx - OTP input and verification
// ConsentScreen.jsx - Document sharing consent
// VerificationComplete.jsx - Success/failure screen
```

## 📊 **Merchant Dashboard Features**

### **Dashboard Statistics**
- Total verification requests
- Success rate percentage
- Pending/completed/failed counts
- Document type breakdown
- Recent activity timeline

### **Request Management**
- Create new verification requests
- View request details and status
- Cancel pending requests
- Resend verification links
- Download verification reports

### **Webhook Configuration**
- Configure webhook endpoints
- Test webhook connectivity
- View webhook delivery logs
- Retry failed webhooks

## 🔐 **Security Features**

### **Token Security**
- 32-character cryptographically secure tokens
- Time-based expiration (24 hours default)
- Single-use verification flow
- Token invalidation after completion

### **OTP Security**
- 6-digit random OTP generation
- 10-minute expiration
- Maximum 3 retry attempts
- Rate limiting protection

### **Data Privacy**
- Mobile number masking in logs
- DigiLocker ID masking
- Secure webhook payload signing
- GDPR-compliant data handling

## 🧪 **Testing the Complete Workflow**

### **1. Start the Application**
```bash
.\mvnw.cmd spring-boot:run
```

### **2. Create Merchant Account & Login**
```bash
# Register merchant user
curl -X POST http://localhost:8081/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "username": "merchant1",
    "email": "merchant@example.com", 
    "password": "password123",
    "fullName": "Merchant User"
  }'

# Login to get JWT token  
curl -X POST http://localhost:8081/api/auth/signin \
  -H "Content-Type: application/json" \
  -d '{
    "username": "merchant1",
    "password": "password123"
  }'
```

### **3. Test Complete Workflow**
```bash
# Use the workflow steps provided above with the JWT token
# from the signin response
```

## 🎉 **Implementation Complete**

The DigiLocker verification workflow is now **fully implemented** and matches your exact requirements:

✅ **Merchant Dashboard** - Create and manage verification requests  
✅ **Link Generation** - Secure verification links for customers  
✅ **Customer Flow** - Mobile → OTP → Consent → Verification  
✅ **Document Verification** - Automatic DigiLocker integration  
✅ **Webhook Notifications** - Real-time merchant updates  
✅ **Security** - Token-based authentication and data protection  
✅ **Status Tracking** - Complete journey visibility  
✅ **Error Handling** - Comprehensive error management  

The system is production-ready and provides the exact workflow you described, enabling merchants to easily verify customer documents through DigiLocker with a seamless user experience! 🚀
