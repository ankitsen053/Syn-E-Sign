# Complete E-Signature Flow Test Script
# This script tests the entire workflow from user login to document signing

Write-Host "=== Legal Advisor E-Signature Flow Test ===" -ForegroundColor Cyan
Write-Host "Testing complete workflow: Login -> Generate Document -> Sign -> Verify" -ForegroundColor Yellow

$baseUrl = "http://localhost:8081/api"
$frontendUrl = "http://localhost:5173"

# Test Configuration
$testUser = @{
    username = "testuser"
    email = "test@example.com"
    password = "Test123!"
    fullName = "Test User"
}

$testAgreement = @{
    type = "Service Agreement"
    partyA = "Test Company Inc."
    partyB = "Client Corporation"
    terms = "This is a comprehensive service agreement with detailed terms and conditions for testing purposes."
}

# Function to make HTTP requests with error handling
function Invoke-SafeRestMethod {
    param(
        [string]$Uri,
        [string]$Method = "GET",
        [hashtable]$Headers = @{},
        [object]$Body = $null,
        [string]$ContentType = "application/json"
    )
    
    try {
        $params = @{
            Uri = $Uri
            Method = $Method
            Headers = $Headers
            ContentType = $ContentType
            UseBasicParsing = $true
        }
        
        if ($Body) {
            if ($ContentType -eq "application/json") {
                $params.Body = $Body | ConvertTo-Json -Depth 10
            } else {
                $params.Body = $Body
            }
        }
        
        $response = Invoke-RestMethod @params
        return $response
    }
    catch {
        Write-Host "Error calling $Uri : $($_.Exception.Message)" -ForegroundColor Red
        if ($_.Exception.Response) {
            $errorResponse = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($errorResponse)
            $errorContent = $reader.ReadToEnd()
            Write-Host "Error Response: $errorContent" -ForegroundColor Red
        }
        throw
    }
}

# Test 1: Backend Health Check
Write-Host "`n1. Testing Backend Health..." -ForegroundColor Green
try {
    $healthResponse = Invoke-SafeRestMethod -Uri "$baseUrl/test/hello"
    Write-Host "✓ Backend is healthy: $($healthResponse.message)" -ForegroundColor Green
}
catch {
    Write-Host "✗ Backend health check failed" -ForegroundColor Red
    exit 1
}

# Test 2: User Signup (if needed)
Write-Host "`n2. Testing User Registration..." -ForegroundColor Green
try {
    $signupResponse = Invoke-SafeRestMethod -Uri "$baseUrl/auth/signup" -Method POST -Body $testUser
    Write-Host "✓ User registration: $($signupResponse.message)" -ForegroundColor Green
}
catch {
    Write-Host "! User might already exist, continuing..." -ForegroundColor Yellow
}

# Test 3: User Login
Write-Host "`n3. Testing User Login..." -ForegroundColor Green
try {
    $loginData = @{
        username = $testUser.username
        password = $testUser.password
    }
    $loginResponse = Invoke-SafeRestMethod -Uri "$baseUrl/auth/login" -Method POST -Body $loginData
    $authToken = $loginResponse.token
    $authHeaders = @{ "Authorization" = "Bearer $authToken" }
    Write-Host "✓ User logged in successfully" -ForegroundColor Green
    Write-Host "  Token: $($authToken.Substring(0, 20))..." -ForegroundColor Cyan
}
catch {
    Write-Host "✗ User login failed" -ForegroundColor Red
    exit 1
}

# Test 4: Create Agreement Document
Write-Host "`n4. Testing Agreement Generation..." -ForegroundColor Green
try {
    $agreementResponse = Invoke-SafeRestMethod -Uri "$baseUrl/ai/create" -Method POST -Body $testAgreement -Headers $authHeaders
    $generatedDocument = $agreementResponse.document
    Write-Host "✓ Agreement generated successfully" -ForegroundColor Green
    Write-Host "  Document length: $($generatedDocument.Length) characters" -ForegroundColor Cyan
}
catch {
    Write-Host "✗ Agreement generation failed" -ForegroundColor Red
    exit 1
}

# Test 5: Simulate Signature Creation (Base64 encoded sample signature)
Write-Host "`n5. Creating Mock Signature..." -ForegroundColor Green
$mockSignatureBase64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
Write-Host "✓ Mock signature created" -ForegroundColor Green

# Test 6: Sign Agreement
Write-Host "`n6. Testing Agreement Signing..." -ForegroundColor Green
try {
    $signatureRequest = @{
        agreementTitle = "$($testAgreement.type) - $($testAgreement.partyA) and $($testAgreement.partyB)"
        agreementContent = $generatedDocument
        agreementType = $testAgreement.type
        partyA = $testAgreement.partyA
        partyB = $testAgreement.partyB
        terms = $testAgreement.terms
        signatureImageBase64 = $mockSignatureBase64
        signerName = $testUser.fullName
        signerEmail = $testUser.email
    }
    
    $signResponse = Invoke-SafeRestMethod -Uri "$baseUrl/signature/sign" -Method POST -Body $signatureRequest -Headers $authHeaders
    $agreementId = $signResponse.agreementId
    Write-Host "✓ Agreement signed successfully" -ForegroundColor Green
    Write-Host "  Agreement ID: $agreementId" -ForegroundColor Cyan
    Write-Host "  Signed At: $($signResponse.signedAt)" -ForegroundColor Cyan
    Write-Host "  Document Hash: $($signResponse.documentHash.Substring(0, 16))..." -ForegroundColor Cyan
}
catch {
    Write-Host "✗ Agreement signing failed" -ForegroundColor Red
    exit 1
}

# Test 7: Retrieve User Agreements
Write-Host "`n7. Testing Agreement Retrieval..." -ForegroundColor Green
try {
    $userAgreements = Invoke-SafeRestMethod -Uri "$baseUrl/signature/user/agreements" -Headers $authHeaders
    Write-Host "✓ Retrieved $($userAgreements.count) user agreements" -ForegroundColor Green
    
    if ($userAgreements.agreements -and $userAgreements.agreements.Count -gt 0) {
        $latestAgreement = $userAgreements.agreements[0]
        Write-Host "  Latest Agreement:" -ForegroundColor Cyan
        Write-Host "    Title: $($latestAgreement.title)" -ForegroundColor Cyan
        Write-Host "    Status: $($latestAgreement.status)" -ForegroundColor Cyan
        Write-Host "    Type: $($latestAgreement.type)" -ForegroundColor Cyan
    }
}
catch {
    Write-Host "✗ Agreement retrieval failed" -ForegroundColor Red
    exit 1
}

# Test 8: Get Signature Statistics
Write-Host "`n8. Testing Signature Statistics..." -ForegroundColor Green
try {
    $stats = Invoke-SafeRestMethod -Uri "$baseUrl/signature/stats" -Headers $authHeaders
    Write-Host "✓ Retrieved signature statistics" -ForegroundColor Green
    Write-Host "  Total Signed: $($stats.totalSigned)" -ForegroundColor Cyan
    Write-Host "  User Agreements: $($stats.userAgreements)" -ForegroundColor Cyan
    Write-Host "  Drafts: $($stats.drafts)" -ForegroundColor Cyan
}
catch {
    Write-Host "✗ Statistics retrieval failed" -ForegroundColor Red
    exit 1
}

# Test 9: Agreement Verification
Write-Host "`n9. Testing Agreement Verification..." -ForegroundColor Green
try {
    $verification = Invoke-SafeRestMethod -Uri "$baseUrl/signature/$agreementId/verify" -Headers $authHeaders
    Write-Host "✓ Agreement verification completed" -ForegroundColor Green
    Write-Host "  Document Valid: $($verification.documentIntegrityValid)" -ForegroundColor Cyan
    Write-Host "  Signature Valid: $($verification.signatureIntegrityValid)" -ForegroundColor Cyan
}
catch {
    Write-Host "✗ Agreement verification failed" -ForegroundColor Red
    exit 1
}

# Test 10: Frontend Accessibility Check
Write-Host "`n10. Testing Frontend Accessibility..." -ForegroundColor Green
try {
    $frontendResponse = Invoke-WebRequest -Uri $frontendUrl -UseBasicParsing -TimeoutSec 10
    if ($frontendResponse.StatusCode -eq 200) {
        Write-Host "✓ Frontend is accessible" -ForegroundColor Green
        Write-Host "  Frontend URL: $frontendUrl" -ForegroundColor Cyan
    }
}
catch {
    Write-Host "! Frontend might not be running on $frontendUrl" -ForegroundColor Yellow
    Write-Host "  Make sure to run 'npm run dev' in the legal-advisor-frontend directory" -ForegroundColor Yellow
}

# Summary
Write-Host "`n=== E-Signature Flow Test Summary ===" -ForegroundColor Cyan
Write-Host "✓ Backend Health Check" -ForegroundColor Green
Write-Host "✓ User Authentication" -ForegroundColor Green
Write-Host "✓ Document Generation" -ForegroundColor Green
Write-Host "✓ Document Signing" -ForegroundColor Green
Write-Host "✓ Signature Storage" -ForegroundColor Green
Write-Host "✓ Agreement Retrieval" -ForegroundColor Green
Write-Host "✓ Statistics & Verification" -ForegroundColor Green

Write-Host "`n🎉 All tests completed successfully!" -ForegroundColor Green
Write-Host "`nTo test the complete UI flow:" -ForegroundColor Yellow
Write-Host "1. Open $frontendUrl in your browser" -ForegroundColor White
Write-Host "2. Login with username: $($testUser.username), password: $($testUser.password)" -ForegroundColor White
Write-Host "3. Navigate to the 'Generate Documents' tab" -ForegroundColor White
Write-Host "4. Switch to the 'E-Sign Portal' tab" -ForegroundColor White
Write-Host "5. Create and sign an agreement using the draw signature feature" -ForegroundColor White
Write-Host "6. Verify the signed agreement appears in your agreements list" -ForegroundColor White

Write-Host "`nKey Features Verified:" -ForegroundColor Cyan
Write-Host "• User authentication and authorization ✓" -ForegroundColor White
Write-Host "• Document generation with AI ✓" -ForegroundColor White
Write-Host "• Digital signature creation and storage ✓" -ForegroundColor White
Write-Host "• Signature linked to logged-in user ✓" -ForegroundColor White
Write-Host "• Document integrity verification ✓" -ForegroundColor White
Write-Host "• User-specific agreement management ✓" -ForegroundColor White
