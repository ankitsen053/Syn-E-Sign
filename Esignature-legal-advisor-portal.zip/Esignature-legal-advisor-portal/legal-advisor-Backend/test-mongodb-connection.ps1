# Quick MongoDB Connection Test
Write-Host "=== Quick MongoDB Connection Test ===" -ForegroundColor Green
Write-Host ""

# Test 1: Basic network connectivity
Write-Host "1. Testing basic network connectivity..." -ForegroundColor Yellow
try {
    $pingResult = Test-Connection "cluster0.klor1l5.mongodb.net" -Count 1 -Quiet
    if ($pingResult) {
        Write-Host "   ✓ Network connectivity OK" -ForegroundColor Green
    } else {
        Write-Host "   ✗ Network connectivity failed" -ForegroundColor Red
    }
} catch {
    Write-Host "   ✗ Network test error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: DNS resolution
Write-Host "2. Testing DNS resolution..." -ForegroundColor Yellow
try {
    $dnsResult = Resolve-DnsName "cluster0.klor1l5.mongodb.net" -ErrorAction Stop
    Write-Host "   ✓ DNS resolution OK: $($dnsResult.IPAddress)" -ForegroundColor Green
} catch {
    Write-Host "   ✗ DNS resolution failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== Quick Fix Options ===" -ForegroundColor Green
Write-Host "Option 1: Use local MongoDB profile" -ForegroundColor Cyan
Write-Host "  mvn spring-boot:run -Dspring.profiles.active=local" -ForegroundColor White
Write-Host ""
Write-Host "Option 2: Test with enhanced connection string" -ForegroundColor Cyan
Write-Host "  Edit application.properties and use enhanced timeout settings" -ForegroundColor White
Write-Host ""
Write-Host "Option 3: Install local MongoDB" -ForegroundColor Cyan
Write-Host "  Download from: https://www.mongodb.com/try/download/community" -ForegroundColor White
Write-Host ""
Write-Host "Option 4: Check MongoDB Atlas" -ForegroundColor Cyan
Write-Host "  - Verify cluster is running" -ForegroundColor White
Write-Host "  - Check IP whitelist" -ForegroundColor White
Write-Host "  - Verify credentials" -ForegroundColor White

Write-Host ""
Write-Host "=== Ready to Test ===" -ForegroundColor Green
Write-Host "Run one of the options above to resolve the MongoDB connection issue." -ForegroundColor White
