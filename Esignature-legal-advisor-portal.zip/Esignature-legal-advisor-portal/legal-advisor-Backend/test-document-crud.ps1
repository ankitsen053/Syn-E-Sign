# Test Document CRUD Operations and Download Functionality
Write-Host "🔧 Testing Document CRUD Operations and Download" -ForegroundColor Cyan
Write-Host "=================================================" -ForegroundColor Cyan

# Check if server is running
Write-Host "`n1. Checking server status..." -ForegroundColor Yellow
try {
    $statusResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/status" -Method GET -TimeoutSec 10
    Write-Host "✅ Server is running" -ForegroundColor Green
    Write-Host "   Status: $($statusResponse.status)" -ForegroundColor Gray
    Write-Host "   Version: $($statusResponse.version)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Server is not running. Please start the server first." -ForegroundColor Red
    Write-Host "   Run: .\mvnw.cmd spring-boot:run" -ForegroundColor Yellow
    exit 1
}

# Run document migration to fix existing documents
Write-Host "`n2. Running document migration..." -ForegroundColor Yellow
try {
    $migrationResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/migrate" -Method POST -TimeoutSec 30
    Write-Host "✅ Document migration completed successfully" -ForegroundColor Green
    Write-Host "   Message: $($migrationResponse.message)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Document migration failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test CRUD Operations
Write-Host "`n3. Testing Document CRUD Operations..." -ForegroundColor Yellow

# Test CREATE - Save new document
Write-Host "   Testing CREATE operation..." -ForegroundColor Gray
$newDocData = @{
    title = "Test CRUD Document - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    content = "This is a test document to verify CRUD operations work properly after the null user reference fix."
    type = "Test Agreement"
    partyA = "Test Company A"
    partyB = "Test Company B"
    terms = "Standard test terms and conditions for CRUD testing."
}

try {
    $saveResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/save" -Method POST -Body ($newDocData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
    Write-Host "   ✅ CREATE operation successful" -ForegroundColor Green
    Write-Host "   📄 Document ID: $($saveResponse.document.id)" -ForegroundColor Gray
    $testDocumentId = $saveResponse.document.id
} catch {
    Write-Host "   ❌ CREATE operation failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test READ - Get the created document
Write-Host "   Testing READ operation..." -ForegroundColor Gray
try {
    $getResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$testDocumentId" -Method GET -TimeoutSec 10
    Write-Host "   ✅ READ operation successful" -ForegroundColor Green
    Write-Host "   📄 Document Title: $($getResponse.document.title)" -ForegroundColor Gray
} catch {
    Write-Host "   ❌ READ operation failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test UPDATE - Update the document
Write-Host "   Testing UPDATE operation..." -ForegroundColor Gray
$updateData = @{
    title = $newDocData.title + " (UPDATED)"
    content = $newDocData.content + " This content has been updated to test the UPDATE operation."
    type = $newDocData.type
    partyA = $newDocData.partyA
    partyB = $newDocData.partyB
    terms = $newDocData.terms + " Updated terms for testing."
}

try {
    $updateResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$testDocumentId" -Method PUT -Body ($updateData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
    Write-Host "   ✅ UPDATE operation successful" -ForegroundColor Green
    Write-Host "   📝 Updated Title: $($updateResponse.document.title)" -ForegroundColor Gray
    Write-Host "   🔢 Version: $($updateResponse.document.version)" -ForegroundColor Gray
} catch {
    Write-Host "   ❌ UPDATE operation failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test DOWNLOAD - Download the document
Write-Host "   Testing DOWNLOAD operation..." -ForegroundColor Gray
try {
    $downloadResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$testDocumentId/download" -Method GET -TimeoutSec 10
    Write-Host "   ✅ DOWNLOAD operation successful" -ForegroundColor Green
    Write-Host "   📥 Document downloaded successfully" -ForegroundColor Gray
} catch {
    Write-Host "   ❌ DOWNLOAD operation failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test DELETE - Delete the document
Write-Host "   Testing DELETE operation..." -ForegroundColor Gray
try {
    $deleteResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$testDocumentId" -Method DELETE -TimeoutSec 10
    Write-Host "   ✅ DELETE operation successful" -ForegroundColor Green
    Write-Host "   🗑️ Document deleted successfully" -ForegroundColor Gray
} catch {
    Write-Host "   ❌ DELETE operation failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Verify document is deleted
Write-Host "   Verifying DELETE operation..." -ForegroundColor Gray
try {
    $verifyResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$testDocumentId" -Method GET -TimeoutSec 10
    Write-Host "   ❌ Document still exists after deletion" -ForegroundColor Red
} catch {
    Write-Host "   ✅ Document successfully deleted (not found)" -ForegroundColor Green
}

# Test existing documents
Write-Host "`n4. Testing existing documents..." -ForegroundColor Yellow
try {
    $userDocsResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/user" -Method GET -TimeoutSec 10
    Write-Host "   ✅ User documents retrieved successfully" -ForegroundColor Green
    Write-Host "   📄 Found $($userDocsResponse.documents.Count) existing documents" -ForegroundColor Gray
    
    # Test operations on existing documents if any exist
    if ($userDocsResponse.documents.Count -gt 0) {
        $existingDoc = $userDocsResponse.documents[0]
        Write-Host "   Testing operations on existing document: $($existingDoc.title)" -ForegroundColor Gray
        
        # Test update on existing document
        $existingUpdateData = @{
            title = $existingDoc.title + " (Test Update)"
            content = $existingDoc.content
            type = $existingDoc.type
            partyA = $existingDoc.partyA
            partyB = $existingDoc.partyB
            terms = $existingDoc.terms
        }
        
        try {
            $existingUpdateResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$($existingDoc.id)" -Method PUT -Body ($existingUpdateData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
            Write-Host "   ✅ Existing document update successful" -ForegroundColor Green
        } catch {
            Write-Host "   ❌ Existing document update failed" -ForegroundColor Red
            Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
        }
        
        # Test download on existing document
        try {
            $existingDownloadResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$($existingDoc.id)/download" -Method GET -TimeoutSec 10
            Write-Host "   ✅ Existing document download successful" -ForegroundColor Green
        } catch {
            Write-Host "   ❌ Existing document download failed" -ForegroundColor Red
            Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
} catch {
    Write-Host "   ❌ Failed to retrieve user documents" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Document CRUD Operations Test Completed!" -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Green
Write-Host "✅ CREATE: New document creation" -ForegroundColor White
Write-Host "✅ READ: Document retrieval" -ForegroundColor White
Write-Host "✅ UPDATE: Document modification" -ForegroundColor White
Write-Host "✅ DOWNLOAD: Document download" -ForegroundColor White
Write-Host "✅ DELETE: Document removal" -ForegroundColor White
Write-Host "`nAll CRUD operations should now work without null user reference errors!" -ForegroundColor White
