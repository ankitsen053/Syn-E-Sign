# KYC Verification Test Script
# This script tests the PAN and Aadhaar verification endpoints

Write-Host "=== KYC Verification Test Script ===" -ForegroundColor Green
Write-Host "Testing PAN and Aadhaar verification endpoints" -ForegroundColor Yellow
Write-Host ""

# Configuration
$BASE_URL = "http://localhost:8081"
$API_BASE = "$BASE_URL/api"

# Test data
$TEST_PAN = "ABCDE1234F"
$TEST_AADHAAR = "123456789012"

Write-Host "1. Testing KYC Service Health Check..." -ForegroundColor Cyan
try {
    $response = Invoke-RestMethod -Uri "$API_BASE/kyc/health" -Method GET -ContentType "application/json"
    Write-Host "Health Check Response:" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 3
} catch {
    Write-Host "Health Check Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "2. Testing Available KYC Providers..." -ForegroundColor Cyan
try {
    $response = Invoke-RestMethod -Uri "$API_BASE/kyc/providers" -Method GET -ContentType "application/json"
    Write-Host "Providers Response:" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 3
} catch {
    Write-Host "Providers Check Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "3. Testing PAN Verification..." -ForegroundColor Cyan
try {
    $panPayload = @{
        panNumber = $TEST_PAN
        documentUrl = "https://example.com/pan-document.pdf"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/kyc/verify/pan" -Method POST -Body $panPayload -ContentType "application/json"
    Write-Host "PAN Verification Response:" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 5
} catch {
    Write-Host "PAN Verification Failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}
Write-Host ""

Write-Host "4. Testing Aadhaar Verification..." -ForegroundColor Cyan
try {
    $aadhaarPayload = @{
        aadharNumber = $TEST_AADHAAR
        documentUrl = "https://example.com/aadhaar-document.pdf"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/kyc/verify/aadhaar" -Method POST -Body $aadhaarPayload -ContentType "application/json"
    Write-Host "Aadhaar Verification Response:" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 5
} catch {
    Write-Host "Aadhaar Verification Failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}
Write-Host ""

Write-Host "5. Testing Bulk Verification..." -ForegroundColor Cyan
try {
    $bulkPayload = @{
        panNumber = $TEST_PAN
        aadhaarNumber = $TEST_AADHAAR
        panDocumentUrl = "https://example.com/pan-document.pdf"
        aadhaarDocumentUrl = "https://example.com/aadhaar-document.pdf"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/kyc/verify/bulk" -Method POST -Body $bulkPayload -ContentType "application/json"
    Write-Host "Bulk Verification Response:" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 5
} catch {
    Write-Host "Bulk Verification Failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}
Write-Host ""

Write-Host "=== KYC Verification Test Summary ===" -ForegroundColor Green
Write-Host "Health check endpoint tested" -ForegroundColor Green
Write-Host "Providers endpoint tested" -ForegroundColor Green
Write-Host "PAN verification endpoint tested" -ForegroundColor Green
Write-Host "Aadhaar verification endpoint tested" -ForegroundColor Green
Write-Host "Bulk verification endpoint tested" -ForegroundColor Green
Write-Host ""
Write-Host "Note: This test uses mock verification since API keys are not configured." -ForegroundColor Yellow
Write-Host "To test with real APIs, configure the API keys in application.properties" -ForegroundColor Yellow
Write-Host ""

Write-Host "Test completed!" -ForegroundColor Green
