Write-Host "========================================" -ForegroundColor Green
Write-Host "Legal Advisor API Testing Script" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

Write-Host "Starting Spring Boot Application..." -ForegroundColor Yellow
Write-Host "Please wait for the application to start..." -ForegroundColor Yellow
Write-Host ""

# Get the directory where this script is located
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptPath

# Start the Spring Boot application
mvn spring-boot:run

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "Application should be running on:" -ForegroundColor Green
Write-Host "http://localhost:8080" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "1. Open Thunder Client in VS Code" -ForegroundColor White
Write-Host "2. Import thunder-client-collection.json" -ForegroundColor White
Write-Host "3. Start testing with Health Check endpoint" -ForegroundColor White
Write-Host "4. Follow the API_TESTING_GUIDE.md for detailed instructions" -ForegroundColor White
Write-Host ""
Write-Host "Press any key to exit..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
