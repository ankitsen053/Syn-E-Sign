#!/usr/bin/env pwsh

Write-Host "=== Testing Signup Fix ===" -ForegroundColor Green
Write-Host ""

# Test 1: Check server status
Write-Host "1. Checking server status..." -ForegroundColor Yellow
try {
    $healthResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/test/health" -Method GET -TimeoutSec 10
    Write-Host "✓ Server is running: $healthResponse" -ForegroundColor Green
} catch {
    Write-Host "✗ Server not running: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test 2: Test signup with detailed error handling
Write-Host ""
Write-Host "2. Testing signup endpoint..." -ForegroundColor Yellow

$signupData = @{
    username = "testuser$(Get-Random -Maximum 1000)"
    email = "test$(Get-Random -Maximum 1000)@example.com"
    password = "password123"
    fullName = "Test User"
}

$signupJson = $signupData | ConvertTo-Json

Write-Host "Signup data: $signupJson" -ForegroundColor Cyan

try {
    # Try signup
    $signupResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/signup" -Method POST -Body $signupJson -ContentType "application/json" -TimeoutSec 30
    Write-Host "✓ Signup successful!" -ForegroundColor Green
    Write-Host "Response: $($signupResponse | ConvertTo-Json)" -ForegroundColor Cyan
    
    # Test login with the same user
    Write-Host ""
    Write-Host "3. Testing login with new user..." -ForegroundColor Yellow
    
    $loginData = @{
        username = $signupData.username
        password = $signupData.password
    } | ConvertTo-Json
    
    try {
        $loginResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/login" -Method POST -Body $loginData -ContentType "application/json" -TimeoutSec 30
        Write-Host "✓ Login successful!" -ForegroundColor Green
        Write-Host "Token: $($loginResponse.accessToken.Substring(0, 20))..." -ForegroundColor Cyan
    } catch {
        Write-Host "✗ Login failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    
} catch {
    Write-Host "✗ Signup failed!" -ForegroundColor Red
    
    # Get more detailed error information
    if ($_.Exception.Response) {
        try {
            $errorStream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($errorStream)
            $errorContent = $reader.ReadToEnd()
            Write-Host "Error details: $errorContent" -ForegroundColor Red
        } catch {
            Write-Host "Could not read error details" -ForegroundColor Red
        }
    }
    
    Write-Host "Exception: $($_.Exception.Message)" -ForegroundColor Red
    
    # Let's try to debug what's happening
    Write-Host ""
    Write-Host "Debugging information:" -ForegroundColor Yellow
    Write-Host "URI: http://localhost:8081/api/auth/signup" -ForegroundColor Cyan
    Write-Host "Method: POST" -ForegroundColor Cyan
    Write-Host "Content-Type: application/json" -ForegroundColor Cyan
    Write-Host "Body: $signupJson" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "=== Test Complete ===" -ForegroundColor Green
