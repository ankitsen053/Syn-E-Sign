# Enhanced Verification System Test Script
# This script tests all the improved verification features

Write-Host "=== Enhanced Verification System Test Script ===" -ForegroundColor Green
Write-Host "Testing all verification improvements and features" -ForegroundColor Yellow
Write-Host ""

# Configuration
$BASE_URL = "http://localhost:8081"
$API_BASE = "$BASE_URL/api"

# Test data
$TEST_PAN = "ABCDE1234F"
$TEST_AADHAAR = "123456789012"
$TEST_USER_ID = "test-user-123"

Write-Host "1. Testing Enhanced PAN Verification..." -ForegroundColor Cyan
Write-Host "   - Detailed validation messages" -ForegroundColor Gray
Write-Host "   - Duplicate verification check" -ForegroundColor Gray
Write-Host "   - Enhanced error handling" -ForegroundColor Gray
Write-Host ""

try {
    # Test 1: Valid PAN
    $panPayload = @{
        panNumber = $TEST_PAN
        documentUrl = "https://example.com/pan-document.pdf"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/verification/pan" -Method POST -Body $panPayload -ContentType "application/json"
    Write-Host "✓ PAN Verification (Valid):" -ForegroundColor Green
    Write-Host "  Response: $($response.message)" -ForegroundColor White
    
    # Test 2: Invalid PAN format
    $invalidPanPayload = @{
        panNumber = "INVALID123"
        documentUrl = "https://example.com/pan-document.pdf"
    } | ConvertTo-Json

    try {
        $response = Invoke-RestMethod -Uri "$API_BASE/verification/pan" -Method POST -Body $invalidPanPayload -ContentType "application/json"
        Write-Host "✗ Invalid PAN should have failed" -ForegroundColor Red
    } catch {
        Write-Host "✓ PAN Verification (Invalid Format):" -ForegroundColor Green
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor White
    }
    
    # Test 3: Duplicate verification
    $response = Invoke-RestMethod -Uri "$API_BASE/verification/pan" -Method POST -Body $panPayload -ContentType "application/json"
    Write-Host "✓ PAN Verification (Duplicate):" -ForegroundColor Green
    Write-Host "  Response: $($response.message)" -ForegroundColor White
    
} catch {
    Write-Host "✗ PAN Verification Tests Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "2. Testing Enhanced Aadhaar Verification..." -ForegroundColor Cyan
Write-Host "   - Detailed validation messages" -ForegroundColor Gray
Write-Host "   - Duplicate verification check" -ForegroundColor Gray
Write-Host "   - Enhanced error handling" -ForegroundColor Gray
Write-Host ""

try {
    # Test 1: Valid Aadhaar
    $aadhaarPayload = @{
        aadharNumber = $TEST_AADHAAR
        documentUrl = "https://example.com/aadhaar-document.pdf"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/verification/aadhaar" -Method POST -Body $aadhaarPayload -ContentType "application/json"
    Write-Host "✓ Aadhaar Verification (Valid):" -ForegroundColor Green
    Write-Host "  Response: $($response.message)" -ForegroundColor White
    
    # Test 2: Invalid Aadhaar format
    $invalidAadhaarPayload = @{
        aadharNumber = "123456789"
        documentUrl = "https://example.com/aadhaar-document.pdf"
    } | ConvertTo-Json

    try {
        $response = Invoke-RestMethod -Uri "$API_BASE/verification/aadhaar" -Method POST -Body $invalidAadhaarPayload -ContentType "application/json"
        Write-Host "✗ Invalid Aadhaar should have failed" -ForegroundColor Red
    } catch {
        Write-Host "✓ Aadhaar Verification (Invalid Format):" -ForegroundColor Green
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor White
    }
    
    # Test 3: Duplicate verification
    $response = Invoke-RestMethod -Uri "$API_BASE/verification/aadhaar" -Method POST -Body $aadhaarPayload -ContentType "application/json"
    Write-Host "✓ Aadhaar Verification (Duplicate):" -ForegroundColor Green
    Write-Host "  Response: $($response.message)" -ForegroundColor White
    
} catch {
    Write-Host "✗ Aadhaar Verification Tests Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "3. Testing Enhanced Video Verification..." -ForegroundColor Cyan
Write-Host "   - File validation" -ForegroundColor Gray
Write-Host "   - Size validation" -ForegroundColor Gray
Write-Host "   - Format validation" -ForegroundColor Gray
Write-Host ""

try {
    # Create a test video file
    $testVideoContent = "This is a test video file for verification"
    $testVideoPath = "test-video.mp4"
    $testVideoContent | Out-File -FilePath $testVideoPath -Encoding UTF8

    $boundary = [System.Guid]::NewGuid().ToString()
    $LF = "`r`n"
    $bodyLines = (
        "--$boundary",
        "Content-Disposition: form-data; name=`"notes`"",
        "",
        "Test video verification notes",
        "--$boundary",
        "Content-Disposition: form-data; name=`"video`"; filename=`"test-video.mp4`"",
        "Content-Type: video/mp4",
        "",
        $testVideoContent,
        "--$boundary--"
    ) -join $LF

    $headers = @{
        "Content-Type" = "multipart/form-data; boundary=$boundary"
    }

    $response = Invoke-RestMethod -Uri "$API_BASE/verification/video" -Method POST -Body $bodyLines -Headers $headers
    Write-Host "✓ Video Verification (Valid):" -ForegroundColor Green
    Write-Host "  Response: $($response.message)" -ForegroundColor White

    # Clean up test file
    Remove-Item $testVideoPath -ErrorAction SilentlyContinue
    
} catch {
    Write-Host "✗ Video Verification Tests Failed: $($_.Exception.Message)" -ForegroundColor Red
    # Clean up test file
    Remove-Item $testVideoPath -ErrorAction SilentlyContinue
}
Write-Host ""

Write-Host "4. Testing Comprehensive Verification Status..." -ForegroundColor Cyan
Write-Host "   - Detailed status information" -ForegroundColor Gray
Write-Host "   - Progress tracking" -ForegroundColor Gray
Write-Host "   - Timestamp information" -ForegroundColor Gray
Write-Host ""

try {
    $response = Invoke-RestMethod -Uri "$API_BASE/verification/status" -Method GET -ContentType "application/json"
    Write-Host "✓ Comprehensive Status:" -ForegroundColor Green
    Write-Host "  Overall Status: $($response.overallStatus)" -ForegroundColor White
    Write-Host "  Fully Verified: $($response.fullyVerified)" -ForegroundColor White
    Write-Host "  Progress: $($response.progress.completed)/$($response.progress.total) ($($response.progress.percentage)%)" -ForegroundColor White
    
    # Show individual verification statuses
    Write-Host "  PAN: $($response.panVerification.status)" -ForegroundColor White
    Write-Host "  Aadhaar: $($response.aadhaarVerification.status)" -ForegroundColor White
    Write-Host "  Video: $($response.videoVerification.status)" -ForegroundColor White
    Write-Host "  Email: $($response.emailVerification.verified)" -ForegroundColor White
    
} catch {
    Write-Host "✗ Status Check Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "5. Testing Reset Functionality..." -ForegroundColor Cyan
Write-Host "   - Reset all verifications" -ForegroundColor Gray
Write-Host "   - Verify reset worked" -ForegroundColor Gray
Write-Host ""

try {
    $response = Invoke-RestMethod -Uri "$API_BASE/verification/reset" -Method POST -ContentType "application/json"
    Write-Host "✓ Reset Verification:" -ForegroundColor Green
    Write-Host "  Response: $($response.message)" -ForegroundColor White
    
    # Check status after reset
    $statusResponse = Invoke-RestMethod -Uri "$API_BASE/verification/status" -Method GET -ContentType "application/json"
    Write-Host "✓ Status After Reset:" -ForegroundColor Green
    Write-Host "  Overall Status: $($statusResponse.overallStatus)" -ForegroundColor White
    Write-Host "  Progress: $($statusResponse.progress.completed)/$($statusResponse.progress.total) ($($statusResponse.progress.percentage)%)" -ForegroundColor White
    
} catch {
    Write-Host "✗ Reset Test Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "=== Enhanced Verification Test Summary ===" -ForegroundColor Green
Write-Host "✓ Enhanced PAN verification with detailed validation" -ForegroundColor Green
Write-Host "✓ Enhanced Aadhaar verification with detailed validation" -ForegroundColor Green
Write-Host "✓ Enhanced Video verification with file validation" -ForegroundColor Green
Write-Host "✓ Comprehensive status tracking with progress" -ForegroundColor Green
Write-Host "✓ Reset functionality for testing" -ForegroundColor Green
Write-Host "✓ Duplicate verification prevention" -ForegroundColor Green
Write-Host "✓ Enhanced error messages and logging" -ForegroundColor Green
Write-Host ""
Write-Host "All verification improvements have been successfully implemented!" -ForegroundColor Yellow
Write-Host ""

Write-Host "Test completed!" -ForegroundColor Green
