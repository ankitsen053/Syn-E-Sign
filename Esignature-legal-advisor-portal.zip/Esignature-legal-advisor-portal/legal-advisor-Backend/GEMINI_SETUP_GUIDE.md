# Gemini 2.5 Pro API Integration Guide

## 🚀 Setup Instructions

### 1. Get Your Gemini API Key
1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create a new API key
3. Copy the API key

### 2. Configure Environment Variable
Set your Gemini API key as an environment variable:

**Windows (PowerShell):**
```powershell
$env:GEMINI_API_KEY="your-actual-gemini-api-key-here"
```

**Windows (Command Prompt):**
```cmd
set GEMINI_API_KEY=your-actual-gemini-api-key-here
```

**Linux/Mac:**
```bash
export GEMINI_API_KEY="your-actual-gemini-api-key-here"
```

### 3. Update application.properties
Replace the placeholder in `src/main/resources/application.properties`:
```properties
spring.ai.openai.api-key=${GEMINI_API_KEY:your-actual-gemini-api-key-here}
```

### 4. Start the Application
```bash
./mvnw spring-boot:run
```

## 🎯 Features Available

### Document Analysis
- **Comprehensive Legal Review**: AI-powered analysis of legal documents
- **Document Type Identification**: Automatic classification of agreement types
- **Structure Analysis**: Evaluation of document organization and flow
- **Key Terms Analysis**: Identification of important terms and implications
- **Legal Compliance Check**: Regulatory compliance assessment
- **Risk Assessment**: Comprehensive risk evaluation
- **Missing Elements Detection**: Identification of critical missing clauses
- **Specific Recommendations**: Actionable improvement suggestions
- **Editing Suggestions**: Specific text changes and additions
- **Enforceability Assessment**: Legal validity evaluation

### Agreement Generation
- **Custom Agreement Creation**: Generate agreements based on type and parameters
- **Comprehensive Clauses**: Include all essential legal provisions
- **Party-Specific Terms**: Tailored to specific parties and requirements
- **Legal Soundness**: Ensure enforceability and compliance

### Issue Highlighting
- **Critical Issues**: Major legal problems requiring immediate attention
- **Moderate Concerns**: Issues that should be addressed
- **Minor Suggestions**: Improvements for clarity and completeness
- **Specific Edits**: Exact text changes with before/after examples
- **Missing Clauses**: Important provisions that should be added
- **Ambiguous Language**: Unclear terms needing clarification
- **Enforceability Issues**: Problems affecting legal validity
- **Compliance Gaps**: Missing regulatory requirements

### Risk Analysis
- **Contractual Risks**: Performance, payment, termination, liability
- **Legal Risks**: Regulatory compliance, statutory violations, jurisdictional issues
- **Operational Risks**: Implementation challenges, resource requirements
- **Reputational Risks**: Public perception, stakeholder impact
- **Technical Risks**: Data security, intellectual property
- **Risk Scoring**: Overall risk assessment (1-10 scale)
- **Mitigation Strategies**: Specific recommendations for risk reduction

### Compliance Assessment
- **Contract Law Compliance**: Essential elements, offer/acceptance, consideration
- **Data Protection Compliance**: Privacy laws, data processing, consent
- **Consumer Protection Compliance**: Fair terms, pricing transparency
- **Employment Law Compliance**: Labor requirements, working conditions
- **Intellectual Property Compliance**: IP protection, licensing, assignment
- **Tax and Financial Compliance**: Tax obligations, financial reporting
- **Jurisdiction-Specific**: Tailored to specific legal jurisdictions

## 🔧 API Endpoints

### Document Analysis
- `POST /api/ai/analyze` - Analyze uploaded document
- `POST /api/ai/highlight-issues` - Highlight legal issues
- `POST /api/ai/risk-analysis` - Perform risk analysis
- `POST /api/ai/compliance-assessment` - Assess compliance

### Agreement Generation
- `POST /api/ai/create` - Create agreement
- `POST /api/ai/create-and-download` - Create and download DOCX
- `POST /api/ai/generate-and-save` - Generate and save agreement

### Status Check
- `GET /api/ai/status` - Check AI service availability

## 📋 Supported Document Types
- PDF files
- DOCX files
- TXT files
- RTF files
- HTML files

## 🎯 Agreement Types Supported
- Service Agreements
- Employment Contracts
- Non-Disclosure Agreements
- Partnership Agreements
- License Agreements
- Sales Contracts
- Lease Agreements
- Consulting Agreements
- And more...

## 🔒 Security & Privacy
- API key stored as environment variable
- No data stored permanently
- Secure HTTPS communication
- Fallback mode when API unavailable

## 🛠️ Troubleshooting

### API Key Issues
- Ensure environment variable is set correctly
- Verify API key is valid and active
- Check API quota and limits

### Service Unavailable
- Application will use fallback mode
- Check network connectivity
- Verify Gemini API service status

### Document Processing Issues
- Ensure file format is supported
- Check file size limits
- Verify file is not corrupted

## 📞 Support
For issues with the Gemini API integration, check:
1. Google AI Studio documentation
2. API key configuration
3. Network connectivity
4. Application logs for detailed error messages
