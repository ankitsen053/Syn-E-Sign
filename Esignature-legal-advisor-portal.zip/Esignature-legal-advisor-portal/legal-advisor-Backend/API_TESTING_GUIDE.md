# Legal Advisor API Testing Guide

## Overview
This guide provides comprehensive testing instructions for all APIs in the Legal Advisor application using Thunder Client (Postman alternative).

## Prerequisites
1. **Application Running**: Ensure the Spring Boot application is running on `http://localhost:8080`
2. **Thunder Client**: Install Thunder Client extension in VS Code
3. **MongoDB**: Ensure MongoDB Atlas connection is configured

## Import Collection
1. Open Thunder Client in VS Code
2. Click "Import" and select the `thunder-client-collection.json` file
3. The collection will be imported with all pre-configured requests

## Testing Sequence

### Step 1: Health & Test Endpoints
Start by testing basic connectivity and health checks:

#### 1.1 Health Check
- **Endpoint**: `GET /api/test/health`
- **Expected Response**: 
```json
{
  "status": "UP",
  "service": "Legal Advisor Backend",
  "version": "1.0.0",
  "timestamp": 1234567890,
  "database": "MongoDB Atlas",
  "authentication": "JWT",
  "ai": "Gemini API"
}
```

#### 1.2 Public Test Endpoint
- **Endpoint**: `GET /api/test/public`
- **Expected Response**:
```json
{
  "message": "Public Content.",
  "status": "success",
  "timestamp": 1234567890
}
```

### Step 2: Authentication Testing

#### 2.1 User Registration
- **Endpoint**: `POST /api/auth/signup`
- **Body**:
```json
{
  "username": "testuser",
  "email": "testuser@example.com",
  "password": "password123",
  "roles": ["user"],
  "fullName": "Test User"
}
```
- **Expected Response**:
```json
{
  "message": "User registered successfully!"
}
```

#### 2.2 Company Registration
- **Endpoint**: `POST /api/auth/signup`
- **Body**:
```json
{
  "username": "testcompany",
  "email": "testcompany@example.com",
  "password": "password123",
  "roles": ["company"],
  "fullName": "Test Company Ltd"
}
```

#### 2.3 Admin Registration
- **Endpoint**: `POST /api/auth/signup`
- **Body**:
```json
{
  "username": "admin",
  "email": "admin@example.com",
  "password": "admin123",
  "roles": ["admin"],
  "fullName": "System Administrator"
}
```

#### 2.4 User Login
- **Endpoint**: `POST /api/auth/login`
- **Body**:
```json
{
  "username": "testuser",
  "password": "password123"
}
```
- **Expected Response**:
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "type": "Bearer",
  "id": "user_id",
  "username": "testuser",
  "email": "testuser@example.com",
  "roles": ["user"],
  "refreshToken": "refresh_token_here"
}
```

**Important**: Copy the `token` value and set it as the `jwt_token` environment variable in Thunder Client.

#### 2.5 Refresh Token
- **Endpoint**: `POST /api/auth/refresh`
- **Body**:
```json
{
  "refreshToken": "{{refresh_token}}"
}
```

#### 2.6 Logout
- **Endpoint**: `POST /api/auth/logout`
- **Body**:
```json
{
  "refreshToken": "{{refresh_token}}"
}
```

### Step 3: Profile Management Testing

#### 3.1 Get Profile (Requires Authentication)
- **Endpoint**: `GET /api/profile`
- **Headers**: `Authorization: Bearer {{jwt_token}}`
- **Expected Response**:
```json
{
  "success": true,
  "profile": {
    "id": "profile_id",
    "userId": "user_id",
    "fullName": "Test User",
    "address": "123 Main Street",
    "phoneNumber": "+91-9876543210",
    "panNumber": "ABCDE1234F",
    "panVerificationStatus": "PENDING",
    "gstVerificationStatus": "PENDING"
  }
}
```

#### 3.2 Create/Update Profile - Individual
- **Endpoint**: `POST /api/profile`
- **Headers**: 
  - `Content-Type: application/json`
  - `Authorization: Bearer {{jwt_token}}`
- **Body**:
```json
{
  "fullName": "John Doe",
  "address": "123 Main Street, City, State 12345",
  "phoneNumber": "+91-9876543210",
  "panNumber": "ABCDE1234F",
  "verificationMethod": "PAN"
}
```

#### 3.3 Create/Update Profile - Company
- **Endpoint**: `POST /api/profile`
- **Headers**: 
  - `Content-Type: application/json`
  - `Authorization: Bearer {{jwt_token}}`
- **Body**:
```json
{
  "fullName": "Jane Smith",
  "address": "456 Business Ave, City, State 12345",
  "phoneNumber": "+91-9876543211",
  "gstNumber": "22AAAAA0000A1Z5",
  "companyName": "Tech Solutions Pvt Ltd",
  "companyAddress": "456 Business Avenue, Tech Park, City, State 12345",
  "verificationMethod": "AADHAAR"
}
```

#### 3.4 Verify Profile - PAN
- **Endpoint**: `POST /api/profile/verify?method=PAN`
- **Headers**: `Authorization: Bearer {{jwt_token}}`
- **Expected Response**:
```json
{
  "success": true,
  "status": "Verification completed",
  "method": "PAN",
  "profilePanStatus": "VERIFIED",
  "profileGstStatus": "PENDING"
}
```

#### 3.5 Verify Profile - AADHAAR
- **Endpoint**: `POST /api/profile/verify?method=AADHAAR`
- **Headers**: `Authorization: Bearer {{jwt_token}}`

#### 3.6 Verify Profile - ESIGN
- **Endpoint**: `POST /api/profile/verify?method=ESIGN`
- **Headers**: `Authorization: Bearer {{jwt_token}}`

### Step 4: AI Services Testing

#### 4.1 AI Service Status
- **Endpoint**: `GET /api/ai/status`
- **Expected Response**:
```json
{
  "status": "AI Service is running",
  "timestamp": 1234567890,
  "version": "1.0.0",
  "features": {
    "documentGeneration": true,
    "documentAnalysis": true,
    "issueHighlighting": true,
    "geminiIntegration": true
  }
}
```

#### 4.2 Generate Agreement - NDA
- **Endpoint**: `POST /api/ai/generate?type=NDA&partyA=Company%20A&partyB=Company%20B`
- **Headers**: `Content-Type: text/plain`
- **Body**: `Confidential information sharing agreement between Company A and Company B for project collaboration.`
- **Expected Response**:
```json
{
  "success": true,
  "document": "Generated NDA document content...",
  "type": "NDA",
  "partyA": "Company A",
  "partyB": "Company B"
}
```

#### 4.3 Generate Agreement - Employment Contract
- **Endpoint**: `POST /api/ai/generate?type=Employment%20Contract&partyA=Tech%20Corp&partyB=John%20Doe`
- **Headers**: `Content-Type: text/plain`
- **Body**: `Full-time employment contract for software developer position with annual salary and benefits.`

#### 4.4 Generate Agreement - Service Agreement
- **Endpoint**: `POST /api/ai/generate?type=Service%20Agreement&partyA=Client%20Inc&partyB=Service%20Provider%20LLC`
- **Headers**: `Content-Type: text/plain`
- **Body**: `IT consulting services agreement for website development and maintenance.`

#### 4.5 Analyze Document
- **Endpoint**: `POST /api/ai/analyze`
- **Headers**: `Content-Type: text/plain`
- **Body**: `This is a sample legal document that needs to be analyzed for potential issues, compliance requirements, and legal implications. The document contains various clauses and terms that should be reviewed carefully.`
- **Expected Response**:
```json
{
  "success": true,
  "analysis": "Document analysis results...",
  "issues": "Highlighted issues...",
  "contentLength": 245
}
```

### Step 5: View Controllers Testing

#### 5.1 Login Page
- **Endpoint**: `GET /`
- **Expected Response**: HTML login page

#### 5.2 Signup Page
- **Endpoint**: `GET /signup`
- **Expected Response**: HTML signup page

#### 5.3 Dashboard Page
- **Endpoint**: `GET /dashboard`
- **Expected Response**: HTML dashboard page

#### 5.4 Profile Page
- **Endpoint**: `GET /profile`
- **Expected Response**: HTML profile page

### Step 6: Protected Endpoints Testing

#### 6.1 User Test Endpoint (Requires Auth)
- **Endpoint**: `GET /api/test/user`
- **Headers**: `Authorization: Bearer {{jwt_token}}`
- **Expected Response**:
```json
{
  "message": "User Content.",
  "user": "testuser",
  "authorities": ["user"],
  "status": "success",
  "timestamp": 1234567890
}
```

#### 6.2 Admin Test Endpoint (Requires Admin)
- **Endpoint**: `GET /api/test/admin`
- **Headers**: `Authorization: Bearer {{jwt_token}}`
- **Expected Response**:
```json
{
  "message": "Admin Content.",
  "user": "admin",
  "authorities": ["admin"],
  "status": "success",
  "timestamp": 1234567890
}
```

## Environment Variables Setup

In Thunder Client, set up the following environment variables:

1. **base_url**: `http://localhost:8080`
2. **jwt_token**: (Copy from login response)
3. **refresh_token**: (Copy from login response)

## Testing Scenarios

### Scenario 1: Complete User Flow
1. Register a new user
2. Login and get JWT token
3. Create/update profile
4. Verify profile
5. Generate legal documents
6. Analyze documents
7. Logout

### Scenario 2: Company Flow
1. Register a company account
2. Login and get JWT token
3. Create company profile with GST details
4. Verify company profile
5. Generate business agreements
6. Logout

### Scenario 3: Admin Flow
1. Register admin account
2. Login and get JWT token
3. Access admin endpoints
4. Test all protected endpoints
5. Logout

## Error Testing

### Test Invalid Credentials
- Try logging in with wrong password
- Expected: 401 Unauthorized

### Test Missing Authentication
- Access protected endpoints without JWT token
- Expected: 401 Unauthorized

### Test Invalid JWT Token
- Use expired or invalid JWT token
- Expected: 401 Unauthorized

### Test Missing Required Fields
- Submit registration without required fields
- Expected: 400 Bad Request

## Performance Testing

### Load Testing
- Test multiple concurrent requests
- Monitor response times
- Check for any timeout issues

### Database Testing
- Test with large datasets
- Verify MongoDB connection stability
- Check for any connection pool issues

## Security Testing

### JWT Token Security
- Verify token expiration
- Test token refresh mechanism
- Check for token validation

### CORS Testing
- Test from different origins
- Verify CORS headers
- Check for any cross-origin issues

## Troubleshooting

### Common Issues

1. **Application Not Starting**
   - Check MongoDB connection
   - Verify application.properties configuration
   - Check for port conflicts

2. **Authentication Failures**
   - Verify JWT secret key configuration
   - Check token expiration settings
   - Ensure proper role assignments

3. **AI Service Issues**
   - Check Gemini API key configuration
   - Verify internet connectivity
   - Check API rate limits

4. **Database Issues**
   - Verify MongoDB Atlas connection
   - Check network connectivity
   - Verify database credentials

### Debug Steps

1. Check application logs for errors
2. Verify environment variables
3. Test individual components
4. Check network connectivity
5. Verify API endpoints are accessible

## API Documentation Summary

| Endpoint | Method | Authentication | Description |
|----------|--------|----------------|-------------|
| `/api/test/health` | GET | No | Health check |
| `/api/test/public` | GET | No | Public test endpoint |
| `/api/test/user` | GET | Yes | User test endpoint |
| `/api/test/admin` | GET | Yes (Admin) | Admin test endpoint |
| `/api/auth/signup` | POST | No | User registration |
| `/api/auth/login` | POST | No | User login |
| `/api/auth/refresh` | POST | No | Token refresh |
| `/api/auth/logout` | POST | No | User logout |
| `/api/profile` | GET | Yes | Get user profile |
| `/api/profile` | POST | Yes | Create/update profile |
| `/api/profile/verify` | POST | Yes | Verify profile |
| `/api/ai/status` | GET | No | AI service status |
| `/api/ai/generate` | POST | No | Generate legal documents |
| `/api/ai/analyze` | POST | No | Analyze documents |

This comprehensive testing guide covers all aspects of the Legal Advisor API and should help you thoroughly test the application functionality.
