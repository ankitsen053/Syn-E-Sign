# Email OTP Verification System Guide

## Overview

The Legal Advisor backend implements a comprehensive email OTP (One-Time Password) verification system that ensures users can only access the application after verifying their email address. This system provides enhanced security and prevents unauthorized access.

## 🔐 System Features

### Core Features
- **6-digit OTP Generation**: Secure random 6-digit codes
- **10-minute Expiration**: OTPs expire after 10 minutes for security
- **3 Attempt Limit**: Maximum 3 failed attempts before OTP is invalidated
- **Email Verification Required**: Users cannot login without email verification
- **Account Activation**: Accounts are only enabled after email verification
- **Resend OTP**: Users can request new OTP codes
- **Professional Email Templates**: User-friendly email notifications

### Security Features
- **Account Locking**: Unverified accounts are disabled
- **OTP Expiration**: Automatic cleanup of expired OTPs
- **Attempt Tracking**: Prevents brute force attacks
- **Secure Email Delivery**: Professional email templates with security tips

## 📧 Email Configuration

The system uses Gmail SMTP for sending emails. Configuration is in `application.properties`:

```properties
# Mail Configuration
spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=anshtalreja025@gmail.com
spring.mail.password=abcdefgh
spring.mail.protocol=smtp
spring.mail.properties.mail.smtp.auth=true
spring.mail.properties.mail.smtp.starttls.enable=true
spring.mail.default-encoding=UTF-8
```

## 🔄 User Registration Flow

1. **User Registration**
   - User provides username, email, and password
   - System creates user account with `emailVerified = false` and `enabled = false`
   - 6-digit OTP is generated and sent to user's email
   - User account is saved to database

2. **Email Verification**
   - User receives email with OTP code
   - User enters OTP in application
   - System verifies OTP and marks email as verified
   - Account is enabled (`enabled = true`)
   - Welcome email is sent to user

3. **Login Access**
   - User can now login with credentials
   - System checks both email verification and account status
   - JWT token is issued for authenticated access

## 📋 API Endpoints

### Authentication Endpoints

#### 1. User Registration
```http
POST /api/auth/signup
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "SecurePassword123!",
  "roles": ["user"]
}
```

**Response:**
```json
{
  "message": "User registered successfully! Please check your email for verification OTP."
}
```

#### 2. Email Verification
```http
POST /api/auth/verify-email
Content-Type: application/json

{
  "email": "john@example.com",
  "otp": "123456"
}
```

**Response:**
```json
{
  "message": "Email verified successfully! Your account is now active."
}
```

#### 3. Resend OTP
```http
POST /api/auth/resend-otp
Content-Type: application/json

{
  "email": "john@example.com"
}
```

**Response:**
```json
{
  "message": "OTP resent successfully! Please check your email."
}
```

#### 4. Check Verification Status
```http
GET /api/auth/verification-status/{email}
```

**Response:**
```json
{
  "email": "john@example.com",
  "verified": true,
  "enabled": true,
  "message": "Email is verified. You can now log in.",
  "status": "VERIFIED"
}
```

#### 5. User Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "john_doe",
  "password": "SecurePassword123!"
}
```

**Response (if email verified):**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "id": "user_id",
  "username": "john_doe",
  "email": "john@example.com",
  "roles": ["ROLE_USER"],
  "refreshToken": "refresh_token_here"
}
```

**Response (if email not verified):**
```json
{
  "message": "Email not verified. Please verify your email before logging in."
}
```

## 🏗️ System Architecture

### Core Components

#### 1. EmailVerification Entity
```java
@Document(collection = "email_verifications")
public class EmailVerification {
    private String id;
    private String email;
    private String otp;
    private LocalDateTime createdAt;
    private LocalDateTime expiresAt;
    private boolean verified = false;
    private int attempts = 0;
}
```

#### 2. EmailVerificationService
- Generates 6-digit OTP codes
- Manages OTP expiration (10 minutes)
- Tracks verification attempts (max 3)
- Handles OTP verification logic

#### 3. EmailService
- Sends OTP emails with professional templates
- Sends welcome emails after verification
- Handles email delivery errors

#### 4. AuthService
- Manages user registration with email verification
- Enforces email verification before login
- Handles account activation after verification

### Database Collections

#### Users Collection
```json
{
  "_id": "user_id",
  "username": "john_doe",
  "email": "john@example.com",
  "password": "hashed_password",
  "emailVerified": true,
  "enabled": true,
  "roles": ["ROLE_USER"]
}
```

#### Email Verifications Collection
```json
{
  "_id": "verification_id",
  "email": "john@example.com",
  "otp": "123456",
  "createdAt": "2024-01-15T10:30:00",
  "expiresAt": "2024-01-15T10:40:00",
  "verified": true,
  "attempts": 1
}
```

## 📧 Email Templates

### OTP Email Template
```
🔐 Email Verification - Legal Advisor

Hello,

Thank you for signing up with Legal Advisor! To complete your registration and access your account, please verify your email address.

📧 Your verification code is:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                    123456
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⏰ This code will expire in 10 minutes for security reasons.

🔒 Security Tips:
• Never share this code with anyone
• Our team will never ask for this code
• If you didn't request this verification, please ignore this email

📱 How to verify:
1. Copy the verification code above
2. Go back to the Legal Advisor application
3. Enter the code in the verification field
4. Click 'Verify Email'

Need help? Contact our support team.

Best regards,
The Legal Advisor Team
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Welcome Email Template
```
🎉 Welcome to Legal Advisor!

Hello John,

Congratulations! Your account has been successfully verified and activated. You now have full access to all features of Legal Advisor.

🚀 What you can do now:
• Generate legal documents with AI assistance
• Analyze existing documents for potential issues
• Manage your document library securely
• Access your profile and customize settings
• Get AI-powered legal advice and insights

🔐 Your account is now secure and ready to use.

📞 Need help? Our support team is here to assist you.

Best regards,
The Legal Advisor Team
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## 🧪 Testing

### Automated Testing
Run the test script to verify the complete email OTP system:

```powershell
.\test-email-otp-system.ps1
```

### Manual Testing Steps

1. **Register a new user**
   - Use the signup endpoint
   - Verify email is sent with OTP

2. **Check verification status**
   - Should show as unverified initially

3. **Try to login**
   - Should be blocked until email is verified

4. **Verify email with OTP**
   - Enter the OTP from email
   - Account should be activated

5. **Login after verification**
   - Should succeed and return JWT token

## 🔧 Configuration

### Email Settings
Update `application.properties` with your email credentials:

```properties
spring.mail.username=your-email@gmail.com
spring.mail.password=your-app-password
```

### OTP Settings
Modify OTP configuration in `EmailVerificationService`:

```java
// OTP expiration time (minutes)
this.expiresAt = LocalDateTime.now().plusMinutes(10);

// Maximum attempts
public boolean isMaxAttemptsReached() {
    return attempts >= 3;
}
```

## 🛡️ Security Considerations

### Best Practices Implemented
- **OTP Expiration**: 10-minute timeout prevents long-term exposure
- **Attempt Limiting**: 3 attempts prevent brute force attacks
- **Account Locking**: Unverified accounts cannot access the system
- **Secure Email**: Professional templates with security warnings
- **Input Validation**: All inputs are validated and sanitized

### Additional Security Recommendations
- Use HTTPS in production
- Implement rate limiting for OTP requests
- Add CAPTCHA for repeated OTP requests
- Monitor and log suspicious activities
- Regular security audits

## 🚀 Deployment

### Prerequisites
- MongoDB database
- SMTP email service (Gmail, SendGrid, etc.)
- Java 17+ runtime
- Maven build tool

### Build and Run
```bash
# Build the application
mvn clean install

# Run the application
mvn spring-boot:run
```

### Environment Variables
Set these environment variables for production:

```bash
export SPRING_MAIL_USERNAME=your-email@gmail.com
export SPRING_MAIL_PASSWORD=your-app-password
export APP_JWT_SECRET=your-jwt-secret
export MONGODB_URI=your-mongodb-connection-string
```

## 📞 Support

For issues or questions about the email OTP verification system:

1. Check the application logs for error details
2. Verify email configuration settings
3. Test email delivery with the provided test script
4. Contact the development team for assistance

## 🔄 Future Enhancements

### Planned Features
- **SMS OTP**: Add SMS-based verification as alternative
- **2FA Integration**: Combine with two-factor authentication
- **Email Templates**: Customizable email templates
- **Analytics**: Track verification success rates
- **Admin Panel**: Manage verification settings

### Performance Optimizations
- **Caching**: Cache verification status
- **Async Processing**: Background email sending
- **Database Indexing**: Optimize verification queries
- **Load Balancing**: Handle high verification volumes
