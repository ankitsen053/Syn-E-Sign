# OpenAI Integration Guide for Legal Advisor

## Overview
This guide explains how to integrate OpenAI GPT-4 into your Legal Advisor application for professional legal document analysis and generation.

## Features
- Professional legal document generation using GPT-4
- Comprehensive legal document analysis
- Risk assessment and compliance checking
- Legal issue identification and highlighting
- Secure API key management
- Fallback support for reliability

## Configuration

### 1. OpenAI API Key Setup

#### Option 1: Environment Variable (Recommended)
```bash
# Set your OpenAI API key as an environment variable
export OPENAI_API_KEY="sk-your-actual-openai-api-key-here"
```

#### Option 2: Application Properties
```properties
# Replace with your actual OpenAI API key
openai.api.key=sk-your-actual-openai-api-key-here
```

### 2. Application Properties Configuration

Add these settings to `src/main/resources/application.properties`:

```properties
# AI Service Configuration
ai.service.enabled=true
ai.service.fallback.enabled=false
ai.service.timeout.seconds=300
ai.service.max-retries=3
ai.service.provider=openai

# OpenAI API Configuration
openai.api.key=${OPENAI_API_KEY:YOUR_OPENAI_API_KEY}
openai.api.url=https://api.openai.com/v1
openai.model=gpt-4
openai.max-tokens=4000
openai.temperature=0.1
openai.timeout.seconds=120
```

### 3. Model Selection

#### Available Models:
- `gpt-4` - Best for complex legal analysis (recommended)
- `gpt-4-turbo-preview` - Faster processing for simpler tasks
- `gpt-3.5-turbo` - Cost-effective alternative

#### Configuration:
```properties
# For professional legal work (recommended)
openai.model=gpt-4

# For cost optimization
openai.model=gpt-3.5-turbo
```

## Security Best Practices

### 1. API Key Security
- Never commit API keys to version control
- Use environment variables in production
- Rotate keys regularly
- Monitor API usage

### 2. Production Configuration
```properties
# Production settings
openai.api.key=${OPENAI_API_KEY}
ai.service.fallback.enabled=false
logging.level.com.esign.legal_advisor.service.OpenAIService=WARN
```

## Usage Examples

### 1. Document Generation
```bash
curl -X POST http://localhost:8081/api/ai/create \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "type": "Service Agreement",
    "partyA": "Company A Ltd",
    "partyB": "Company B Inc",
    "terms": "Software development services with monthly deliverables"
  }'
```

### 2. Document Analysis
```bash
curl -X POST http://localhost:8081/api/ai/analyze-text \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "content": "Your legal document content here..."
  }'
```

### 3. Risk Analysis
```bash
curl -X POST http://localhost:8081/api/ai/risk-analysis-text \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "content": "Your contract content for risk analysis..."
  }'
```

### 4. Compliance Assessment
```bash
curl -X POST http://localhost:8081/api/ai/compliance-assessment-text \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "content": "Document content...",
    "jurisdiction": "IN"
  }'
```

## API Endpoints

### Document Generation
- `POST /api/ai/create` - Generate legal agreement
- `POST /api/ai/create-and-download` - Generate and download DOCX
- `POST /api/ai/generate-and-save` - Generate and save to database

### Document Analysis
- `POST /api/ai/analyze` - Analyze uploaded document
- `POST /api/ai/analyze-text` - Analyze text content
- `POST /api/ai/risk-analysis-text` - Perform risk analysis
- `POST /api/ai/compliance-assessment-text` - Assess compliance
- `POST /api/ai/highlight-issues-text` - Highlight legal issues

### System Status
- `GET /api/ai/status` - Check AI service status and configuration

## Legal Prompts and Analysis

### Document Analysis Features:
1. **Comprehensive Legal Review**
   - Document structure analysis
   - Legal strengths and weaknesses identification
   - Risk assessment
   - Recommendations for improvement

2. **Compliance Assessment**
   - Jurisdiction-specific legal compliance
   - Regulatory requirement checking
   - Industry standard adherence
   - Gap analysis and remediation

3. **Risk Analysis**
   - Contractual risk identification
   - Liability exposure assessment
   - Financial risk evaluation
   - Mitigation strategies

4. **Issue Highlighting**
   - Critical legal issues identification
   - Ambiguous clause detection
   - Missing essential terms
   - Enforceability concerns

## Cost Management

### 1. Token Optimization
```properties
# Optimize for cost
openai.max-tokens=2000
openai.temperature=0.0
```

### 2. Usage Monitoring
Monitor your OpenAI usage through the OpenAI dashboard and set up billing alerts.

### 3. Caching Strategy
Consider implementing caching for repeated analyses of similar documents.

## Error Handling

### 1. API Rate Limits
The system automatically handles rate limits with retry logic.

### 2. Timeout Management
```properties
# Adjust timeouts based on your needs
openai.timeout.seconds=120
ai.service.timeout.seconds=300
```

### 3. Fallback Configuration
```properties
# Enable fallback if needed
ai.service.fallback.enabled=true
```

## Testing

### 1. Service Status Check
```bash
curl -X GET http://localhost:8081/api/ai/status \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### 2. Integration Test
Run the provided test script:
```bash
powershell -ExecutionPolicy Bypass -File test-openai-integration.ps1
```

## Troubleshooting

### Common Issues:

1. **API Key Not Working**
   - Verify the API key is correct
   - Check billing status in OpenAI dashboard
   - Ensure sufficient credits

2. **Timeout Errors**
   - Increase timeout values
   - Check network connectivity
   - Monitor OpenAI service status

3. **Rate Limit Errors**
   - Implement exponential backoff
   - Upgrade OpenAI plan if needed
   - Monitor usage patterns

### Logs:
Check application logs for detailed error information:
```bash
tail -f logs/legal-advisor.log | grep OpenAI
```

## Performance Optimization

### 1. Response Time
- Use appropriate models for different tasks
- Implement async processing for large documents
- Cache frequently requested analyses

### 2. Cost Optimization
- Use token limits effectively
- Implement smart prompt engineering
- Monitor and optimize usage patterns

## Support and Maintenance

### 1. Regular Updates
- Monitor OpenAI API changes
- Update models as new versions become available
- Review and optimize prompts regularly

### 2. Monitoring
- Set up alerts for API failures
- Monitor response times and accuracy
- Track usage and costs

## Legal Disclaimer

This integration provides AI-powered legal assistance but should not replace professional legal advice. Always consult with qualified legal professionals for important legal matters.
