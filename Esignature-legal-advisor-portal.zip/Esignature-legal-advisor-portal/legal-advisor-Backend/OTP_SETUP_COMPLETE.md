# 🎉 OTP Verification System - Complete Setup Guide

## ✅ **Issues Fixed:**

### 1. **CORS Error Fixed**
- **Problem**: Frontend on port 5174 was blocked by CORS
- **Solution**: Updated CORS configuration to allow port 5174
- **Files Updated**: `application.properties`, `SecurityConfig.java`

### 2. **Server Compilation Error Fixed**
- **Problem**: Missing `findByEmail` method in UserRepository
- **Solution**: Added the missing method
- **File Updated**: `UserRepository.java`

### 3. **Email Configuration Enhanced**
- **Problem**: Gmail configuration issues causing server crashes
- **Solution**: Added timeout settings and better error handling
- **File Updated**: `application.properties`

## 🚀 **Quick Start Commands:**

### **Step 1: Set up Gmail OTP**
```powershell
.\setup-gmail-otp.ps1
```
This will:
- Guide you through Gmail App Password setup
- Update email configuration
- Start the server automatically

### **Step 2: Test the System**
```powershell
.\test-otp-system.ps1
```
This will test:
- Server status
- CORS configuration
- Email functionality
- User registration
- OTP verification flow

## 📧 **Gmail App Password Setup:**

1. **Go to Google Account**: https://myaccount.google.com/
2. **Navigate to Security**
3. **Enable 2-Step Verification** (if not already enabled)
4. **Click "App passwords"**
5. **Select "Mail" and "Other (Custom name)"**
6. **Enter "Legal Advisor" as the name**
7. **Copy the 16-character password**

## 🔧 **Manual Configuration (if needed):**

### **Update Email Settings:**
```properties
# In application.properties
spring.mail.username=your-email@gmail.com
spring.mail.password=YOUR_16_CHARACTER_APP_PASSWORD
```

### **CORS Configuration:**
```properties
# In application.properties
app.cors.allowed-origins=http://localhost:5173,http://localhost:5174,http://localhost:3000,http://localhost:8080
```

## 🧪 **Testing the System:**

### **1. Health Check:**
```bash
curl http://localhost:8080/api/test/health
```

### **2. User Registration:**
```bash
curl -X POST http://localhost:8080/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser123",
    "email": "your-email@gmail.com",
    "password": "TestPassword123!",
    "roles": ["user"]
  }'
```

### **3. Check Verification Status:**
```bash
curl http://localhost:8080/api/auth/verification-status/your-email@gmail.com
```

### **4. Verify Email (after receiving OTP):**
```bash
curl -X POST http://localhost:8080/api/auth/verify-email \
  -H "Content-Type: application/json" \
  -d '{
    "email": "your-email@gmail.com",
    "otp": "123456"
  }'
```

## 🎯 **What You Get:**

### **Complete OTP Verification Flow:**
1. ✅ **User Registration** - Creates account and sends OTP
2. ✅ **Email Verification** - Professional OTP emails
3. ✅ **Account Activation** - Enables account after verification
4. ✅ **Secure Login** - Only verified users can login
5. ✅ **Resend OTP** - Users can request new codes
6. ✅ **Status Checking** - Check verification status

### **Security Features:**
- 🔐 **6-digit OTP codes** with 10-minute expiration
- 🛡️ **3 attempt limit** before OTP invalidation
- 🔒 **Account locking** for unverified users
- 📧 **Professional email templates** with security tips

## 🌐 **Frontend Integration:**

Your frontend should now work perfectly with:
- **Frontend URL**: http://localhost:5174
- **Backend URL**: http://localhost:8080
- **CORS**: Properly configured for both ports

## 📞 **Troubleshooting:**

### **If CORS errors persist:**
1. Restart the backend server
2. Clear browser cache
3. Check browser console for errors

### **If email doesn't work:**
1. Verify Gmail App Password is correct
2. Check spam/junk folder
3. Ensure 2-Step Verification is enabled

### **If server won't start:**
1. Check Java version (requires Java 17+)
2. Verify MongoDB connection
3. Check application.properties for syntax errors

## 🎉 **Success!**

Your OTP verification system is now:
- ✅ **Fully implemented**
- ✅ **CORS configured**
- ✅ **Email ready**
- ✅ **Security enhanced**
- ✅ **Frontend compatible**

**Next step**: Run `.\setup-gmail-otp.ps1` to configure your Gmail and start testing!
