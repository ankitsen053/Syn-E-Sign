Write-Host "Gmail OTP Setup for Legal Advisor" -ForegroundColor Green
Write-Host "=================================" -ForegroundColor Green

Write-Host "`nStep 1: Gmail App Password Setup" -ForegroundColor Yellow
Write-Host "=================================" -ForegroundColor Yellow
Write-Host "1. Go to your Google Account: https://myaccount.google.com/" -ForegroundColor Cyan
Write-Host "2. Navigate to Security" -ForegroundColor Cyan
Write-Host "3. Enable 2-Step Verification (if not already enabled)" -ForegroundColor Cyan
Write-Host "4. Click 'App passwords'" -ForegroundColor Cyan
Write-Host "5. Select 'Mail' and 'Other (Custom name)'" -ForegroundColor Cyan
Write-Host "6. Enter 'Legal Advisor' as the name" -ForegroundColor Cyan
Write-Host "7. Copy the generated 16-character password" -ForegroundColor Cyan

Write-Host "`nStep 2: Update Email Configuration" -ForegroundColor Yellow
Write-Host "===================================" -ForegroundColor Yellow

# Get email credentials
$email = Read-Host "Enter your Gmail address"
$appPassword = Read-Host "Enter your Gmail App Password (16 characters)" -AsSecureString
$appPasswordText = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($appPassword))

# Validate input
if (-not $email -or -not $appPasswordText) {
    Write-Host "ERROR: Email or password cannot be empty!" -ForegroundColor Red
    exit
}

if ($appPasswordText.Length -ne 16) {
    Write-Host "ERROR: Gmail App Password must be exactly 16 characters!" -ForegroundColor Red
    Write-Host "Current length: $($appPasswordText.Length)" -ForegroundColor Red
    exit
}

# Backup original file
Write-Host "`nCreating backup of application.properties..." -ForegroundColor Yellow
Copy-Item "src/main/resources/application.properties" "src/main/resources/application.properties.backup"
Write-Host "SUCCESS: Backup created" -ForegroundColor Green

# Update the properties file
Write-Host "`nUpdating email configuration..." -ForegroundColor Yellow
$content = Get-Content "src/main/resources/application.properties"
$content = $content -replace "spring.mail.username=.*", "spring.mail.username=$email"
$content = $content -replace "spring.mail.password=.*", "spring.mail.password=$appPasswordText"
$content | Set-Content "src/main/resources/application.properties"

Write-Host "SUCCESS: Email configuration updated!" -ForegroundColor Green
Write-Host "Email: $email" -ForegroundColor Cyan
Write-Host "Password: $('*' * $appPasswordText.Length)" -ForegroundColor Cyan

Write-Host "`nStep 3: Start the Server" -ForegroundColor Yellow
Write-Host "=======================" -ForegroundColor Yellow
Write-Host "Starting the backend server..." -ForegroundColor Cyan

# Start the server in background
Start-Process -FilePath ".\mvnw.cmd" -ArgumentList "spring-boot:run" -NoNewWindow

Write-Host "SUCCESS: Server starting..." -ForegroundColor Green
Write-Host "Please wait 30 seconds for the server to fully start." -ForegroundColor Yellow

Write-Host "`nStep 4: Test the System" -ForegroundColor Yellow
Write-Host "======================" -ForegroundColor Yellow
Write-Host "After 30 seconds, run: .\test-otp-system.ps1" -ForegroundColor Cyan

Write-Host "`nStep 5: Frontend Integration" -ForegroundColor Yellow
Write-Host "============================" -ForegroundColor Yellow
Write-Host "Your frontend should now work with the backend!" -ForegroundColor Green
Write-Host "Frontend URL: http://localhost:5174" -ForegroundColor Cyan
Write-Host "Backend URL: http://localhost:8080" -ForegroundColor Cyan

Write-Host "`nTroubleshooting:" -ForegroundColor Yellow
Write-Host "===============" -ForegroundColor Yellow
Write-Host "If you still get CORS errors:" -ForegroundColor Cyan
Write-Host "1. Restart the backend server" -ForegroundColor Cyan
Write-Host "2. Clear browser cache" -ForegroundColor Cyan
Write-Host "3. Check browser console for errors" -ForegroundColor Cyan

Write-Host "`nSUCCESS: Gmail OTP setup complete!" -ForegroundColor Green
