Write-Host "Simple Gmail OAuth Test" -ForegroundColor Green
Write-Host "=======================" -ForegroundColor Green

# Test 1: Check if server is running
Write-Host "`nTest 1: Server Status Check" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8080/api/test/health" -Method "GET"
    Write-Host "SUCCESS: Server is running!" -ForegroundColor Green
    Write-Host "   Status: $($response.status)" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: Server is not running" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
    exit
}

# Test 2: Test simple Gmail OAuth login URL generation
Write-Host "`nTest 2: Simple Gmail OAuth URL Generation" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/simple-gmail/login-url" -Method "GET"
    Write-Host "SUCCESS: Simple Gmail OAuth URL generated!" -ForegroundColor Green
    Write-Host "   URL: $($response.message)" -ForegroundColor Cyan
    
    if ($response.message -like "*accounts.google.com*") {
        Write-Host "   ✅ Valid Google OAuth URL" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️  URL format may be incorrect" -ForegroundColor Yellow
    }
} catch {
    Write-Host "ERROR: Failed to generate simple Gmail OAuth URL" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Test simple Gmail OAuth initiation
Write-Host "`nTest 3: Simple Gmail OAuth Initiation" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/simple-gmail/login" -Method "GET"
    Write-Host "SUCCESS: Simple Gmail OAuth initiated!" -ForegroundColor Green
    Write-Host "   Response: $($response.message)" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: Failed to initiate simple Gmail OAuth" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: Test direct Gmail login (mock)
Write-Host "`nTest 4: Direct Gmail Login Test" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/simple-gmail/test-login" -Method "GET"
    Write-Host "SUCCESS: Direct Gmail login test successful!" -ForegroundColor Green
    Write-Host "   Response: $($response.message)" -ForegroundColor Cyan
    
    if ($response.message -like "*Token:*") {
        Write-Host "   ✅ JWT Token generated successfully" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️  Token generation may have failed" -ForegroundColor Yellow
    }
} catch {
    Write-Host "ERROR: Direct Gmail login test failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`nSimple Gmail OAuth Integration Status:" -ForegroundColor Yellow
Write-Host "=====================================" -ForegroundColor Yellow
Write-Host "✅ Backend: http://localhost:8080 - RUNNING" -ForegroundColor Green
Write-Host "✅ Simple Gmail OAuth: URL generation working" -ForegroundColor Green
Write-Host "✅ Mock Login: Direct login test working" -ForegroundColor Green
Write-Host "✅ Frontend: Ready to test Gmail login" -ForegroundColor Green

Write-Host "`nNext Steps:" -ForegroundColor Yellow
Write-Host "1. Go to your frontend: http://localhost:5174/login" -ForegroundColor Cyan
Write-Host "2. Click 'Continue with Google'" -ForegroundColor Cyan
Write-Host "3. You should be redirected to the callback" -ForegroundColor Cyan
Write-Host "4. A mock Gmail user will be created" -ForegroundColor Cyan
Write-Host "5. You'll be redirected to dashboard with JWT token" -ForegroundColor Cyan

Write-Host "`nNote: This is using mock user data for testing" -ForegroundColor Yellow
Write-Host "Email: test.user@gmail.com" -ForegroundColor Cyan
Write-Host "Name: Test User" -ForegroundColor Cyan

Write-Host "`nSUCCESS: Simple Gmail OAuth test complete!" -ForegroundColor Green

