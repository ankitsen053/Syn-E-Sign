# Comprehensive API Testing Script for Legal Advisor Backend and Frontend
# This script tests all available APIs in your application

param(
    [string]$BackendUrl = "http://localhost:8081",
    [string]$FrontendUrl = "http://localhost:5173",
    [switch]$StartServices = $true,
    [switch]$StopServices = $false
)

# Colors for output
$Red = "`e[31m"
$Green = "`e[32m"
$Yellow = "`e[33m"
$Blue = "`e[34m"
$Magenta = "`e[35m"
$Cyan = "`e[36m"
$Reset = "`e[0m"
$Bold = "`e[1m"

# Test results tracking
$TestResults = @{
    Total = 0
    Passed = 0
    Failed = 0
    Skipped = 0
}

function Write-TestHeader {
    param([string]$Title)
    Write-Host "`n$Bold$Cyan" -NoNewline
    Write-Host "=" * 80
    Write-Host "  $Title" -NoNewline
    Write-Host "$Reset"
    Write-Host "$Cyan" -NoNewline
    Write-Host "=" * 80
    Write-Host "$Reset"
}

function Write-TestResult {
    param(
        [string]$TestName,
        [string]$Status,
        [string]$Message = "",
        [string]$Response = ""
    )
    
    $TestResults.Total++
    
    switch ($Status) {
        "PASS" { 
            Write-Host "$Green✓ PASS$Reset" -NoNewline
            $TestResults.Passed++
        }
        "FAIL" { 
            Write-Host "$Red✗ FAIL$Reset" -NoNewline
            $TestResults.Failed++
        }
        "SKIP" { 
            Write-Host "$Yellow- SKIP$Reset" -NoNewline
            $TestResults.Skipped++
        }
    }
    
    Write-Host " - $TestName"
    if ($Message) {
        Write-Host "  $Yellow$Message$Reset"
    }
    if ($Response) {
        Write-Host "  $BlueResponse: $Response$Reset"
    }
}

function Test-HealthCheck {
    Write-TestHeader "Health Check Tests"
    
    # Test backend health
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/test/health" -Method GET -TimeoutSec 10
        Write-TestResult "Backend Health Check" "PASS" "" "Status: $($response.status)"
    }
    catch {
        Write-TestResult "Backend Health Check" "FAIL" "Backend not responding" $_.Exception.Message
    }
    
    # Test frontend health (basic connectivity)
    try {
        $response = Invoke-WebRequest -Uri "$FrontendUrl" -Method GET -TimeoutSec 10
        Write-TestResult "Frontend Health Check" "PASS" "" "Status: $($response.StatusCode)"
    }
    catch {
        Write-TestResult "Frontend Health Check" "FAIL" "Frontend not responding" $_.Exception.Message
    }
}

function Test-AuthAPIs {
    Write-TestHeader "Authentication API Tests"
    
    # Test signup
    $signupData = @{
        username = "testuser_$(Get-Random)"
        email = "test_$(Get-Random)@example.com"
        password = "TestPassword123!"
        roles = @("user")
    }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/signup" -Method POST -Body ($signupData | ConvertTo-Json) -ContentType "application/json"
        Write-TestResult "User Signup" "PASS" "" "User created: $($signupData.username)"
        $testUser = $signupData
    }
    catch {
        Write-TestResult "User Signup" "FAIL" "Signup failed" $_.Exception.Message
        $testUser = $null
    }
    
    # Test login
    if ($testUser) {
        $loginData = @{
            username = $testUser.username
            password = $testUser.password
        }
        
        try {
            $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/login" -Method POST -Body ($loginData | ConvertTo-Json) -ContentType "application/json"
            Write-TestResult "User Login" "PASS" "" "Token received"
            $accessToken = $response.accessToken
            $refreshToken = $response.refreshToken
        }
        catch {
            Write-TestResult "User Login" "FAIL" "Login failed" $_.Exception.Message
            $accessToken = $null
        }
    }
    else {
        Write-TestResult "User Login" "SKIP" "Skipped due to signup failure"
    }
    
    # Test token refresh
    if ($refreshToken) {
        try {
            $refreshData = @{ refreshToken = $refreshToken }
            $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/refresh" -Method POST -Body ($refreshData | ConvertTo-Json) -ContentType "application/json"
            Write-TestResult "Token Refresh" "PASS" "" "New token received"
        }
        catch {
            Write-TestResult "Token Refresh" "FAIL" "Token refresh failed" $_.Exception.Message
        }
    }
    else {
        Write-TestResult "Token Refresh" "SKIP" "Skipped due to login failure"
    }
    
    # Test logout
    if ($refreshToken) {
        try {
            $logoutData = @{ refreshToken = $refreshToken }
            $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/logout" -Method POST -Body ($logoutData | ConvertTo-Json) -ContentType "application/json"
            Write-TestResult "User Logout" "PASS" "" "Logout successful"
        }
        catch {
            Write-TestResult "User Logout" "FAIL" "Logout failed" $_.Exception.Message
        }
    }
    else {
        Write-TestResult "User Logout" "SKIP" "Skipped due to login failure"
    }
    
    return $accessToken
}

function Test-AIAPIs {
    param([string]$AccessToken)
    
    Write-TestHeader "AI Service API Tests"
    
    $headers = @{}
    if ($AccessToken) {
        $headers.Authorization = "Bearer $AccessToken"
    }
    
    # Test AI status
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/status" -Method GET -Headers $headers -TimeoutSec 30
        Write-TestResult "AI Service Status" "PASS" "" "Status: $($response.status)"
    }
    catch {
        Write-TestResult "AI Service Status" "FAIL" "AI service not responding" $_.Exception.Message
    }
    
    # Test document analysis
    $analysisData = @{
        content = "This is a test legal document for analysis. It contains various legal terms and conditions that need to be analyzed for compliance and risk assessment."
    }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/analyze" -Method POST -Body ($analysisData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 60
        Write-TestResult "Document Analysis" "PASS" "" "Analysis completed"
    }
    catch {
        Write-TestResult "Document Analysis" "FAIL" "Document analysis failed" $_.Exception.Message
    }
    
    # Test agreement creation
    $agreementData = @{
        type = "NDA"
        partyA = "Test Company A"
        partyB = "Test Company B"
        terms = "Confidentiality agreement for business partnership"
    }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/create" -Method POST -Body ($agreementData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 120
        Write-TestResult "Agreement Creation" "PASS" "" "Agreement created"
    }
    catch {
        Write-TestResult "Agreement Creation" "FAIL" "Agreement creation failed" $_.Exception.Message
    }
    
    # Test comprehensive analysis
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/analyze-comprehensive" -Method POST -Body ($analysisData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 90
        Write-TestResult "Comprehensive Analysis" "PASS" "" "Comprehensive analysis completed"
    }
    catch {
        Write-TestResult "Comprehensive Analysis" "FAIL" "Comprehensive analysis failed" $_.Exception.Message
    }
    
    # Test risk analysis
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/risk-analysis" -Method POST -Body ($analysisData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 60
        Write-TestResult "Risk Analysis" "PASS" "" "Risk analysis completed"
    }
    catch {
        Write-TestResult "Risk Analysis" "FAIL" "Risk analysis failed" $_.Exception.Message
    }
    
    # Test compliance assessment
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/compliance-assessment?jurisdiction=IN" -Method POST -Body ($analysisData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 60
        Write-TestResult "Compliance Assessment" "PASS" "" "Compliance assessment completed"
    }
    catch {
        Write-TestResult "Compliance Assessment" "FAIL" "Compliance assessment failed" $_.Exception.Message
    }
}

function Test-DocumentAPIs {
    param([string]$AccessToken)
    
    Write-TestHeader "Document Management API Tests"
    
    $headers = @{}
    if ($AccessToken) {
        $headers.Authorization = "Bearer $AccessToken"
    }
    
    # Test document status
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/status" -Method GET -Headers $headers
        Write-TestResult "Document Service Status" "PASS" "" "Status: $($response.status)"
    }
    catch {
        Write-TestResult "Document Service Status" "FAIL" "Document service not responding" $_.Exception.Message
    }
    
    # Test save document
    $documentData = @{
        title = "Test Legal Document"
        content = "This is a test legal document content for testing purposes."
        type = "CONTRACT"
        status = "DRAFT"
    }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/save" -Method POST -Body ($documentData | ConvertTo-Json) -Headers $headers -ContentType "application/json"
        Write-TestResult "Save Document" "PASS" "" "Document saved with ID: $($response.id)"
        $documentId = $response.id
    }
    catch {
        Write-TestResult "Save Document" "FAIL" "Document save failed" $_.Exception.Message
        $documentId = $null
    }
    
    # Test get user documents
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/user" -Method GET -Headers $headers
        Write-TestResult "Get User Documents" "PASS" "" "Found $($response.Count) documents"
    }
    catch {
        Write-TestResult "Get User Documents" "FAIL" "Failed to get user documents" $_.Exception.Message
    }
    
    # Test get specific document
    if ($documentId) {
        try {
            $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/$documentId" -Method GET -Headers $headers
            Write-TestResult "Get Document" "PASS" "" "Document retrieved: $($response.title)"
        }
        catch {
            Write-TestResult "Get Document" "FAIL" "Failed to get document" $_.Exception.Message
        }
        
        # Test update document
        $updateData = @{
            title = "Updated Test Legal Document"
            content = "This is an updated test legal document content."
            type = "CONTRACT"
            status = "REVIEW"
        }
        
        try {
            $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/$documentId" -Method PUT -Body ($updateData | ConvertTo-Json) -Headers $headers -ContentType "application/json"
            Write-TestResult "Update Document" "PASS" "" "Document updated successfully"
        }
        catch {
            Write-TestResult "Update Document" "FAIL" "Document update failed" $_.Exception.Message
        }
        
        # Test delete document
        try {
            $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/$documentId" -Method DELETE -Headers $headers
            Write-TestResult "Delete Document" "PASS" "" "Document deleted successfully"
        }
        catch {
            Write-TestResult "Delete Document" "FAIL" "Document deletion failed" $_.Exception.Message
        }
    }
    else {
        Write-TestResult "Get Document" "SKIP" "Skipped due to save failure"
        Write-TestResult "Update Document" "SKIP" "Skipped due to save failure"
        Write-TestResult "Delete Document" "SKIP" "Skipped due to save failure"
    }
}

function Test-ProfileAPIs {
    param([string]$AccessToken)
    
    Write-TestHeader "Profile Management API Tests"
    
    $headers = @{}
    if ($AccessToken) {
        $headers.Authorization = "Bearer $AccessToken"
    }
    
    # Test get profile
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/profile" -Method GET -Headers $headers
        Write-TestResult "Get Profile" "PASS" "" "Profile retrieved"
    }
    catch {
        Write-TestResult "Get Profile" "FAIL" "Failed to get profile" $_.Exception.Message
    }
    
    # Test update profile
    $profileData = @{
        firstName = "Test"
        lastName = "User"
        phone = "+1234567890"
        address = "123 Test Street, Test City"
        company = "Test Company"
        position = "Test Position"
    }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/profile" -Method POST -Body ($profileData | ConvertTo-Json) -Headers $headers -ContentType "application/json"
        Write-TestResult "Update Profile" "PASS" "" "Profile updated successfully"
    }
    catch {
        Write-TestResult "Update Profile" "FAIL" "Profile update failed" $_.Exception.Message
    }
    
    # Test profile verification
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/profile/verify?method=email" -Method POST -Headers $headers
        Write-TestResult "Profile Verification" "PASS" "" "Verification initiated"
    }
    catch {
        Write-TestResult "Profile Verification" "FAIL" "Profile verification failed" $_.Exception.Message
    }
}

function Test-OAuthAPIs {
    Write-TestHeader "OAuth API Tests"
    
    # Test Google OAuth endpoints
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/google/url" -Method GET -TimeoutSec 10
        Write-TestResult "Google OAuth URL" "PASS" "" "OAuth URL generated"
    }
    catch {
        Write-TestResult "Google OAuth URL" "FAIL" "Google OAuth not configured" $_.Exception.Message
    }
    
    # Test Gmail OAuth endpoints
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/gmail/oauth/url" -Method GET -TimeoutSec 10
        Write-TestResult "Gmail OAuth URL" "PASS" "" "Gmail OAuth URL generated"
    }
    catch {
        Write-TestResult "Gmail OAuth URL" "FAIL" "Gmail OAuth not configured" $_.Exception.Message
    }
}

function Test-DocumentScannerAPIs {
    param([string]$AccessToken)
    
    Write-TestHeader "Document Scanner API Tests"
    
    $headers = @{}
    if ($AccessToken) {
        $headers.Authorization = "Bearer $AccessToken"
    }
    
    # Test document scanner status
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/scanner/status" -Method GET -Headers $headers
        Write-TestResult "Document Scanner Status" "PASS" "" "Scanner status: $($response.status)"
    }
    catch {
        Write-TestResult "Document Scanner Status" "FAIL" "Document scanner not responding" $_.Exception.Message
    }
    
    # Test document scanning
    $scanData = @{
        documentType = "CONTRACT"
        content = "This is a test document for scanning and analysis."
        scanType = "FULL"
    }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/scanner/scan" -Method POST -Body ($scanData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 60
        Write-TestResult "Document Scanning" "PASS" "" "Document scanned successfully"
    }
    catch {
        Write-TestResult "Document Scanning" "FAIL" "Document scanning failed" $_.Exception.Message
    }
}

function Test-FrontendAPIs {
    Write-TestHeader "Frontend API Integration Tests"
    
    # Test frontend API service endpoints
    $frontendApiUrl = "$FrontendUrl/api"
    
    # Note: Frontend APIs are typically called from the browser, but we can test the endpoints
    # that the frontend would call to ensure they're accessible
    
    try {
        $response = Invoke-WebRequest -Uri "$BackendUrl/api/test/health" -Method GET -TimeoutSec 10
        Write-TestResult "Frontend-Backend Connection" "PASS" "" "Connection successful"
    }
    catch {
        Write-TestResult "Frontend-Backend Connection" "FAIL" "Frontend cannot connect to backend" $_.Exception.Message
    }
}

function Start-Services {
    Write-TestHeader "Starting Services"
    
    # Start backend service
    Write-Host "$YellowStarting Backend Service...$Reset"
    Start-Process -FilePath "mvn" -ArgumentList "spring-boot:run" -WorkingDirectory (Get-Location) -WindowStyle Hidden
    Start-Sleep -Seconds 10
    
    # Start frontend service
    Write-Host "$YellowStarting Frontend Service...$Reset"
    Set-Location "legal-advisor-frontend"
    Start-Process -FilePath "npm" -ArgumentList "run", "dev" -WindowStyle Hidden
    Set-Location ".."
    Start-Sleep -Seconds 15
    
    Write-Host "$GreenServices started successfully!$Reset"
}

function Stop-Services {
    Write-TestHeader "Stopping Services"
    
    # Stop Java processes (Spring Boot)
    Get-Process -Name "java" -ErrorAction SilentlyContinue | Stop-Process -Force
    
    # Stop Node processes (Vite)
    Get-Process -Name "node" -ErrorAction SilentlyContinue | Stop-Process -Force
    
    Write-Host "$GreenServices stopped successfully!$Reset"
}

function Show-TestSummary {
    Write-TestHeader "Test Summary"
    
    Write-Host "$Bold$CyanTest Results:$Reset"
    Write-Host "  Total Tests: $($TestResults.Total)"
    Write-Host "  $GreenPassed: $($TestResults.Passed)$Reset"
    Write-Host "  $RedFailed: $($TestResults.Failed)$Reset"
    Write-Host "  $YellowSkipped: $($TestResults.Skipped)$Reset"
    
    $successRate = if ($TestResults.Total -gt 0) { [math]::Round(($TestResults.Passed / $TestResults.Total) * 100, 2) } else { 0 }
    Write-Host "`n$Bold$CyanSuccess Rate: $successRate%$Reset"
    
    if ($TestResults.Failed -eq 0) {
        Write-Host "`n$Bold$Green🎉 All tests passed! Your APIs are working correctly.$Reset"
    } else {
        Write-Host "`n$Bold$Red⚠️  Some tests failed. Please check the error messages above.$Reset"
    }
}

# Main execution
try {
    Write-Host "$Bold$Magenta" -NoNewline
    Write-Host "=" * 80
    Write-Host "  COMPREHENSIVE API TESTING SUITE - LEGAL ADVISOR APPLICATION" -NoNewline
    Write-Host "$Reset"
    Write-Host "$Magenta" -NoNewline
    Write-Host "=" * 80
    Write-Host "$Reset"
    
    Write-Host "`n$YellowConfiguration:$Reset"
    Write-Host "  Backend URL: $BackendUrl"
    Write-Host "  Frontend URL: $FrontendUrl"
    Write-Host "  Start Services: $StartServices"
    Write-Host "  Stop Services: $StopServices"
    
    if ($StartServices) {
        Start-Services
    }
    
    # Wait for services to be ready
    Write-Host "`n$YellowWaiting for services to be ready...$Reset"
    Start-Sleep -Seconds 5
    
    # Run all tests
    Test-HealthCheck
    $accessToken = Test-AuthAPIs
    Test-AIAPIs -AccessToken $accessToken
    Test-DocumentAPIs -AccessToken $accessToken
    Test-ProfileAPIs -AccessToken $accessToken
    Test-OAuthAPIs
    Test-DocumentScannerAPIs -AccessToken $accessToken
    Test-FrontendAPIs
    
    Show-TestSummary
    
    if ($StopServices) {
        Stop-Services
    }
}
catch {
    Write-Host "`n$Bold$RedError during testing: $($_.Exception.Message)$Reset"
    if ($StopServices) {
        Stop-Services
    }
    exit 1
}
finally {
    Write-Host "`n$Bold$CyanTesting completed!$Reset"
}
