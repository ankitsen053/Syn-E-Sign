# OTP Verification System Troubleshooting Guide

## 🔍 Current Issue Analysis

The OTP verification system is implemented but may not be working due to email configuration issues.

## 🚨 Critical Issues Found

### 1. Email Configuration Problem
**Issue**: Gmail password is set to placeholder value `abcdefgh`
**Location**: `src/main/resources/application.properties`
**Fix Required**: Update with real Gmail App Password

### 2. Gmail App Password Setup Required
Gmail requires an "App Password" for SMTP access, not your regular password.

## 🔧 Step-by-Step Fix Instructions

### Step 1: Set Up Gmail App Password

1. **Enable 2-Factor Authentication** (if not already enabled)
   - Go to your Google Account settings
   - Navigate to Security
   - Enable 2-Step Verification

2. **Generate App Password**
   - Go to Google Account settings
   - Navigate to Security
   - Under "2-Step Verification", click "App passwords"
   - Select "Mail" and "Other (Custom name)"
   - Enter "Legal Advisor" as the name
   - Copy the generated 16-character password

### Step 2: Update Application Properties

Update `src/main/resources/application.properties`:

```properties
# Mail Configuration
spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=anshtalreja025@gmail.com
spring.mail.password=YOUR_16_CHARACTER_APP_PASSWORD_HERE
spring.mail.protocol=smtp
spring.mail.properties.mail.smtp.auth=true
spring.mail.properties.mail.smtp.starttls.enable=true
spring.mail.default-encoding=UTF-8
```

### Step 3: Alternative Email Services

If Gmail doesn't work, you can use other email services:

#### Option A: SendGrid (Recommended for Production)
```properties
spring.mail.host=smtp.sendgrid.net
spring.mail.port=587
spring.mail.username=apikey
spring.mail.password=YOUR_SENDGRID_API_KEY
```

#### Option B: Outlook/Hotmail
```properties
spring.mail.host=smtp-mail.outlook.com
spring.mail.port=587
spring.mail.username=your-email@outlook.com
spring.mail.password=YOUR_PASSWORD
```

## 🧪 Testing the Fix

### 1. Start the Server
```powershell
.\mvnw.cmd spring-boot:run
```

### 2. Run the Status Check
```powershell
.\check-otp-status.ps1
```

### 3. Manual Testing Steps

#### Test Registration:
```bash
curl -X POST http://localhost:8080/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser123",
    "email": "your-email@gmail.com",
    "password": "TestPassword123!",
    "roles": ["user"]
  }'
```

#### Check Verification Status:
```bash
curl -X GET http://localhost:8080/api/auth/verification-status/your-email@gmail.com
```

#### Verify Email (after receiving OTP):
```bash
curl -X POST http://localhost:8080/api/auth/verify-email \
  -H "Content-Type: application/json" \
  -d '{
    "email": "your-email@gmail.com",
    "otp": "123456"
  }'
```

## 🔍 Debugging Steps

### 1. Check Server Logs
Look for email-related errors in the console output:
- SMTP connection errors
- Authentication failures
- Email sending errors

### 2. Test Email Configuration
Add this test endpoint to verify email setup:

```java
@GetMapping("/test-email")
public ResponseEntity<String> testEmail() {
    try {
        emailService.sendOtpEmail("test@example.com", "123456");
        return ResponseEntity.ok("Email test successful");
    } catch (Exception e) {
        return ResponseEntity.status(500).body("Email test failed: " + e.getMessage());
    }
}
```

### 3. Common Error Messages and Solutions

#### "535-5.7.8 Username and Password not accepted"
**Solution**: Use Gmail App Password, not regular password

#### "Connection timeout"
**Solution**: Check firewall settings, try different port (465 with SSL)

#### "Authentication failed"
**Solution**: Verify email and password, ensure 2FA is enabled

## 🛠️ Quick Fix Script

Create a file called `fix-email-config.ps1`:

```powershell
Write-Host "🔧 Email Configuration Fix Tool" -ForegroundColor Green

# Backup original file
Copy-Item "src/main/resources/application.properties" "src/main/resources/application.properties.backup"

# Get new email credentials
$email = Read-Host "Enter your Gmail address"
$appPassword = Read-Host "Enter your Gmail App Password (16 characters)" -AsSecureString
$appPasswordText = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($appPassword))

# Update the properties file
$content = Get-Content "src/main/resources/application.properties"
$content = $content -replace "spring.mail.username=.*", "spring.mail.username=$email"
$content = $content -replace "spring.mail.password=.*", "spring.mail.password=$appPasswordText"
$content | Set-Content "src/main/resources/application.properties"

Write-Host "✅ Email configuration updated!" -ForegroundColor Green
Write-Host "📧 Username: $email" -ForegroundColor Cyan
Write-Host "🔑 Password: $('*' * $appPasswordText.Length)" -ForegroundColor Cyan
```

## 📧 Email Template Testing

To test if emails are being sent correctly, check:

1. **Spam/Junk folder** - OTP emails might be filtered
2. **Email format** - Should be plain text with OTP code
3. **Sender address** - Should be your configured Gmail address

## 🚀 Production Recommendations

### 1. Use Professional Email Service
- **SendGrid**: Best for production applications
- **Amazon SES**: Cost-effective for high volume
- **Mailgun**: Good for transactional emails

### 2. Environment Variables
Don't hardcode email credentials. Use environment variables:

```properties
spring.mail.username=${MAIL_USERNAME}
spring.mail.password=${MAIL_PASSWORD}
```

### 3. Email Templates
Consider using HTML templates for better user experience:

```java
// In EmailService.java
public void sendOtpEmail(String to, String otp) {
    try {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        
        helper.setTo(to);
        helper.setSubject("Email Verification - Legal Advisor");
        helper.setText(generateHtmlOtpEmail(otp), true); // HTML content
        
        mailSender.send(message);
    } catch (Exception e) {
        throw new RuntimeException("Failed to send email: " + e.getMessage());
    }
}
```

## 📞 Support

If you're still having issues:

1. **Check the logs** for specific error messages
2. **Verify Gmail settings** - ensure "Less secure app access" is enabled (if not using App Password)
3. **Test with a different email service** like SendGrid
4. **Check network connectivity** - ensure port 587 is not blocked

## 🔄 Next Steps

1. **Fix email configuration** using the steps above
2. **Test the system** with the provided scripts
3. **Verify OTP delivery** in your email
4. **Test complete user flow** from registration to login
