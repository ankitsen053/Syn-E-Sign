# GST Verification System Test Script
# This script tests the complete GST verification functionality

Write-Host "=== GST Verification System Test Script ===" -ForegroundColor Green
Write-Host "Testing GST verification for company agreements" -ForegroundColor Yellow
Write-Host ""

# Configuration
$BASE_URL = "http://localhost:8081"
$API_BASE = "$BASE_URL/api"

# Test data
$TEST_GST = "27AAPFU0939F1Z5"
$TEST_COMPANY = "Test Company Pvt Ltd"
$TEST_PAN = "ABCDE1234F"
$TEST_AADHAAR = "123456789012"

Write-Host "1. Testing GST Verification Endpoint..." -ForegroundColor Cyan
Write-Host "   - Real-time GST verification" -ForegroundColor Gray
Write-Host "   - Company information validation" -ForegroundColor Gray
Write-Host "   - Document upload support" -ForegroundColor Gray
Write-Host ""

try {
    # Test 1: Valid GST with company details
    $gstPayload = @{
        gstNumber = $TEST_GST
        companyName = $TEST_COMPANY
        documentUrl = "https://example.com/gst-document.pdf"
        businessAddress = "123 Business Street, Mumbai, Maharashtra - 400001"
        contactNumber = "+91-9876543210"
        email = "contact@testcompany.com"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/kyc/verify/gst" -Method POST -Body $gstPayload -ContentType "application/json"
    Write-Host "✓ GST Verification (Valid):" -ForegroundColor Green
    Write-Host "  Success: $($response.success)" -ForegroundColor White
    Write-Host "  Message: $($response.message)" -ForegroundColor White
    Write-Host "  API Provider: $($response.apiProvider)" -ForegroundColor White
    Write-Host "  Company Name: $($response.companyName)" -ForegroundColor White
    
    # Test 2: Invalid GST format
    $invalidGstPayload = @{
        gstNumber = "INVALID123"
        companyName = $TEST_COMPANY
        documentUrl = "https://example.com/gst-document.pdf"
    } | ConvertTo-Json

    try {
        $response = Invoke-RestMethod -Uri "$API_BASE/kyc/verify/gst" -Method POST -Body $invalidGstPayload -ContentType "application/json"
        Write-Host "✗ Invalid GST should have failed" -ForegroundColor Red
    } catch {
        Write-Host "✓ GST Verification (Invalid Format):" -ForegroundColor Green
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor White
    }
    
} catch {
    Write-Host "✗ GST Verification Tests Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "2. Testing GST Verification via Verification Service..." -ForegroundColor Cyan
Write-Host "   - Integration with verification system" -ForegroundColor Gray
Write-Host "   - Status tracking" -ForegroundColor Gray
Write-Host "   - Auto-approval for development" -ForegroundColor Gray
Write-Host ""

try {
    $gstVerificationPayload = @{
        gstNumber = $TEST_GST
        companyName = $TEST_COMPANY
        documentUrl = "https://example.com/gst-document.pdf"
        businessAddress = "123 Business Street, Mumbai, Maharashtra - 400001"
        contactNumber = "+91-9876543210"
        email = "contact@testcompany.com"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/verification/gst" -Method POST -Body $gstVerificationPayload -ContentType "application/json"
    Write-Host "✓ GST Verification Service:" -ForegroundColor Green
    Write-Host "  Response: $($response.message)" -ForegroundColor White
    
} catch {
    Write-Host "✗ GST Verification Service Test Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "3. Testing Bulk Verification with GST..." -ForegroundColor Cyan
Write-Host "   - PAN + Aadhaar + GST verification" -ForegroundColor Gray
Write-Host "   - Complete company verification" -ForegroundColor Gray
Write-Host ""

try {
    $bulkPayload = @{
        panNumber = $TEST_PAN
        aadhaarNumber = $TEST_AADHAAR
        gstNumber = $TEST_GST
        panDocumentUrl = "https://example.com/pan-document.pdf"
        aadhaarDocumentUrl = "https://example.com/aadhaar-document.pdf"
        gstDocumentUrl = "https://example.com/gst-document.pdf"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/kyc/verify/bulk" -Method POST -Body $bulkPayload -ContentType "application/json"
    Write-Host "✓ Bulk Verification (PAN + Aadhaar + GST):" -ForegroundColor Green
    Write-Host "  Success: $($response.success)" -ForegroundColor White
    Write-Host "  Message: $($response.message)" -ForegroundColor White
    
    if ($response.panVerification) {
        Write-Host "  PAN Verification: $($response.panVerification.success)" -ForegroundColor White
    }
    if ($response.aadhaarVerification) {
        Write-Host "  Aadhaar Verification: $($response.aadhaarVerification.success)" -ForegroundColor White
    }
    if ($response.gstVerification) {
        Write-Host "  GST Verification: $($response.gstVerification.success)" -ForegroundColor White
    }
    
} catch {
    Write-Host "✗ Bulk Verification Test Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "4. Testing Comprehensive Verification Status..." -ForegroundColor Cyan
Write-Host "   - GST status in overall verification" -ForegroundColor Gray
Write-Host "   - Progress tracking with GST" -ForegroundColor Gray
Write-Host ""

try {
    $response = Invoke-RestMethod -Uri "$API_BASE/verification/status" -Method GET -ContentType "application/json"
    Write-Host "✓ Comprehensive Status (with GST):" -ForegroundColor Green
    Write-Host "  Overall Status: $($response.overallStatus)" -ForegroundColor White
    Write-Host "  Fully Verified: $($response.fullyVerified)" -ForegroundColor White
    Write-Host "  Progress: $($response.progress.completed)/$($response.progress.total) ($($response.progress.percentage)%)" -ForegroundColor White
    
    # Show individual verification statuses
    Write-Host "  PAN: $($response.panVerification.status)" -ForegroundColor White
    Write-Host "  Aadhaar: $($response.aadhaarVerification.status)" -ForegroundColor White
    Write-Host "  Video: $($response.videoVerification.status)" -ForegroundColor White
    Write-Host "  GST: $($response.gstVerification.status)" -ForegroundColor White
    Write-Host "  Email: $($response.emailVerification.verified)" -ForegroundColor White
    
    # Show GST details
    if ($response.gstVerification.verified) {
        Write-Host "  GST Number: $($response.gstVerification.gstNumber)" -ForegroundColor White
        Write-Host "  Company Name: $($response.gstVerification.companyName)" -ForegroundColor White
        Write-Host "  Business Address: $($response.gstVerification.businessAddress)" -ForegroundColor White
    }
    
} catch {
    Write-Host "✗ Status Check Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "5. Testing GST Admin Endpoints..." -ForegroundColor Cyan
Write-Host "   - Admin approval/rejection" -ForegroundColor Gray
Write-Host "   - Manual verification control" -ForegroundColor Gray
Write-Host ""

try {
    $testUserId = "test-user-123"
    
    # Test GST approval
    $response = Invoke-RestMethod -Uri "$API_BASE/verification/admin/gst/approve/$testUserId" -Method POST -ContentType "application/json"
    Write-Host "✓ GST Admin Approval:" -ForegroundColor Green
    Write-Host "  Response: $($response.message)" -ForegroundColor White
    
    # Test GST rejection
    $rejectionReason = "Document verification failed"
    $response = Invoke-RestMethod -Uri "$API_BASE/verification/admin/gst/reject/$testUserId" -Method POST -Body $rejectionReason -ContentType "application/json"
    Write-Host "✓ GST Admin Rejection:" -ForegroundColor Green
    Write-Host "  Response: $($response.message)" -ForegroundColor White
    
} catch {
    Write-Host "✗ GST Admin Tests Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "6. Testing GST Format Validation..." -ForegroundColor Cyan
Write-Host "   - Various GST format scenarios" -ForegroundColor Gray
Write-Host "   - Error message validation" -ForegroundColor Gray
Write-Host ""

try {
    # Test various invalid GST formats
    $invalidGstFormats = @(
        "123456789012345",  # Too long
        "12345678901234",   # Too short
        "ABCDEFGHIJKLMNO",  # All letters
        "12345678901234A",  # Wrong format
        "27AAPFU0939F1Z4"   # Invalid check digit
    )

    foreach ($invalidGst in $invalidGstFormats) {
        $invalidPayload = @{
            gstNumber = $invalidGst
            companyName = $TEST_COMPANY
            documentUrl = "https://example.com/gst-document.pdf"
        } | ConvertTo-Json

        try {
            $response = Invoke-RestMethod -Uri "$API_BASE/verification/gst" -Method POST -Body $invalidPayload -ContentType "application/json"
            Write-Host "✗ GST $invalidGst should have failed" -ForegroundColor Red
        } catch {
            Write-Host "✓ GST Format Validation ($invalidGst):" -ForegroundColor Green
            Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor White
        }
    }
    
} catch {
    Write-Host "✗ GST Format Validation Tests Failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "=== GST Verification Test Summary ===" -ForegroundColor Green
Write-Host "✓ Real-time GST verification with KYC APIs" -ForegroundColor Green
Write-Host "✓ GST verification integration with verification system" -ForegroundColor Green
Write-Host "✓ Bulk verification (PAN + Aadhaar + GST)" -ForegroundColor Green
Write-Host "✓ Comprehensive status tracking with GST" -ForegroundColor Green
Write-Host "✓ GST admin approval/rejection endpoints" -ForegroundColor Green
Write-Host "✓ GST format validation and error handling" -ForegroundColor Green
Write-Host "✓ Company information storage and retrieval" -ForegroundColor Green
Write-Host "✓ Auto-approval for development" -ForegroundColor Green
Write-Host ""
Write-Host "GST verification system is fully functional for company agreements!" -ForegroundColor Yellow
Write-Host ""

Write-Host "Test completed!" -ForegroundColor Green
