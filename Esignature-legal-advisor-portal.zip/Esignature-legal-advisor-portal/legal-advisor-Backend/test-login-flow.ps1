# Test Complete Login Flow
Write-Host "=== Complete Login Flow Test ===" -ForegroundColor Green

# Test login endpoint
Write-Host "`n1. Testing login endpoint..." -ForegroundColor Yellow
try {
    $loginBody = @{
        username = "testuser2"
        password = "testpass123"
    } | ConvertTo-Json

    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/login" -Method POST -Headers @{"Content-Type"="application/json"} -Body $loginBody -UseBasicParsing
    Write-Host "✅ Login successful" -ForegroundColor Green
    $loginData = $response.Content | ConvertFrom-Json
    Write-Host "   - Username: $($loginData.username)" -ForegroundColor Gray
    Write-Host "   - Token received: $($loginData.token.Length) characters" -ForegroundColor Gray
    Write-Host "   - Token type: $($loginData.type)" -ForegroundColor Gray
    
    $token = $loginData.token
} catch {
    Write-Host "❌ Login failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test profile endpoint with the token
Write-Host "`n2. Testing profile endpoint with token..." -ForegroundColor Yellow
try {
    $profileResponse = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/profile" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Profile fetch successful" -ForegroundColor Green
    $profileData = $profileResponse.Content | ConvertFrom-Json
    Write-Host "   - User ID: $($profileData.id)" -ForegroundColor Gray
    Write-Host "   - Email: $($profileData.email)" -ForegroundColor Gray
    Write-Host "   - Email Verified: $($profileData.emailVerified)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Profile fetch failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}

# Test dashboard endpoint with the token
Write-Host "`n3. Testing dashboard endpoint with token..." -ForegroundColor Yellow
try {
    $dashboardResponse = Invoke-WebRequest -Uri "http://localhost:8081/api/dashboard/stats" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Dashboard fetch successful" -ForegroundColor Green
    $dashboardData = $dashboardResponse.Content | ConvertFrom-Json
    Write-Host "   - Documents Generated: $($dashboardData.documentsGenerated.value)" -ForegroundColor Gray
    Write-Host "   - Documents Analyzed: $($dashboardData.documentsAnalyzed.value)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Dashboard fetch failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n=== Login Flow Test Complete ===" -ForegroundColor Green
