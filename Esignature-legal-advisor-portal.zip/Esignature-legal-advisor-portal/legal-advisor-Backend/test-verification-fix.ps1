# Verification Fix Test Script
# This script tests that all verifications are now auto-approved

Write-Host "=== Verification Fix Test Script ===" -ForegroundColor Green
Write-Host "Testing that all verifications are now auto-approved" -ForegroundColor Yellow
Write-Host ""

# Configuration
$BASE_URL = "http://localhost:8081"
$API_BASE = "$BASE_URL/api"

# Test data
$TEST_PAN = "ABCDE1234F"
$TEST_AADHAAR = "123456789012"

Write-Host "1. Testing PAN Verification (should auto-approve)..." -ForegroundColor Cyan
try {
    $panPayload = @{
        panNumber = $TEST_PAN
        documentUrl = "https://example.com/pan-document.pdf"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/verification/pan" -Method POST -Body $panPayload -ContentType "application/json"
    Write-Host "PAN Verification Response:" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 3
} catch {
    Write-Host "PAN Verification Failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}
Write-Host ""

Write-Host "2. Testing Aadhaar Verification (should auto-approve)..." -ForegroundColor Cyan
try {
    $aadhaarPayload = @{
        aadharNumber = $TEST_AADHAAR
        documentUrl = "https://example.com/aadhaar-document.pdf"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$API_BASE/verification/aadhaar" -Method POST -Body $aadhaarPayload -ContentType "application/json"
    Write-Host "Aadhaar Verification Response:" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 3
} catch {
    Write-Host "Aadhaar Verification Failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}
Write-Host ""

Write-Host "3. Testing Video Verification (should auto-approve)..." -ForegroundColor Cyan
try {
    # Create a simple text file to simulate video upload
    $testVideoContent = "This is a test video file for verification"
    $testVideoPath = "test-video.txt"
    $testVideoContent | Out-File -FilePath $testVideoPath -Encoding UTF8

    $boundary = [System.Guid]::NewGuid().ToString()
    $LF = "`r`n"
    $bodyLines = (
        "--$boundary",
        "Content-Disposition: form-data; name=`"notes`"",
        "",
        "Test video verification notes",
        "--$boundary",
        "Content-Disposition: form-data; name=`"video`"; filename=`"test-video.txt`"",
        "Content-Type: text/plain",
        "",
        $testVideoContent,
        "--$boundary--"
    ) -join $LF

    $headers = @{
        "Content-Type" = "multipart/form-data; boundary=$boundary"
    }

    $response = Invoke-RestMethod -Uri "$API_BASE/verification/video" -Method POST -Body $bodyLines -Headers $headers
    Write-Host "Video Verification Response:" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 3

    # Clean up test file
    Remove-Item $testVideoPath -ErrorAction SilentlyContinue
} catch {
    Write-Host "Video Verification Failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
    # Clean up test file
    Remove-Item $testVideoPath -ErrorAction SilentlyContinue
}
Write-Host ""

Write-Host "4. Testing Verification Status..." -ForegroundColor Cyan
try {
    $response = Invoke-RestMethod -Uri "$API_BASE/verification/status" -Method GET -ContentType "application/json"
    Write-Host "Verification Status Response:" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 5
} catch {
    Write-Host "Verification Status Failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}
Write-Host ""

Write-Host "=== Verification Fix Test Summary ===" -ForegroundColor Green
Write-Host "All verifications should now auto-approve for development" -ForegroundColor Green
Write-Host "PAN verification: Auto-approved" -ForegroundColor Green
Write-Host "Aadhaar verification: Auto-approved" -ForegroundColor Green
Write-Host "Video verification: Auto-approved" -ForegroundColor Green
Write-Host ""
Write-Host "Note: This is for development/testing only. For production, disable auto-approval." -ForegroundColor Yellow
Write-Host ""

Write-Host "Test completed!" -ForegroundColor Green
