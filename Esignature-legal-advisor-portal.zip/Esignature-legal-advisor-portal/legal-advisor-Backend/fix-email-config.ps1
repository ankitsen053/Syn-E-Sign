Write-Host "🔧 Email Configuration Fix Tool" -ForegroundColor Green
Write-Host "=================================" -ForegroundColor Green

# Check if application.properties exists
if (-not (Test-Path "src/main/resources/application.properties")) {
    Write-Host "❌ application.properties not found!" -ForegroundColor Red
    Write-Host "Please run this script from the project root directory." -ForegroundColor Yellow
    exit
}

# Backup original file
Write-Host "📋 Creating backup of application.properties..." -ForegroundColor Yellow
Copy-Item "src/main/resources/application.properties" "src/main/resources/application.properties.backup"
Write-Host "✅ Backup created: application.properties.backup" -ForegroundColor Green

Write-Host "`n📧 Email Configuration Setup" -ForegroundColor Yellow
Write-Host "=============================" -ForegroundColor Yellow

# Get email credentials
$email = Read-Host "Enter your Gmail address"
$appPassword = Read-Host "Enter your Gmail App Password (16 characters)" -AsSecureString
$appPasswordText = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($appPassword))

# Validate input
if (-not $email -or -not $appPasswordText) {
    Write-Host "❌ Email or password cannot be empty!" -ForegroundColor Red
    exit
}

if ($appPasswordText.Length -ne 16) {
    Write-Host "❌ Gmail App Password must be exactly 16 characters!" -ForegroundColor Red
    Write-Host "💡 To get an App Password:" -ForegroundColor Yellow
    Write-Host "   1. Go to your Google Account settings" -ForegroundColor Cyan
    Write-Host "   2. Navigate to Security" -ForegroundColor Cyan
    Write-Host "   3. Enable 2-Step Verification if not already enabled" -ForegroundColor Cyan
    Write-Host "   4. Click 'App passwords'" -ForegroundColor Cyan
    Write-Host "   5. Select 'Mail' and generate a password" -ForegroundColor Cyan
    exit
}

# Update the properties file
Write-Host "`n🔧 Updating application.properties..." -ForegroundColor Yellow
$content = Get-Content "src/main/resources/application.properties"
$content = $content -replace "spring.mail.username=.*", "spring.mail.username=$email"
$content = $content -replace "spring.mail.password=.*", "spring.mail.password=$appPasswordText"
$content | Set-Content "src/main/resources/application.properties"

Write-Host "✅ Email configuration updated successfully!" -ForegroundColor Green
Write-Host "📧 Username: $email" -ForegroundColor Cyan
Write-Host "🔑 Password: $('*' * $appPasswordText.Length)" -ForegroundColor Cyan

Write-Host "`n🚀 Next Steps:" -ForegroundColor Yellow
Write-Host "1. Start the server: .\mvnw.cmd spring-boot:run" -ForegroundColor Cyan
Write-Host "2. Test the system: .\check-otp-status.ps1" -ForegroundColor Cyan
Write-Host "3. Check your email for OTP codes" -ForegroundColor Cyan

Write-Host "`n📚 For more help, see: OTP_TROUBLESHOOTING_GUIDE.md" -ForegroundColor Yellow
