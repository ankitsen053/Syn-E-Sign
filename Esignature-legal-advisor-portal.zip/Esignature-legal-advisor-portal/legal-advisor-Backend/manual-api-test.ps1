# Manual API Testing Script for Legal Advisor
# This script properly handles authentication and tests all protected endpoints

param(
    [string]$BackendUrl = "http://localhost:8081",
    [string]$FrontendUrl = "http://localhost:5173"
)

$TestResults = @{
    Total = 0
    Passed = 0
    Failed = 0
    Skipped = 0
}

function Write-TestResult {
    param(
        [string]$TestName,
        [string]$Status,
        [string]$Message = ""
    )
    
    $TestResults.Total++
    
    switch ($Status) {
        "PASS" { 
            Write-Host "PASS - $TestName" -ForegroundColor Green
            $TestResults.Passed++
        }
        "FAIL" { 
            Write-Host "FAIL - $TestName" -ForegroundColor Red
            $TestResults.Failed++
        }
        "SKIP" { 
            Write-Host "SKIP - $TestName" -ForegroundColor Yellow
            $TestResults.Skipped++
        }
    }
    
    if ($Message) {
        Write-Host "  $Message" -ForegroundColor Gray
    }
}

function Get-AuthToken {
    param([string]$Username, [string]$Password)
    
    try {
        $loginData = @{
            username = $Username
            password = $Password
        }
        
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/login" -Method POST -Body ($loginData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
        return $response.token
    } catch {
        Write-Host "Failed to get auth token: $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }
}

Write-Host "=== Manual API Testing - Legal Advisor ===" -ForegroundColor Cyan

# Test 1: Backend Health
Write-Host "`n1. Testing Backend Health..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/test/health" -Method GET -TimeoutSec 10
    Write-TestResult "Backend Health Check" "PASS" "Status: $($response.status)"
} catch {
    Write-TestResult "Backend Health Check" "FAIL" $_.Exception.Message
}

# Test 2: Frontend Health
Write-Host "`n2. Testing Frontend Health..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$FrontendUrl" -Method GET -TimeoutSec 10
    Write-TestResult "Frontend Health Check" "PASS" "Status: $($response.StatusCode)"
} catch {
    Write-TestResult "Frontend Health Check" "FAIL" $_.Exception.Message
}

# Test 3: Authentication - Create Test User
Write-Host "`n3. Setting up Authentication..." -ForegroundColor Yellow
$testUser = @{
    username = "manualtest_$(Get-Random)"
    email = "manualtest_$(Get-Random)@example.com"
    password = "TestPassword123!"
    roles = @("user")
}

try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/signup" -Method POST -Body ($testUser | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
    Write-TestResult "User Signup" "PASS" "User created: $($testUser.username)"
} catch {
    Write-TestResult "User Signup" "FAIL" $_.Exception.Message
    $testUser = $null
}

# Test 4: Get Authentication Token
$accessToken = $null
if ($testUser) {
    $accessToken = Get-AuthToken -Username $testUser.username -Password $testUser.password
    if ($accessToken) {
        Write-TestResult "Get Auth Token" "PASS" "Token received successfully"
        Write-Host "  Token: $($accessToken.Substring(0, 20))..." -ForegroundColor Gray
    } else {
        Write-TestResult "Get Auth Token" "FAIL" "Failed to get authentication token"
    }
} else {
    Write-TestResult "Get Auth Token" "SKIP" "Skipped due to signup failure"
}

# Test 5: AI Service APIs (Protected)
Write-Host "`n4. Testing AI Service APIs (Protected)..." -ForegroundColor Yellow
if ($accessToken) {
    $headers = @{ Authorization = "Bearer $accessToken" }
    
    # Test AI Status
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/status" -Method GET -Headers $headers -TimeoutSec 30
        Write-TestResult "AI Service Status" "PASS" "Status: $($response.status)"
    } catch {
        Write-TestResult "AI Service Status" "FAIL" $_.Exception.Message
    }
    
    # Test Document Analysis
    try {
        $analysisData = @{ content = "This is a test legal document for analysis." }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/analyze" -Method POST -Body ($analysisData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 60
        Write-TestResult "Document Analysis" "PASS" "Analysis completed"
    } catch {
        Write-TestResult "Document Analysis" "FAIL" $_.Exception.Message
    }
    
    # Test Agreement Creation
    try {
        $agreementData = @{
            type = "NDA"
            partyA = "Test Company A"
            partyB = "Test Company B"
            terms = "Confidentiality agreement for business partnership"
        }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/create" -Method POST -Body ($agreementData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 120
        Write-TestResult "Agreement Creation" "PASS" "Agreement created"
    } catch {
        Write-TestResult "Agreement Creation" "FAIL" $_.Exception.Message
    }
} else {
    Write-TestResult "AI Service Status" "SKIP" "Skipped - no access token"
    Write-TestResult "Document Analysis" "SKIP" "Skipped - no access token"
    Write-TestResult "Agreement Creation" "SKIP" "Skipped - no access token"
}

# Test 6: Document Management APIs (Protected)
Write-Host "`n5. Testing Document Management APIs (Protected)..." -ForegroundColor Yellow
if ($accessToken) {
    $headers = @{ Authorization = "Bearer $accessToken" }
    
    # Test Document Service Status
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/status" -Method GET -Headers $headers -TimeoutSec 10
        Write-TestResult "Document Service Status" "PASS" "Status: $($response.status)"
    } catch {
        Write-TestResult "Document Service Status" "FAIL" $_.Exception.Message
    }
    
    # Test Save Document
    try {
        $docData = @{
            title = "Manual Test Document"
            content = "This is a manual test document."
            type = "CONTRACT"
            status = "DRAFT"
        }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/save" -Method POST -Body ($docData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 10
        Write-TestResult "Save Document" "PASS" "Document saved with ID: $($response.id)"
        $documentId = $response.id
    } catch {
        Write-TestResult "Save Document" "FAIL" $_.Exception.Message
        $documentId = $null
    }
    
    # Test Get User Documents
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/user" -Method GET -Headers $headers -TimeoutSec 10
        Write-TestResult "Get User Documents" "PASS" "Found $($response.Count) documents"
    } catch {
        Write-TestResult "Get User Documents" "FAIL" $_.Exception.Message
    }
    
    # Test Get Specific Document
    if ($documentId) {
        try {
            $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/$documentId" -Method GET -Headers $headers -TimeoutSec 10
            Write-TestResult "Get Document" "PASS" "Document retrieved: $($response.title)"
        } catch {
            Write-TestResult "Get Document" "FAIL" $_.Exception.Message
        }
        
        # Test Update Document
        try {
            $updateData = @{
                title = "Updated Manual Test Document"
                content = "This is an updated manual test document."
                type = "CONTRACT"
                status = "REVIEW"
            }
            $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/$documentId" -Method PUT -Body ($updateData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 10
            Write-TestResult "Update Document" "PASS" "Document updated successfully"
        } catch {
            Write-TestResult "Update Document" "FAIL" $_.Exception.Message
        }
        
        # Test Delete Document
        try {
            $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/$documentId" -Method DELETE -Headers $headers -TimeoutSec 10
            Write-TestResult "Delete Document" "PASS" "Document deleted successfully"
        } catch {
            Write-TestResult "Delete Document" "FAIL" $_.Exception.Message
        }
    } else {
        Write-TestResult "Get Document" "SKIP" "Skipped - no document ID"
        Write-TestResult "Update Document" "SKIP" "Skipped - no document ID"
        Write-TestResult "Delete Document" "SKIP" "Skipped - no document ID"
    }
} else {
    Write-TestResult "Document Service Status" "SKIP" "Skipped - no access token"
    Write-TestResult "Save Document" "SKIP" "Skipped - no access token"
    Write-TestResult "Get User Documents" "SKIP" "Skipped - no access token"
    Write-TestResult "Get Document" "SKIP" "Skipped - no access token"
    Write-TestResult "Update Document" "SKIP" "Skipped - no access token"
    Write-TestResult "Delete Document" "SKIP" "Skipped - no access token"
}

# Test 7: Profile Management APIs (Protected)
Write-Host "`n6. Testing Profile Management APIs (Protected)..." -ForegroundColor Yellow
if ($accessToken) {
    $headers = @{ Authorization = "Bearer $accessToken" }
    
    # Test Get Profile
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/profile" -Method GET -Headers $headers -TimeoutSec 10
        Write-TestResult "Get Profile" "PASS" "Profile retrieved"
    } catch {
        Write-TestResult "Get Profile" "FAIL" $_.Exception.Message
    }
    
    # Test Update Profile
    try {
        $profileData = @{
            firstName = "Manual"
            lastName = "Test"
            phone = "+1234567890"
            address = "123 Manual Test Street, Test City"
            company = "Manual Test Company"
            position = "Manual Test Position"
        }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/profile" -Method POST -Body ($profileData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 10
        Write-TestResult "Update Profile" "PASS" "Profile updated successfully"
    } catch {
        Write-TestResult "Update Profile" "FAIL" $_.Exception.Message
    }
} else {
    Write-TestResult "Get Profile" "SKIP" "Skipped - no access token"
    Write-TestResult "Update Profile" "SKIP" "Skipped - no access token"
}

# Test 8: Document Scanner APIs (Protected)
Write-Host "`n7. Testing Document Scanner APIs (Protected)..." -ForegroundColor Yellow
if ($accessToken) {
    $headers = @{ Authorization = "Bearer $accessToken" }
    
    # Test Document Scanner Status
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/scanner/status" -Method GET -Headers $headers -TimeoutSec 10
        Write-TestResult "Document Scanner Status" "PASS" "Scanner status: $($response.status)"
    } catch {
        Write-TestResult "Document Scanner Status" "FAIL" $_.Exception.Message
    }
    
    # Test Document Scanning
    try {
        $scanData = @{
            documentType = "CONTRACT"
            content = "This is a manual test document for scanning."
            scanType = "FULL"
        }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/scanner/scan" -Method POST -Body ($scanData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 60
        Write-TestResult "Document Scanning" "PASS" "Document scanned successfully"
    } catch {
        Write-TestResult "Document Scanning" "FAIL" $_.Exception.Message
    }
} else {
    Write-TestResult "Document Scanner Status" "SKIP" "Skipped - no access token"
    Write-TestResult "Document Scanning" "SKIP" "Skipped - no access token"
}

# Test 9: OAuth Endpoints (Fixed URLs)
Write-Host "`n8. Testing OAuth APIs (Fixed URLs)..." -ForegroundColor Yellow

# Test Google OAuth URL (Fixed endpoint)
try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/oauth2/google-login-url" -Method GET -TimeoutSec 10
    Write-TestResult "Google OAuth URL" "PASS" "OAuth URL generated"
} catch {
    Write-TestResult "Google OAuth URL" "FAIL" $_.Exception.Message
}

# Test Gmail OAuth URL (Fixed endpoint)
try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/gmail/login-url" -Method GET -TimeoutSec 10
    Write-TestResult "Gmail OAuth URL" "PASS" "OAuth URL generated"
} catch {
    Write-TestResult "Gmail OAuth URL" "FAIL" $_.Exception.Message
}

# Test Summary
Write-Host "`n=== Test Summary ===" -ForegroundColor Cyan
Write-Host "Total Tests: $($TestResults.Total)" -ForegroundColor White
Write-Host "Passed: $($TestResults.Passed)" -ForegroundColor Green
Write-Host "Failed: $($TestResults.Failed)" -ForegroundColor Red
Write-Host "Skipped: $($TestResults.Skipped)" -ForegroundColor Yellow

$successRate = if ($TestResults.Total -gt 0) { [math]::Round(($TestResults.Passed / $TestResults.Total) * 100, 2) } else { 0 }
Write-Host "Success Rate: $successRate%" -ForegroundColor Cyan

if ($TestResults.Failed -eq 0) {
    Write-Host "`nAll tests passed! Your APIs are working correctly." -ForegroundColor Green
} else {
    Write-Host "`nSome tests failed. Please check the error messages above." -ForegroundColor Red
}

Write-Host "`n=== Manual Testing Instructions ===" -ForegroundColor Cyan
Write-Host "1. Use this script to test all protected endpoints with proper authentication" -ForegroundColor White
Write-Host "2. The script creates a test user and gets an authentication token" -ForegroundColor White
Write-Host "3. All protected endpoints are tested with the valid token" -ForegroundColor White
Write-Host "4. OAuth endpoints are tested with corrected URLs" -ForegroundColor White
