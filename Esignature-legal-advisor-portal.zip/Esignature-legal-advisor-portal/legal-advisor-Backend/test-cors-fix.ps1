# Test CORS Configuration Fix
Write-Host "🔧 Testing CORS Configuration..." -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan

# Wait for backend to start
Write-Host "⏳ Waiting for backend to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 20

# Test 1: Health endpoint (should work)
Write-Host "1️⃣ Testing health endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/test/health" -Method GET
    Write-Host "   ✅ Health endpoint working: $($response.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Health endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: CORS preflight for profile endpoint
Write-Host "2️⃣ Testing CORS preflight for profile endpoint..." -ForegroundColor Yellow
try {
    $headers = @{
        "Origin" = "http://localhost:5173"
        "Access-Control-Request-Method" = "GET"
        "Access-Control-Request-Headers" = "Content-Type,Authorization"
    }
    
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/profile" -Method OPTIONS -Headers $headers
    Write-Host "   ✅ CORS preflight successful: $($response.StatusCode)" -ForegroundColor Green
    
    # Check CORS headers
    if ($response.Headers["Access-Control-Allow-Origin"]) {
        Write-Host "   ✅ Access-Control-Allow-Origin header present" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️ Access-Control-Allow-Origin header missing" -ForegroundColor Yellow
    }
    
    if ($response.Headers["Access-Control-Allow-Methods"]) {
        Write-Host "   ✅ Access-Control-Allow-Methods header present" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️ Access-Control-Allow-Methods header missing" -ForegroundColor Yellow
    }
    
} catch {
    Write-Host "   ❌ CORS preflight failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Test with curl (if available)
Write-Host "3️⃣ Testing with curl..." -ForegroundColor Yellow
try {
    $curlOutput = curl -X OPTIONS -H "Origin: http://localhost:5173" -H "Access-Control-Request-Method: GET" -H "Access-Control-Request-Headers: Content-Type,Authorization" -v http://localhost:8081/api/profile 2>&1
    Write-Host "   ✅ Curl test completed" -ForegroundColor Green
    Write-Host "   📄 Output: $($curlOutput | Select-Object -Last 5)" -ForegroundColor Gray
} catch {
    Write-Host "   ⚠️ Curl not available or test failed" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "🎯 CORS Test Summary:" -ForegroundColor Cyan
Write-Host "   • Backend should be running on http://localhost:8081" -ForegroundColor White
Write-Host "   • Frontend should be running on http://localhost:5173" -ForegroundColor White
Write-Host "   • CORS should now allow cross-origin requests" -ForegroundColor White

Write-Host ""
Write-Host "💡 If CORS is still failing:" -ForegroundColor Cyan
Write-Host "   1. Make sure backend is fully started" -ForegroundColor White
Write-Host "   2. Clear browser cache and reload" -ForegroundColor White
Write-Host "   3. Check browser developer tools for detailed errors" -ForegroundColor White


