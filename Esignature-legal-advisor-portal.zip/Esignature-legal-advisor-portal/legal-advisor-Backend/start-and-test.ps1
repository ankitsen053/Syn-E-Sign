Write-Host "========================================" -ForegroundColor Green
Write-Host "Legal Advisor API - Start & Test Script" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# Check if Java is installed
Write-Host "Checking Java installation..." -ForegroundColor Yellow
try {
    $javaVersion = java -version 2>&1 | Select-String "version"
    Write-Host "✅ Java is installed: $javaVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Java is not installed or not in PATH" -ForegroundColor Red
    exit 1
}

# Check if Maven wrapper exists
Write-Host "Checking Maven wrapper..." -ForegroundColor Yellow
if (Test-Path ".\mvnw.cmd") {
    Write-Host "✅ Maven wrapper found" -ForegroundColor Green
} else {
    Write-Host "❌ Maven wrapper not found" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Starting Spring Boot Application..." -ForegroundColor Yellow
Write-Host "This may take a few minutes..." -ForegroundColor Yellow
Write-Host ""

# Start the application in background
$job = Start-Job -ScriptBlock {
    Set-Location $using:PWD
    .\mvnw.cmd spring-boot:run
}

Write-Host "Application is starting..." -ForegroundColor Cyan
Write-Host "Waiting for application to be ready..." -ForegroundColor Cyan

# Wait for application to start
$maxAttempts = 30
$attempt = 0
$appReady = $false

while ($attempt -lt $maxAttempts -and -not $appReady) {
    Start-Sleep 2
    $attempt++
    
    try {
        $response = Invoke-RestMethod -Uri "http://localhost:8080/api/test/health" -Method Get -TimeoutSec 5
        if ($response.status -eq "UP") {
            $appReady = $true
            Write-Host "✅ Application is running!" -ForegroundColor Green
        }
    } catch {
        Write-Host "Attempt $attempt/$maxAttempts - Application not ready yet..." -ForegroundColor Yellow
    }
}

if (-not $appReady) {
    Write-Host "❌ Application failed to start within expected time" -ForegroundColor Red
    Write-Host "Check the application logs for errors" -ForegroundColor Red
    Stop-Job $job
    Remove-Job $job
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "Application is running on:" -ForegroundColor Green
Write-Host "http://localhost:8080" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# Run basic tests
Write-Host "Running basic API tests..." -ForegroundColor Yellow
Write-Host ""

# Test 1: Health Check
Write-Host "1. Testing Health Check..." -ForegroundColor White
try {
    $health = Invoke-RestMethod -Uri "http://localhost:8080/api/test/health" -Method Get
    Write-Host "   ✅ Health Check: $($health.status)" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Health Check failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: Public Endpoint
Write-Host "2. Testing Public Endpoint..." -ForegroundColor White
try {
    $public = Invoke-RestMethod -Uri "http://localhost:8080/api/test/public" -Method Get
    Write-Host "   ✅ Public Endpoint: $($public.message)" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Public Endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: AI Status
Write-Host "3. Testing AI Service Status..." -ForegroundColor White
try {
    $aiStatus = Invoke-RestMethod -Uri "http://localhost:8080/api/ai/status" -Method Get
    Write-Host "   ✅ AI Service: $($aiStatus.status)" -ForegroundColor Green
} catch {
    Write-Host "   ❌ AI Service failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "Basic tests completed!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "1. Open Thunder Client in VS Code" -ForegroundColor White
Write-Host "2. Import thunder-client-collection.json" -ForegroundColor White
Write-Host "3. Follow the QUICK_START_GUIDE.md for complete testing" -ForegroundColor White
Write-Host "4. Or use the PowerShell commands below for quick testing" -ForegroundColor White
Write-Host ""

Write-Host "Quick Test Commands:" -ForegroundColor Cyan
Write-Host ""

# Registration test
Write-Host "# Register a test user:" -ForegroundColor Gray
Write-Host '$body = @{ username = "testuser"; email = "testuser@example.com"; password = "password123"; roles = @("user"); fullName = "Test User" } | ConvertTo-Json' -ForegroundColor DarkGray
Write-Host 'Invoke-RestMethod -Uri "http://localhost:8080/api/auth/signup" -Method Post -Body $body -ContentType "application/json"' -ForegroundColor DarkGray
Write-Host ""

# Login test
Write-Host "# Login and get token:" -ForegroundColor Gray
Write-Host '$loginBody = @{ username = "testuser"; password = "password123" } | ConvertTo-Json' -ForegroundColor DarkGray
Write-Host '$response = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" -Method Post -Body $loginBody -ContentType "application/json"' -ForegroundColor DarkGray
Write-Host '$token = $response.token' -ForegroundColor DarkGray
Write-Host ""

# Protected endpoint test
Write-Host "# Test protected endpoint:" -ForegroundColor Gray
Write-Host '$headers = @{ Authorization = "Bearer $token" }' -ForegroundColor DarkGray
Write-Host 'Invoke-RestMethod -Uri "http://localhost:8080/api/test/user" -Method Get -Headers $headers' -ForegroundColor DarkGray
Write-Host ""

Write-Host "Press any key to stop the application..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

Write-Host ""
Write-Host "Stopping application..." -ForegroundColor Yellow
Stop-Job $job
Remove-Job $job
Write-Host "Application stopped." -ForegroundColor Green
