# OAuth & Email Verification Setup Guide

## Overview
This guide explains how to set up Google OAuth authentication and email OTP verification for the Legal Advisor application.

## Features Implemented

### 1. Google OAuth Authentication
- **"Continue with Google"** button on login page
- Automatic user creation for new OAuth users
- JWT token generation for OAuth users
- Seamless integration with existing authentication system

### 2. Email OTP Verification
- **OTP generation and email delivery** for new user signups
- **Email verification modal** in frontend
- **OTP resend functionality** with cooldown timer
- **Account activation** after successful verification

## Backend Implementation

### Dependencies Added
The following dependencies are already included in `pom.xml`:
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-oauth2-client</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-mail</artifactId>
</dependency>
```

### Key Components

#### 1. SecurityConfig.java
- Configured OAuth2 client authentication
- Added OAuth2 endpoints to security configuration
- Enabled OAuth2 login with proper redirect handling

#### 2. OAuthController.java
- Handles Google OAuth callback
- Processes OAuth2 authentication tokens
- Redirects to frontend with JWT tokens

#### 3. GoogleOAuthService.java
- Processes Google OAuth user data
- Creates new users from OAuth information
- Links existing accounts with Google IDs
- Generates JWT tokens for OAuth users

#### 4. AuthService.java
- Enhanced with email verification for new signups
- OTP generation and verification
- Account activation after email verification

#### 5. User Entity
- Added `googleId` field for OAuth users
- Enhanced with OAuth-related fields

## Frontend Implementation

### Key Components

#### 1. GoogleLogin.jsx
- "Continue with Google" button
- Redirects to OAuth2 authorization endpoint

#### 2. OAuthCallback.jsx
- Handles OAuth redirect from backend
- Processes JWT tokens and user data
- Provides user feedback during authentication

#### 3. EmailVerification.jsx
- OTP input modal for email verification
- Resend OTP functionality with timer
- Success/error feedback

#### 4. AuthContext.jsx
- Enhanced with `loginWithToken` method
- Handles OAuth authentication tokens
- Manages user session state

## Configuration

### 1. Google OAuth Setup

#### Step 1: Create Google OAuth Credentials
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable Google+ API
4. Go to "Credentials" → "Create Credentials" → "OAuth 2.0 Client IDs"
5. Configure OAuth consent screen
6. Create OAuth 2.0 client ID for "Web application"

#### Step 2: Configure application.properties
```properties
# Google OAuth Configuration
google.oauth.client.id=your-google-client-id
google.oauth.client.secret=your-google-client-secret
google.oauth.redirect.uri=http://localhost:8081/login/oauth2/code/google

# Spring OAuth2 Configuration
spring.security.oauth2.client.registration.google.client-id=${google.oauth.client.id}
spring.security.oauth2.client.registration.google.client-secret=${google.oauth.client.secret}
spring.security.oauth2.client.registration.google.scope=openid,email,profile
spring.security.oauth2.client.registration.google.redirect-uri=${google.oauth.redirect.uri}
spring.security.oauth2.client.registration.google.client-authentication-method=client_secret_post
spring.security.oauth2.client.registration.google.authorization-grant-type=authorization_code
```

### 2. Email Configuration

#### Step 1: Gmail App Password Setup
1. Enable 2-factor authentication on your Gmail account
2. Generate an App Password:
   - Go to Google Account settings
   - Security → 2-Step Verification → App passwords
   - Generate password for "Mail"

#### Step 2: Configure application.properties
```properties
# Email Configuration
spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=your-email@gmail.com
spring.mail.password=your-app-password
spring.mail.properties.mail.smtp.auth=true
spring.mail.properties.mail.smtp.starttls.enable=true
```

## API Endpoints

### OAuth Endpoints
- `GET /oauth2/authorization/google` - Initiate Google OAuth
- `GET /login/oauth2/code/google` - OAuth callback (handled by Spring Security)
- `GET /api/auth/oauth2/status` - OAuth status check
- `GET /api/auth/oauth2/google-login-url` - Get OAuth URL

### Email Verification Endpoints
- `POST /api/auth/signup` - User registration with OTP
- `POST /api/auth/verify-email` - Verify email with OTP
- `POST /api/auth/resend-otp` - Resend OTP
- `GET /api/auth/verification-status/{email}` - Check verification status

## User Flows

### OAuth Authentication Flow
1. User clicks "Continue with Google" on login page
2. Frontend redirects to `/oauth2/authorization/google`
3. User authorizes application on Google
4. Google redirects to `/login/oauth2/code/google`
5. OAuthController processes callback and generates JWT
6. User redirected to frontend with JWT token
7. Frontend stores token and logs user in

### Email Verification Flow
1. User signs up with email and password
2. System generates 6-digit OTP
3. OTP sent to user's email
4. Email verification modal appears
5. User enters OTP
6. System verifies OTP and activates account
7. User can now log in normally

## Testing

### Run the Test Script
```powershell
.\test-oauth-email-verification.ps1
```

### Manual Testing Steps
1. **Test OAuth Flow:**
   - Start application
   - Go to login page
   - Click "Continue with Google"
   - Complete OAuth flow
   - Verify user is logged in

2. **Test Email Verification:**
   - Go to signup page
   - Create new account
   - Check email for OTP
   - Enter OTP in verification modal
   - Verify account is activated

## Security Considerations

### OAuth Security
- OAuth tokens are validated by Google
- JWT tokens are generated for session management
- OAuth users are automatically email verified
- Google ID is stored for account linking

### Email Security
- OTPs are 6-digit numeric codes
- OTPs expire after 10 minutes
- Resend cooldown prevents spam
- Email verification is required for account activation

## Troubleshooting

### Common Issues

#### 1. OAuth Redirect URI Mismatch
**Error:** "redirect_uri_mismatch"
**Solution:** Ensure redirect URI in Google Console matches application.properties

#### 2. Email Not Sending
**Error:** SMTP authentication failed
**Solution:** 
- Verify Gmail app password is correct
- Enable "Less secure app access" or use app password
- Check firewall/network settings

#### 3. OAuth Callback Not Working
**Error:** 404 on callback endpoint
**Solution:** 
- Verify OAuth2 configuration in SecurityConfig
- Check that OAuth endpoints are permitted in security

#### 4. Frontend OAuth Issues
**Error:** CORS errors or redirect issues
**Solution:**
- Verify CORS configuration
- Check frontend URL matches backend configuration
- Ensure OAuth callback route is properly configured

### Debug Steps
1. Check application logs for OAuth errors
2. Verify Google OAuth credentials
3. Test email configuration separately
4. Check network requests in browser dev tools
5. Verify JWT token generation

## Production Deployment

### Environment Variables
Set these environment variables in production:
```bash
GOOGLE_OAUTH_CLIENT_ID=your-production-client-id
GOOGLE_OAUTH_CLIENT_SECRET=your-production-client-secret
SPRING_MAIL_USERNAME=your-production-email
SPRING_MAIL_PASSWORD=your-production-app-password
```

### Security Checklist
- [ ] Use HTTPS in production
- [ ] Configure proper CORS origins
- [ ] Set secure JWT secret
- [ ] Enable email verification
- [ ] Configure proper redirect URIs
- [ ] Set up monitoring and logging

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review application logs
3. Test individual components
4. Verify configuration settings

The system is now fully configured for both Google OAuth authentication and email OTP verification!
