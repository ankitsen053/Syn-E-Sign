# Simple E-Signature Test Script
Write-Host "=== Legal Advisor E-Signature Test ===" -ForegroundColor Cyan

$baseUrl = "http://localhost:8081/api"

# Test user data
$testUser = @{
    username = "testuser"
    email = "test@example.com" 
    password = "Test123!"
    fullName = "Test User"
}

$testAgreement = @{
    type = "Service Agreement"
    partyA = "Test Company Inc."
    partyB = "Client Corporation"
    terms = "Test agreement terms and conditions."
}

Write-Host "Testing backend health..." -ForegroundColor Green
try {
    $health = Invoke-RestMethod -Uri "$baseUrl/test/hello" -Method GET
    Write-Host "Backend is healthy: $($health.message)" -ForegroundColor Green
}
catch {
    Write-Host "Backend health check failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "Testing user login..." -ForegroundColor Green
try {
    $loginData = @{
        username = $testUser.username
        password = $testUser.password
    }
    $loginResponse = Invoke-RestMethod -Uri "$baseUrl/auth/login" -Method POST -Body ($loginData | ConvertTo-Json) -ContentType "application/json"
    $token = $loginResponse.token
    Write-Host "Login successful!" -ForegroundColor Green
    
    $headers = @{ "Authorization" = "Bearer $token" }
}
catch {
    Write-Host "Login failed: $($_.Exception.Message)" -ForegroundColor Red
    # Try to signup first
    Write-Host "Attempting signup..." -ForegroundColor Yellow
    try {
        $signupResponse = Invoke-RestMethod -Uri "$baseUrl/auth/signup" -Method POST -Body ($testUser | ConvertTo-Json) -ContentType "application/json"
        Write-Host "Signup successful, now logging in..." -ForegroundColor Green
        
        $loginResponse = Invoke-RestMethod -Uri "$baseUrl/auth/login" -Method POST -Body ($loginData | ConvertTo-Json) -ContentType "application/json"
        $token = $loginResponse.token
        $headers = @{ "Authorization" = "Bearer $token" }
        Write-Host "Login after signup successful!" -ForegroundColor Green
    }
    catch {
        Write-Host "Signup/Login failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

Write-Host "Testing document generation..." -ForegroundColor Green
try {
    $docResponse = Invoke-RestMethod -Uri "$baseUrl/ai/create" -Method POST -Body ($testAgreement | ConvertTo-Json) -ContentType "application/json" -Headers $headers
    $document = $docResponse.document
    Write-Host "Document generated successfully! Length: $($document.Length)" -ForegroundColor Green
}
catch {
    Write-Host "Document generation failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "Testing agreement signing..." -ForegroundColor Green
try {
    $mockSignature = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
    
    $signRequest = @{
        agreementTitle = "$($testAgreement.type) - $($testAgreement.partyA) and $($testAgreement.partyB)"
        agreementContent = $document
        agreementType = $testAgreement.type
        partyA = $testAgreement.partyA
        partyB = $testAgreement.partyB
        terms = $testAgreement.terms
        signatureImageBase64 = $mockSignature
        signerName = $testUser.fullName
        signerEmail = $testUser.email
    }
    
    $signResponse = Invoke-RestMethod -Uri "$baseUrl/signature/sign" -Method POST -Body ($signRequest | ConvertTo-Json) -ContentType "application/json" -Headers $headers
    $agreementId = $signResponse.agreementId
    Write-Host "Agreement signed successfully! ID: $agreementId" -ForegroundColor Green
}
catch {
    Write-Host "Agreement signing failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "Testing agreement retrieval..." -ForegroundColor Green
try {
    $agreements = Invoke-RestMethod -Uri "$baseUrl/signature/user/agreements" -Method GET -Headers $headers
    Write-Host "Retrieved $($agreements.count) agreements" -ForegroundColor Green
}
catch {
    Write-Host "Agreement retrieval failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "Testing statistics..." -ForegroundColor Green
try {
    $stats = Invoke-RestMethod -Uri "$baseUrl/signature/stats" -Method GET -Headers $headers
    Write-Host "Statistics retrieved successfully" -ForegroundColor Green
    Write-Host "Total Signed: $($stats.totalSigned)" -ForegroundColor Cyan
    Write-Host "User Agreements: $($stats.userAgreements)" -ForegroundColor Cyan
}
catch {
    Write-Host "Statistics retrieval failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "=== ALL TESTS PASSED ===" -ForegroundColor Green
Write-Host "E-signature workflow is working correctly!" -ForegroundColor Green
Write-Host ""
Write-Host "Frontend URL: http://localhost:5173" -ForegroundColor Yellow
Write-Host "Test credentials: username=$($testUser.username), password=$($testUser.password)" -ForegroundColor Yellow
