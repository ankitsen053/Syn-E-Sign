# Test Connection Script for Legal Advisor
Write-Host "Testing Legal Advisor Application..." -ForegroundColor Green

# Test Backend Status
Write-Host "`n1. Testing Backend Status..." -ForegroundColor Yellow
try {
    $backendStatus = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/status" -Method GET
    Write-Host "✅ Backend is running on port 8081" -ForegroundColor Green
    Write-Host "   Status: $($backendStatus.status)" -ForegroundColor Cyan
    Write-Host "   Version: $($backendStatus.version)" -ForegroundColor Cyan
    Write-Host "   Spring AI Available: $($backendStatus.springAiAvailable)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Backend is not responding on port 8081" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test Frontend
Write-Host "`n2. Testing Frontend..." -ForegroundColor Yellow
try {
    $frontendResponse = Invoke-WebRequest -Uri "http://localhost:5173" -Method GET -TimeoutSec 5
    Write-Host "✅ Frontend is running on port 5173" -ForegroundColor Green
    Write-Host "   Status Code: $($frontendResponse.StatusCode)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Frontend is not responding on port 5173" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test Document Analysis
Write-Host "`n3. Testing Document Analysis..." -ForegroundColor Yellow
try {
    $testContent = "This is a test legal document for analysis."
    $analysisResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/analyze" -Method POST -Body $testContent -ContentType "text/plain"
    Write-Host "✅ Document Analysis is working" -ForegroundColor Green
    Write-Host "   Success: $($analysisResponse.success)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Document Analysis failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Testing Complete!" -ForegroundColor Green
Write-Host "Frontend URL: http://localhost:5173" -ForegroundColor Cyan
Write-Host "Backend URL: http://localhost:8081" -ForegroundColor Cyan
