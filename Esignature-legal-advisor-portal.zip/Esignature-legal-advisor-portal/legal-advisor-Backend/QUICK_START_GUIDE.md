# 🚀 Quick Start Guide - Legal Advisor API Testing

## Prerequisites Check ✅

### 1. Java Installation
```powershell
java -version
```
✅ Java 21.0.1 is installed

### 2. Maven Wrapper
```powershell
.\mvnw.cmd -version
```
✅ Maven 3.9.11 is available

## 🏃‍♂️ Step-by-Step Testing Process

### Step 1: Start the Application

**Option A: Using Maven Wrapper (Recommended)**
```powershell
.\mvnw.cmd spring-boot:run
```

**Option B: Using PowerShell Script**
```powershell
.\test-apis.ps1
```

**Option C: Using Batch Script**
```cmd
.\test-apis.bat
```

### Step 2: Verify Application is Running

Wait for the application to start (look for "Started LegalAdvisorApplication" in the console), then test:

```powershell
Invoke-RestMethod -Uri "http://localhost:8080/api/test/health" -Method Get
```

Expected Response:
```json
{
  "status": "UP",
  "service": "Legal Advisor Backend",
  "version": "1.0.0",
  "timestamp": 1234567890,
  "database": "MongoDB Atlas",
  "authentication": "JWT",
  "ai": "Gemini API"
}
```

### Step 3: Set Up Thunder Client

1. **Install Thunder Client Extension** in VS Code
   - Open VS Code
   - Go to Extensions (Ctrl+Shift+X)
   - Search for "Thunder Client"
   - Install the extension

2. **Import the Collection**
   - Open Thunder Client (Ctrl+Shift+P → "Thunder Client: Open")
   - Click "Import" button
   - Select `thunder-client-collection.json` file
   - The collection will be imported with all pre-configured requests

3. **Set Environment Variables**
   - In Thunder Client, click on "Environment" tab
   - Set the following variables:
     - `base_url`: `http://localhost:8080`
     - `jwt_token`: (leave empty for now)
     - `refresh_token`: (leave empty for now)

## 🧪 Testing Sequence

### Phase 1: Basic Connectivity Tests

1. **Health Check**
   - Run: `GET /api/test/health`
   - Expected: 200 OK with service status

2. **Public Test Endpoint**
   - Run: `GET /api/test/public`
   - Expected: 200 OK with public content

3. **AI Service Status**
   - Run: `GET /api/ai/status`
   - Expected: 200 OK with AI service status

### Phase 2: Authentication Tests

1. **User Registration**
   - Run: `POST /api/auth/signup`
   - Body: User registration JSON
   - Expected: 201 Created

2. **User Login**
   - Run: `POST /api/auth/login`
   - Body: Login credentials
   - Expected: 200 OK with JWT token

3. **Save JWT Token**
   - Copy the `token` from login response
   - Set it as `jwt_token` environment variable

### Phase 3: Protected Endpoint Tests

1. **User Test Endpoint**
   - Run: `GET /api/test/user`
   - Headers: `Authorization: Bearer {{jwt_token}}`
   - Expected: 200 OK with user info

2. **Get Profile**
   - Run: `GET /api/profile`
   - Headers: `Authorization: Bearer {{jwt_token}}`
   - Expected: 200 OK with profile data

### Phase 4: Profile Management Tests

1. **Create/Update Profile**
   - Run: `POST /api/profile`
   - Headers: `Authorization: Bearer {{jwt_token}}`
   - Body: Profile data JSON
   - Expected: 200 OK

2. **Verify Profile**
   - Run: `POST /api/profile/verify?method=PAN`
   - Headers: `Authorization: Bearer {{jwt_token}}`
   - Expected: 200 OK

### Phase 5: AI Services Tests

1. **Generate Agreement**
   - Run: `POST /api/ai/generate?type=NDA&partyA=Company%20A&partyB=Company%20B`
   - Headers: `Content-Type: text/plain`
   - Body: Agreement terms
   - Expected: 200 OK with generated document

2. **Analyze Document**
   - Run: `POST /api/ai/analyze`
   - Headers: `Content-Type: text/plain`
   - Body: Document content
   - Expected: 200 OK with analysis

## 🔧 Troubleshooting

### Application Won't Start

**Check MongoDB Connection:**
- Verify MongoDB Atlas connection string in `application.properties`
- Ensure network connectivity
- Check if MongoDB Atlas cluster is accessible

**Check Port Availability:**
```powershell
netstat -ano | findstr :8080
```

**Check Java Version:**
```powershell
java -version
```

### Authentication Issues

**JWT Token Problems:**
- Verify JWT secret key in `application.properties`
- Check token expiration settings
- Ensure proper role assignments

**Database Issues:**
- Check MongoDB connection
- Verify user collection exists
- Check for any database errors in logs

### AI Service Issues

**Gemini API Problems:**
- Check if `GEMINI_API_KEY` environment variable is set
- Verify internet connectivity
- Check API rate limits

## 📋 Complete Test Checklist

### ✅ Basic Tests
- [ ] Application starts successfully
- [ ] Health endpoint responds
- [ ] Public endpoint accessible
- [ ] AI service status check

### ✅ Authentication Tests
- [ ] User registration works
- [ ] User login returns JWT token
- [ ] JWT token is valid
- [ ] Protected endpoints require authentication
- [ ] Token refresh works
- [ ] Logout works

### ✅ Profile Tests
- [ ] Get profile (authenticated)
- [ ] Create/update profile
- [ ] Profile verification (PAN)
- [ ] Profile verification (AADHAAR)
- [ ] Profile verification (ESIGN)

### ✅ AI Service Tests
- [ ] Generate NDA agreement
- [ ] Generate employment contract
- [ ] Generate service agreement
- [ ] Analyze document
- [ ] Error handling for invalid inputs

### ✅ Error Handling Tests
- [ ] Invalid credentials return 401
- [ ] Missing authentication returns 401
- [ ] Invalid JWT token returns 401
- [ ] Missing required fields return 400
- [ ] Invalid request format returns 400

### ✅ Performance Tests
- [ ] Response times are acceptable
- [ ] No timeout issues
- [ ] Database connections stable
- [ ] AI service responses timely

## 🎯 Quick Test Commands

### PowerShell Commands for Quick Testing

```powershell
# Test health endpoint
Invoke-RestMethod -Uri "http://localhost:8080/api/test/health" -Method Get

# Test public endpoint
Invoke-RestMethod -Uri "http://localhost:8080/api/test/public" -Method Get

# Test AI status
Invoke-RestMethod -Uri "http://localhost:8080/api/ai/status" -Method Get

# Register a user
$body = @{
    username = "testuser"
    email = "testuser@example.com"
    password = "password123"
    roles = @("user")
    fullName = "Test User"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8080/api/auth/signup" -Method Post -Body $body -ContentType "application/json"

# Login and get token
$loginBody = @{
    username = "testuser"
    password = "password123"
} | ConvertTo-Json

$response = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" -Method Post -Body $loginBody -ContentType "application/json"
$token = $response.token

# Test protected endpoint
$headers = @{
    Authorization = "Bearer $token"
}

Invoke-RestMethod -Uri "http://localhost:8080/api/test/user" -Method Get -Headers $headers
```

## 📞 Support

If you encounter any issues:

1. **Check Application Logs** - Look for error messages in the console
2. **Verify Configuration** - Check `application.properties` file
3. **Test Individual Components** - Test each service separately
4. **Check Network** - Ensure MongoDB Atlas and Gemini API are accessible

## 🎉 Success Criteria

Your API testing is successful when:

- ✅ All endpoints respond correctly
- ✅ Authentication works properly
- ✅ JWT tokens are generated and validated
- ✅ Profile management functions correctly
- ✅ AI services generate and analyze documents
- ✅ Error handling works as expected
- ✅ Performance is acceptable

---

**Happy Testing! 🚀**

Follow this guide step by step, and you'll have thoroughly tested all APIs in your Legal Advisor application.
