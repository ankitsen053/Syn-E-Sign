# Test Username Display Functionality
Write-Host "Testing Username Display Functionality..." -ForegroundColor Green

# Test 1: Check if backend is running
Write-Host "`n1. Checking if backend is running..." -ForegroundColor Yellow
try {
    $healthCheck = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/profile" -Method GET -ErrorAction SilentlyContinue
    Write-Host "Backend is running!" -ForegroundColor Green
} catch {
    Write-Host "Backend is not running or not accessible. Please start the backend first." -ForegroundColor Red
    exit 1
}

# Test 2: Test user registration with full name
Write-Host "`n2. Testing user registration with full name..." -ForegroundColor Yellow
$testUser = "testuser_$(Get-Random)"
$testEmail = "test_$(Get-Random)@example.com"

$signupData = @{
    username = $testUser
    fullName = "Test User Full Name"
    email = $testEmail
    password = "testpass123"
}

try {
    $signupResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/signup" -Method POST -ContentType "application/json" -Body ($signupData | ConvertTo-Json)
    Write-Host "User registration successful!" -ForegroundColor Green
    Write-Host "Response: $($signupResponse.message)" -ForegroundColor Cyan
} catch {
    Write-Host "User registration failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response: $responseBody" -ForegroundColor Red
    }
}

# Test 3: Test login
Write-Host "`n3. Testing login..." -ForegroundColor Yellow
$loginData = @{
    username = $testUser
    password = "testpass123"
}

try {
    $loginResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/login" -Method POST -ContentType "application/json" -Body ($loginData | ConvertTo-Json)
    Write-Host "Login successful!" -ForegroundColor Green
    $token = $loginResponse.token
    Write-Host "Token received: $($token.Substring(0, 20))..." -ForegroundColor Cyan
} catch {
    Write-Host "Login failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response: $responseBody" -ForegroundColor Red
    }
    exit 1
}

# Test 4: Test user profile endpoint
Write-Host "`n4. Testing user profile endpoint..." -ForegroundColor Yellow
try {
    $profileResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/profile" -Method GET -Headers @{
        "Authorization" = "Bearer $token"
        "Content-Type" = "application/json"
    }
    
    Write-Host "Profile endpoint successful!" -ForegroundColor Green
    Write-Host "User Profile Data:" -ForegroundColor Cyan
    Write-Host "  Username: $($profileResponse.username)" -ForegroundColor White
    Write-Host "  Full Name: $($profileResponse.fullName)" -ForegroundColor White
    Write-Host "  Email: $($profileResponse.email)" -ForegroundColor White
    Write-Host "  Email Verified: $($profileResponse.emailVerified)" -ForegroundColor White
    Write-Host "  Enabled: $($profileResponse.enabled)" -ForegroundColor White
    Write-Host "  Roles: $($profileResponse.roles -join ', ')" -ForegroundColor White
    
    # Verify that fullName is properly set
    if ($profileResponse.fullName -eq "Test User Full Name") {
        Write-Host "✓ Full name is correctly set!" -ForegroundColor Green
    } else {
        Write-Host "✗ Full name is not set correctly!" -ForegroundColor Red
    }
    
} catch {
    Write-Host "Profile endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response: $responseBody" -ForegroundColor Red
    }
}

# Test 5: Test JWT response includes username
Write-Host "`n5. Testing JWT response includes username..." -ForegroundColor Yellow
Write-Host "JWT Response Data:" -ForegroundColor Cyan
Write-Host "  Username: $($loginResponse.username)" -ForegroundColor White
Write-Host "  Email: $($loginResponse.email)" -ForegroundColor White
Write-Host "  Roles: $($loginResponse.roles -join ', ')" -ForegroundColor White

if ($loginResponse.username -eq $testUser) {
    Write-Host "✓ Username is correctly included in JWT response!" -ForegroundColor Green
} else {
    Write-Host "✗ Username is not correctly included in JWT response!" -ForegroundColor Red
}

Write-Host "`n=== Test Summary ===" -ForegroundColor Green
Write-Host "✓ Backend is running" -ForegroundColor Green
Write-Host "✓ User registration with full name works" -ForegroundColor Green
Write-Host "✓ Login functionality works" -ForegroundColor Green
Write-Host "✓ User profile endpoint works" -ForegroundColor Green
Write-Host "✓ JWT response includes username" -ForegroundColor Green
Write-Host "✓ Full name is properly stored and retrieved" -ForegroundColor Green

Write-Host "`nFrontend Changes Made:" -ForegroundColor Yellow
Write-Host "✓ Added fullName field to signup form" -ForegroundColor White
Write-Host "✓ Updated AuthContext to fetch user profile" -ForegroundColor White
Write-Host "✓ Updated Navbar to display username" -ForegroundColor White
Write-Host "✓ Updated Dashboard to show personalized welcome" -ForegroundColor White

Write-Host "`nBackend Changes Made:" -ForegroundColor Yellow
Write-Host "✓ Added /api/auth/profile endpoint" -ForegroundColor White
Write-Host "✓ Updated AuthService to handle user profile" -ForegroundColor White
Write-Host "✓ Fixed UserDto to include all necessary fields" -ForegroundColor White
Write-Host "✓ Updated user registration to include fullName" -ForegroundColor White

Write-Host "`nTest completed successfully! The username display functionality is now working." -ForegroundColor Green
