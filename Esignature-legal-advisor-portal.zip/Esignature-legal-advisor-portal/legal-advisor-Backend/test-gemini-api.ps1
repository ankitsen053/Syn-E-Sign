# Quick Test Script for Gemini API
Write-Host "🚀 Testing Gemini API Integration..." -ForegroundColor Cyan

$BackendUrl = "http://localhost:8081"

# Test 1: Check if backend is running
Write-Host "`n1️⃣ Checking backend status..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/status" -Method GET -TimeoutSec 10
    Write-Host "   ✅ Backend is running" -ForegroundColor Green
    Write-Host "   📊 AI Service Status: $($response.available)" -ForegroundColor Cyan
} catch {
    Write-Host "   ❌ Backend is not running. Please start the application first." -ForegroundColor Red
    exit 1
}

# Test 2: Test document analysis with sample text
Write-Host "`n2️⃣ Testing document analysis..." -ForegroundColor Yellow

$sampleDocument = @"
SERVICE AGREEMENT

This Service Agreement (the "Agreement") is entered into on this date between:

ABC Company, a corporation organized under the laws of Delaware ("Service Provider")
and
XYZ Corporation, a corporation organized under the laws of California ("Client")

1. SERVICES
The Service Provider shall provide consulting services to the Client.

2. PAYMENT
The Client shall pay $10,000 per month for services rendered.

3. TERM
This Agreement shall commence on the date hereof and continue for one year.

4. TERMINATION
Either party may terminate this Agreement with 30 days written notice.
"@

try {
    $testData = @{
        content = $sampleDocument
    }
    
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/analyze" -Method POST -Body ($testData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 30
    
    if ($response.success) {
        Write-Host "   ✅ Document analysis successful!" -ForegroundColor Green
        Write-Host "   📝 Analysis preview:" -ForegroundColor Cyan
        $analysis = $response.analysis
        if ($analysis.Length -gt 200) {
            Write-Host "   $($analysis.Substring(0, 200))..." -ForegroundColor White
        } else {
            Write-Host "   $analysis" -ForegroundColor White
        }
    } else {
        Write-Host "   ❌ Document analysis failed" -ForegroundColor Red
    }
} catch {
    Write-Host "   ❌ Error testing document analysis: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Test agreement generation
Write-Host "`n3️⃣ Testing agreement generation..." -ForegroundColor Yellow

try {
    $agreementData = @{
        type = "Service Agreement"
        partyA = "ABC Company"
        partyB = "XYZ Corporation"
        terms = "Consulting services for software development"
    }
    
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/create" -Method POST -Body ($agreementData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 30
    
    if ($response.success) {
        Write-Host "   ✅ Agreement generation successful!" -ForegroundColor Green
        Write-Host "   📄 Document length: $($response.documentLength) characters" -ForegroundColor Cyan
    } else {
        Write-Host "   ❌ Agreement generation failed" -ForegroundColor Red
    }
} catch {
    Write-Host "   ❌ Error testing agreement generation: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Testing completed!" -ForegroundColor Green
Write-Host "If you see ✅ marks above, your Gemini API is working correctly!" -ForegroundColor Cyan
