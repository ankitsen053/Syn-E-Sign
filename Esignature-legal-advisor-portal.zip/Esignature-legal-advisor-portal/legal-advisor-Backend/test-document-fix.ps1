# Test Document System Fix and Migration
Write-Host "🔧 Testing Document System Fix and Migration" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

# Check if server is running
Write-Host "`n1. Checking server status..." -ForegroundColor Yellow
try {
    $statusResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/status" -Method GET -TimeoutSec 10
    Write-Host "✅ Server is running" -ForegroundColor Green
    Write-Host "   Status: $($statusResponse.status)" -ForegroundColor Gray
    Write-Host "   Version: $($statusResponse.version)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Server is not running. Please start the server first." -ForegroundColor Red
    Write-Host "   Run: .\mvnw.cmd spring-boot:run" -ForegroundColor Yellow
    exit 1
}

# Run document migration to fix existing documents
Write-Host "`n2. Running document migration..." -ForegroundColor Yellow
try {
    $migrationResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/migrate" -Method POST -TimeoutSec 30
    Write-Host "✅ Document migration completed successfully" -ForegroundColor Green
    Write-Host "   Message: $($migrationResponse.message)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Document migration failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test document operations
Write-Host "`n3. Testing document operations..." -ForegroundColor Yellow

# Test getting user documents
Write-Host "   Testing user documents retrieval..." -ForegroundColor Gray
try {
    $userDocsResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/user" -Method GET -TimeoutSec 10
    Write-Host "   ✅ User documents retrieved successfully" -ForegroundColor Green
    Write-Host "   📄 Found $($userDocsResponse.documents.Count) documents" -ForegroundColor Gray
} catch {
    Write-Host "   ❌ Failed to retrieve user documents" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test document save (if we have documents, try to update one)
if ($userDocsResponse -and $userDocsResponse.documents -and $userDocsResponse.documents.Count -gt 0) {
    $firstDoc = $userDocsResponse.documents[0]
    Write-Host "   Testing document update..." -ForegroundColor Gray
    
    $updateData = @{
        title = $firstDoc.title + " (Updated)"
        content = $firstDoc.content
        type = $firstDoc.type
        partyA = $firstDoc.partyA
        partyB = $firstDoc.partyB
        terms = $firstDoc.terms
    }
    
    try {
        $updateResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$($firstDoc.id)" -Method PUT -Body ($updateData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
        Write-Host "   ✅ Document update successful" -ForegroundColor Green
        Write-Host "   📝 Updated document: $($updateResponse.document.title)" -ForegroundColor Gray
    } catch {
        Write-Host "   ❌ Document update failed" -ForegroundColor Red
        Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Test document save with new document
Write-Host "   Testing new document creation..." -ForegroundColor Gray
$newDocData = @{
    title = "Test Document - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    content = "This is a test document to verify the null user reference fix."
    type = "Test Agreement"
    partyA = "Test Company A"
    partyB = "Test Company B"
    terms = "Standard test terms and conditions."
}

try {
    $saveResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/save" -Method POST -Body ($newDocData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
    Write-Host "   ✅ New document created successfully" -ForegroundColor Green
    Write-Host "   📄 Document ID: $($saveResponse.document.id)" -ForegroundColor Gray
} catch {
    Write-Host "   ❌ New document creation failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Document System Fix Test Completed!" -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Green
Write-Host "The null user reference error should now be resolved." -ForegroundColor White
Write-Host "All document operations should work without the getUser().getId() null pointer exception." -ForegroundColor White
