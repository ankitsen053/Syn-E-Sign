# Test Simple Dashboard
Write-Host "=== Simple Dashboard Test ===" -ForegroundColor Green

# Get fresh token
Write-Host "`n1. Getting fresh token..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/login" -Method POST -Headers @{"Content-Type"="application/json"} -Body '{"username":"testuser2","password":"testpass123"}' -UseBasicParsing
    $token = ($response.Content | ConvertFrom-Json).token
    Write-Host "✅ Token received" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed to get token" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test simple metrics endpoint
Write-Host "`n2. Testing simple metrics endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/dashboard/metrics" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Metrics endpoint successful" -ForegroundColor Green
    Write-Host "Response: $($response.Content)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Metrics endpoint failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}

# Test profile endpoint
Write-Host "`n3. Testing profile endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/profile" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
    Write-Host "✅ Profile endpoint successful" -ForegroundColor Green
    Write-Host "Response: $($response.Content)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Profile endpoint failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}

Write-Host "`n=== Test Complete ===" -ForegroundColor Green
