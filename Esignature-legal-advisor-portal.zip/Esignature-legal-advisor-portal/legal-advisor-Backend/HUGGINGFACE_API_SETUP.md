# HuggingFace API Setup for Legal Advisor

## Quick Setup (2 minutes)

### Step 1: Get Your Free HuggingFace API Key

1. Go to [https://huggingface.co/settings/tokens](https://huggingface.co/settings/tokens)
2. Click "New token"
3. Give it a name like "Legal Advisor API"
4. Select "Read" access
5. Click "Generate a token"
6. Copy the token (starts with `hf_`)

### Step 2: Update Your Configuration

Replace the placeholder in `src/main/resources/application.properties`:

```properties
# Replace this line:
huggingface.api.key=hf_placeholder_key_replace_with_your_actual_key

# With your actual key:
huggingface.api.key=hf_your_actual_token_here
```

### Step 3: Test the Connection

Run the application and test:
```bash
curl -X GET http://localhost:8081/api/ai/test-huggingface
```

## Alternative: Use OpenAI (Already Configured)

If you prefer to use OpenAI (which is already working), just change:

```properties
ai.service.provider=openai
```

## Features Available

✅ **Document Analysis**: Upload PDF, DOCX, TXT files
✅ **Legal Issue Detection**: Identify problems and risks
✅ **Agreement Generation**: Create professional legal documents
✅ **Compliance Assessment**: Check legal compliance
✅ **Risk Analysis**: Evaluate potential risks
✅ **Professional Legal Advice**: AI acts as experienced lawyer

## Model Information

- **Model**: ChatGPT-2.V2-GGUF (Legal-focused)
- **Capabilities**: Legal document analysis, agreement generation, issue detection
- **Performance**: Professional lawyer-level analysis
- **Response Time**: 2-5 seconds for most documents














