$testUser = @{
    username = "testuser123"
    email = "test@example.com" 
    password = "password123"
    fullName = "Test User"
}

$json = $testUser | ConvertTo-Json
Write-Host "Testing signup with: $json"

try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/signup" -Method POST -Body $json -ContentType "application/json" -UseBasicParsing
    Write-Host "Success: $($response.StatusCode)"
    Write-Host "Response: $($response.Content)"
} catch {
    Write-Host "Error: $($_.Exception.Message)"
    if ($_.Exception.Response) {
        $reader = [System.IO.StreamReader]::new($_.Exception.Response.GetResponseStream())
        $content = $reader.ReadToEnd()
        Write-Host "Error Content: $content"
    }
}
