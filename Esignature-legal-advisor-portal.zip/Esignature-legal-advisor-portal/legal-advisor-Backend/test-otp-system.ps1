Write-Host "OTP Verification System Test" -ForegroundColor Green
Write-Host "============================" -ForegroundColor Green

$baseUrl = "http://localhost:8080/api"

# Test 1: Check if server is running
Write-Host "`nTest 1: Server Status Check" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8080/api/test/health" -Method "GET"
    Write-Host "SUCCESS: Server is running!" -ForegroundColor Green
    Write-Host "   Status: $($response.status)" -ForegroundColor Cyan
    Write-Host "   Service: $($response.service)" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: Server is not running or not accessible" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "`nPlease start the server with: .\mvnw.cmd spring-boot:run" -ForegroundColor Cyan
    exit
}

# Test 2: Test CORS configuration
Write-Host "`nTest 2: CORS Configuration Test" -ForegroundColor Yellow
try {
    $corsResponse = Invoke-RestMethod -Uri "http://localhost:8080/api/test/public" -Method "GET"
    Write-Host "SUCCESS: CORS is working correctly!" -ForegroundColor Green
    Write-Host "   Message: $($corsResponse.message)" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: CORS configuration issue" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Test email functionality
Write-Host "`nTest 3: Email Functionality Test" -ForegroundColor Yellow
try {
    $emailResponse = Invoke-RestMethod -Uri "http://localhost:8080/api/test/test-email" -Method "GET"
    Write-Host "SUCCESS: Email test: $($emailResponse.message)" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Email test failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "   This indicates an email configuration issue." -ForegroundColor Yellow
    Write-Host "   Run: .\setup-gmail-otp.ps1 to fix email settings" -ForegroundColor Cyan
}

# Test 4: Test user registration
Write-Host "`nTest 4: User Registration Test" -ForegroundColor Yellow
$timestamp = Get-Date -Format "yyyyMMddHHmmss"
$testEmail = "test.user.$timestamp@example.com"
$testUsername = "testuser$timestamp"

$signupData = @{
    username = $testUsername
    email = $testEmail
    password = "TestPassword123!"
    roles = @("user")
} | ConvertTo-Json

try {
    $signupResponse = Invoke-RestMethod -Uri "$baseUrl/auth/signup" -Method "POST" -Body $signupData -ContentType "application/json"
    Write-Host "SUCCESS: Registration successful: $($signupResponse.message)" -ForegroundColor Green
    Write-Host "   Email: $testEmail" -ForegroundColor Cyan
    Write-Host "   Username: $testUsername" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: Registration failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 5: Check verification status
Write-Host "`nTest 5: Verification Status Check" -ForegroundColor Yellow
try {
    $statusResponse = Invoke-RestMethod -Uri "$baseUrl/auth/verification-status/$testEmail" -Method "GET"
    Write-Host "SUCCESS: Status check successful:" -ForegroundColor Green
    Write-Host "   Email: $($statusResponse.email)" -ForegroundColor Cyan
    Write-Host "   Verified: $($statusResponse.verified)" -ForegroundColor Cyan
    Write-Host "   Enabled: $($statusResponse.enabled)" -ForegroundColor Cyan
    Write-Host "   Status: $($statusResponse.status)" -ForegroundColor Cyan
    Write-Host "   Message: $($statusResponse.message)" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: Status check failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 6: Try to login (should fail - email not verified)
Write-Host "`nTest 6: Login Attempt (Should Fail - Email Not Verified)" -ForegroundColor Yellow
$loginData = @{
    username = $testUsername
    password = "TestPassword123!"
} | ConvertTo-Json

try {
    $loginResponse = Invoke-RestMethod -Uri "$baseUrl/auth/login" -Method "POST" -Body $loginData -ContentType "application/json"
    Write-Host "ERROR: Login should have been blocked but succeeded" -ForegroundColor Red
} catch {
    Write-Host "SUCCESS: Login correctly blocked: $($_.Exception.Message)" -ForegroundColor Green
}

# Test 7: Resend OTP
Write-Host "`nTest 7: Resend OTP Test" -ForegroundColor Yellow
$resendData = @{
    email = $testEmail
} | ConvertTo-Json

try {
    $resendResponse = Invoke-RestMethod -Uri "$baseUrl/auth/resend-otp" -Method "POST" -Body $resendData -ContentType "application/json"
    Write-Host "SUCCESS: OTP resent: $($resendResponse.message)" -ForegroundColor Green
} catch {
    Write-Host "ERROR: OTP resend failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`nTest Summary:" -ForegroundColor Green
Write-Host "=============" -ForegroundColor Green
Write-Host "SUCCESS: Server Status: Running" -ForegroundColor Green
Write-Host "SUCCESS: CORS Configuration: Working" -ForegroundColor Green
Write-Host "SUCCESS: Email Test: Completed" -ForegroundColor Green
Write-Host "SUCCESS: Registration Test: Completed" -ForegroundColor Green
Write-Host "SUCCESS: Status Check: Working" -ForegroundColor Green
Write-Host "SUCCESS: Login Blocking: Working" -ForegroundColor Green
Write-Host "SUCCESS: OTP Resend: Working" -ForegroundColor Green

Write-Host "`nNext Steps:" -ForegroundColor Yellow
Write-Host "1. Check your email ($testEmail) for OTP code" -ForegroundColor Cyan
Write-Host "2. If no email received, run: .\setup-gmail-otp.ps1" -ForegroundColor Cyan
Write-Host "3. Verify email with OTP code" -ForegroundColor Cyan
Write-Host "4. Test login after verification" -ForegroundColor Cyan

Write-Host "`nManual Verification Command:" -ForegroundColor Yellow
Write-Host "curl -X POST http://localhost:8080/api/auth/verify-email -H 'Content-Type: application/json' -d '{\"email\": \"$testEmail\", \"otp\": \"YOUR_OTP_CODE\"}'" -ForegroundColor Cyan

Write-Host "`nSUCCESS: OTP Verification System is working!" -ForegroundColor Green
