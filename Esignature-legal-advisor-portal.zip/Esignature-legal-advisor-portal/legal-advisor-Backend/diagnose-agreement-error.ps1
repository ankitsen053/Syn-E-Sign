# Diagnose Agreement Creation Error Script
Write-Host "=== Diagnosing Agreement Creation Error ===" -ForegroundColor Cyan

$baseUrl = "http://localhost:8081/api"

# Test user credentials
$testUser = @{
    username = "testuser"
    email = "test@example.com"
    password = "Test123!"
}

# Function to make HTTP requests safely
function Invoke-SafeRequest {
    param(
        [string]$Uri,
        [string]$Method = "GET",
        [hashtable]$Headers = @{},
        [object]$Body = $null
    )
    
    try {
        $params = @{
            Uri = $Uri
            Method = $Method
            Headers = $Headers
            ContentType = "application/json"
            UseBasicParsing = $true
        }
        
        if ($Body) {
            $params.Body = $Body | ConvertTo-Json -Depth 10
        }
        
        $response = Invoke-RestMethod @params
        return @{ Success = $true; Data = $response }
    }
    catch {
        $errorMessage = $_.Exception.Message
        if ($_.Exception.Response) {
            $errorStream = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($errorStream)
            $errorBody = $reader.ReadToEnd()
            $errorMessage += " - Response: $errorBody"
        }
        return @{ Success = $false; Error = $errorMessage }
    }
}

# Step 1: Check if backend is running
Write-Host "`n1. Testing Backend Connection..." -ForegroundColor Green
$healthTest = Invoke-SafeRequest -Uri "$baseUrl/test/hello"
if ($healthTest.Success) {
    Write-Host "✓ Backend is running: $($healthTest.Data.message)" -ForegroundColor Green
} else {
    Write-Host "✗ Backend is not responding: $($healthTest.Error)" -ForegroundColor Red
    Write-Host "Please start the backend with: mvn spring-boot:run" -ForegroundColor Yellow
    exit 1
}

# Step 2: Get authentication token
Write-Host "`n2. Getting Authentication Token..." -ForegroundColor Green
$loginData = @{
    username = $testUser.username
    password = $testUser.password
}

$loginTest = Invoke-SafeRequest -Uri "$baseUrl/auth/login" -Method POST -Body $loginData
if ($loginTest.Success) {
    $token = $loginTest.Data.token
    $headers = @{ "Authorization" = "Bearer $token" }
    Write-Host "✓ Successfully authenticated" -ForegroundColor Green
} else {
    Write-Host "! Login failed, attempting signup..." -ForegroundColor Yellow
    $signupTest = Invoke-SafeRequest -Uri "$baseUrl/auth/signup" -Method POST -Body $testUser
    if ($signupTest.Success) {
        Write-Host "✓ User registered successfully" -ForegroundColor Green
        $loginTest = Invoke-SafeRequest -Uri "$baseUrl/auth/login" -Method POST -Body $loginData
        if ($loginTest.Success) {
            $token = $loginTest.Data.token
            $headers = @{ "Authorization" = "Bearer $token" }
            Write-Host "✓ Successfully authenticated after signup" -ForegroundColor Green
        } else {
            Write-Host "✗ Authentication failed completely: $($loginTest.Error)" -ForegroundColor Red
            exit 1
        }
    } else {
        Write-Host "✗ Signup and login failed: $($signupTest.Error)" -ForegroundColor Red
        exit 1
    }
}

# Step 3: Check AI Service Status
Write-Host "`n3. Checking AI Service Status..." -ForegroundColor Green
$statusTest = Invoke-SafeRequest -Uri "$baseUrl/ai/status" -Headers $headers
if ($statusTest.Success) {
    $status = $statusTest.Data
    Write-Host "✓ AI Service Status Retrieved" -ForegroundColor Green
    Write-Host "  Provider: $($status.primaryProvider)" -ForegroundColor Cyan
    Write-Host "  Fallback Enabled: $($status.fallbackEnabled)" -ForegroundColor Cyan
    
    if ($status.openai) {
        $openaiStatus = $status.openai
        if ($openaiStatus.success) {
            Write-Host "  ✓ OpenAI: Connected ($($openaiStatus.model))" -ForegroundColor Green
        } else {
            Write-Host "  ✗ OpenAI: $($openaiStatus.message)" -ForegroundColor Red
            Write-Host "    This is likely the cause of agreement creation failure!" -ForegroundColor Yellow
        }
    } else {
        Write-Host "  ✗ OpenAI status not available" -ForegroundColor Red
    }
} else {
    Write-Host "✗ AI Service Status Failed: $($statusTest.Error)" -ForegroundColor Red
    Write-Host "  This indicates a backend configuration issue" -ForegroundColor Yellow
}

# Step 4: Test Agreement Creation
Write-Host "`n4. Testing Agreement Creation..." -ForegroundColor Green
$agreementData = @{
    type = "Test Agreement"
    partyA = "Test Company A"
    partyB = "Test Company B"
    terms = "This is a test agreement for diagnostic purposes"
}

$createTest = Invoke-SafeRequest -Uri "$baseUrl/ai/create" -Method POST -Body $agreementData -Headers $headers
if ($createTest.Success) {
    Write-Host "✓ Agreement Creation SUCCESS!" -ForegroundColor Green
    Write-Host "  Document Length: $($createTest.Data.documentLength) characters" -ForegroundColor Cyan
    Write-Host "  Processing Time: $($createTest.Data.processingTime) ms" -ForegroundColor Cyan
} else {
    Write-Host "✗ Agreement Creation FAILED: $($createTest.Error)" -ForegroundColor Red
    Write-Host "`nDEBUG INFORMATION:" -ForegroundColor Yellow
    Write-Host $createTest.Error -ForegroundColor Gray
}

# Step 5: Provide Diagnostic Summary
Write-Host "`n=== DIAGNOSTIC SUMMARY ===" -ForegroundColor Cyan

if ($statusTest.Success -and $statusTest.Data.openai.success) {
    Write-Host "✓ Backend: Running" -ForegroundColor Green
    Write-Host "✓ Authentication: Working" -ForegroundColor Green
    Write-Host "✓ OpenAI: Connected" -ForegroundColor Green
    if ($createTest.Success) {
        Write-Host "✓ Agreement Creation: Working" -ForegroundColor Green
        Write-Host "`n🎉 NO ISSUES FOUND - Agreement creation should work!" -ForegroundColor Green
    } else {
        Write-Host "✗ Agreement Creation: Failed" -ForegroundColor Red
        Write-Host "`n🔧 ISSUE: Agreement creation endpoint has an error" -ForegroundColor Yellow
    }
} else {
    Write-Host "✓ Backend: Running" -ForegroundColor Green
    Write-Host "✓ Authentication: Working" -ForegroundColor Green
    Write-Host "✗ OpenAI: Not configured properly" -ForegroundColor Red
    Write-Host "`n🔧 MAIN ISSUE: OpenAI API configuration" -ForegroundColor Yellow
    Write-Host "`nSOLUTIONS:" -ForegroundColor Cyan
    Write-Host "1. Check your OpenAI API key in application.properties" -ForegroundColor White
    Write-Host "2. Verify the API key has sufficient credits" -ForegroundColor White
    Write-Host "3. Check network connectivity to OpenAI servers" -ForegroundColor White
    Write-Host "4. Restart the backend after fixing configuration" -ForegroundColor White
}

Write-Host "`nFor more details, check the backend logs when starting with: mvn spring-boot:run" -ForegroundColor Gray
