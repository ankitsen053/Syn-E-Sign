# Simple Document Delete Test
Write-Host "Simple Document Delete Test" -ForegroundColor Cyan

# Test 1: Check if server is running
Write-Host "1. Testing server status..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/status" -Method GET
    Write-Host "   Server is running: $($response.status)" -ForegroundColor Green
} catch {
    Write-Host "   Server error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test 2: Try to get documents
Write-Host "2. Testing get documents..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/user" -Method GET
    Write-Host "   Documents found: $($response.count)" -ForegroundColor Green
    if ($response.documents.Count -gt 0) {
        $docId = $response.documents[0].id
        Write-Host "   First document ID: $docId" -ForegroundColor Gray
        
        # Test 3: Try to delete the document
        Write-Host "3. Testing delete document..." -ForegroundColor Yellow
        try {
            $deleteResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$docId" -Method DELETE
            Write-Host "   Delete successful: $($deleteResponse.success)" -ForegroundColor Green
        } catch {
            Write-Host "   Delete failed: $($_.Exception.Message)" -ForegroundColor Red
            if ($_.Exception.Response) {
                $stream = $_.Exception.Response.GetResponseStream()
                $reader = New-Object System.IO.StreamReader($stream)
                $errorBody = $reader.ReadToEnd()
                Write-Host "   Error details: $errorBody" -ForegroundColor Red
            }
        }
    }
} catch {
    Write-Host "   Get documents failed: $($_.Exception.Message)" -ForegroundColor Red
}
