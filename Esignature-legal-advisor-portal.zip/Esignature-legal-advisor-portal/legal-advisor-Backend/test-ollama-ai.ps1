# Test Ollama AI Integration for Document Generation and Analysis
Write-Host "🤖 Testing Ollama AI Integration..." -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan

# Wait for backend to start
Write-Host "⏳ Waiting for backend to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 15

# Test 1: Check if backend is running
Write-Host "1️⃣ Checking backend status..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/test/health" -Method GET
    Write-Host "   ✅ Backend is running: $($response.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Backend is not running: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "   💡 Please start the backend first: .\mvnw.cmd spring-boot:run" -ForegroundColor Cyan
    exit 1
}

# Test 2: Check Spring AI status
Write-Host "2️⃣ Checking Spring AI status..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/ai/status" -Method GET
    $aiStatus = $response.Content | ConvertFrom-Json
    if ($aiStatus.springAiAvailable) {
        Write-Host "   ✅ Spring AI is available and working" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️ Spring AI is not available" -ForegroundColor Yellow
    }
} catch {
    Write-Host "   ❌ Could not check Spring AI status: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Test document generation
Write-Host "3️⃣ Testing document generation..." -ForegroundColor Yellow
try {
    $generateData = @{
        type = "Service Agreement"
        partyA = "TechCorp Inc."
        partyB = "Consultant Services Ltd."
        terms = "The consultant will provide software development services for 6 months with monthly payments of $5000."
    } | ConvertTo-Json

    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/ai/generate" -Method POST -ContentType "application/json" -Body $generateData
    $result = $response.Content | ConvertFrom-Json
    
    if ($result.success) {
        Write-Host "   ✅ Document generation successful" -ForegroundColor Green
        Write-Host "   📄 Generated document length: $($result.agreement.Length) characters" -ForegroundColor Gray
    } else {
        Write-Host "   ❌ Document generation failed: $($result.message)" -ForegroundColor Red
    }
} catch {
    Write-Host "   ❌ Document generation test failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: Test document analysis
Write-Host "4️⃣ Testing document analysis..." -ForegroundColor Yellow
try {
    $testDocument = @"
SERVICE AGREEMENT

This agreement is made between TechCorp Inc. (hereinafter "Client") and Consultant Services Ltd. (hereinafter "Consultant").

1. SERVICES: The Consultant will provide software development services.
2. PAYMENT: Client will pay $5000 per month.
3. TERM: This agreement is for 6 months.
4. CONFIDENTIALITY: Both parties agree to maintain confidentiality.

This agreement is governed by the laws of the State of California.
"@

    $analyzeData = @{
        content = $testDocument
    } | ConvertTo-Json

    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/ai/analyze" -Method POST -ContentType "application/json" -Body $analyzeData
    $result = $response.Content | ConvertFrom-Json
    
    if ($result.success) {
        Write-Host "   ✅ Document analysis successful" -ForegroundColor Green
        Write-Host "   📊 Analysis length: $($result.analysis.Length) characters" -ForegroundColor Gray
        Write-Host "   🔍 Analysis preview: $($result.analysis.Substring(0, [Math]::Min(200, $result.analysis.Length)))..." -ForegroundColor Gray
    } else {
        Write-Host "   ❌ Document analysis failed: $($result.message)" -ForegroundColor Red
    }
} catch {
    Write-Host "   ❌ Document analysis test failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 5: Test risk analysis
Write-Host "5️⃣ Testing risk analysis..." -ForegroundColor Yellow
try {
    $riskData = @{
        content = $testDocument
    } | ConvertTo-Json

    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/ai/risk-analysis" -Method POST -ContentType "application/json" -Body $riskData
    $result = $response.Content | ConvertFrom-Json
    
    if ($result.success) {
        Write-Host "   ✅ Risk analysis successful" -ForegroundColor Green
        Write-Host "   ⚠️ Risk analysis length: $($result.riskAnalysis.Length) characters" -ForegroundColor Gray
    } else {
        Write-Host "   ❌ Risk analysis failed: $($result.message)" -ForegroundColor Red
    }
} catch {
    Write-Host "   ❌ Risk analysis test failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 6: Test compliance assessment
Write-Host "6️⃣ Testing compliance assessment..." -ForegroundColor Yellow
try {
    $complianceData = @{
        content = $testDocument
        jurisdiction = "California"
    } | ConvertTo-Json

    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/ai/compliance" -Method POST -ContentType "application/json" -Body $complianceData
    $result = $response.Content | ConvertFrom-Json
    
    if ($result.success) {
        Write-Host "   ✅ Compliance assessment successful" -ForegroundColor Green
        Write-Host "   📋 Compliance assessment length: $($result.complianceAssessment.Length) characters" -ForegroundColor Gray
    } else {
        Write-Host "   ❌ Compliance assessment failed: $($result.message)" -ForegroundColor Red
    }
} catch {
    Write-Host "   ❌ Compliance assessment test failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "🎯 Ollama AI Integration Test Summary:" -ForegroundColor Cyan
Write-Host "   • Backend: Running on http://localhost:8081" -ForegroundColor White
Write-Host "   • Ollama: Running on http://localhost:11434" -ForegroundColor White
Write-Host "   • Model: llama3.1:latest" -ForegroundColor White
Write-Host "   • Document Generation: Ready" -ForegroundColor White
Write-Host "   • Document Analysis: Ready" -ForegroundColor White
Write-Host "   • Risk Analysis: Ready" -ForegroundColor White
Write-Host "   • Compliance Assessment: Ready" -ForegroundColor White

Write-Host ""
Write-Host "🚀 Next Steps:" -ForegroundColor Cyan
Write-Host "   1. Start frontend: cd legal-advisor-frontend; npm run dev" -ForegroundColor White
Write-Host "   2. Access: http://localhost:5173" -ForegroundColor White
Write-Host "   3. Test document generation and analysis features" -ForegroundColor White

Write-Host ""
Write-Host "Tips:" -ForegroundColor Cyan
Write-Host "   - Keep Ollama running: ollama serve" -ForegroundColor White
Write-Host "   - Monitor Ollama logs for performance" -ForegroundColor White
Write-Host "   - Use different models: ollama pull model-name" -ForegroundColor White

Write-Host ""
Write-Host "Ollama AI Integration Ready!" -ForegroundColor Green
