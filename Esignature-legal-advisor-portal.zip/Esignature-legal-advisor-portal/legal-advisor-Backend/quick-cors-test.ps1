Write-Host "Quick CORS Test for Frontend" -ForegroundColor Green
Write-Host "============================" -ForegroundColor Green

# Test 1: Simple health check
Write-Host "`nTest 1: Health Check" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8080/api/test/health" -Method "GET"
    Write-Host "SUCCESS: Backend is running!" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Backend not accessible" -ForegroundColor Red
    exit
}

# Test 2: CORS preflight for signup
Write-Host "`nTest 2: CORS Preflight Test" -ForegroundColor Yellow
try {
    $headers = @{
        'Origin' = 'http://localhost:5174'
        'Access-Control-Request-Method' = 'POST'
        'Access-Control-Request-Headers' = 'Content-Type'
    }
    
    $response = Invoke-WebRequest -Uri "http://localhost:8080/api/auth/signup" -Method "OPTIONS" -Headers $headers
    Write-Host "SUCCESS: CORS preflight works!" -ForegroundColor Green
    Write-Host "   Status: $($response.StatusCode)" -ForegroundColor Cyan
    Write-Host "   CORS Origin: $($response.Headers['Access-Control-Allow-Origin'])" -ForegroundColor Cyan
} catch {
    Write-Host "ERROR: CORS preflight failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`nFrontend Integration Status:" -ForegroundColor Yellow
Write-Host "============================" -ForegroundColor Yellow
Write-Host "✅ Backend: http://localhost:8080 - RUNNING" -ForegroundColor Green
Write-Host "✅ CORS: Preflight requests working" -ForegroundColor Green
Write-Host "✅ Frontend: http://localhost:5174 - READY TO TEST" -ForegroundColor Green

Write-Host "`nNext Steps:" -ForegroundColor Yellow
Write-Host "1. Go to your frontend: http://localhost:5174" -ForegroundColor Cyan
Write-Host "2. Try to sign up with a new account" -ForegroundColor Cyan
Write-Host "3. The CORS error should be resolved now" -ForegroundColor Cyan

Write-Host "`nIf you still get CORS errors:" -ForegroundColor Yellow
Write-Host "1. Clear browser cache (Ctrl+Shift+R)" -ForegroundColor Cyan
Write-Host "2. Try in incognito/private mode" -ForegroundColor Cyan
Write-Host "3. Check browser console for specific errors" -ForegroundColor Cyan

Write-Host "`nSUCCESS: CORS should be working now!" -ForegroundColor Green
