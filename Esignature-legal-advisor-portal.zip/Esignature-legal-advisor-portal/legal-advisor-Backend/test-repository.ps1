# Test Repository Operations
Write-Host "Testing Repository Operations" -ForegroundColor Cyan

# Test 1: Check if server is running
Write-Host "1. Testing server status..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/status" -Method GET
    Write-Host "   Server is running: $($response.status)" -ForegroundColor Green
} catch {
    Write-Host "   Server error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test 2: Try to get documents (this works)
Write-Host "2. Testing get documents..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/user" -Method GET
    Write-Host "   Documents found: $($response.count)" -ForegroundColor Green
    if ($response.documents.Count -gt 0) {
        $docId = $response.documents[0].id
        Write-Host "   First document ID: $docId" -ForegroundColor Gray
        
        # Test 3: Try to get a specific document (this should work)
        Write-Host "3. Testing get specific document..." -ForegroundColor Yellow
        try {
            $getResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$docId" -Method GET
            Write-Host "   Get document successful: $($getResponse.success)" -ForegroundColor Green
        } catch {
            Write-Host "   Get document failed: $($_.Exception.Message)" -ForegroundColor Red
        }
        
        # Test 4: Try to delete the document
        Write-Host "4. Testing delete document..." -ForegroundColor Yellow
        try {
            $deleteResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$docId" -Method DELETE
            Write-Host "   Delete successful: $($deleteResponse.success)" -ForegroundColor Green
        } catch {
            Write-Host "   Delete failed: $($_.Exception.Message)" -ForegroundColor Red
            if ($_.Exception.Response) {
                $stream = $_.Exception.Response.GetResponseStream()
                $reader = New-Object System.IO.StreamReader($stream)
                $errorBody = $reader.ReadToEnd()
                Write-Host "   Error details: $errorBody" -ForegroundColor Red
            }
        }
    }
} catch {
    Write-Host "   Get documents failed: $($_.Exception.Message)" -ForegroundColor Red
}
