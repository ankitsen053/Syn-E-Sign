# Simple API Test Script for Legal Advisor
param(
    [string]$BackendUrl = "http://localhost:8081",
    [string]$FrontendUrl = "http://localhost:5173"
)

$TestResults = @{
    Total = 0
    Passed = 0
    Failed = 0
    Skipped = 0
}

function Write-TestResult {
    param(
        [string]$TestName,
        [string]$Status,
        [string]$Message = ""
    )
    
    $TestResults.Total++
    
    switch ($Status) {
        "PASS" { 
            Write-Host "PASS - $TestName" -ForegroundColor Green
            $TestResults.Passed++
        }
        "FAIL" { 
            Write-Host "FAIL - $TestName" -ForegroundColor Red
            $TestResults.Failed++
        }
        "SKIP" { 
            Write-Host "SKIP - $TestName" -ForegroundColor Yellow
            $TestResults.Skipped++
        }
    }
    
    if ($Message) {
        Write-Host "  $Message" -ForegroundColor Gray
    }
}

Write-Host "=== API Testing - Legal Advisor ===" -ForegroundColor Cyan

# Test 1: Backend Health
Write-Host "`n1. Testing Backend Health..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/test/health" -Method GET -TimeoutSec 10
    Write-TestResult "Backend Health Check" "PASS" "Status: $($response.status)"
} catch {
    Write-TestResult "Backend Health Check" "FAIL" $_.Exception.Message
}

# Test 2: Frontend Health
Write-Host "`n2. Testing Frontend Health..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$FrontendUrl" -Method GET -TimeoutSec 10
    Write-TestResult "Frontend Health Check" "PASS" "Status: $($response.StatusCode)"
} catch {
    Write-TestResult "Frontend Health Check" "FAIL" $_.Exception.Message
}

# Test 3: Authentication - Signup
Write-Host "`n3. Testing Authentication APIs..." -ForegroundColor Yellow
$testUser = @{
    username = "testuser_$(Get-Random)"
    email = "test_$(Get-Random)@example.com"
    password = "TestPassword123!"
    roles = @("user")
}

try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/signup" -Method POST -Body ($testUser | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
    Write-TestResult "User Signup" "PASS" "User created: $($testUser.username)"
} catch {
    Write-TestResult "User Signup" "FAIL" $_.Exception.Message
    $testUser = $null
}

# Test 4: Authentication - Login
if ($testUser) {
    try {
        $loginData = @{
            username = $testUser.username
            password = $testUser.password
        }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/login" -Method POST -Body ($loginData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 10
        Write-TestResult "User Login" "PASS" "Token received"
        $accessToken = $response.accessToken
        $refreshToken = $response.refreshToken
    } catch {
        Write-TestResult "User Login" "FAIL" $_.Exception.Message
        $accessToken = $null
    }
} else {
    Write-TestResult "User Login" "SKIP" "Skipped due to signup failure"
}

# Test 5: AI Service Status
Write-Host "`n4. Testing AI Service APIs..." -ForegroundColor Yellow
if ($accessToken) {
    $headers = @{ Authorization = "Bearer $accessToken" }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/status" -Method GET -Headers $headers -TimeoutSec 30
        Write-TestResult "AI Service Status" "PASS" "Status: $($response.status)"
    } catch {
        Write-TestResult "AI Service Status" "FAIL" $_.Exception.Message
    }
    
    # Test AI Document Analysis
    try {
        $analysisData = @{ content = "Test legal document for analysis." }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/analyze" -Method POST -Body ($analysisData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 60
        Write-TestResult "Document Analysis" "PASS" "Analysis completed"
    } catch {
        Write-TestResult "Document Analysis" "FAIL" $_.Exception.Message
    }
} else {
    Write-TestResult "AI Service Status" "SKIP" "Skipped - no access token"
    Write-TestResult "Document Analysis" "SKIP" "Skipped - no access token"
}

# Test 6: Document Management
Write-Host "`n5. Testing Document Management APIs..." -ForegroundColor Yellow
if ($accessToken) {
    $headers = @{ Authorization = "Bearer $accessToken" }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/status" -Method GET -Headers $headers -TimeoutSec 10
        Write-TestResult "Document Service Status" "PASS" "Status: $($response.status)"
    } catch {
        Write-TestResult "Document Service Status" "FAIL" $_.Exception.Message
    }
    
    try {
        $docData = @{
            title = "Test Document"
            content = "This is a test document."
            type = "CONTRACT"
            status = "DRAFT"
        }
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/documents/save" -Method POST -Body ($docData | ConvertTo-Json) -Headers $headers -ContentType "application/json" -TimeoutSec 10
        Write-TestResult "Save Document" "PASS" "Document saved with ID: $($response.id)"
    } catch {
        Write-TestResult "Save Document" "FAIL" $_.Exception.Message
    }
} else {
    Write-TestResult "Document Service Status" "SKIP" "Skipped - no access token"
    Write-TestResult "Save Document" "SKIP" "Skipped - no access token"
}

# Test 7: Profile Management
Write-Host "`n6. Testing Profile Management APIs..." -ForegroundColor Yellow
if ($accessToken) {
    $headers = @{ Authorization = "Bearer $accessToken" }
    
    try {
        $response = Invoke-RestMethod -Uri "$BackendUrl/api/profile" -Method GET -Headers $headers -TimeoutSec 10
        Write-TestResult "Get Profile" "PASS" "Profile retrieved"
    } catch {
        Write-TestResult "Get Profile" "FAIL" $_.Exception.Message
    }
} else {
    Write-TestResult "Get Profile" "SKIP" "Skipped - no access token"
}

# Test 8: OAuth Endpoints
Write-Host "`n7. Testing OAuth APIs..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/auth/google/url" -Method GET -TimeoutSec 10
    Write-TestResult "Google OAuth URL" "PASS" "OAuth URL generated"
} catch {
    Write-TestResult "Google OAuth URL" "FAIL" $_.Exception.Message
}

try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/gmail/oauth/url" -Method GET -TimeoutSec 10
    Write-TestResult "Gmail OAuth URL" "PASS" "OAuth URL generated"
} catch {
    Write-TestResult "Gmail OAuth URL" "FAIL" $_.Exception.Message
}

# Test Summary
Write-Host "`n=== Test Summary ===" -ForegroundColor Cyan
Write-Host "Total Tests: $($TestResults.Total)" -ForegroundColor White
Write-Host "Passed: $($TestResults.Passed)" -ForegroundColor Green
Write-Host "Failed: $($TestResults.Failed)" -ForegroundColor Red
Write-Host "Skipped: $($TestResults.Skipped)" -ForegroundColor Yellow

$successRate = if ($TestResults.Total -gt 0) { [math]::Round(($TestResults.Passed / $TestResults.Total) * 100, 2) } else { 0 }
Write-Host "Success Rate: $successRate%" -ForegroundColor Cyan

if ($TestResults.Failed -eq 0) {
    Write-Host "`nAll tests passed! Your APIs are working correctly." -ForegroundColor Green
} else {
    Write-Host "`nSome tests failed. Please check the error messages above." -ForegroundColor Red
}
