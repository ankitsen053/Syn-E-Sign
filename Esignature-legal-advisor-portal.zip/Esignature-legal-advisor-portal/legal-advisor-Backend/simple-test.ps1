Write-Host "Testing Gemini API..." -ForegroundColor Green

$BackendUrl = "http://localhost:8081"

# Test 1: Check backend status
Write-Host "Checking backend status..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/status" -Method GET -TimeoutSec 10
    Write-Host "Backend is running. AI Service: $($response.available)" -ForegroundColor Green
} catch {
    Write-Host "Backend is not running. Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test 2: Test document analysis
Write-Host "Testing document analysis..." -ForegroundColor Yellow
try {
    $testData = @{
        content = "This is a test legal document for analysis."
    }
    
    $response = Invoke-RestMethod -Uri "$BackendUrl/api/ai/analyze" -Method POST -Body ($testData | ConvertTo-Json) -ContentType "application/json" -TimeoutSec 30
    
    if ($response.success) {
        Write-Host "Document analysis successful!" -ForegroundColor Green
        Write-Host "Analysis preview: $($response.analysis.Substring(0, [Math]::Min(100, $response.analysis.Length)))..." -ForegroundColor Cyan
    } else {
        Write-Host "Document analysis failed" -ForegroundColor Red
    }
} catch {
    Write-Host "Error testing document analysis: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "Test completed!" -ForegroundColor Green
