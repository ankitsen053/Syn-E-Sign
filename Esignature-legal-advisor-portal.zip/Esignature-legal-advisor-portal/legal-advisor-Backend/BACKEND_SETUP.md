# Legal Advisor Portal - Backend Setup Guide

## 🚀 Quick Start

### Prerequisites
- **Java 17 or higher** - [Download here](https://adoptium.net/)
- **Apache Maven 3.6+** - [Download here](https://maven.apache.org/download.cgi)
- **MongoDB Atlas Account** - [Sign up here](https://www.mongodb.com/atlas)

### Windows Setup
1. Open Command Prompt as Administrator
2. Navigate to the backend directory:
   ```cmd
   cd legal-advisor-Backend
   ```
3. Run the setup script:
   ```cmd
   setup-environment.bat
   ```

### Linux/Mac Setup
1. Open Terminal
2. Navigate to the backend directory:
   ```bash
   cd legal-advisor-Backend
   ```
3. Make the script executable:
   ```bash
   chmod +x setup-environment.sh
   ```
4. Run the setup script:
   ```bash
   ./setup-environment.sh
   ```

## 🔧 Manual Setup

### 1. Environment Variables
Set these environment variables before running:

```bash
# Database
export MONGODB_URI="mongodb+srv://anshtalreja025:ansh25@cluster0.klor1l5.mongodb.net/esign-dev?retryWrites=true&w=majority&appName=Cluster0"

# JWT Security
export JWT_SECRET="your-super-secure-jwt-secret-key"

# AI Services
export OPENAI_API_KEY="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"
export GEMINI_API_KEY="AIzaSyAvVL2jDtrJapX5EjCFQxJKno_Y0DiLJJQ"

# Email Configuration
export MAIL_USERNAME="anshtalreja025@gmail.com"
export MAIL_PASSWORD="lqep yfiw brrq xmmc"

# OAuth (Optional)
export GOOGLE_CLIENT_ID="your-google-client-id"
export GOOGLE_CLIENT_SECRET="your-google-client-secret"

# CORS
export CORS_ORIGINS="http://localhost:3000,http://localhost:5173"
```

### 2. Build and Run
```bash
# Clean and compile
mvn clean compile

# Run in development mode
mvn spring-boot:run -Dspring-boot.run.profiles=dev

# Run in production mode
mvn spring-boot:run -Dspring-boot.run.profiles=prod
```

## 🔑 Credentials Configuration

### 1. MongoDB Atlas
- **Database**: `esign-dev` (development) / `esign` (production)
- **Connection String**: Already configured in application properties
- **Collections**: Auto-created on first run

### 2. OpenAI API
- **API Key**: `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`
- **Model**: `gpt-4o-mini`
- **Usage**: Document analysis, agreement generation

### 3. Gemini API (Fallback)
- **API Key**: `AIzaSyAvVL2jDtrJapX5EjCFQxJKno_Y0DiLJJQ`
- **Model**: `gemini-2.0-flash`
- **Usage**: Backup AI service

### 4. Email Service (Gmail)
- **Username**: `anshtalreja025@gmail.com`
- **Password**: `lqep yfiw brrq xmmc` (App Password)
- **SMTP**: `smtp.gmail.com:587`

### 5. Google OAuth (Optional)
- **Client ID**: Set your Google OAuth Client ID
- **Client Secret**: Set your Google OAuth Client Secret
- **Redirect URI**: `http://localhost:8081/login/oauth2/code/google`

## 🌐 API Endpoints

### Base URL
- **Development**: `http://localhost:8081`
- **Production**: `https://your-domain.com`

### Key Endpoints
- **Authentication**: `/api/auth/*`
- **AI Services**: `/api/ai/*`
- **Documents**: `/api/documents/*`
- **Signatures**: `/api/signature/*`
- **Verification**: `/api/verification/*`
- **Admin Panel**: `/api/admin/*`
- **Dashboard**: `/api/dashboard/*`

### API Documentation
- **Swagger UI**: `http://localhost:8081/swagger-ui.html`
- **OpenAPI JSON**: `http://localhost:8081/v3/api-docs`

## 🔍 Troubleshooting

### Common Issues

#### 1. MongoDB Connection Error
```
Error: Unable to connect to MongoDB
```
**Solution**: Check your MongoDB Atlas connection string and network access settings.

#### 2. JWT Secret Error
```
Error: JWT secret is too short
```
**Solution**: Set a longer JWT secret (minimum 32 characters).

#### 3. OpenAI API Error
```
Error: OpenAI API key invalid
```
**Solution**: Verify your OpenAI API key and check your account balance.

#### 4. Email Service Error
```
Error: Authentication failed for email service
```
**Solution**: Use App Password for Gmail, not your regular password.

#### 5. CORS Error
```
Error: CORS policy blocked the request
```
**Solution**: Add your frontend URL to the CORS origins list.

### Logs
- **Application Logs**: Check console output
- **Error Logs**: Look for stack traces in console
- **Debug Mode**: Set `logging.level.com.esign.legal_advisor=DEBUG`

## 🚀 Production Deployment

### 1. Environment Variables
Set all production environment variables:
```bash
export SPRING_PROFILES_ACTIVE=prod
export MONGODB_URI="your-production-mongodb-uri"
export JWT_SECRET="your-production-jwt-secret"
export OPENAI_API_KEY="your-production-openai-key"
# ... other production variables
```

### 2. Build for Production
```bash
mvn clean package -Pprod
```

### 3. Run Production JAR
```bash
java -jar target/legal-advisor-portal-1.0.0.jar
```

## 📊 Monitoring

### Health Checks
- **Health**: `http://localhost:8081/actuator/health`
- **Info**: `http://localhost:8081/actuator/info`
- **Metrics**: `http://localhost:8081/actuator/metrics`

### Database Monitoring
- **MongoDB Atlas Dashboard**: Monitor connection and performance
- **Application Logs**: Check for database-related errors

## 🔒 Security

### JWT Configuration
- **Secret**: Use a strong, random secret (32+ characters)
- **Expiration**: 24 hours (86400000 ms)
- **Algorithm**: HS256

### CORS Configuration
- **Origins**: Only allow trusted domains
- **Methods**: Limit to necessary HTTP methods
- **Headers**: Restrict to required headers

### API Security
- **Authentication**: Required for all protected endpoints
- **Authorization**: Role-based access control
- **Rate Limiting**: Implement if needed

## 📝 Development Notes

### Code Structure
- **Controllers**: REST API endpoints
- **Services**: Business logic
- **Repositories**: Data access
- **DTOs**: Data transfer objects
- **Entities**: Database models

### Testing
```bash
# Run all tests
mvn test

# Run specific test class
mvn test -Dtest=AuthServiceTest

# Run with coverage
mvn test jacoco:report
```

### Database Migrations
- **Auto-creation**: Enabled for development
- **Manual**: Use MongoDB Compass for schema changes
- **Backup**: Regular backups via MongoDB Atlas

## 🆘 Support

### Getting Help
1. Check the logs for error messages
2. Verify all environment variables are set
3. Ensure all services (MongoDB, OpenAI) are accessible
4. Check network connectivity

### Common Commands
```bash
# Check Java version
java -version

# Check Maven version
mvn -version

# Check if port is in use
netstat -an | findstr :8081

# Kill process on port 8081
taskkill /F /PID <process_id>
```

## ✅ Verification

After setup, verify everything is working:

1. **Health Check**: Visit `http://localhost:8081/actuator/health`
2. **API Docs**: Visit `http://localhost:8081/swagger-ui.html`
3. **Database**: Check MongoDB Atlas for collections
4. **Logs**: Look for "Started LegalAdvisorPortalApplication" message

Your Legal Advisor Portal backend should now be running successfully! 🎉






















