Write-Host "Testing Backend Server..." -ForegroundColor Yellow
try {
    $backendStatus = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/status" -Method GET -TimeoutSec 5
    Write-Host "Backend is running on port 8081" -ForegroundColor Green
} catch {
    Write-Host "Backend is not running on port 8081" -ForegroundColor Red
}

Write-Host "Testing Frontend Server..." -ForegroundColor Yellow
try {
    $frontendResponse = Invoke-WebRequest -Uri "http://localhost:5173" -Method GET -TimeoutSec 5
    Write-Host "Frontend is running on port 5173" -ForegroundColor Green
} catch {
    Write-Host "Frontend is not running on port 5173" -ForegroundColor Red
}

Write-Host "Testing Document Analysis API..." -ForegroundColor Yellow
try {
    $testContent = @{
        content = "This is a test legal document for analysis."
    } | ConvertTo-Json

    $analysisResult = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/analyze" -Method POST -ContentType "application/json" -Body $testContent -TimeoutSec 10
    Write-Host "Document Analysis API is working" -ForegroundColor Green
} catch {
    Write-Host "Document Analysis API failed" -ForegroundColor Red
}

Write-Host "Integration test completed!" -ForegroundColor Green
Write-Host "Frontend: http://localhost:5173" -ForegroundColor White
Write-Host "Backend API: http://localhost:8081/api" -ForegroundColor White
