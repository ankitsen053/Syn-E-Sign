Write-Host "Testing API Fix for generate-and-save" -ForegroundColor Yellow
Write-Host "=====================================" -ForegroundColor Yellow

try {
    $headers = @{ "Content-Type" = "application/json" }
    $body = '{"type":"General Agreement","partyA":"Party A","partyB":"Party B","terms":"Standard terms and conditions apply"}'
    
    Write-Host "Sending POST request to /api/ai/generate-and-save..." -ForegroundColor Gray
    
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/ai/generate-and-save" -Method POST -Headers $headers -Body $body -UseBasicParsing
    
    Write-Host "Status Code: $($response.StatusCode)" -ForegroundColor Green
    Write-Host "Response: $($response.Content)" -ForegroundColor Gray
    
    if ($response.StatusCode -eq 200) {
        Write-Host "✅ API is working correctly!" -ForegroundColor Green
    } else {
        Write-Host "❌ API returned unexpected status code" -ForegroundColor Red
    }
} catch {
    Write-Host "❌ API test failed: $($_.Exception.Message)" -ForegroundColor Red
}
