# HuggingFace ChatGPT-2.V2 Integration Setup

This document provides instructions for setting up the HuggingFace ChatGPT-2.V2 model integration to replace Gemini API.

## Model Information

- **Model**: `mradermacher/ChatGPT-2.V2-GGUF`
- **Repository**: https://huggingface.co/mradermacher/ChatGPT-2.V2-GGUFmodel
- **API Endpoint**: https://api-inference.huggingface.co/models/mradermacher/ChatGPT-2.V2-GGUF

## Setup Instructions

### 1. Get HuggingFace API Key

1. Go to [HuggingFace](https://huggingface.co/)
2. Create an account or sign in
3. Go to your profile settings
4. Navigate to "Access Tokens" section
5. Create a new token with "Read" permissions
6. Copy the generated token

### 2. Configure Application Properties

Update `src/main/resources/application.properties`:

```properties
# HuggingFace API Configuration (Primary - ChatGPT-2.V2 Model)
huggingface.api.enabled=true
huggingface.api.key=YOUR_ACTUAL_HUGGINGFACE_API_KEY_HERE
huggingface.api.url=https://api-inference.huggingface.co/models/mradermacher/ChatGPT-2.V2-GGUF
huggingface.model.max-tokens=4000
huggingface.model.temperature=0.1
huggingface.timeout.seconds=120

# AI Service Configuration
ai.service.provider=huggingface
ai.service.enabled=true
ai.service.fallback.enabled=true
```

### 3. Environment Variable (Alternative)

You can also set the API key as an environment variable:

```bash
export HUGGINGFACE_API_KEY=your_actual_api_key_here
```

Then update the properties file:

```properties
huggingface.api.key=${HUGGINGFACE_API_KEY}
```

## Features

### Legal Advisor Capabilities

The HuggingFace ChatGPT-2.V2 model is configured to work as a professional legal advisor with the following capabilities:

1. **Legal Document Analysis**
   - Comprehensive legal document review
   - Professional-grade analysis suitable for lawyers
   - Executive summary and detailed breakdown

2. **Issue Detection**
   - Critical legal issues identification
   - High-risk issues assessment
   - Moderate and minor issues categorization
   - Specific recommendations with sample language

3. **Risk Assessment**
   - Contractual risks analysis
   - Liability risks evaluation
   - Operational risks assessment
   - Legal risks identification
   - Financial risks analysis

4. **Compliance Assessment**
   - Regulatory compliance analysis
   - Jurisdictional requirements review
   - Industry standards adherence
   - Compliance gaps identification

5. **Professional Recommendations**
   - Strategic legal guidance
   - Specific clause improvements
   - Risk mitigation strategies
   - Implementation roadmaps

## API Endpoints

### Test Connection
```
GET /api/ai/test-huggingface
```

### Professional Analysis
```
POST /api/ai/professional-analyze
POST /api/ai/professional-analyze-text
```

### Standard Analysis
```
POST /api/ai/analyze
POST /api/ai/analyze-text
```

## Model Configuration

The model is configured with the following parameters:

- **Max Tokens**: 4000 (adjustable)
- **Temperature**: 0.1 (low for consistent legal analysis)
- **Timeout**: 120 seconds
- **Model**: ChatGPT-2.V2-GGUF

## Legal Analysis Quality

The integration provides:

- **Senior Partner Level Analysis**: 25+ years experience simulation
- **Professional Legal Memorandum Format**: Executive summary, detailed analysis
- **Critical Legal Issues**: Enforceability problems, missing essential terms
- **High-Risk Issues**: Ambiguous language, inadequate protections
- **Strategic Recommendations**: Specific clause improvements with sample language

## Troubleshooting

### Common Issues

1. **API Key Not Working**
   - Verify the API key is correct
   - Check if the token has proper permissions
   - Ensure the model is accessible

2. **Timeout Issues**
   - Increase timeout settings in application.properties
   - Check network connectivity
   - Verify model availability

3. **Response Quality**
   - Adjust temperature settings (lower for more consistent results)
   - Modify max-tokens for longer responses
   - Check prompt engineering in service classes

### Testing

Use the test endpoint to verify the connection:

```bash
curl -X GET http://localhost:8081/api/ai/test-huggingface
```

Expected response:
```json
{
  "success": true,
  "message": "HuggingFace ChatGPT-2.V2 connection successful",
  "model": "mradermacher/ChatGPT-2.V2-GGUF",
  "response": "Test response from the model"
}
```

## Migration from Gemini

The system has been completely migrated from Gemini to HuggingFace:

- ✅ All Gemini references replaced with HuggingFace
- ✅ Service classes updated
- ✅ Configuration updated
- ✅ API endpoints updated
- ✅ Professional legal analysis maintained
- ✅ Enhanced issue detection preserved

## Support

For issues related to the HuggingFace integration:

1. Check the application logs for detailed error messages
2. Verify API key configuration
3. Test the connection endpoint
4. Review the model documentation on HuggingFace

The system now uses HuggingFace ChatGPT-2.V2 as the primary AI service for all legal analysis and document processing tasks.



















