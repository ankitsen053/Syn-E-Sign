#!/usr/bin/env pwsh
# Verification Refresh System Test Script
# Tests the comprehensive verification refresh functionality

Write-Host "🔄 Verification Refresh System Test" -ForegroundColor Blue
Write-Host "===================================" -ForegroundColor Blue
Write-Host ""

$BaseUrl = "http://localhost:8081/api"
$FrontendUrl = "http://localhost:3000"

function Test-ApiEndpoint($endpoint, $method = "GET", $body = $null) {
    try {
        $headers = @{
            "Content-Type" = "application/json"
            "Accept" = "application/json"
        }
        
        if ($body) {
            $response = Invoke-RestMethod -Uri "$BaseUrl$endpoint" -Method $method -Body ($body | ConvertTo-Json) -Headers $headers
        } else {
            $response = Invoke-RestMethod -Uri "$BaseUrl$endpoint" -Method $method -Headers $headers
        }
        
        return @{
            Success = $true
            Data = $response
            StatusCode = 200
        }
    } catch {
        return @{
            Success = $false
            Error = $_.Exception.Message
            StatusCode = $_.Exception.Response.StatusCode.value__
        }
    }
}

function Test-GenerateRefreshToken() {
    Write-Host "🎯 Testing refresh token generation..." -ForegroundColor Yellow
    
    $result = Test-ApiEndpoint "/verification-refresh/generate-token" "POST"
    
    if ($result.Success) {
        Write-Host "✅ Refresh token generated successfully" -ForegroundColor Green
        Write-Host "   - Token: $($result.Data.refreshToken.Substring(0, 8))..." -ForegroundColor Cyan
        Write-Host "   - User ID: $($result.Data.userId)" -ForegroundColor Cyan
        Write-Host "   - Username: $($result.Data.username)" -ForegroundColor Cyan
        return $result.Data.refreshToken
    } else {
        Write-Host "❌ Failed to generate refresh token: $($result.Error)" -ForegroundColor Red
        return $null
    }
}

function Test-GetVerificationProfile() {
    Write-Host "👤 Testing user verification profile..." -ForegroundColor Yellow
    
    $result = Test-ApiEndpoint "/verification-refresh/profile"
    
    if ($result.Success) {
        Write-Host "✅ Verification profile retrieved successfully" -ForegroundColor Green
        $profile = $result.Data.profile
        Write-Host "   - User Terms: $($profile.userVerificationTerms)" -ForegroundColor Cyan
        Write-Host "   - Business Type: $($profile.businessType)" -ForegroundColor Cyan
        Write-Host "   - Required Verifications: $($profile.requiredVerifications -join ', ')" -ForegroundColor Cyan
        Write-Host "   - Completion: $([math]::Round($profile.completionPercentage, 1))%" -ForegroundColor Cyan
        Write-Host "   - Completed: $($profile.completed) / $($profile.totalRequired)" -ForegroundColor Cyan
        return $profile
    } else {
        Write-Host "❌ Failed to get verification profile: $($result.Error)" -ForegroundColor Red
        return $null
    }
}

function Test-RefreshVerificationStatus($refreshToken) {
    Write-Host "🔄 Testing verification status refresh..." -ForegroundColor Yellow
    
    $requestBody = @{
        refreshToken = $refreshToken
    }
    
    $result = Test-ApiEndpoint "/verification-refresh/refresh" "POST" $requestBody
    
    if ($result.Success) {
        Write-Host "✅ Verification status refreshed successfully" -ForegroundColor Green
        $data = $result.Data.data
        Write-Host "   - User Terms: $($data.userTerms)" -ForegroundColor Cyan
        Write-Host "   - Required Verifications: $($data.requiredVerifications -join ', ')" -ForegroundColor Cyan
        Write-Host "   - Completion: $([math]::Round($data.overallCompletionPercentage, 1))%" -ForegroundColor Cyan
        Write-Host "   - Fully Verified: $($data.fullyVerified)" -ForegroundColor Cyan
        
        # Show individual verification statuses
        Write-Host "   - Verification Statuses:" -ForegroundColor Cyan
        foreach ($verification in $data.verificationStatuses.PSObject.Properties) {
            $status = $verification.Value
            Write-Host "     • $($verification.Name): $($status.status) $(if($status.verifiedAt) { "at $($status.verifiedAt)" })" -ForegroundColor Gray
        }
        
        return $data
    } else {
        Write-Host "❌ Failed to refresh verification status: $($result.Error)" -ForegroundColor Red
        return $null
    }
}

function Test-RefreshSpecificVerification($verificationType, $refreshToken) {
    Write-Host "🎯 Testing specific verification refresh: $verificationType" -ForegroundColor Yellow
    
    $requestBody = @{
        refreshToken = $refreshToken
    }
    
    $result = Test-ApiEndpoint "/verification-refresh/refresh/$verificationType" "POST" $requestBody
    
    if ($result.Success) {
        Write-Host "✅ $verificationType verification refreshed successfully" -ForegroundColor Green
        $verificationData = $result.Data.verificationData
        Write-Host "   - Type: $($verificationData.type)" -ForegroundColor Cyan
        Write-Host "   - Status: $($verificationData.status)" -ForegroundColor Cyan
        Write-Host "   - Description: $($verificationData.description)" -ForegroundColor Cyan
        Write-Host "   - Refreshed At: $($result.Data.refreshedAt)" -ForegroundColor Cyan
        return $true
    } else {
        Write-Host "❌ Failed to refresh $verificationType verification: $($result.Error)" -ForegroundColor Red
        return $false
    }
}

function Test-GetTermsExplanation() {
    Write-Host "📚 Testing verification terms explanation..." -ForegroundColor Yellow
    
    $result = Test-ApiEndpoint "/verification-refresh/terms-explanation"
    
    if ($result.Success) {
        Write-Host "✅ Terms explanation retrieved successfully" -ForegroundColor Green
        $explanation = $result.Data.explanation
        
        foreach ($term in $explanation.PSObject.Properties) {
            $termData = $term.Value
            Write-Host "   - $($term.Name):" -ForegroundColor Cyan
            Write-Host "     Description: $($termData.description)" -ForegroundColor Gray
            Write-Host "     Required: $($termData.required -join ', ')" -ForegroundColor Gray
            Write-Host "     Purpose: $($termData.purpose)" -ForegroundColor Gray
        }
        
        return $explanation
    } else {
        Write-Host "❌ Failed to get terms explanation: $($result.Error)" -ForegroundColor Red
        return $null
    }
}

function Test-VerificationStatusByUserId($userId) {
    Write-Host "🔍 Testing verification status by user ID: $userId" -ForegroundColor Yellow
    
    $result = Test-ApiEndpoint "/verification-refresh/status/$userId"
    
    if ($result.Success) {
        Write-Host "✅ Verification status retrieved by user ID" -ForegroundColor Green
        $profile = $result.Data.profile
        Write-Host "   - User ID: $($profile.userId)" -ForegroundColor Cyan
        Write-Host "   - User Terms: $($profile.userVerificationTerms)" -ForegroundColor Cyan
        Write-Host "   - Completion: $([math]::Round($profile.completionPercentage, 1))%" -ForegroundColor Cyan
        return $profile
    } else {
        Write-Host "❌ Failed to get verification status by user ID: $($result.Error)" -ForegroundColor Red
        return $null
    }
}

function Show-TestSummary($results) {
    Write-Host ""
    Write-Host "📊 Test Summary" -ForegroundColor Blue
    Write-Host "===============" -ForegroundColor Blue
    
    $totalTests = $results.Count
    $passedTests = ($results | Where-Object { $_ -eq $true }).Count
    $failedTests = $totalTests - $passedTests
    
    Write-Host "Total Tests: $totalTests" -ForegroundColor White
    Write-Host "Passed: $passedTests" -ForegroundColor Green
    Write-Host "Failed: $failedTests" -ForegroundColor Red
    Write-Host "Success Rate: $([math]::Round(($passedTests / $totalTests) * 100, 2))%" -ForegroundColor Cyan
    
    if ($failedTests -eq 0) {
        Write-Host ""
        Write-Host "🎉 All tests passed! Verification refresh system is working properly." -ForegroundColor Green
    } else {
        Write-Host ""
        Write-Host "⚠️  Some tests failed. Check the output above for details." -ForegroundColor Yellow
    }
}

function Test-FrontendIntegration() {
    Write-Host "🌐 Testing Frontend Integration..." -ForegroundColor Yellow
    
    Write-Host "   📱 Verification Refresh Status Component:" -ForegroundColor Cyan
    Write-Host "      - User-specific verification terms display" -ForegroundColor Gray
    Write-Host "      - Progress bar with completion percentage" -ForegroundColor Gray
    Write-Host "      - Individual verification status cards" -ForegroundColor Gray
    Write-Host "      - Refresh token generation and management" -ForegroundColor Gray
    Write-Host "      - Individual and bulk verification refresh" -ForegroundColor Gray
    
    Write-Host "   🔄 Refresh Functionality:" -ForegroundColor Cyan
    Write-Host "      - Generate new refresh tokens" -ForegroundColor Gray
    Write-Host "      - Refresh all verifications at once" -ForegroundColor Gray
    Write-Host "      - Refresh individual verification types" -ForegroundColor Gray
    Write-Host "      - Real-time status updates" -ForegroundColor Gray
    
    Write-Host "   🎨 User Experience:" -ForegroundColor Cyan
    Write-Host "      - Business type-specific requirements" -ForegroundColor Gray
    Write-Host "      - Color-coded status indicators" -ForegroundColor Gray
    Write-Host "      - Detailed verification explanations" -ForegroundColor Gray
    Write-Host "      - Secure token display with show/hide" -ForegroundColor Gray
    
    Write-Host "✅ Frontend integration features documented" -ForegroundColor Green
    return $true
}

# Main test execution
Write-Host "Starting verification refresh system tests..." -ForegroundColor White
Write-Host ""

$results = @()

# Test 1: Generate refresh token
$refreshToken = Test-GenerateRefreshToken
$results += ($refreshToken -ne $null)

# Test 2: Get verification profile
$profile = Test-GetVerificationProfile
$results += ($profile -ne $null)

# Test 3: Get terms explanation
$termsExplanation = Test-GetTermsExplanation
$results += ($termsExplanation -ne $null)

if ($refreshToken) {
    # Test 4: Refresh verification status
    $refreshData = Test-RefreshVerificationStatus $refreshToken
    $results += ($refreshData -ne $null)
    
    # Test 5: Refresh specific verifications
    if ($profile -and $profile.requiredVerifications) {
        foreach ($verificationType in $profile.requiredVerifications) {
            $specificRefreshResult = Test-RefreshSpecificVerification $verificationType $refreshToken
            $results += $specificRefreshResult
        }
    }
}

# Test 6: Get verification status by user ID (if we have profile data)
if ($profile -and $profile.userId) {
    $userIdProfile = Test-VerificationStatusByUserId $profile.userId
    $results += ($userIdProfile -ne $null)
}

# Test 7: Frontend integration (documentation)
$frontendResult = Test-FrontendIntegration
$results += $frontendResult

# Show summary
Show-TestSummary $results

Write-Host ""
Write-Host "🌐 Frontend Testing Instructions:" -ForegroundColor Blue
Write-Host "1. Open $FrontendUrl in your browser" -ForegroundColor White
Write-Host "2. Navigate to Verification page" -ForegroundColor White
Write-Host "3. Click on 'Refresh Status' tab" -ForegroundColor White
Write-Host "4. Test the following features:" -ForegroundColor White
Write-Host "   - Generate new refresh token" -ForegroundColor Gray
Write-Host "   - View user-specific verification requirements" -ForegroundColor Gray
Write-Host "   - Refresh all verifications" -ForegroundColor Gray
Write-Host "   - Refresh individual verification types" -ForegroundColor Gray
Write-Host "   - Check progress bar and completion percentage" -ForegroundColor Gray
Write-Host "   - Verify business type-specific requirements" -ForegroundColor Gray

Write-Host ""
Write-Host "✨ Verification Refresh Features Implemented:" -ForegroundColor Green
Write-Host "- ✅ User-specific verification terms (INDIVIDUAL, BUSINESS, CORPORATE)" -ForegroundColor Green
Write-Host "- ✅ Refresh token generation and management" -ForegroundColor Green
Write-Host "- ✅ Individual and bulk verification refresh" -ForegroundColor Green
Write-Host "- ✅ Business type-specific verification requirements" -ForegroundColor Green
Write-Host "- ✅ Real-time progress tracking and completion percentage" -ForegroundColor Green
Write-Host "- ✅ Comprehensive verification status display" -ForegroundColor Green
Write-Host "- ✅ Secure token handling with masked display" -ForegroundColor Green
Write-Host "- ✅ Detailed verification explanations and requirements" -ForegroundColor Green

Write-Host ""
Write-Host "🔧 API Endpoints Available:" -ForegroundColor Green
Write-Host "- POST /api/verification-refresh/generate-token" -ForegroundColor Gray
Write-Host "- POST /api/verification-refresh/refresh" -ForegroundColor Gray
Write-Host "- GET  /api/verification-refresh/profile" -ForegroundColor Gray
Write-Host "- GET  /api/verification-refresh/status/{userId}" -ForegroundColor Gray
Write-Host "- POST /api/verification-refresh/refresh/{verificationType}" -ForegroundColor Gray
Write-Host "- GET  /api/verification-refresh/terms-explanation" -ForegroundColor Gray
