# Test Document System Script for Legal Advisor
Write-Host "Testing Improved Document System..." -ForegroundColor Green

# Test Backend Status
Write-Host "`n1. Testing Backend Status..." -ForegroundColor Yellow
try {
    $backendStatus = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/status" -Method GET
    Write-Host "✅ Backend is running on port 8081" -ForegroundColor Green
    Write-Host "   Status: $($backendStatus.status)" -ForegroundColor Cyan
    Write-Host "   Version: $($backendStatus.version)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Backend is not responding on port 8081" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test Document Service Status
Write-Host "`n2. Testing Document Service Status..." -ForegroundColor Yellow
try {
    $docStatus = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/status" -Method GET
    Write-Host "✅ Document Service is running" -ForegroundColor Green
    Write-Host "   Status: $($docStatus.status)" -ForegroundColor Cyan
    Write-Host "   Version: $($docStatus.version)" -ForegroundColor Cyan
    Write-Host "   Features: $($docStatus.features.migration)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Document Service is not responding" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test Document Migration
Write-Host "`n3. Testing Document Migration..." -ForegroundColor Yellow
try {
    $migrationResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/migrate" -Method POST
    Write-Host "✅ Document Migration completed" -ForegroundColor Green
    Write-Host "   Message: $($migrationResponse.message)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Document Migration failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test User Documents Retrieval
Write-Host "`n4. Testing User Documents Retrieval..." -ForegroundColor Yellow
try {
    $userDocsResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/user" -Method GET
    Write-Host "✅ User Documents retrieved successfully" -ForegroundColor Green
    Write-Host "   Count: $($userDocsResponse.count)" -ForegroundColor Cyan
    Write-Host "   Success: $($userDocsResponse.success)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ User Documents retrieval failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test Document Generation and Save
Write-Host "`n5. Testing Document Generation and Save..." -ForegroundColor Yellow
try {
    $generateResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/generate" -Method POST -Body "Test document content" -ContentType "text/plain"
    Write-Host "✅ Document Generation completed" -ForegroundColor Green
    Write-Host "   Success: $($generateResponse.success)" -ForegroundColor Cyan
    Write-Host "   Type: $($generateResponse.type)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Document Generation failed" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Document System Testing Complete!" -ForegroundColor Green
Write-Host "All improvements have been implemented:" -ForegroundColor Cyan
Write-Host "✅ Fixed null user reference issues" -ForegroundColor Green
Write-Host "✅ Added userId field for better querying" -ForegroundColor Green
Write-Host "✅ Improved error handling and logging" -ForegroundColor Green
Write-Host "✅ Added document migration service" -ForegroundColor Green
Write-Host "✅ Enhanced user management" -ForegroundColor Green
