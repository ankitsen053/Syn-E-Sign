# Test Document Deletion - Debug Script
Write-Host "Testing Document Deletion..." -ForegroundColor Cyan

# Check server status
Write-Host "   Checking server status..." -ForegroundColor Gray
try {
    $statusResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/status" -Method GET -TimeoutSec 5
    Write-Host "   Server is running" -ForegroundColor Green
} catch {
    Write-Host "   Server is not running. Please start the server first." -ForegroundColor Red
    exit 1
}

# Get user documents first
Write-Host "   Getting user documents..." -ForegroundColor Gray
try {
    $documentsResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/user" -Method GET -TimeoutSec 10
    if ($documentsResponse.success) {
        $documents = $documentsResponse.documents
        Write-Host "   Found $($documents.Count) documents" -ForegroundColor Green
        
        if ($documents.Count -gt 0) {
            $testDocument = $documents[0]
            $testDocumentId = $testDocument.id
            Write-Host "   Testing with document: $($testDocument.title) (ID: $testDocumentId)" -ForegroundColor Yellow
            
            # Try to delete the document
            Write-Host "   Attempting to delete document..." -ForegroundColor Gray
            try {
                $deleteResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/documents/$testDocumentId" -Method DELETE -TimeoutSec 10
                Write-Host "   DELETE operation successful" -ForegroundColor Green
                Write-Host "   Response: $($deleteResponse | ConvertTo-Json)" -ForegroundColor Gray
            } catch {
                Write-Host "   DELETE operation failed" -ForegroundColor Red
                Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
                if ($_.Exception.Response) {
                    $errorResponse = $_.Exception.Response.GetResponseStream()
                    $reader = New-Object System.IO.StreamReader($errorResponse)
                    $errorBody = $reader.ReadToEnd()
                    Write-Host "   Error Body: $errorBody" -ForegroundColor Red
                }
            }
        } else {
            Write-Host "   No documents found to test deletion" -ForegroundColor Yellow
        }
    } else {
        Write-Host "   Failed to get documents: $($documentsResponse.error)" -ForegroundColor Red
    }
} catch {
    Write-Host "   Failed to get documents" -ForegroundColor Red
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "Debug Information:" -ForegroundColor Cyan
Write-Host "   - Server URL: http://localhost:8081" -ForegroundColor Gray
Write-Host "   - Document API: /api/documents" -ForegroundColor Gray
Write-Host "   - Delete Endpoint: DELETE /api/documents/{id}" -ForegroundColor Gray
