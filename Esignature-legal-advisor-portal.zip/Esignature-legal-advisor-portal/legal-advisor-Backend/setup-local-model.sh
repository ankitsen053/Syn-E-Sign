#!/bin/bash

# Setup script for local ChatGPT-2.V2-GGUF model integration
echo "Setting up local ChatGPT-2.V2-GGUF model integration..."

# Create models directory
mkdir -p models
cd models

# Clone the model repository
echo "Downloading ChatGPT-2.V2-GGUF model..."
git clone https://huggingface.co/mradermacher/ChatGPT-2.V2-GGUF

# Check if download was successful
if [ -d "ChatGPT-2.V2-GGUF" ]; then
    echo "✅ Model downloaded successfully!"
    echo "Model location: $(pwd)/ChatGPT-2.V2-GGUF"
    
    # List model files
    echo "Model files:"
    ls -la ChatGPT-2.V2-GGUF/
    
    # Check for GGUF files
    echo "GGUF files found:"
    find ChatGPT-2.V2-GGUF/ -name "*.gguf" -type f
    
else
    echo "❌ Model download failed!"
    exit 1
fi

# Go back to project root
cd ..

echo "✅ Local model setup complete!"
echo "Next steps:"
echo "1. Install required dependencies (see setup-local-model.md)"
echo "2. Configure application.properties for local inference"
echo "3. Start the application with local model support"


















