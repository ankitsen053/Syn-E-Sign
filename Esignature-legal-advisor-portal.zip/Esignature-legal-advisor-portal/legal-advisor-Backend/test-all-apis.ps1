Write-Host "========================================" -ForegroundColor Green
Write-Host "Legal Advisor API - Complete Test Suite" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

$baseUrl = "http://localhost:8080"
$testResults = @()

# Function to test an API endpoint
function Test-ApiEndpoint {
    param(
        [string]$Name,
        [string]$Method,
        [string]$Url,
        [hashtable]$Headers = @{},
        [string]$Body = $null,
        [string]$ContentType = "application/json"
    )
    
    try {
        $params = @{
            Uri = $Url
            Method = $Method
            TimeoutSec = 10
        }
        
        if ($Headers.Count -gt 0) {
            $params.Headers = $Headers
        }
        
        if ($Body) {
            $params.Body = $Body
            $params.ContentType = $ContentType
        }
        
        $response = Invoke-RestMethod @params
        Write-Host "✅ $Name - SUCCESS" -ForegroundColor Green
        $testResults += @{Name = $Name; Status = "SUCCESS"; Response = $response }
        return $true
    }
    catch {
        Write-Host "❌ $Name - FAILED: $($_.Exception.Message)" -ForegroundColor Red
        $testResults += @{Name = $Name; Status = "FAILED"; Error = $_.Exception.Message }
        return $false
    }
}

Write-Host "Testing Basic Connectivity..." -ForegroundColor Yellow
Write-Host ""

# Test 1: Health Check
Test-ApiEndpoint -Name "Health Check" -Method "GET" -Url "$baseUrl/api/test/health"

# Test 2: Public Test Endpoint
Test-ApiEndpoint -Name "Public Test Endpoint" -Method "GET" -Url "$baseUrl/api/test/public"

# Test 3: AI Service Status
Test-ApiEndpoint -Name "AI Service Status" -Method "GET" -Url "$baseUrl/api/ai/status"

Write-Host ""
Write-Host "Testing Authentication..." -ForegroundColor Yellow
Write-Host ""

# Test 4: User Registration
$signupBody = @{
    username = "testuser_$(Get-Random)"
    email = "testuser_$(Get-Random)@example.com"
    password = "password123"
    roles = @("user")
    fullName = "Test User"
} | ConvertTo-Json

$registrationSuccess = Test-ApiEndpoint -Name "User Registration" -Method "POST" -Url "$baseUrl/api/auth/signup" -Body $signupBody

# Test 5: User Login
if ($registrationSuccess) {
    $loginBody = @{
        username = ($signupBody | ConvertFrom-Json).username
        password = "password123"
    } | ConvertTo-Json
    
    $loginSuccess = Test-ApiEndpoint -Name "User Login" -Method "POST" -Url "$baseUrl/api/auth/login" -Body $loginBody
    
    if ($loginSuccess) {
        # Get the token from the last successful response
        $token = $testResults[-1].Response.token
        
        Write-Host ""
        Write-Host "Testing Protected Endpoints..." -ForegroundColor Yellow
        Write-Host ""
        
        $authHeaders = @{
            Authorization = "Bearer $token"
        }
        
        # Test 6: User Test Endpoint (Protected)
        Test-ApiEndpoint -Name "User Test Endpoint (Protected)" -Method "GET" -Url "$baseUrl/api/test/user" -Headers $authHeaders
        
        # Test 7: Get Profile (Protected)
        Test-ApiEndpoint -Name "Get Profile (Protected)" -Method "GET" -Url "$baseUrl/api/profile" -Headers $authHeaders
        
        Write-Host ""
        Write-Host "Testing Profile Management..." -ForegroundColor Yellow
        Write-Host ""
        
        # Test 8: Create/Update Profile
        $profileBody = @{
            fullName = "John Doe"
            address = "123 Main Street, City, State 12345"
            phoneNumber = "+91-9876543210"
            panNumber = "ABCDE1234F"
            verificationMethod = "PAN"
        } | ConvertTo-Json
        
        Test-ApiEndpoint -Name "Create/Update Profile" -Method "POST" -Url "$baseUrl/api/profile" -Headers $authHeaders -Body $profileBody
        
        # Test 9: Verify Profile - PAN
        Test-ApiEndpoint -Name "Verify Profile - PAN" -Method "POST" -Url "$baseUrl/api/profile/verify?method=PAN" -Headers $authHeaders
        
        Write-Host ""
        Write-Host "Testing AI Services..." -ForegroundColor Yellow
        Write-Host ""
        
        # Test 10: Generate Agreement - NDA
        $agreementTerms = "Confidential information sharing agreement between Company A and Company B for project collaboration."
        Test-ApiEndpoint -Name "Generate Agreement - NDA" -Method "POST" -Url "$baseUrl/api/ai/generate?type=NDA&partyA=Company%20A&partyB=Company%20B" -Body $agreementTerms -ContentType "text/plain"
        
        # Test 11: Analyze Document
        $documentContent = "This is a sample legal document that needs to be analyzed for potential issues, compliance requirements, and legal implications."
        Test-ApiEndpoint -Name "Analyze Document" -Method "POST" -Url "$baseUrl/api/ai/analyze" -Body $documentContent -ContentType "text/plain"
        
        Write-Host ""
        Write-Host "Testing Error Handling..." -ForegroundColor Yellow
        Write-Host ""
        
        # Test 12: Invalid Credentials
        $invalidLoginBody = @{
            username = "nonexistentuser"
            password = "wrongpassword"
        } | ConvertTo-Json
        
        Test-ApiEndpoint -Name "Invalid Credentials (Should Fail)" -Method "POST" -Url "$baseUrl/api/auth/login" -Body $invalidLoginBody
        
        # Test 13: Missing Authentication
        Test-ApiEndpoint -Name "Missing Authentication (Should Fail)" -Method "GET" -Url "$baseUrl/api/test/user"
        
        # Test 14: Invalid JWT Token
        $invalidAuthHeaders = @{
            Authorization = "Bearer invalid_token_here"
        }
        Test-ApiEndpoint -Name "Invalid JWT Token (Should Fail)" -Method "GET" -Url "$baseUrl/api/test/user" -Headers $invalidAuthHeaders
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "API TESTING SUMMARY" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

$successCount = ($testResults | Where-Object { $_.Status -eq "SUCCESS" }).Count
$failedCount = ($testResults | Where-Object { $_.Status -eq "FAILED" }).Count
$totalCount = $testResults.Count

Write-Host "Total Tests: $totalCount" -ForegroundColor White
Write-Host "Successful: $successCount" -ForegroundColor Green
Write-Host "Failed: $failedCount" -ForegroundColor Red
Write-Host ""

if ($failedCount -eq 0) {
    Write-Host "🎉 ALL APIs ARE WORKING CORRECTLY!" -ForegroundColor Green
} else {
    Write-Host "⚠️  Some APIs have issues. Check the details above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Detailed Results:" -ForegroundColor Yellow
Write-Host ""

foreach ($result in $testResults) {
    $statusColor = if ($result.Status -eq "SUCCESS") { "Green" } else { "Red" }
    Write-Host "$($result.Name): $($result.Status)" -ForegroundColor $statusColor
    if ($result.Status -eq "FAILED" -and $result.Error) {
        Write-Host "  Error: $($result.Error)" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "Testing Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
