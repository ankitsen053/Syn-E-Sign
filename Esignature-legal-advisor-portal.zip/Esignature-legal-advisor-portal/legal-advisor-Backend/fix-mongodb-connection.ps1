# MongoDB Connection Diagnostic and Fix Script
# This script helps diagnose and fix MongoDB connection issues

Write-Host "=== MongoDB Connection Diagnostic Tool ===" -ForegroundColor Green
Write-Host ""

# Function to test network connectivity
function Test-NetworkConnectivity {
    Write-Host "Testing network connectivity..." -ForegroundColor Yellow
    
    # Test DNS resolution
    try {
        $dnsResult = Resolve-DnsName "cluster0.klor1l5.mongodb.net" -ErrorAction Stop
        Write-Host "✓ DNS resolution successful: $($dnsResult.IPAddress)" -ForegroundColor Green
    } catch {
        Write-Host "✗ DNS resolution failed: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
    
    # Test ping
    try {
        $pingResult = Test-Connection "cluster0.klor1l5.mongodb.net" -Count 1 -Quiet
        if ($pingResult) {
            Write-Host "✓ Ping successful" -ForegroundColor Green
        } else {
            Write-Host "✗ Ping failed" -ForegroundColor Red
            return $false
        }
    } catch {
        Write-Host "✗ Ping test failed: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
    
    # Test port connectivity (MongoDB default port 27017)
    try {
        $tcpClient = New-Object System.Net.Sockets.TcpClient
        $tcpClient.ConnectAsync("cluster0.klor1l5.mongodb.net", 27017).Wait(5000)
        if ($tcpClient.Connected) {
            Write-Host "✓ Port 27017 accessible" -ForegroundColor Green
            $tcpClient.Close()
        } else {
            Write-Host "✗ Port 27017 not accessible" -ForegroundColor Red
            return $false
        }
    } catch {
        Write-Host "✗ Port connectivity test failed: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
    
    return $true
}

# Function to check MongoDB Atlas status
function Test-MongoDBAtlasStatus {
    Write-Host "`nChecking MongoDB Atlas status..." -ForegroundColor Yellow
    
    try {
        # Test connection to MongoDB Atlas
        $uri = "mongodb+srv://anshtalreja025:ansh25@cluster0.klor1l5.mongodb.net/esign?retryWrites=true&w=majority&appName=Cluster0"
        
        # Create a simple connection test
        $mongoTest = @"
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

public class MongoConnectionTest {
    public static void main(String[] args) {
        try {
            ConnectionString connectionString = new ConnectionString("$uri");
            MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .build();
            MongoClient mongoClient = MongoClients.create(settings);
            System.out.println("Connection successful!");
            mongoClient.close();
        } catch (Exception e) {
            System.err.println("Connection failed: " + e.getMessage());
            System.exit(1);
        }
    }
}
"@
        
        $mongoTest | Out-File -FilePath "MongoConnectionTest.java" -Encoding UTF8
        
        Write-Host "✓ MongoDB Atlas connection test created" -ForegroundColor Green
        Write-Host "  Run: javac MongoConnectionTest.java && java MongoConnectionTest" -ForegroundColor Cyan
        
    } catch {
        Write-Host "✗ Failed to create MongoDB test: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Function to provide solutions
function Show-Solutions {
    Write-Host "`n=== Solutions ===" -ForegroundColor Green
    
    Write-Host "1. Network Issues:" -ForegroundColor Yellow
    Write-Host "   - Check your internet connection" -ForegroundColor White
    Write-Host "   - Try using a different DNS server (8.8.8.8 or 1.1.1.1)" -ForegroundColor White
    Write-Host "   - Check if your firewall is blocking MongoDB connections" -ForegroundColor White
    
    Write-Host "`n2. MongoDB Atlas Issues:" -ForegroundColor Yellow
    Write-Host "   - Verify your MongoDB Atlas cluster is running" -ForegroundColor White
    Write-Host "   - Check if your IP is whitelisted in MongoDB Atlas" -ForegroundColor White
    Write-Host "   - Verify your username and password are correct" -ForegroundColor White
    
    Write-Host "`n3. Use Local MongoDB:" -ForegroundColor Yellow
    Write-Host "   - Install MongoDB locally: https://www.mongodb.com/try/download/community" -ForegroundColor White
    Write-Host "   - Run with local profile: --spring.profiles.active=local" -ForegroundColor White
    
    Write-Host "`n4. Alternative Connection String:" -ForegroundColor Yellow
    Write-Host "   - Try using the direct connection string without DNS SRV:" -ForegroundColor White
    Write-Host "   - mongodb://anshtalreja025:ansh25@cluster0-shard-00-00.klor1l5.mongodb.net:27017,cluster0-shard-00-01.klor1l5.mongodb.net:27017,cluster0-shard-00-02.klor1l5.mongodb.net:27017/esign?ssl=true&replicaSet=atlas-xxxxx&authSource=admin" -ForegroundColor White
}

# Function to create alternative configuration
function Create-AlternativeConfig {
    Write-Host "`nCreating alternative MongoDB configuration..." -ForegroundColor Yellow
    
    $alternativeConfig = @"
# Alternative MongoDB Configuration (Direct Connection)
# Try this if DNS SRV resolution fails

# Option 1: Direct connection to cluster nodes
# spring.data.mongodb.uri=mongodb://anshtalreja025:ansh25@cluster0-shard-00-00.klor1l5.mongodb.net:27017,cluster0-shard-00-01.klor1l5.mongodb.net:27017,cluster0-shard-00-02.klor1l5.mongodb.net:27017/esign?ssl=true&replicaSet=atlas-xxxxx&authSource=admin&retryWrites=true&w=majority

# Option 2: Use local MongoDB
# spring.data.mongodb.uri=mongodb://localhost:27017/esign

# Option 3: Use MongoDB Atlas with different settings
# spring.data.mongodb.uri=mongodb+srv://anshtalreja025:ansh25@cluster0.klor1l5.mongodb.net/esign?retryWrites=true&w=majority&appName=Cluster0&directConnection=false&serverSelectionTimeoutMS=60000&connectTimeoutMS=60000&socketTimeoutMS=60000
"@
    
    $alternativeConfig | Out-File -FilePath "mongodb-alternative-config.txt" -Encoding UTF8
    Write-Host "✓ Alternative configuration saved to: mongodb-alternative-config.txt" -ForegroundColor Green
}

# Main execution
Write-Host "Starting diagnostics..." -ForegroundColor Cyan

# Test network connectivity
$networkOk = Test-NetworkConnectivity

if ($networkOk) {
    Write-Host "`n✓ Network connectivity is good" -ForegroundColor Green
} else {
    Write-Host "`n✗ Network connectivity issues detected" -ForegroundColor Red
}

# Test MongoDB Atlas status
Test-MongoDBAtlasStatus

# Show solutions
Show-Solutions

# Create alternative configuration
Create-AlternativeConfig

Write-Host "`n=== Quick Fix Commands ===" -ForegroundColor Green
Write-Host "1. Test with local profile: mvn spring-boot:run -Dspring.profiles.active=local" -ForegroundColor Cyan
Write-Host "2. Test network: ping cluster0.klor1l5.mongodb.net" -ForegroundColor Cyan
Write-Host "3. Test DNS: nslookup cluster0.klor1l5.mongodb.net" -ForegroundColor Cyan
Write-Host "4. Check firewall: netsh advfirewall firewall show rule name=all | findstr MongoDB" -ForegroundColor Cyan

Write-Host "`nDiagnostic complete! Check the output above for issues and solutions." -ForegroundColor Green
