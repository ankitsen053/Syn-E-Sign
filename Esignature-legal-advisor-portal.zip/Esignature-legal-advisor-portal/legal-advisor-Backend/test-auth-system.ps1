# Test Authentication System
Write-Host "=== Authentication System Test ===" -ForegroundColor Green

# Check if application is running
Write-Host "`n1. Checking application status..." -ForegroundColor Yellow
try {
    # Try to access a simple endpoint to check if app is running
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/signup" -Method POST -Headers @{"Content-Type"="application/json"} -Body '{"username":"test","email":"test@test.com","password":"test123","roles":["user"]}' -UseBasicParsing -TimeoutSec 5
    Write-Host "✅ Application is responding" -ForegroundColor Green
} catch {
    if ($_.Exception.Response.StatusCode -eq 400) {
        Write-Host "✅ Application is responding (400 is expected for invalid data)" -ForegroundColor Green
    } else {
        Write-Host "❌ Application is not responding" -ForegroundColor Red
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

# Test signup endpoint with proper data
Write-Host "`n2. Testing signup endpoint..." -ForegroundColor Yellow
try {
    $signupBody = @{
        username = "testuser"
        email = "test@example.com"
        password = "testpass123"
        roles = @("user")
    } | ConvertTo-Json

    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/signup" -Method POST -Headers @{"Content-Type"="application/json"} -Body $signupBody -UseBasicParsing
    Write-Host "✅ Signup successful" -ForegroundColor Green
    Write-Host "Response: $($response.Content)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Signup failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}

# Test login endpoint
Write-Host "`n3. Testing login endpoint..." -ForegroundColor Yellow
try {
    $loginBody = @{
        username = "testuser"
        password = "testpass123"
    } | ConvertTo-Json

    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/login" -Method POST -Headers @{"Content-Type"="application/json"} -Body $loginBody -UseBasicParsing
    Write-Host "✅ Login successful" -ForegroundColor Green
    Write-Host "Response: $($response.Content)" -ForegroundColor Gray
    
    # Extract token for further testing
    $responseData = $response.Content | ConvertFrom-Json
    if ($responseData.accessToken) {
        $token = $responseData.accessToken
        Write-Host "✅ JWT Token received" -ForegroundColor Green
        
        # Test dashboard endpoint with token
        Write-Host "`n4. Testing dashboard endpoint with token..." -ForegroundColor Yellow
        try {
            $dashboardResponse = Invoke-WebRequest -Uri "http://localhost:8081/api/dashboard/stats" -Method GET -Headers @{"Authorization"="Bearer $token"} -UseBasicParsing
            Write-Host "✅ Dashboard access successful" -ForegroundColor Green
            Write-Host "Dashboard Response: $($dashboardResponse.Content)" -ForegroundColor Gray
        } catch {
            Write-Host "❌ Dashboard access failed" -ForegroundColor Red
            Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
} catch {
    Write-Host "❌ Login failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    }
}

Write-Host "`n=== Test Complete ===" -ForegroundColor Green
