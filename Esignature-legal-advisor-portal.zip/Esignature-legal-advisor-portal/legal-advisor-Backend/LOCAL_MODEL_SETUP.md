# Local ChatGPT-2.V2-GGUF Model Integration Setup

This guide provides complete instructions for downloading and integrating the ChatGPT-2.V2-GGUF model locally for your legal advisor application.

## Prerequisites

### System Requirements
- **Operating System**: Windows 10/11, macOS, or Linux
- **RAM**: Minimum 8GB (16GB recommended)
- **Storage**: At least 10GB free space
- **CPU**: Multi-core processor (GPU support optional but recommended)

### Required Software
1. **Git** - For downloading the model
2. **Java 17+** - For running the Spring Boot application
3. **llama.cpp** - For running GGUF models locally

## Step 1: Download the Model

### Option A: Using the Setup Script (Recommended)

#### For Windows:
```bash
# Run the Windows batch script
setup-local-model.bat
```

#### For Linux/macOS:
```bash
# Make the script executable and run it
chmod +x setup-local-model.sh
./setup-local-model.sh
```

### Option B: Manual Download
```bash
# Create models directory
mkdir -p models
cd models

# Clone the model repository
git clone https://huggingface.co/mradermacher/ChatGPT-2.V2-GGUF

# Verify download
ls -la ChatGPT-2.V2-GGUF/
```

## Step 2: Install llama.cpp

### For Windows:
1. Download llama.cpp from: https://github.com/ggerganov/llama.cpp
2. Extract to `llama.cpp/` directory in your project root
3. Build the executable:
   ```bash
   cd llama.cpp
   make
   ```

### For Linux/macOS:
```bash
# Clone llama.cpp
git clone https://github.com/ggerganov/llama.cpp.git
cd llama.cpp

# Build
make

# For GPU support (optional)
make LLAMA_CUBLAS=1
```

## Step 3: Configure Application

### Update application.properties:
```properties
# Local Model Configuration (Primary - ChatGPT-2.V2-GGUF)
local.model.enabled=true
local.model.path=models/ChatGPT-2.V2-GGUF
local.model.executable=llama.cpp/main
local.model.max-tokens=4000
local.model.temperature=0.1
local.model.timeout.seconds=300

# AI Service Configuration
ai.service.provider=local
ai.service.enabled=true
ai.service.fallback.enabled=true
```

### Verify Model Files:
The model directory should contain:
```
models/ChatGPT-2.V2-GGUF/
├── config.json
├── pytorch_model.bin
├── tokenizer.json
├── tokenizer_config.json
└── *.gguf (model files)
```

## Step 4: Test the Integration

### 1. Start the Application:
```bash
cd legal-advisor-Backend
./mvnw spring-boot:run
```

### 2. Test Local Model Connection:
```bash
curl -X GET http://localhost:8081/api/ai/test-local-model
```

Expected response:
```json
{
  "success": true,
  "message": "Local ChatGPT-2.V2 connection successful",
  "model": "ChatGPT-2.V2-GGUF (Local)",
  "response": "Test response from the model"
}
```

### 3. Test Document Analysis:
```bash
curl -X POST http://localhost:8081/api/ai/analyze-text \
  -H "Content-Type: application/json" \
  -d '{"content": "This is a test legal document for analysis."}'
```

## Step 5: Performance Optimization

### Memory Optimization:
```properties
# Increase JVM heap size
-Xmx8g -Xms4g
```

### Model Configuration:
```properties
# Adjust based on your system capabilities
local.model.max-tokens=2000  # Reduce for faster responses
local.model.temperature=0.1  # Lower for more consistent results
local.model.timeout.seconds=600  # Increase for complex documents
```

## Troubleshooting

### Common Issues:

#### 1. Model Not Found
**Error**: `Model file not found in: models/ChatGPT-2.V2-GGUF`
**Solution**: 
- Verify the model was downloaded correctly
- Check the path in application.properties
- Ensure GGUF files exist in the model directory

#### 2. Executable Not Found
**Error**: `Model executable does not exist: llama.cpp/main`
**Solution**:
- Build llama.cpp: `cd llama.cpp && make`
- Verify the executable path in application.properties
- On Windows, use `llama.cpp/main.exe`

#### 3. Out of Memory
**Error**: `OutOfMemoryError` or slow performance
**Solution**:
- Reduce `max-tokens` in configuration
- Increase JVM heap size
- Use a smaller model variant if available

#### 4. Timeout Issues
**Error**: `Local model execution timed out`
**Solution**:
- Increase `timeout.seconds` in configuration
- Reduce document complexity
- Check system resources

### Performance Tips:

1. **Use GPU Acceleration** (if available):
   ```bash
   cd llama.cpp
   make LLAMA_CUBLAS=1  # For NVIDIA GPU
   make LLAMA_METAL=1   # For Apple Silicon
   ```

2. **Optimize Model Parameters**:
   ```properties
   local.model.temperature=0.1    # Lower for consistency
   local.model.max-tokens=2000    # Adjust based on needs
   ```

3. **Monitor System Resources**:
   - Use `htop` or Task Manager to monitor CPU/RAM usage
   - Adjust JVM heap size based on available memory

## API Endpoints

### Local Model Endpoints:
- **`GET /api/ai/test-local-model`** - Test local model connection
- **`POST /api/ai/analyze`** - Analyze uploaded document
- **`POST /api/ai/analyze-text`** - Analyze text content
- **`POST /api/ai/highlight-issues`** - Highlight legal issues
- **`POST /api/ai/risk-analysis`** - Perform risk analysis
- **`POST /api/ai/compliance-assessment`** - Assess compliance

### Professional Analysis:
- **`POST /api/ai/professional-analyze`** - Professional legal analysis
- **`POST /api/ai/professional-analyze-text`** - Professional text analysis

## Model Capabilities

The local ChatGPT-2.V2 model provides:

### Legal Analysis Features:
1. **Comprehensive Document Review**
2. **Critical Issue Detection**
3. **Risk Assessment**
4. **Compliance Analysis**
5. **Professional Recommendations**
6. **Legal Agreement Generation**

### Analysis Quality:
- **Senior Partner Level**: 25+ years experience simulation
- **Professional Legal Memorandum Format**
- **Critical Legal Issues**: Enforceability problems, missing terms
- **High-Risk Issues**: Ambiguous language, inadequate protections
- **Strategic Recommendations**: Specific improvements with sample language

## Security Considerations

1. **Local Processing**: All analysis happens locally - no data sent to external APIs
2. **Data Privacy**: Documents remain on your system
3. **No Internet Required**: Works completely offline after setup
4. **Customizable**: Full control over model parameters and prompts

## Support

For issues with local model integration:

1. Check the application logs for detailed error messages
2. Verify model files and executable paths
3. Test the connection endpoint
4. Review system resource usage
5. Check llama.cpp documentation for model-specific issues

## Next Steps

After successful setup:

1. **Test with Real Documents**: Upload actual legal documents for analysis
2. **Fine-tune Parameters**: Adjust model settings based on your needs
3. **Monitor Performance**: Track response times and quality
4. **Scale as Needed**: Consider GPU acceleration for better performance

The system now uses the local ChatGPT-2.V2 model as the primary AI service for all legal analysis and document processing tasks, providing professional-grade legal advisory services with complete data privacy and offline capability.


















