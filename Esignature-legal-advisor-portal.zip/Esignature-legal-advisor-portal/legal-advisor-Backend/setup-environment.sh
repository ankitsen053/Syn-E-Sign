#!/bin/bash

echo "Setting up Legal Advisor Portal Backend Environment..."

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "ERROR: Java is not installed or not in PATH"
    echo "Please install Java 17 or higher"
    exit 1
fi

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "ERROR: Maven is not installed or not in PATH"
    echo "Please install Apache Maven"
    exit 1
fi

echo "Java and Maven are installed correctly."

# Create necessary directories
mkdir -p documents
mkdir -p documents-dev
mkdir -p uploads/documents
mkdir -p uploads/documents-dev
mkdir -p logs

echo "Created necessary directories."

# Set environment variables for development
export SPRING_PROFILES_ACTIVE=dev
export MONGODB_URI="mongodb+srv://anshtalreja025:ansh25@cluster0.klor1l5.mongodb.net/esign-dev?retryWrites=true&w=majority&appName=Cluster0"
export JWT_SECRET="dev-jwt-secret-key-for-development-only-not-for-production"
export OPENAI_API_KEY="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"
export GEMINI_API_KEY="AIzaSyAvVL2jDtrJapX5EjCFQxJKno_Y0DiLJJQ"
export MAIL_USERNAME="anshtalreja025@gmail.com"
export MAIL_PASSWORD="lqep yfiw brrq xmmc"
export GOOGLE_CLIENT_ID="YOUR_GOOGLE_CLIENT_ID"
export GOOGLE_CLIENT_SECRET="YOUR_GOOGLE_CLIENT_SECRET"
export CORS_ORIGINS="http://localhost:3000,http://localhost:5173,http://127.0.0.1:3000,http://127.0.0.1:5173"

echo "Environment variables set for development."

# Clean and compile the project
echo "Cleaning and compiling the project..."
mvn clean compile -DskipTests

if [ $? -ne 0 ]; then
    echo "ERROR: Compilation failed"
    exit 1
fi

echo "Compilation successful!"

# Run the application
echo "Starting the application..."
echo ""
echo "========================================"
echo "Legal Advisor Portal Backend Starting..."
echo "========================================"
echo ""
echo "Server will be available at: http://localhost:8081"
echo "API Documentation: http://localhost:8081/swagger-ui.html"
echo "Health Check: http://localhost:8081/actuator/health"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

mvn spring-boot:run -Dspring-boot.run.profiles=dev





















