# 🚀 Quick Setup Instructions - ChatGPT-2.V2 Legal Advisor

## ⚠️ Current Issue
The application failed to start because the HuggingFace API key is not configured. Here's how to fix it:

## 🔑 Step 1: Get HuggingFace API Key (2 minutes)

### Option A: Free HuggingFace Account
1. Go to [https://huggingface.co/](https://huggingface.co/)
2. Click "Sign Up" and create a free account
3. Go to your profile → Settings → Access Tokens
4. Click "New token"
5. Name it "Legal Advisor" and select "Read" permissions
6. Copy the token (starts with `hf_...`)

### Option B: Use Existing Account
1. Sign in to [https://huggingface.co/](https://huggingface.co/)
2. Go to Settings → Access Tokens
3. Create a new token or use an existing one
4. Copy the token

## ⚙️ Step 2: Configure the Application

### Update application.properties:
1. Open `src/main/resources/application.properties`
2. Find this line:
   ```properties
   huggingface.api.key=hf_placeholder_key_replace_with_your_actual_key
   ```
3. Replace it with your actual API key:
   ```properties
   huggingface.api.key=hf_your_actual_api_key_here
   ```

### Example:
```properties
huggingface.api.key=hf_abc123def456ghi789jkl012mno345pqr678stu901vwx234yz
```

## 🚀 Step 3: Start the Application

```bash
cd legal-advisor-Backend
./mvnw spring-boot:run
```

## ✅ Step 4: Test the Integration

### Test 1: Check if application starts
You should see:
```
Started LegalAdvisorApplication in X.XXX seconds
```

### Test 2: Test HuggingFace connection
Open your browser and go to:
```
http://localhost:8081/api/ai/test-huggingface
```

Expected response:
```json
{
  "success": true,
  "message": "HuggingFace ChatGPT-2.V2 connection successful",
  "model": "mradermacher/ChatGPT-2.V2-GGUF",
  "response": "Test response from the model"
}
```

### Test 3: Test legal analysis
```bash
curl -X POST http://localhost:8081/api/ai/analyze-text \
  -H "Content-Type: application/json" \
  -d '{"content": "This agreement between Company A and Company B shall be governed by the laws of India."}'
```

## 🎯 What You'll Get

Once configured, your legal advisor will provide:

### Professional Legal Analysis:
- **Executive Summary** with commercial context
- **Legal Structure Analysis** with enforceability assessment
- **Risk Assessment** with detailed liability analysis
- **Compliance Analysis** with regulatory requirements
- **Strategic Recommendations** with sample language

### Enhanced Issue Detection:
- **Critical Legal Issues** requiring immediate attention
- **High-Risk Issues** with significant legal exposure
- **Moderate Issues** for standard practice improvements
- **Minor Issues** for drafting improvements

### Legal Agreement Generation:
- **Professional legal language** and terminology
- **Essential clauses** for enforceability
- **Dispute resolution** mechanisms
- **Governing law** and jurisdiction clauses

## 🔧 Alternative: Use Gemini (If HuggingFace doesn't work)

If you have issues with HuggingFace, you can temporarily use Gemini:

1. Update `application.properties`:
   ```properties
   ai.service.provider=gemini
   ```

2. The Gemini API key is already configured in your application

## 🆘 Troubleshooting

### Issue 1: "Could not resolve placeholder 'huggingface.api.key'"
**Solution**: Make sure you replaced the placeholder with your actual API key

### Issue 2: "HuggingFace connection failed"
**Solution**: 
- Check your internet connection
- Verify the API key is correct
- Make sure the token has "Read" permissions

### Issue 3: Application won't start
**Solution**:
- Check the console for error messages
- Verify all configuration values are correct
- Make sure MongoDB is running

## 📞 Need Help?

1. Check the application logs in the console
2. Test the connection endpoint first
3. Verify your API key configuration
4. Review the troubleshooting section above

## 🎉 Success!

Once you see the test endpoint working, your ChatGPT-2.V2 legal advisor is ready to provide professional-grade legal analysis for all your documents!

The system will now use the ChatGPT-2.V2 model for:
- Document analysis
- Issue detection
- Risk assessment
- Compliance review
- Agreement generation

All with the quality and depth expected by professional lawyers! 🏆


















