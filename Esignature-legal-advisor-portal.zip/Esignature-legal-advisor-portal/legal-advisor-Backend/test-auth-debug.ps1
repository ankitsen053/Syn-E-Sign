# Comprehensive Authentication Debug Test
Write-Host "=== Authentication Debug Test ===" -ForegroundColor Green

# Test 1: Check if backend is running
Write-Host "`n1. Checking backend status..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/signup-status" -Method GET -UseBasicParsing
    Write-Host "✅ Backend is running" -ForegroundColor Green
    $status = $response.Content | ConvertFrom-Json
    Write-Host "   - Development Mode: $($status.developmentMode)" -ForegroundColor Gray
    Write-Host "   - Email Service: $($status.emailServiceEnabled)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Backend is not running or not accessible" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test 2: Test login with correct credentials
Write-Host "`n2. Testing login with testuser2..." -ForegroundColor Yellow
try {
    $loginBody = @{
        username = "testuser2"
        password = "testpass123"
    } | ConvertTo-Json

    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/login" -Method POST -Headers @{"Content-Type"="application/json"} -Body $loginBody -UseBasicParsing
    Write-Host "✅ Login successful" -ForegroundColor Green
    $loginData = $response.Content | ConvertFrom-Json
    Write-Host "   - Username: $($loginData.username)" -ForegroundColor Gray
    Write-Host "   - Token Length: $($loginData.token.Length)" -ForegroundColor Gray
    Write-Host "   - Token Type: $($loginData.type)" -ForegroundColor Gray
    
    $token = $loginData.token
} catch {
    Write-Host "❌ Login failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response: $responseBody" -ForegroundColor Red
    }
    exit 1
}

# Test 3: Test profile endpoint with token
Write-Host "`n3. Testing profile endpoint..." -ForegroundColor Yellow
try {
    $profileResponse = Invoke-WebRequest -Uri "http://localhost:8081/api/auth/profile" -Method GET -Headers @{"Authorization"="Bearer $token"; "Cache-Control"="no-cache"} -UseBasicParsing
    Write-Host "✅ Profile fetch successful" -ForegroundColor Green
    $profileData = $profileResponse.Content | ConvertFrom-Json
    Write-Host "   - User ID: $($profileData.id)" -ForegroundColor Gray
    Write-Host "   - Email: $($profileData.email)" -ForegroundColor Gray
    Write-Host "   - Email Verified: $($profileData.emailVerified)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Profile fetch failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response: $responseBody" -ForegroundColor Red
    }
}

# Test 4: Test dashboard endpoint
Write-Host "`n4. Testing dashboard endpoint..." -ForegroundColor Yellow
try {
    $dashboardResponse = Invoke-WebRequest -Uri "http://localhost:8081/api/dashboard/stats" -Method GET -Headers @{"Authorization"="Bearer $token"; "Cache-Control"="no-cache"} -UseBasicParsing
    Write-Host "✅ Dashboard fetch successful" -ForegroundColor Green
    $dashboardData = $dashboardResponse.Content | ConvertFrom-Json
    Write-Host "   - Documents Generated: $($dashboardData.documentsGenerated.value)" -ForegroundColor Gray
    Write-Host "   - Documents Analyzed: $($dashboardData.documentsAnalyzed.value)" -ForegroundColor Gray
} catch {
    Write-Host "❌ Dashboard fetch failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 5: Test token format
Write-Host "`n5. Validating token format..." -ForegroundColor Yellow
$tokenParts = $token.Split('.')
if ($tokenParts.Length -eq 3) {
    Write-Host "✅ Token format is valid (3 parts)" -ForegroundColor Green
    Write-Host "   - Header length: $($tokenParts[0].Length)" -ForegroundColor Gray
    Write-Host "   - Payload length: $($tokenParts[1].Length)" -ForegroundColor Gray
    Write-Host "   - Signature length: $($tokenParts[2].Length)" -ForegroundColor Gray
} else {
    Write-Host "❌ Token format is invalid" -ForegroundColor Red
    Write-Host "   - Expected 3 parts, got $($tokenParts.Length)" -ForegroundColor Red
}

Write-Host "`n=== Authentication Debug Test Complete ===" -ForegroundColor Green
Write-Host "`nIf all tests passed, the backend is working correctly." -ForegroundColor Cyan
Write-Host "The issue might be in the frontend token handling or timing." -ForegroundColor Cyan
