# KYC Verification System Guide

## Overview

The KYC (Know Your Customer) verification system provides real-time verification of PAN and Aadhaar documents using multiple third-party API providers. The system includes fallback mechanisms and mock verification for development purposes.

## Features

- **Multi-Provider Support**: Integration with Surepass, Karza, Signzy, and Setu APIs
- **Real-time Verification**: Instant verification results
- **Fallback Mechanism**: Automatic fallback to mock verification when APIs are unavailable
- **Bulk Verification**: Verify both PAN and Aadhaar in a single request
- **Security**: Document number masking in logs for privacy
- **Error Handling**: Comprehensive error handling and logging

## API Endpoints

### 1. Health Check
```
GET /api/kyc/health
```
Returns the health status of the KYC service.

**Response:**
```json
{
  "status": "UP",
  "service": "KYC Verification Service",
  "timestamp": 1703123456789,
  "message": "KYC service is operational"
}
```

### 2. Available Providers
```
GET /api/kyc/providers
```
Returns the list of available KYC API providers.

**Response:**
```json
{
  "providers": ["Surepass", "Karza", "Signzy", "Setu"],
  "message": "Available KYC API providers",
  "note": "Mock verification is used when APIs are not configured"
}
```

### 3. PAN Verification
```
POST /api/kyc/verify/pan
```

**Request Body:**
```json
{
  "panNumber": "ABCDE1234F",
  "documentUrl": "https://example.com/pan-document.pdf"
}
```

**Response:**
```json
{
  "success": true,
  "message": "PAN verification completed successfully",
  "apiProvider": "Mock",
  "verificationData": {
    "success": true,
    "apiProvider": "Mock",
    "documentType": "PAN",
    "documentNumber": "ABCDE1234F",
    "name": "John Doe",
    "fatherName": "James Doe",
    "dateOfBirth": "1990-01-01",
    "panNumber": "ABCDE1234F",
    "verificationMessage": "Mock verification successful for development purposes"
  },
  "documentUrl": "https://example.com/pan-document.pdf"
}
```

### 4. Aadhaar Verification
```
POST /api/kyc/verify/aadhaar
```

**Request Body:**
```json
{
  "aadharNumber": "123456789012",
  "documentUrl": "https://example.com/aadhaar-document.pdf"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Aadhaar verification completed successfully",
  "apiProvider": "Mock",
  "verificationData": {
    "success": true,
    "apiProvider": "Mock",
    "documentType": "AADHAAR",
    "documentNumber": "123456789012",
    "name": "John Doe",
    "fatherName": "James Doe",
    "dateOfBirth": "1990-01-01",
    "aadhaarNumber": "123456789012",
    "address": "123 Main Street, City, State - 123456",
    "verificationMessage": "Mock verification successful for development purposes"
  },
  "documentUrl": "https://example.com/aadhaar-document.pdf"
}
```

### 5. Bulk Verification
```
POST /api/kyc/verify/bulk
```

**Request Body:**
```json
{
  "panNumber": "ABCDE1234F",
  "aadhaarNumber": "123456789012",
  "panDocumentUrl": "https://example.com/pan-document.pdf",
  "aadhaarDocumentUrl": "https://example.com/aadhaar-document.pdf"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Bulk verification completed",
  "panVerification": {
    "success": true,
    "apiProvider": "Mock",
    "documentType": "PAN",
    "documentNumber": "ABCDE1234F",
    "name": "John Doe",
    "fatherName": "James Doe",
    "dateOfBirth": "1990-01-01",
    "panNumber": "ABCDE1234F"
  },
  "aadhaarVerification": {
    "success": true,
    "apiProvider": "Mock",
    "documentType": "AADHAAR",
    "documentNumber": "123456789012",
    "name": "John Doe",
    "fatherName": "James Doe",
    "dateOfBirth": "1990-01-01",
    "aadhaarNumber": "123456789012",
    "address": "123 Main Street, City, State - 123456"
  }
}
```

## Configuration

### Application Properties

Add the following configuration to `application.properties`:

```properties
# KYC API Configuration
kyc.surepass.api.key=${SURPASS_API_KEY:}
kyc.karza.api.key=${KARZA_API_KEY:}
kyc.signzy.api.key=${SIGNZY_API_KEY:}
kyc.setu.api.key=${SETU_API_KEY:}

# KYC Service Configuration
kyc.service.enabled=true
kyc.service.timeout.seconds=10
kyc.service.fallback.enabled=true
kyc.service.mock.enabled=true
```

### Environment Variables

Set the following environment variables for production:

```bash
# Surepass API Key
export SURPASS_API_KEY=your_surepass_api_key

# Karza API Key
export KARZA_API_KEY=your_karza_api_key

# Signzy API Key
export SIGNZY_API_KEY=your_signzy_api_key

# Setu API Key
export SETU_API_KEY=your_setu_api_key
```

## Third-Party API Providers

### 1. Surepass
- **Website**: https://surepass.io/
- **API Documentation**: https://surepass.io/api-docs
- **Features**: PAN, Aadhaar, GST verification
- **Pricing**: Free tier available, paid plans for higher volume

### 2. Karza
- **Website**: https://karza.in/
- **API Documentation**: https://karza.in/api-docs
- **Features**: Comprehensive KYC APIs (PAN, Aadhaar, GST, Voter ID, DL)
- **Pricing**: Free tier available, paid plans for higher volume

### 3. Signzy
- **Website**: https://signzy.com/
- **API Documentation**: https://signzy.com/api-docs
- **Features**: PAN & Aadhaar verification
- **Pricing**: Free tier available, paid plans for higher volume

### 4. Setu
- **Website**: https://setu.co/
- **API Documentation**: https://setu.co/api-docs
- **Features**: Aadhaar OTP & PAN verification
- **Pricing**: Free tier available, paid plans for higher volume

## Implementation Details

### Service Architecture

The KYC system consists of:

1. **KycService**: Core service handling API integrations
2. **KycController**: REST endpoints for verification
3. **VerificationService**: Enhanced with KYC integration
4. **VerificationStatus**: Entity with additional verification details

### Fallback Mechanism

The system implements a robust fallback mechanism:

1. **Primary**: Try multiple APIs in parallel with timeout
2. **Secondary**: Use the first successful response
3. **Fallback**: Mock verification for development/testing
4. **Error Handling**: Comprehensive logging and error reporting

### Security Features

- **Document Masking**: PAN and Aadhaar numbers are masked in logs
- **API Key Management**: Environment variable-based configuration
- **Request Validation**: Input validation for document formats
- **Error Handling**: Secure error messages without exposing sensitive data

## Testing

### Running Tests

Use the provided test script:

```powershell
.\test-kyc-verification.ps1
```

### Manual Testing

1. **Start the application**:
   ```bash
   mvn spring-boot:run
   ```

2. **Test health check**:
   ```bash
   curl http://localhost:8081/api/kyc/health
   ```

3. **Test PAN verification**:
   ```bash
   curl -X POST http://localhost:8081/api/kyc/verify/pan \
     -H "Content-Type: application/json" \
     -d '{"panNumber":"ABCDE1234F","documentUrl":"https://example.com/pan.pdf"}'
   ```

4. **Test Aadhaar verification**:
   ```bash
   curl -X POST http://localhost:8081/api/kyc/verify/aadhaar \
     -H "Content-Type: application/json" \
     -d '{"aadharNumber":"123456789012","documentUrl":"https://example.com/aadhaar.pdf"}'
   ```

## Integration with Existing System

### Enhanced Verification Flow

The existing verification system has been enhanced:

1. **Real-time Verification**: KYC verification happens immediately
2. **Status Updates**: Verification status is updated in real-time
3. **Fallback Support**: Manual review if KYC fails
4. **Detailed Logging**: Comprehensive audit trail

### Database Schema Updates

The `VerificationStatus` entity has been enhanced with:

- `panVerificationDetails`: Additional details about PAN verification
- `aadharVerificationDetails`: Additional details about Aadhaar verification

## Production Deployment

### Prerequisites

1. **API Keys**: Obtain API keys from chosen providers
2. **SSL Certificate**: Configure HTTPS for production
3. **Rate Limiting**: Implement rate limiting for API calls
4. **Monitoring**: Set up monitoring and alerting

### Configuration Steps

1. **Set Environment Variables**:
   ```bash
   export SURPASS_API_KEY=your_key
   export KARZA_API_KEY=your_key
   export SIGNZY_API_KEY=your_key
   export SETU_API_KEY=your_key
   ```

2. **Update Application Properties**:
   ```properties
   kyc.service.enabled=true
   kyc.service.mock.enabled=false
   ```

3. **Configure Logging**:
   ```properties
   logging.level.com.esign.legal_advisor.service.KycService=INFO
   ```

### Monitoring

Monitor the following metrics:

- API response times
- Success/failure rates
- API provider usage
- Error rates and types
- Verification completion times

## Troubleshooting

### Common Issues

1. **API Key Issues**:
   - Verify API keys are correctly set
   - Check API key permissions
   - Ensure API keys are active

2. **Network Issues**:
   - Check internet connectivity
   - Verify firewall settings
   - Test API endpoints directly

3. **Timeout Issues**:
   - Increase timeout values
   - Check network latency
   - Monitor API provider status

### Debug Mode

Enable debug logging:

```properties
logging.level.com.esign.legal_advisor.service.KycService=DEBUG
```

### Error Codes

- `400`: Invalid input format
- `401`: Unauthorized (API key issues)
- `429`: Rate limit exceeded
- `500`: Internal server error
- `503`: Service unavailable

## Support

For issues and questions:

1. Check the application logs
2. Review API provider documentation
3. Test with the provided test script
4. Contact the development team

## License

This KYC verification system is part of the Legal Advisor application and follows the same licensing terms.
