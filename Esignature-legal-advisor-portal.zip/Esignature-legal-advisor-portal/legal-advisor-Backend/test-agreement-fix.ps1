Write-Host "=== Agreement Creation Fix Test ===" -ForegroundColor Green
Write-Host ""

# Test 1: Health check
Write-Host "1. Testing application health..." -ForegroundColor Yellow
try {
    $healthResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/test/health" -Method GET -TimeoutSec 10
    Write-Host "Success: Health check passed: $healthResponse" -ForegroundColor Green
}
catch {
    Write-Host "Error: Health check failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Please ensure the application is running on port 8081" -ForegroundColor Yellow
    exit 1
}

Write-Host ""

# Test 2: Agreement creation test endpoint
Write-Host "2. Testing agreement creation fix..." -ForegroundColor Yellow
try {
    $testResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/test/agreement" -Method POST -ContentType "application/json" -TimeoutSec 30
    
    if ($testResponse.success) {
        Write-Host "Success: Agreement creation test PASSED!" -ForegroundColor Green
        Write-Host "   Message: $($testResponse.message)" -ForegroundColor Cyan
    }
    else {
        Write-Host "Error: Agreement creation test FAILED!" -ForegroundColor Red
        Write-Host "   Error: $($testResponse.message)" -ForegroundColor Red
    }
}
catch {
    Write-Host "Error: Agreement creation test ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""

# Test 3: Original AI endpoint
Write-Host "3. Testing original AI create endpoint..." -ForegroundColor Yellow
$requestBody = @{
    type = "Service Agreement"
    partyA = "Company A"
    partyB = "Company B"
    terms = "Test terms for validation"
} | ConvertTo-Json

try {
    $aiResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/create" -Method POST -Body $requestBody -ContentType "application/json" -TimeoutSec 30
    
    if ($aiResponse.success) {
        Write-Host "Success: Original AI endpoint WORKING!" -ForegroundColor Green
        Write-Host "   Document length: $($aiResponse.documentLength) characters" -ForegroundColor Cyan
        Write-Host "   Processing time: $($aiResponse.processingTime)ms" -ForegroundColor Cyan
    }
    else {
        Write-Host "Error: Original AI endpoint failed" -ForegroundColor Red
    }
}
catch {
    Write-Host "Error: Original AI endpoint ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== Test Complete ===" -ForegroundColor Green
Write-Host ""
Write-Host "Summary of fixes applied:" -ForegroundColor Yellow
Write-Host "1. Enabled AI service fallback (ai.service.fallback.enabled=true)" -ForegroundColor Cyan
Write-Host "2. Enabled Gemini API as backup (gemini.api.enabled=true)" -ForegroundColor Cyan
Write-Host "3. Improved error handling in AiService" -ForegroundColor Cyan
Write-Host "4. Enhanced OpenAI configuration validation" -ForegroundColor Cyan
Write-Host "5. Added test endpoint for validation" -ForegroundColor Cyan
Write-Host ""
Write-Host "The 'Failed to create agreement' error should now be resolved!" -ForegroundColor Green
