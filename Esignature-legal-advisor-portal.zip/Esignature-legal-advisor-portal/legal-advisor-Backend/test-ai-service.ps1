Write-Host "Testing AI Service Endpoints..." -ForegroundColor Yellow
Write-Host "==================================================" -ForegroundColor Cyan

# Test 1: Check AI Service Status
Write-Host "1. Testing AI Service Status..." -ForegroundColor Green
try {
    $statusResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/status" -Method GET -TimeoutSec 10
    Write-Host "   Status: $($statusResponse.status)" -ForegroundColor Green
    Write-Host "   Spring AI Available: $($statusResponse.springAiAvailable)" -ForegroundColor Green
    Write-Host "   Version: $($statusResponse.version)" -ForegroundColor Green
} catch {
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: Test Agreement Generation
Write-Host "`n2. Testing Agreement Generation..." -ForegroundColor Green
try {
    $agreementData = @{
        type = "Service Agreement"
        partyA = "Company ABC"
        partyB = "Client XYZ"
        terms = "Standard service terms"
    } | ConvertTo-Json

    $agreementResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/generate" -Method POST -ContentType "application/json" -Body $agreementData -TimeoutSec 30
    Write-Host "   Success: $($agreementResponse.success)" -ForegroundColor Green
    if ($agreementResponse.success) {
        Write-Host "   Document Length: $($agreementResponse.document.Length) characters" -ForegroundColor Green
    } else {
        Write-Host "   Error: $($agreementResponse.error)" -ForegroundColor Red
    }
} catch {
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Test Document Analysis
Write-Host "`n3. Testing Document Analysis..." -ForegroundColor Green
try {
    $testContent = "This is a test legal document for analysis. It contains standard legal terms and conditions."
    $analysisData = $testContent | ConvertTo-Json

    $analysisResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/ai/analyze" -Method POST -ContentType "application/json" -Body $analysisData -TimeoutSec 30
    Write-Host "   Success: $($analysisResponse.success)" -ForegroundColor Green
    if ($analysisResponse.success) {
        Write-Host "   Analysis Length: $($analysisResponse.analysis.Length) characters" -ForegroundColor Green
        Write-Host "   Issues Length: $($analysisResponse.issues.Length) characters" -ForegroundColor Green
    } else {
        Write-Host "   Error: $($analysisResponse.error)" -ForegroundColor Red
    }
} catch {
    Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`nAI Service Testing Completed!" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
