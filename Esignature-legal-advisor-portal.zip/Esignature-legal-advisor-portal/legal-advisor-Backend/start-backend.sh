#!/bin/bash

echo "Starting Legal Advisor Portal Backend..."

# Set environment variables
export SPRING_PROFILES_ACTIVE=dev
export MONGODB_URI="mongodb+srv://anshtalreja025:ansh25@cluster0.klor1l5.mongodb.net/esign-dev?retryWrites=true&w=majority&appName=Cluster0"
export JWT_SECRET="dev-jwt-secret-key-for-development-only-not-for-production"
export OPENAI_API_KEY="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"
export GEMINI_API_KEY="AIzaSyAvVL2jDtrJapX5EjCFQxJKno_Y0DiLJJQ"
export MAIL_USERNAME="anshtalreja025@gmail.com"
export MAIL_PASSWORD="lqep yfiw brrq xmmc"
export CORS_ORIGINS="http://localhost:3000,http://localhost:5173,http://127.0.0.1:3000,http://127.0.0.1:5173"

echo "Environment variables set."

# Create directories
mkdir -p documents
mkdir -p documents-dev
mkdir -p uploads/documents
mkdir -p uploads/documents-dev
mkdir -p logs

echo "Directories created."

# Check if Java is available
if ! command -v java &> /dev/null; then
    echo "ERROR: Java is not installed or not in PATH"
    echo "Please install Java 17 or higher"
    exit 1
fi

echo "Java is available."

# Try to run with Maven first
if command -v mvn &> /dev/null; then
    echo "Maven found, using Maven to start the application..."
    mvn spring-boot:run -Dspring-boot.run.profiles=dev
else
    echo "Maven not found, trying to run with Java directly..."
    echo ""
    echo "========================================"
    echo "Legal Advisor Portal Backend"
    echo "========================================"
    echo ""
    echo "To run this application, you need either:"
    echo "1. Maven installed and in PATH, or"
    echo "2. A compiled JAR file"
    echo ""
    echo "Please install Maven or compile the project first."
    echo ""
    read -p "Press Enter to continue..."
fi






















