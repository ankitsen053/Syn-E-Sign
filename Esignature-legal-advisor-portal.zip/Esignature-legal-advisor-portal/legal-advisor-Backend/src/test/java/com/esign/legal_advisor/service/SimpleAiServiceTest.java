package com.esign.legal_advisor.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SimpleAiServiceTest {

    @Test
    void testAnalyzeDocument() {
        // Create AiService instance directly
        AiService aiService = new AiService();

        // Test document analysis
        String testContent = "This is a test legal document for analysis. It contains various legal terms and conditions.";

        String result = aiService.analyzeDocument(testContent);

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("DOCUMENT ANALYSIS"));

        System.out.println("✅ Document Analysis Test PASSED");
        System.out.println("Document Analysis Result:");
        System.out.println(result);
        System.out.println("==================================================");
    }

    @Test
    void testHighlightIssues() {
        // Create AiService instance directly
        AiService aiService = new AiService();

        // Test issue highlighting
        String testContent = "This agreement is between Party A and Party B. The terms are vague and unclear.";

        String result = aiService.highlightIssues(testContent);

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("LEGAL ISSUES"));

        System.out.println("✅ Issue Highlighting Test PASSED");
        System.out.println("Issue Highlighting Result:");
        System.out.println(result);
        System.out.println("==================================================");
    }

    @Test
    void testPerformRiskAnalysis() {
        // Create AiService instance directly
        AiService aiService = new AiService();

        // Test risk analysis
        String testContent = "This contract involves significant financial obligations and potential liabilities.";

        String result = aiService.performRiskAnalysis(testContent);

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("RISK ANALYSIS"));

        System.out.println("✅ Risk Analysis Test PASSED");
        System.out.println("Risk Analysis Result:");
        System.out.println(result);
        System.out.println("==================================================");
    }

    @Test
    void testAssessCompliance() {
        // Create AiService instance directly
        AiService aiService = new AiService();

        // Test compliance assessment
        String testContent = "This document must comply with Indian contract law and data protection regulations.";

        String result = aiService.assessCompliance(testContent, "IN");

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("COMPLIANCE ASSESSMENT"));

        System.out.println("✅ Compliance Assessment Test PASSED");
        System.out.println("Compliance Assessment Result:");
        System.out.println(result);
        System.out.println("==================================================");
    }

    @Test
    void testGenerateAgreement() {
        // Create AiService instance directly
        AiService aiService = new AiService();

        // Test agreement generation
        String result = aiService.generateAgreement("NDA", "Company A", "Company B",
                "Confidential information sharing");

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("LEGAL AGREEMENT"));
        assertTrue(result.contains("NDA"));
        assertTrue(result.contains("Company A"));
        assertTrue(result.contains("Company B"));

        System.out.println("✅ Agreement Generation Test PASSED");
        System.out.println("Generated Agreement:");
        System.out.println(result);
        System.out.println("==================================================");
    }

    @Test
    void testEmptyContent() {
        // Create AiService instance directly
        AiService aiService = new AiService();

        // Test with empty content
        String result = aiService.analyzeDocument("");

        assertNotNull(result);
        assertTrue(result.length() > 0);

        System.out.println("✅ Empty Content Test PASSED");
        System.out.println("Empty Content Analysis Result:");
        System.out.println(result);
        System.out.println("==================================================");
    }

    @Test
    void testNullContent() {
        // Create AiService instance directly
        AiService aiService = new AiService();

        // Test with null content
        String result = aiService.analyzeDocument(null);

        assertNotNull(result);
        assertTrue(result.length() > 0);

        System.out.println("✅ Null Content Test PASSED");
        System.out.println("Null Content Analysis Result:");
        System.out.println(result);
        System.out.println("==================================================");
    }

    @Test
    void testComprehensiveDocumentAnalysis() {
        // Create AiService instance directly
        AiService aiService = new AiService();

        // Test comprehensive document analysis
        String testContent = """
                AGREEMENT BETWEEN PARTIES

                This agreement is made between Company A and Company B for the purpose of
                establishing a business relationship. The terms and conditions are as follows:

                1. Company A will provide services to Company B
                2. Payment terms are net 30 days
                3. This agreement is valid for one year
                4. Either party may terminate with 30 days notice

                The parties agree to maintain confidentiality of all proprietary information.
                """;

        // Test all analysis methods
        String analysis = aiService.analyzeDocument(testContent);
        String issues = aiService.highlightIssues(testContent);
        String riskAnalysis = aiService.performRiskAnalysis(testContent);
        String compliance = aiService.assessCompliance(testContent, "IN");

        assertNotNull(analysis);
        assertNotNull(issues);
        assertNotNull(riskAnalysis);
        assertNotNull(compliance);

        System.out.println("✅ Comprehensive Document Analysis Test PASSED");
        System.out.println("All AI analysis methods are working correctly!");
        System.out.println("==================================================");
    }
}
