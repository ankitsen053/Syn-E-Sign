package com.esign.legal_advisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LegalAdvisorApplicationTests {

	@Test
	void contextLoads() {
	}

}
