package com.esign.legal_advisor.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(properties = {
        "spring.data.mongodb.uri=mongodb://localhost:27017/test",
        "server.port=0"
})
public class AiServiceTest {

    private AiService aiService;

    @BeforeEach
    void setUp() {
        aiService = new AiService();
    }

    @Test
    void testAnalyzeDocument() {
        // Test document analysis
        String testContent = "This is a test legal document for analysis. It contains various legal terms and conditions.";

        String result = aiService.analyzeDocument(testContent);

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("DOCUMENT ANALYSIS"));

        System.out.println("Document Analysis Result:");
        System.out.println(result);
    }

    @Test
    void testHighlightIssues() {
        // Test issue highlighting
        String testContent = "This agreement is between Party A and Party B. The terms are vague and unclear.";

        String result = aiService.highlightIssues(testContent);

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("LEGAL ISSUES"));

        System.out.println("Issue Highlighting Result:");
        System.out.println(result);
    }

    @Test
    void testPerformRiskAnalysis() {
        // Test risk analysis
        String testContent = "This contract involves significant financial obligations and potential liabilities.";

        String result = aiService.performRiskAnalysis(testContent);

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("RISK ANALYSIS"));

        System.out.println("Risk Analysis Result:");
        System.out.println(result);
    }

    @Test
    void testAssessCompliance() {
        // Test compliance assessment
        String testContent = "This document must comply with Indian contract law and data protection regulations.";

        String result = aiService.assessCompliance(testContent, "IN");

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("COMPLIANCE ASSESSMENT"));

        System.out.println("Compliance Assessment Result:");
        System.out.println(result);
    }

    @Test
    void testGenerateAgreement() {
        // Test agreement generation
        String result = aiService.generateAgreement("NDA", "Company A", "Company B",
                "Confidential information sharing");

        assertNotNull(result);
        assertTrue(result.length() > 0);
        assertTrue(result.contains("LEGAL AGREEMENT"));
        assertTrue(result.contains("NDA"));
        assertTrue(result.contains("Company A"));
        assertTrue(result.contains("Company B"));

        System.out.println("Generated Agreement:");
        System.out.println(result);
    }

    @Test
    void testEmptyContent() {
        // Test with empty content
        String result = aiService.analyzeDocument("");

        assertNotNull(result);
        assertTrue(result.length() > 0);

        System.out.println("Empty Content Analysis Result:");
        System.out.println(result);
    }

    @Test
    void testNullContent() {
        // Test with null content
        String result = aiService.analyzeDocument(null);

        assertNotNull(result);
        assertTrue(result.length() > 0);

        System.out.println("Null Content Analysis Result:");
        System.out.println(result);
    }
}
