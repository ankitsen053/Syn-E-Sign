package com.esign.legal_advisor.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

@Service
public class KycService {

    private static final Logger logger = LoggerFactory.getLogger(KycService.class);

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    // API Configuration - These should be moved to application.properties
    @Value("${kyc.surepass.api.key:}")
    private String surepassApiKey;

    @Value("${kyc.karza.api.key:}")
    private String karzaApiKey;

    @Value("${kyc.signzy.api.key:}")
    private String signzyApiKey;

    @Value("${kyc.setu.api.key:}")
    private String setuApiKey;

    // API URLs
    private static final String SURPASS_PAN_URL = "https://kyc-api.surepass.io/api/v1/ocr/pan";
    private static final String SURPASS_AADHAAR_URL = "https://kyc-api.surepass.io/api/v1/ocr/aadhaar";
    private static final String KARZA_PAN_URL = "https://api.karza.in/v3/pan";
    private static final String KARZA_AADHAAR_URL = "https://api.karza.in/v3/aadhaar";
    private static final String SIGNZY_PAN_URL = "https://api.signzy.com/api/v2/pan";
    private static final String SIGNZY_AADHAAR_URL = "https://api.signzy.com/api/v2/aadhaar";
    private static final String SETU_PAN_URL = "https://fiu-uat.setu.co/consents/request";

    /**
     * Verify PAN number using multiple API providers with fallback
     */
    public KycVerificationResult verifyPan(String panNumber) {
        logger.info("Starting PAN verification for: {}", maskPan(panNumber));

        KycVerificationResult result = new KycVerificationResult();
        result.setDocumentType("PAN");
        result.setDocumentNumber(panNumber);

        // Try multiple APIs in parallel with timeout
        try {
            CompletableFuture<KycVerificationResult> surepassFuture = CompletableFuture
                    .supplyAsync(() -> verifyPanWithSurepass(panNumber))
                    .orTimeout(10, TimeUnit.SECONDS);

            CompletableFuture<KycVerificationResult> karzaFuture = CompletableFuture
                    .supplyAsync(() -> verifyPanWithKarza(panNumber))
                    .orTimeout(10, TimeUnit.SECONDS);

            CompletableFuture<KycVerificationResult> signzyFuture = CompletableFuture
                    .supplyAsync(() -> verifyPanWithSignzy(panNumber))
                    .orTimeout(10, TimeUnit.SECONDS);

            // Wait for the first successful response
            CompletableFuture<Object> anyOf = CompletableFuture.anyOf(
                    surepassFuture, karzaFuture, signzyFuture);

            KycVerificationResult successfulResult = (KycVerificationResult) anyOf.get();
            if (successfulResult.isSuccess()) {
                logger.info("PAN verification successful using API: {}", successfulResult.getApiProvider());
                return successfulResult;
            }

        } catch (Exception e) {
            logger.warn("All PAN verification APIs failed, using mock verification", e);
        }

        // Fallback to mock verification for development
        return createMockPanVerification(panNumber);
    }

    /**
     * Verify Aadhaar number using multiple API providers with fallback
     */
    public KycVerificationResult verifyAadhaar(String aadhaarNumber) {
        logger.info("Starting Aadhaar verification for: {}", maskAadhaar(aadhaarNumber));

        KycVerificationResult result = new KycVerificationResult();
        result.setDocumentType("AADHAAR");
        result.setDocumentNumber(aadhaarNumber);

        // Try multiple APIs in parallel with timeout
        try {
            CompletableFuture<KycVerificationResult> surepassFuture = CompletableFuture
                    .supplyAsync(() -> verifyAadhaarWithSurepass(aadhaarNumber))
                    .orTimeout(10, TimeUnit.SECONDS);

            CompletableFuture<KycVerificationResult> karzaFuture = CompletableFuture
                    .supplyAsync(() -> verifyAadhaarWithKarza(aadhaarNumber))
                    .orTimeout(10, TimeUnit.SECONDS);

            CompletableFuture<KycVerificationResult> signzyFuture = CompletableFuture
                    .supplyAsync(() -> verifyAadhaarWithSignzy(aadhaarNumber))
                    .orTimeout(10, TimeUnit.SECONDS);

            // Wait for the first successful response
            CompletableFuture<Object> anyOf = CompletableFuture.anyOf(
                    surepassFuture, karzaFuture, signzyFuture);

            KycVerificationResult successfulResult = (KycVerificationResult) anyOf.get();
            if (successfulResult.isSuccess()) {
                logger.info("Aadhaar verification successful using API: {}", successfulResult.getApiProvider());
                return successfulResult;
            }

        } catch (Exception e) {
            logger.warn("All Aadhaar verification APIs failed, using mock verification", e);
        }

        // Fallback to mock verification for development
        return createMockAadhaarVerification(aadhaarNumber);
    }

    /**
     * Verify GST number using multiple API providers with fallback
     */
    public KycVerificationResult verifyGst(String gstNumber) {
        logger.info("Starting GST verification for: {}", maskGst(gstNumber));

        KycVerificationResult result = new KycVerificationResult();
        result.setDocumentType("GST");
        result.setDocumentNumber(gstNumber);

        // Try multiple APIs in parallel with timeout
        try {
            CompletableFuture<KycVerificationResult> surepassFuture = CompletableFuture
                    .supplyAsync(() -> verifyGstWithSurepass(gstNumber))
                    .orTimeout(10, TimeUnit.SECONDS);

            CompletableFuture<KycVerificationResult> karzaFuture = CompletableFuture
                    .supplyAsync(() -> verifyGstWithKarza(gstNumber))
                    .orTimeout(10, TimeUnit.SECONDS);

            CompletableFuture<KycVerificationResult> signzyFuture = CompletableFuture
                    .supplyAsync(() -> verifyGstWithSignzy(gstNumber))
                    .orTimeout(10, TimeUnit.SECONDS);

            // Wait for the first successful response
            CompletableFuture<Object> anyOf = CompletableFuture.anyOf(
                    surepassFuture, karzaFuture, signzyFuture);

            KycVerificationResult successfulResult = (KycVerificationResult) anyOf.get();
            if (successfulResult.isSuccess()) {
                logger.info("GST verification successful using API: {}", successfulResult.getApiProvider());
                return successfulResult;
            }

        } catch (Exception e) {
            logger.warn("All GST verification APIs failed, using mock verification", e);
        }

        // Fallback to mock verification for development
        return createMockGstVerification(gstNumber);
    }

    /**
     * Verify PAN using Surepass API
     */
    private KycVerificationResult verifyPanWithSurepass(String panNumber) {
        if (surepassApiKey == null || surepassApiKey.isEmpty()) {
            throw new RuntimeException("Surepass API key not configured");
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + surepassApiKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("pan", panNumber);
            requestBody.put("consent", "Y");
            requestBody.put("consent_text", "I hereby give my consent to verify my PAN details");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    SURPASS_PAN_URL, request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());

                KycVerificationResult result = new KycVerificationResult();
                result.setSuccess(true);
                result.setApiProvider("Surepass");
                result.setDocumentType("PAN");
                result.setDocumentNumber(panNumber);

                if (jsonResponse.has("data")) {
                    JsonNode data = jsonResponse.get("data");
                    result.setName(data.path("name").asText());
                    result.setFatherName(data.path("father_name").asText());
                    result.setDateOfBirth(data.path("dob").asText());
                    result.setPanNumber(data.path("pan").asText());
                }

                return result;
            }

        } catch (Exception e) {
            logger.error("Error calling Surepass PAN API", e);
        }

        throw new RuntimeException("Surepass PAN verification failed");
    }

    /**
     * Verify PAN using Karza API
     */
    private KycVerificationResult verifyPanWithKarza(String panNumber) {
        if (karzaApiKey == null || karzaApiKey.isEmpty()) {
            throw new RuntimeException("Karza API key not configured");
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("x-karza-key", karzaApiKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("pan", panNumber);
            requestBody.put("consent", "Y");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    KARZA_PAN_URL, request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());

                KycVerificationResult result = new KycVerificationResult();
                result.setSuccess(true);
                result.setApiProvider("Karza");
                result.setDocumentType("PAN");
                result.setDocumentNumber(panNumber);

                if (jsonResponse.has("data")) {
                    JsonNode data = jsonResponse.get("data");
                    result.setName(data.path("name").asText());
                    result.setFatherName(data.path("father_name").asText());
                    result.setDateOfBirth(data.path("dob").asText());
                    result.setPanNumber(data.path("pan").asText());
                }

                return result;
            }

        } catch (Exception e) {
            logger.error("Error calling Karza PAN API", e);
        }

        throw new RuntimeException("Karza PAN verification failed");
    }

    /**
     * Verify PAN using Signzy API
     */
    private KycVerificationResult verifyPanWithSignzy(String panNumber) {
        if (signzyApiKey == null || signzyApiKey.isEmpty()) {
            throw new RuntimeException("Signzy API key not configured");
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + signzyApiKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("pan", panNumber);
            requestBody.put("consent", "Y");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    SIGNZY_PAN_URL, request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());

                KycVerificationResult result = new KycVerificationResult();
                result.setSuccess(true);
                result.setApiProvider("Signzy");
                result.setDocumentType("PAN");
                result.setDocumentNumber(panNumber);

                if (jsonResponse.has("data")) {
                    JsonNode data = jsonResponse.get("data");
                    result.setName(data.path("name").asText());
                    result.setFatherName(data.path("father_name").asText());
                    result.setDateOfBirth(data.path("dob").asText());
                    result.setPanNumber(data.path("pan").asText());
                }

                return result;
            }

        } catch (Exception e) {
            logger.error("Error calling Signzy PAN API", e);
        }

        throw new RuntimeException("Signzy PAN verification failed");
    }

    /**
     * Verify Aadhaar using Surepass API
     */
    private KycVerificationResult verifyAadhaarWithSurepass(String aadhaarNumber) {
        if (surepassApiKey == null || surepassApiKey.isEmpty()) {
            throw new RuntimeException("Surepass API key not configured");
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + surepassApiKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("aadhaar_number", aadhaarNumber);
            requestBody.put("consent", "Y");
            requestBody.put("consent_text", "I hereby give my consent to verify my Aadhaar details");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    SURPASS_AADHAAR_URL, request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());

                KycVerificationResult result = new KycVerificationResult();
                result.setSuccess(true);
                result.setApiProvider("Surepass");
                result.setDocumentType("AADHAAR");
                result.setDocumentNumber(aadhaarNumber);

                if (jsonResponse.has("data")) {
                    JsonNode data = jsonResponse.get("data");
                    result.setName(data.path("name").asText());
                    result.setFatherName(data.path("father_name").asText());
                    result.setDateOfBirth(data.path("dob").asText());
                    result.setAadhaarNumber(data.path("aadhaar_number").asText());
                    result.setAddress(data.path("address").asText());
                }

                return result;
            }

        } catch (Exception e) {
            logger.error("Error calling Surepass Aadhaar API", e);
        }

        throw new RuntimeException("Surepass Aadhaar verification failed");
    }

    /**
     * Verify Aadhaar using Karza API
     */
    private KycVerificationResult verifyAadhaarWithKarza(String aadhaarNumber) {
        if (karzaApiKey == null || karzaApiKey.isEmpty()) {
            throw new RuntimeException("Karza API key not configured");
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("x-karza-key", karzaApiKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("aadhaar_number", aadhaarNumber);
            requestBody.put("consent", "Y");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    KARZA_AADHAAR_URL, request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());

                KycVerificationResult result = new KycVerificationResult();
                result.setSuccess(true);
                result.setApiProvider("Karza");
                result.setDocumentType("AADHAAR");
                result.setDocumentNumber(aadhaarNumber);

                if (jsonResponse.has("data")) {
                    JsonNode data = jsonResponse.get("data");
                    result.setName(data.path("name").asText());
                    result.setFatherName(data.path("father_name").asText());
                    result.setDateOfBirth(data.path("dob").asText());
                    result.setAadhaarNumber(data.path("aadhaar_number").asText());
                    result.setAddress(data.path("address").asText());
                }

                return result;
            }

        } catch (Exception e) {
            logger.error("Error calling Karza Aadhaar API", e);
        }

        throw new RuntimeException("Karza Aadhaar verification failed");
    }

    /**
     * Verify Aadhaar using Signzy API
     */
    private KycVerificationResult verifyAadhaarWithSignzy(String aadhaarNumber) {
        if (signzyApiKey == null || signzyApiKey.isEmpty()) {
            throw new RuntimeException("Signzy API key not configured");
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + signzyApiKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("aadhaar_number", aadhaarNumber);
            requestBody.put("consent", "Y");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    SIGNZY_AADHAAR_URL, request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());

                KycVerificationResult result = new KycVerificationResult();
                result.setSuccess(true);
                result.setApiProvider("Signzy");
                result.setDocumentType("AADHAAR");
                result.setDocumentNumber(aadhaarNumber);

                if (jsonResponse.has("data")) {
                    JsonNode data = jsonResponse.get("data");
                    result.setName(data.path("name").asText());
                    result.setFatherName(data.path("father_name").asText());
                    result.setDateOfBirth(data.path("dob").asText());
                    result.setAadhaarNumber(data.path("aadhaar_number").asText());
                    result.setAddress(data.path("address").asText());
                }

                return result;
            }

        } catch (Exception e) {
            logger.error("Error calling Signzy Aadhaar API", e);
        }

        throw new RuntimeException("Signzy Aadhaar verification failed");
    }

    /**
     * Create mock PAN verification for development/testing
     */
    private KycVerificationResult createMockPanVerification(String panNumber) {
        logger.info("Using mock PAN verification for development");

        KycVerificationResult result = new KycVerificationResult();
        result.setSuccess(true);
        result.setApiProvider("Mock");
        result.setDocumentType("PAN");
        result.setDocumentNumber(panNumber);
        result.setName("John Doe");
        result.setFatherName("James Doe");
        result.setDateOfBirth("1990-01-01");
        result.setPanNumber(panNumber);
        result.setVerificationMessage("Mock verification successful for development purposes");

        return result;
    }

    /**
     * Create mock Aadhaar verification for development/testing
     */
    private KycVerificationResult createMockAadhaarVerification(String aadhaarNumber) {
        logger.info("Using mock Aadhaar verification for development");

        KycVerificationResult result = new KycVerificationResult();
        result.setSuccess(true);
        result.setApiProvider("Mock");
        result.setDocumentType("AADHAAR");
        result.setDocumentNumber(aadhaarNumber);
        result.setName("John Doe");
        result.setFatherName("James Doe");
        result.setDateOfBirth("1990-01-01");
        result.setAadhaarNumber(aadhaarNumber);
        result.setAddress("123 Main Street, City, State - 123456");
        result.setVerificationMessage("Mock verification successful for development purposes");

        return result;
    }

    /**
     * Mask PAN number for logging
     */
    private String maskPan(String pan) {
        if (pan == null || pan.length() < 4)
            return "****";
        return pan.substring(0, 2) + "****" + pan.substring(pan.length() - 2);
    }

    /**
     * Mask Aadhaar number for logging
     */
    private String maskAadhaar(String aadhaar) {
        if (aadhaar == null || aadhaar.length() < 4)
            return "****";
        return aadhaar.substring(0, 4) + "****" + aadhaar.substring(aadhaar.length() - 4);
    }

    /**
     * Inner class to hold verification results
     */
    public static class KycVerificationResult {
        private boolean success;
        private String apiProvider;
        private String documentType;
        private String documentNumber;
        private String name;
        private String fatherName;
        private String dateOfBirth;
        private String panNumber;
        private String aadhaarNumber;
        private String address;
        private String verificationMessage;
        private String errorMessage;

        // Getters and Setters
        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getApiProvider() {
            return apiProvider;
        }

        public void setApiProvider(String apiProvider) {
            this.apiProvider = apiProvider;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }

        public String getDocumentNumber() {
            return documentNumber;
        }

        public void setDocumentNumber(String documentNumber) {
            this.documentNumber = documentNumber;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getFatherName() {
            return fatherName;
        }

        public void setFatherName(String fatherName) {
            this.fatherName = fatherName;
        }

        public String getDateOfBirth() {
            return dateOfBirth;
        }

        public void setDateOfBirth(String dateOfBirth) {
            this.dateOfBirth = dateOfBirth;
        }

        public String getPanNumber() {
            return panNumber;
        }

        public void setPanNumber(String panNumber) {
            this.panNumber = panNumber;
        }

        public String getAadhaarNumber() {
            return aadhaarNumber;
        }

        public void setAadhaarNumber(String aadhaarNumber) {
            this.aadhaarNumber = aadhaarNumber;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getVerificationMessage() {
            return verificationMessage;
        }

        public void setVerificationMessage(String verificationMessage) {
            this.verificationMessage = verificationMessage;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }
    }

    // GST Verification Helper Methods
    private String maskGst(String gst) {
        if (gst == null || gst.length() < 4)
            return "****";
        return gst.substring(0, 2) + "****" + gst.substring(gst.length() - 2);
    }

    private KycVerificationResult verifyGstWithSurepass(String gstNumber) {
        if (surepassApiKey == null || surepassApiKey.isEmpty()) {
            throw new RuntimeException("Surepass API key not configured");
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + surepassApiKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("gst", gstNumber);
            requestBody.put("consent", "Y");
            requestBody.put("consent_text", "I hereby give my consent to verify my GST details");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    "https://kyc-api.surepass.io/api/v1/gst/verify", request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());

                KycVerificationResult result = new KycVerificationResult();
                result.setSuccess(true);
                result.setApiProvider("Surepass");
                result.setDocumentType("GST");
                result.setDocumentNumber(gstNumber);

                if (jsonResponse.has("data")) {
                    JsonNode data = jsonResponse.get("data");
                    result.setName(data.path("legal_name").asText());
                    result.setAddress(data.path("address").asText());
                }

                return result;
            }

        } catch (Exception e) {
            logger.error("Error calling Surepass GST API", e);
        }

        throw new RuntimeException("Surepass GST verification failed");
    }

    private KycVerificationResult verifyGstWithKarza(String gstNumber) {
        if (karzaApiKey == null || karzaApiKey.isEmpty()) {
            throw new RuntimeException("Karza API key not configured");
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("x-karza-key", karzaApiKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("gst", gstNumber);

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    "https://api.karza.in/v3/gst", request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());

                KycVerificationResult result = new KycVerificationResult();
                result.setSuccess(true);
                result.setApiProvider("Karza");
                result.setDocumentType("GST");
                result.setDocumentNumber(gstNumber);

                if (jsonResponse.has("data")) {
                    JsonNode data = jsonResponse.get("data");
                    result.setName(data.path("legal_name").asText());
                    result.setAddress(data.path("address").asText());
                }

                return result;
            }

        } catch (Exception e) {
            logger.error("Error calling Karza GST API", e);
        }

        throw new RuntimeException("Karza GST verification failed");
    }

    private KycVerificationResult verifyGstWithSignzy(String gstNumber) {
        if (signzyApiKey == null || signzyApiKey.isEmpty()) {
            throw new RuntimeException("Signzy API key not configured");
        }

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + signzyApiKey);
            headers.setContentType(MediaType.APPLICATION_JSON);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("gst", gstNumber);
            requestBody.put("consent", "Y");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    "https://api.signzy.com/api/v2/gst", request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());

                KycVerificationResult result = new KycVerificationResult();
                result.setSuccess(true);
                result.setApiProvider("Signzy");
                result.setDocumentType("GST");
                result.setDocumentNumber(gstNumber);

                if (jsonResponse.has("data")) {
                    JsonNode data = jsonResponse.get("data");
                    result.setName(data.path("legal_name").asText());
                    result.setAddress(data.path("address").asText());
                }

                return result;
            }

        } catch (Exception e) {
            logger.error("Error calling Signzy GST API", e);
        }

        throw new RuntimeException("Signzy GST verification failed");
    }

    private KycVerificationResult createMockGstVerification(String gstNumber) {
        logger.info("Creating mock GST verification for: {}", maskGst(gstNumber));

        KycVerificationResult result = new KycVerificationResult();
        result.setSuccess(true);
        result.setApiProvider("Mock");
        result.setDocumentType("GST");
        result.setDocumentNumber(gstNumber);
        result.setName("Mock Company Pvt Ltd");
        result.setAddress("123 Business Street, Mumbai, Maharashtra - 400001");
        result.setVerificationMessage("Mock GST verification completed successfully");

        return result;
    }
}
