package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.NotBlank;

public class TwoFactorAuthDto {
    
    @NotBlank(message = "OTP is required")
    private String otp;
    
    private String type; // LOGIN_VERIFICATION, FILE_VERIFICATION
    private String fileName; // For file verification
    
    public TwoFactorAuthDto() {}
    
    public TwoFactorAuthDto(String otp) {
        this.otp = otp;
    }
    
    public TwoFactorAuthDto(String otp, String type) {
        this.otp = otp;
        this.type = type;
    }
    
    public TwoFactorAuthDto(String otp, String type, String fileName) {
        this.otp = otp;
        this.type = type;
        this.fileName = fileName;
    }
    
    // Getters and Setters
    public String getOtp() {
        return otp;
    }
    
    public void setOtp(String otp) {
        this.otp = otp;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getFileName() {
        return fileName;
    }
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
