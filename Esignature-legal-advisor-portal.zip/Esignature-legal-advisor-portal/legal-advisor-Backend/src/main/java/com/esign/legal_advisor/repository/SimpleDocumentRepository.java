package com.esign.legal_advisor.repository;

import com.esign.legal_advisor.entites.SimpleDocument;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SimpleDocumentRepository extends MongoRepository<SimpleDocument, String> {
    List<SimpleDocument> findByUserIdOrderByCreatedAtDesc(String userId);

    List<SimpleDocument> findByUserId(String userId);
}
