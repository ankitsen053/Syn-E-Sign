package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
	private String id;
	private String username;
	private String firstName;
	private String lastName;
	private String fullName;
	private String profilePicture;
	@NotEmpty(message = "Email should not be empty")
	@Email
	private String email;
	private String password;
	private boolean emailVerified;
	private boolean enabled;
	private List<String> roles;
	private String googleId;

	// Additional profile fields
	private String phone;
	private String address;
	private String company;
	private String position;
	private String bio;
	private String website;
	private String timezone;
	private String dateOfBirth;

	// User Type and Verification
	private String userType;
	private String panNumber;
	private String gstNumber;
	private String companyName;
	private String businessAddress;
	private String contactNumber;
	private String companyEmail;
	private boolean isVerified;
	private String verificationLevel;

	// Lawyer-specific fields
	private String barNumber;
	private String barAssociation;
	private String practiceAreas;
	private String lawSchool;
	private String yearOfAdmission;
	private String licenseNumber;
	private String specialization;
	private String experience;
	private String hourlyRate;
	private String firmName;
	private String firmAddress;
	private String professionalBio;
	private String certifications;
	private String languages;
	private boolean isBarVerified;
	private String verificationDocument;
}
