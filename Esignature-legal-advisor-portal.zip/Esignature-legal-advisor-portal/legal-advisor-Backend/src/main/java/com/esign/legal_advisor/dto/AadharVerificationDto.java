package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.NotNull;
import org.springframework.web.multipart.MultipartFile;

public class AadharVerificationDto {

    @NotBlank(message = "Aadhar number is required")
    @Pattern(regexp = "^[0-9]{12}$", message = "Invalid Aadhar number format (12 digits)")
    private String aadharNumber;

    @NotNull(message = "Aadhaar document file is required")
    private MultipartFile documentFile;

    public AadharVerificationDto() {
    }

    public AadharVerificationDto(String aadharNumber, MultipartFile documentFile) {
        this.aadharNumber = aadharNumber;
        this.documentFile = documentFile;
    }

    public String getAadharNumber() {
        return aadharNumber;
    }

    public void setAadharNumber(String aadharNumber) {
        this.aadharNumber = aadharNumber;
    }

    public MultipartFile getDocumentFile() {
        return documentFile;
    }

    public void setDocumentFile(MultipartFile documentFile) {
        this.documentFile = documentFile;
    }
}
