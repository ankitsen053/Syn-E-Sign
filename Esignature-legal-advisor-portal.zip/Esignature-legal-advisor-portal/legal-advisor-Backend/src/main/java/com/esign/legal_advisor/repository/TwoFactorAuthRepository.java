package com.esign.legal_advisor.repository;

import com.esign.legal_advisor.entites.TwoFactorAuth;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface TwoFactorAuthRepository extends MongoRepository<TwoFactorAuth, String> {
    
    void deleteByUserId(String userId);
    
    void deleteByUserIdAndType(String userId, String type);
    
    @Query("{'expiresAt': {$lt: ?0}}")
    void deleteByExpiresAtBefore(LocalDateTime dateTime);
    
    Optional<TwoFactorAuth> findByUserIdAndType(String userId, String type);
    
    Optional<TwoFactorAuth> findByUserId(String userId);
}
