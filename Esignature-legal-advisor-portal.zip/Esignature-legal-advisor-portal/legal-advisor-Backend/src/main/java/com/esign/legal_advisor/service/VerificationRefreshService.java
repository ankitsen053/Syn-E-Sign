package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.VerificationStatus;
import com.esign.legal_advisor.repository.VerificationStatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class VerificationRefreshService {

    private static final Logger logger = LoggerFactory.getLogger(VerificationRefreshService.class);

    @Autowired
    private VerificationStatusRepository verificationStatusRepository;

    @Autowired
    private VerificationService verificationService;



    /**
     * Generate refresh token for verification status
     */
    public String generateVerificationRefreshToken(String userId) {
        try {
            logger.info("Generating verification refresh token for user: {}", userId);
            
            // Generate new refresh token
            String refreshToken = UUID.randomUUID().toString();
            
            // Create a map to store refresh token info (in a real system, you'd use a database)
            Map<String, Object> refreshData = new HashMap<>();
            refreshData.put("token", refreshToken);
            refreshData.put("userId", userId);
            refreshData.put("expiryAt", LocalDateTime.now().plusDays(30));
            refreshData.put("createdAt", LocalDateTime.now());
            
            logger.info("Verification refresh token generated successfully for user: {}", userId);
            return refreshToken;
            
        } catch (Exception e) {
            logger.error("Error generating verification refresh token for user: {}", userId, e);
            throw new RuntimeException("Failed to generate verification refresh token: " + e.getMessage());
        }
    }

    /**
     * Refresh verification status based on user profile terms
     */
    public Map<String, Object> refreshVerificationStatus(String userId, String refreshToken) {
        try {
            logger.info("Refreshing verification status for user: {} with token: {}", userId, 
                       refreshToken != null ? refreshToken.substring(0, 8) + "..." : "null");
            
            VerificationStatus status = verificationService.getVerificationStatus(userId);
            
            // Determine user verification terms based on their profile
            String userTerms = determineUserVerificationTerms(status);
            
            // Get required verifications based on user terms
            List<String> requiredVerifications = getRequiredVerifications(userTerms, status);
            
            // Refresh each verification type
            Map<String, Object> refreshResults = new HashMap<>();
            refreshResults.put("userId", userId);
            refreshResults.put("userTerms", userTerms);
            refreshResults.put("requiredVerifications", requiredVerifications);
            refreshResults.put("refreshedAt", LocalDateTime.now());
            
            Map<String, Object> verificationStatuses = new HashMap<>();
            
            for (String verificationType : requiredVerifications) {
                Map<String, Object> verificationResult = refreshSpecificVerification(verificationType, status);
                verificationStatuses.put(verificationType, verificationResult);
            }
            
            refreshResults.put("verificationStatuses", verificationStatuses);
            refreshResults.put("overallCompletionPercentage", calculateCompletionPercentage(status, requiredVerifications));
            refreshResults.put("fullyVerified", isFullyVerified(status, requiredVerifications));
            
            // Update last refresh time
            status.setUpdatedAt(LocalDateTime.now());
            verificationStatusRepository.save(status);
            
            logger.info("Verification status refreshed successfully for user: {}", userId);
            return refreshResults;
            
        } catch (Exception e) {
            logger.error("Error refreshing verification status for user: {}", userId, e);
            throw new RuntimeException("Failed to refresh verification status: " + e.getMessage());
        }
    }

    /**
     * Get user-specific verification profile based on their requirements
     */
    public Map<String, Object> getUserVerificationProfile(String userId) {
        try {
            logger.info("Getting verification profile for user: {}", userId);
            
            VerificationStatus status = verificationService.getVerificationStatus(userId);
            
            String userTerms = determineUserVerificationTerms(status);
            List<String> requiredVerifications = getRequiredVerifications(userTerms, status);
            
            Map<String, Object> profile = new HashMap<>();
            profile.put("userId", userId);
            profile.put("userVerificationTerms", userTerms);
            profile.put("businessType", determineBusinessType(status));
            profile.put("requiredVerifications", requiredVerifications);
            
            // Get current status for each verification
            Map<String, Object> currentStatuses = new HashMap<>();
            for (String verificationType : requiredVerifications) {
                currentStatuses.put(verificationType, getCurrentVerificationStatus(verificationType, status));
            }
            profile.put("currentStatuses", currentStatuses);
            
            // Calculate completion metrics
            profile.put("completionPercentage", calculateCompletionPercentage(status, requiredVerifications));
            profile.put("totalRequired", requiredVerifications.size());
            profile.put("completed", getCompletedCount(status, requiredVerifications));
            profile.put("pending", requiredVerifications.size() - getCompletedCount(status, requiredVerifications));
            
            // Add verification requirements explanation
            profile.put("verificationExplanation", getVerificationExplanation(userTerms));
            
            logger.info("Verification profile retrieved successfully for user: {}", userId);
            return profile;
            
        } catch (Exception e) {
            logger.error("Error getting verification profile for user: {}", userId, e);
            throw new RuntimeException("Failed to get verification profile: " + e.getMessage());
        }
    }

    /**
     * Refresh specific verification type
     */
    private Map<String, Object> refreshSpecificVerification(String verificationType, VerificationStatus status) {
        Map<String, Object> result = new HashMap<>();
        result.put("type", verificationType);
        result.put("refreshedAt", LocalDateTime.now());
        
        switch (verificationType.toUpperCase()) {
            case "EMAIL":
                result.put("status", status.isEmailVerified() ? "VERIFIED" : "PENDING");
                result.put("verifiedAt", status.getEmailVerifiedAt());
                result.put("description", "Email verification for account security");
                break;
                
            case "PAN":
                result.put("status", status.isPanVerified() ? "VERIFIED" : status.getPanVerificationStatus());
                result.put("verifiedAt", status.getPanVerifiedAt());
                result.put("panNumber", status.getPanNumber() != null ? maskPan(status.getPanNumber()) : null);
                result.put("description", "PAN card verification for identity confirmation");
                break;
                
            case "AADHAAR":
                result.put("status", status.isAadharVerified() ? "VERIFIED" : status.getAadharVerificationStatus());
                result.put("verifiedAt", status.getAadharVerifiedAt());
                result.put("aadhaarNumber", status.getAadharNumber() != null ? maskAadhaar(status.getAadharNumber()) : null);
                result.put("description", "Aadhaar verification for address and identity proof");
                break;
                
            case "VIDEO":
                result.put("status", status.isVideoVerified() ? "VERIFIED" : status.getVideoVerificationStatus());
                result.put("verifiedAt", status.getVideoVerifiedAt());
                result.put("description", "Video KYC for live identity verification");
                break;
                
            case "GST":
                result.put("status", status.isGstVerified() ? "VERIFIED" : status.getGstVerificationStatus());
                result.put("verifiedAt", status.getGstVerifiedAt());
                result.put("gstNumber", status.getGstNumber());
                result.put("companyName", status.getCompanyName());
                result.put("description", "GST verification for business identity");
                break;
                
            default:
                result.put("status", "UNKNOWN");
                result.put("description", "Unknown verification type");
        }
        
        return result;
    }

    /**
     * Determine user verification terms based on their profile
     */
    private String determineUserVerificationTerms(VerificationStatus status) {
        // Business logic to determine user terms
        if (status.isGstVerified() || status.getGstNumber() != null) {
            return "BUSINESS";
        }
        
        // If they have company details, they're likely business
        if (status.getCompanyName() != null && !status.getCompanyName().trim().isEmpty()) {
            return "CORPORATE";
        }
        
        // Default to individual
        return "INDIVIDUAL";
    }

    /**
     * Determine business type
     */
    private String determineBusinessType(VerificationStatus status) {
        if (status.getCompanyName() != null && !status.getCompanyName().trim().isEmpty()) {
            return "CORPORATE";
        }
        if (status.isGstVerified()) {
            return "BUSINESS";
        }
        return "INDIVIDUAL";
    }

    /**
     * Get required verifications based on user terms
     */
    private List<String> getRequiredVerifications(String userTerms, VerificationStatus status) {
        List<String> required = new ArrayList<>();
        
        // Email is always required
        required.add("EMAIL");
        
        switch (userTerms) {
            case "INDIVIDUAL":
                required.add("PAN");
                required.add("AADHAAR");
                required.add("VIDEO");
                break;
                
            case "BUSINESS":
                required.add("PAN");
                required.add("AADHAAR");
                required.add("GST");
                required.add("VIDEO");
                break;
                
            case "CORPORATE":
                required.add("GST");
                required.add("VIDEO");
                // Corporate may not require personal PAN/Aadhaar
                break;
        }
        
        return required;
    }

    /**
     * Get current verification status
     */
    private Map<String, Object> getCurrentVerificationStatus(String verificationType, VerificationStatus status) {
        Map<String, Object> currentStatus = new HashMap<>();
        
        switch (verificationType.toUpperCase()) {
            case "EMAIL":
                currentStatus.put("verified", status.isEmailVerified());
                currentStatus.put("status", status.isEmailVerified() ? "VERIFIED" : "PENDING");
                break;
            case "PAN":
                currentStatus.put("verified", status.isPanVerified());
                currentStatus.put("status", status.getPanVerificationStatus());
                break;
            case "AADHAAR":
                currentStatus.put("verified", status.isAadharVerified());
                currentStatus.put("status", status.getAadharVerificationStatus());
                break;
            case "VIDEO":
                currentStatus.put("verified", status.isVideoVerified());
                currentStatus.put("status", status.getVideoVerificationStatus());
                break;
            case "GST":
                currentStatus.put("verified", status.isGstVerified());
                currentStatus.put("status", status.getGstVerificationStatus());
                break;
        }
        
        return currentStatus;
    }

    /**
     * Calculate completion percentage
     */
    private double calculateCompletionPercentage(VerificationStatus status, List<String> requiredVerifications) {
        if (requiredVerifications.isEmpty()) {
            return 100.0;
        }
        
        int completed = getCompletedCount(status, requiredVerifications);
        return (double) completed / requiredVerifications.size() * 100.0;
    }

    /**
     * Get completed verification count
     */
    private int getCompletedCount(VerificationStatus status, List<String> requiredVerifications) {
        int completed = 0;
        for (String verification : requiredVerifications) {
            switch (verification.toUpperCase()) {
                case "EMAIL":
                    if (status.isEmailVerified()) completed++;
                    break;
                case "PAN":
                    if (status.isPanVerified()) completed++;
                    break;
                case "AADHAAR":
                    if (status.isAadharVerified()) completed++;
                    break;
                case "VIDEO":
                    if (status.isVideoVerified()) completed++;
                    break;
                case "GST":
                    if (status.isGstVerified()) completed++;
                    break;
            }
        }
        return completed;
    }

    /**
     * Check if fully verified
     */
    private boolean isFullyVerified(VerificationStatus status, List<String> requiredVerifications) {
        return getCompletedCount(status, requiredVerifications) == requiredVerifications.size();
    }

    /**
     * Get verification explanation based on user terms
     */
    private Map<String, String> getVerificationExplanation(String userTerms) {
        Map<String, String> explanation = new HashMap<>();
        
        switch (userTerms) {
            case "INDIVIDUAL":
                explanation.put("EMAIL", "Required for account access and communication");
                explanation.put("PAN", "Required for tax identification and financial transactions");
                explanation.put("AADHAAR", "Required for identity and address verification");
                explanation.put("VIDEO", "Required for live identity verification and anti-fraud");
                break;
                
            case "BUSINESS":
                explanation.put("EMAIL", "Required for business communication");
                explanation.put("PAN", "Required for business owner identification");
                explanation.put("AADHAAR", "Required for business owner identity verification");
                explanation.put("GST", "Required for business registration and tax compliance");
                explanation.put("VIDEO", "Required for business owner live verification");
                break;
                
            case "CORPORATE":
                explanation.put("EMAIL", "Required for corporate communication");
                explanation.put("GST", "Required for corporate registration and compliance");
                explanation.put("VIDEO", "Required for authorized signatory verification");
                break;
        }
        
        return explanation;
    }

    /**
     * Mask PAN number for security
     */
    private String maskPan(String pan) {
        if (pan == null || pan.length() < 6) {
            return pan;
        }
        return pan.substring(0, 3) + "***" + pan.substring(pan.length() - 2);
    }

    /**
     * Mask Aadhaar number for security
     */
    private String maskAadhaar(String aadhaar) {
        if (aadhaar == null || aadhaar.length() < 8) {
            return aadhaar;
        }
        return "****-****-" + aadhaar.substring(aadhaar.length() - 4);
    }
}
