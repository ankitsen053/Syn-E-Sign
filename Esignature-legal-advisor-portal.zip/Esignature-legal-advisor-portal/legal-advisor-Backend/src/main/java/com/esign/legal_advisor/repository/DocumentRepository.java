package com.esign.legal_advisor.repository;

import com.esign.legal_advisor.entites.LegalDocument;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface DocumentRepository extends MongoRepository<LegalDocument, String> {

    List<LegalDocument> findByUserId(String userId);

    List<LegalDocument> findByUserIdOrderByCreatedAtDesc(String userId);

    List<LegalDocument> findByTypeAndUserId(String type, String userId);

    List<LegalDocument> findByIsEditedTrueAndUserId(String userId);

    // Dashboard methods
    long countByUserIdAndType(String userId, String type);

    long countByUserId(String userId);

    List<LegalDocument> findTop10ByUserIdOrderByCreatedAtDesc(String userId);

    @Query("{'userId': ?0, 'createdAt': {$gte: ?1}}")
    long countByUserIdAndCreatedAtAfter(String userId, LocalDateTime dateTime);

    @Query("{'userId': ?0, 'type': ?1, 'createdAt': {$gte: ?2}}")
    long countByUserIdAndTypeAndCreatedAtAfter(String userId, String type, LocalDateTime dateTime);

    @Query("{'userId': ?0, 'createdAt': {$gte: ?1, $lt: ?2}}")
    long countByUserIdAndCreatedAtBetween(String userId, LocalDateTime startDateTime, LocalDateTime endDateTime);

    @Query("{'userId': ?0, 'type': ?1, 'createdAt': {$gte: ?2, $lt: ?3}}")
    long countByUserIdAndTypeAndCreatedAtBetween(String userId, String type, LocalDateTime startDateTime,
            LocalDateTime endDateTime);

    @Query(value = "{'userId': ?0}", fields = "{'type': 1}")
    List<String> findTopDocumentTypesByUserId(String userId);

    @Query(value = "{'userId': ?0}", fields = "{'createdAt': 1}")
    List<Integer> findMostActiveHoursByUserId(String userId);

    @Query(value = "{'userId': ?0}", fields = "{'createdAt': 1}")
    List<String> findMostActiveDaysByUserId(String userId);
}
