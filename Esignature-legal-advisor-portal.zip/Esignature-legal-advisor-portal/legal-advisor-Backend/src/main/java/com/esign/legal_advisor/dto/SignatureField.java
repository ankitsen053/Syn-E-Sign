package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

/**
 * DTO representing a signature field in a document
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SignatureField {

    private String fieldName;
    private String fieldLabel;
    private String fieldType; // SIGNATURE, INITIAL, DATE, TEXT
    private boolean required;
    private String position; // bottom_left, bottom_right, bottom_center, etc.
    private Integer pageNumber;
    private Double xPosition;
    private Double yPosition;
    private Double width;
    private Double height;
    private String signerRole; // PARTY_A, PARTY_B, WITNESS, etc.
    private boolean completed;
    private String completedBy;
}
