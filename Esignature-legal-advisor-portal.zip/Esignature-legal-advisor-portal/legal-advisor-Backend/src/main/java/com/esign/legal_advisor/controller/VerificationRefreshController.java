package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.service.VerificationRefreshService;
import com.esign.legal_advisor.entites.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

@RestController
@RequestMapping("/api/verification-refresh")
@CrossOrigin(origins = "*", maxAge = 3600)
public class VerificationRefreshController {

    private static final Logger logger = LoggerFactory.getLogger(VerificationRefreshController.class);

    @Autowired
    private VerificationRefreshService verificationRefreshService;

    /**
     * Generate verification refresh token
     */
    @PostMapping("/generate-token")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> generateRefreshToken() {
        logger.info("Generating verification refresh token");

        try {
            User currentUser = getCurrentUser();
            String refreshToken = verificationRefreshService.generateVerificationRefreshToken(currentUser.getId());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Verification refresh token generated successfully");
            response.put("refreshToken", refreshToken);
            response.put("userId", currentUser.getId());
            response.put("username", currentUser.getUsername());

            logger.info("Verification refresh token generated successfully for user: {}", currentUser.getUsername());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error generating verification refresh token", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to generate refresh token: " + e.getMessage()));
        }
    }

    /**
     * Refresh verification status for current user
     */
    @PostMapping("/refresh")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> refreshVerificationStatus(
            @RequestBody(required = false) Map<String, String> request) {
        logger.info("Refreshing verification status");

        try {
            User currentUser = getCurrentUser();
            String refreshToken = request != null ? request.get("refreshToken") : null;

            Map<String, Object> refreshResult = verificationRefreshService.refreshVerificationStatus(
                    currentUser.getId(), refreshToken);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Verification status refreshed successfully");
            response.put("data", refreshResult);

            logger.info("Verification status refreshed successfully for user: {}", currentUser.getUsername());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error refreshing verification status", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to refresh verification status: " + e.getMessage()));
        }
    }

    /**
     * Get user verification profile
     */
    @GetMapping("/profile")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> getUserVerificationProfile() {
        logger.info("Getting user verification profile");

        try {
            User currentUser = getCurrentUser();
            Map<String, Object> profile = verificationRefreshService.getUserVerificationProfile(currentUser.getId());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "User verification profile retrieved successfully");
            response.put("profile", profile);

            logger.info("User verification profile retrieved successfully for user: {}", currentUser.getUsername());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting user verification profile", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to get verification profile: " + e.getMessage()));
        }
    }

    /**
     * Get verification status by user ID (for admin/development)
     */
    @GetMapping("/status/{userId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> getVerificationStatusByUserId(@PathVariable String userId) {
        logger.info("Getting verification status for user: {}", userId);

        try {
            Map<String, Object> profile = verificationRefreshService.getUserVerificationProfile(userId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Verification status retrieved successfully");
            response.put("userId", userId);
            response.put("profile", profile);

            logger.info("Verification status retrieved successfully for user: {}", userId);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting verification status for user: {}", userId, e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to get verification status: " + e.getMessage()));
        }
    }

    /**
     * Refresh specific verification type
     */
    @PostMapping("/refresh/{verificationType}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> refreshSpecificVerification(
            @PathVariable String verificationType,
            @RequestBody(required = false) Map<String, String> request) {

        logger.info("Refreshing specific verification: {}", verificationType);

        try {
            User currentUser = getCurrentUser();
            String refreshToken = request != null ? request.get("refreshToken") : null;

            // Get current verification status
            Map<String, Object> refreshResult = verificationRefreshService.refreshVerificationStatus(
                    currentUser.getId(), refreshToken);

            // Extract the specific verification from the result
            @SuppressWarnings("unchecked")
            Map<String, Object> verificationStatuses = (Map<String, Object>) refreshResult.get("verificationStatuses");
            Object specificVerification = verificationStatuses.get(verificationType.toUpperCase());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", verificationType + " verification status refreshed successfully");
            response.put("verificationType", verificationType);
            response.put("verificationData", specificVerification);
            response.put("refreshedAt", refreshResult.get("refreshedAt"));

            logger.info("{} verification refreshed successfully for user: {}", verificationType,
                    currentUser.getUsername());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error refreshing {} verification", verificationType, e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to refresh " + verificationType + " verification: " + e.getMessage()));
        }
    }

    /**
     * Get verification terms explanation
     */
    @GetMapping("/terms-explanation")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> getVerificationTermsExplanation() {
        logger.info("Getting verification terms explanation");

        try {
            Map<String, Object> explanation = new HashMap<>();

            Map<String, Object> individual = new HashMap<>();
            individual.put("description", "Individual user verification for personal accounts");
            individual.put("required", java.util.List.of("EMAIL", "PAN", "AADHAAR", "VIDEO"));
            individual.put("purpose", "Personal identity verification and compliance");

            Map<String, Object> business = new HashMap<>();
            business.put("description", "Business user verification for business accounts");
            business.put("required", java.util.List.of("EMAIL", "PAN", "AADHAAR", "GST", "VIDEO"));
            business.put("purpose", "Business identity verification and tax compliance");

            Map<String, Object> corporate = new HashMap<>();
            corporate.put("description", "Corporate user verification for company accounts");
            corporate.put("required", java.util.List.of("EMAIL", "GST", "VIDEO"));
            corporate.put("purpose", "Corporate identity verification and regulatory compliance");

            explanation.put("INDIVIDUAL", individual);
            explanation.put("BUSINESS", business);
            explanation.put("CORPORATE", corporate);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Verification terms explanation retrieved successfully");
            response.put("explanation", explanation);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting verification terms explanation", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to get verification terms explanation: " + e.getMessage()));
        }
    }

    /**
     * Get current authenticated user
     */
    private User getCurrentUser() {
        try {
            logger.info("Getting current user from SecurityContext");
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            logger.info("Authentication object: {}",
                    authentication != null ? authentication.getClass().getSimpleName() : "null");

            if (authentication != null) {
                logger.info("Authentication principal: {}",
                        authentication.getPrincipal() != null ? authentication.getPrincipal().getClass().getSimpleName()
                                : "null");

                if (authentication.getPrincipal() instanceof User) {
                    User user = (User) authentication.getPrincipal();
                    logger.info("Authenticated user: {}", user.getUsername());
                    return user;
                } else {
                    logger.warn("Authentication principal is not a User instance: {}", authentication.getPrincipal());
                }
            } else {
                logger.warn("No authentication found in SecurityContext");
            }

            // For development: return a default user if not authenticated
            logger.warn("No authenticated user found, using default user for development");
            User defaultUser = new User();
            defaultUser.setId("dev-user-id");
            defaultUser.setUsername("dev-user");
            defaultUser.setEmail("dev@example.com");
            defaultUser.setRoles(new HashSet<>());
            logger.info("Created default user: {}", defaultUser.getUsername());
            return defaultUser;
        } catch (Exception e) {
            logger.error("Error in getCurrentUser(): {}", e.getMessage(), e);
            throw e;
        }
    }
}
