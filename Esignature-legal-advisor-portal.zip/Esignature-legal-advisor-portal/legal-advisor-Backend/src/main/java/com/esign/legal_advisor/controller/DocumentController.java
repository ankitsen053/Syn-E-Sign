package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.DocumentDto;
import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.entites.LegalDocument;
import com.esign.legal_advisor.entites.SimpleDocument;
import com.esign.legal_advisor.repository.DocumentRepository;
import com.esign.legal_advisor.repository.SimpleDocumentRepository;
import com.esign.legal_advisor.service.DocumentService;
import com.esign.legal_advisor.service.DocumentMigrationService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.HashSet;
import java.util.Optional;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/documents")
@CrossOrigin(origins = "*", maxAge = 3600)
public class DocumentController {

    private static final Logger logger = LoggerFactory.getLogger(DocumentController.class);
    private final DocumentService documentService;
    private final DocumentMigrationService documentMigrationService;
    private final DocumentRepository documentRepository;
    private final SimpleDocumentRepository simpleDocumentRepository;

    public DocumentController(DocumentService documentService, DocumentMigrationService documentMigrationService,
            DocumentRepository documentRepository, SimpleDocumentRepository simpleDocumentRepository) {
        this.documentService = documentService;
        this.documentMigrationService = documentMigrationService;
        this.documentRepository = documentRepository;
        this.simpleDocumentRepository = simpleDocumentRepository;
    }

    @PostMapping("/save")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> saveDocument(@RequestBody DocumentDto documentDto) {
        logger.info("Saving document: type={}, partyA={}, partyB={}",
                documentDto.getType(), documentDto.getPartyA(), documentDto.getPartyB());

        try {
            User currentUser = getCurrentUser();
            DocumentDto savedDocument = documentService.saveDocument(documentDto, currentUser);

            logger.info("Document saved successfully with ID: {}", savedDocument.getId());

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "document", savedDocument,
                    "message", "Document saved successfully"));
        } catch (Exception e) {
            logger.error("Error saving document", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to save document: " + e.getMessage()));
        }
    }

    @PutMapping("/{documentId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> updateDocument(
            @PathVariable String documentId,
            @RequestBody DocumentDto documentDto) {
        logger.info("Updating document: {}", documentId);

        try {
            User currentUser = getCurrentUser();
            DocumentDto updatedDocument = documentService.updateDocument(documentId, documentDto, currentUser);

            logger.info("Document updated successfully: {}", documentId);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "document", updatedDocument,
                    "message", "Document updated successfully"));
        } catch (Exception e) {
            logger.error("Error updating document", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to update document: " + e.getMessage()));
        }
    }

    @GetMapping("/user")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> getUserDocuments() {
        logger.info("Retrieving user documents");

        try {
            User currentUser = getCurrentUser();
            List<DocumentDto> documents = documentService.getUserDocuments(currentUser);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "documents", documents,
                    "count", documents.size()));
        } catch (Exception e) {
            logger.error("Error retrieving user documents", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to retrieve user documents: " + e.getMessage()));
        }
    }

    @GetMapping("/{documentId}/download")
    @PreAuthorize("permitAll()")
    public ResponseEntity<byte[]> downloadDocument(@PathVariable String documentId) {
        logger.info("Downloading document: {}", documentId);

        try {
            User currentUser = getCurrentUser();
            DocumentDto document = documentService.getDocument(documentId, currentUser);

            // Create document content
            String content = buildDocumentContent(document);
            byte[] documentBytes = content.getBytes("UTF-8");

            // Create filename
            String filename = document.getTitle().replaceAll("[^a-zA-Z0-9._-]", "_") + "_v" + document.getVersion()
                    + ".txt";

            logger.info("Document downloaded successfully: {}", documentId);

            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"" + filename + "\"")
                    .header("Content-Type", "text/plain; charset=UTF-8")
                    .body(documentBytes);

        } catch (Exception e) {
            logger.error("Error downloading document", e);
            return ResponseEntity.status(500).build();
        }
    }

    @GetMapping("/{documentId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> getDocument(@PathVariable String documentId) {
        logger.info("Retrieving document: {}", documentId);

        try {
            // Direct database access without service layer
            logger.warn("Direct database access for document retrieval");
            Optional<LegalDocument> document = documentRepository.findById(documentId);

            if (document.isEmpty()) {
                return ResponseEntity.status(404).body(Map.of(
                        "success", false,
                        "error", "Document not found"));
            }

            LegalDocument doc = document.get();
            DocumentDto dto = new DocumentDto();
            dto.setId(doc.getId());
            dto.setTitle(doc.getTitle());
            dto.setContent(doc.getContent());
            dto.setType(doc.getType());
            dto.setPartyA(doc.getPartyA());
            dto.setPartyB(doc.getPartyB());
            dto.setTerms(doc.getTerms());
            dto.setCreatedAt(doc.getCreatedAt());
            dto.setUpdatedAt(doc.getUpdatedAt());
            dto.setIsEdited(doc.getIsEdited());
            dto.setVersion(doc.getVersion());

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "document", dto));
        } catch (Exception e) {
            logger.error("Error retrieving document", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to retrieve document: " + e.getMessage()));
        }
    }

    @DeleteMapping("/{documentId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> deleteDocument(@PathVariable String documentId) {
        logger.info("Deleting document: {}", documentId);

        try {
            User currentUser = getCurrentUser();

            // Use service layer for proper authorization and logging
            documentService.deleteDocument(documentId, currentUser);

            logger.info("Document deleted successfully: {}", documentId);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Document deleted successfully",
                    "deletedDocumentId", documentId));
        } catch (Exception e) {
            logger.error("Error deleting document: {}", documentId, e);

            // Return appropriate status code based on error type
            if (e.getMessage().contains("not found")) {
                return ResponseEntity.status(404).body(Map.of(
                        "success", false,
                        "error", e.getMessage()));
            } else if (e.getMessage().contains("Unauthorized")) {
                return ResponseEntity.status(403).body(Map.of(
                        "success", false,
                        "error", e.getMessage()));
            } else {
                return ResponseEntity.status(500).body(Map.of(
                        "success", false,
                        "error", "Failed to delete document: " + e.getMessage()));
            }
        }
    }

    @DeleteMapping("/bulk")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> deleteBulkDocuments(@RequestBody Map<String, Object> request) {
        logger.info("Bulk deleting documents");

        try {
            @SuppressWarnings("unchecked")
            List<String> documentIds = (List<String>) request.get("documentIds");

            if (documentIds == null || documentIds.isEmpty()) {
                return ResponseEntity.status(400).body(Map.of(
                        "success", false,
                        "error", "No document IDs provided"));
            }

            User currentUser = getCurrentUser();

            // Use service layer for bulk deletion
            documentService.deleteMultipleDocuments(documentIds, currentUser);

            logger.info("Bulk delete completed successfully for {} documents", documentIds.size());

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", String.format("%d documents deleted successfully", documentIds.size()),
                    "deletedCount", documentIds.size(),
                    "deletedDocumentIds", documentIds));
        } catch (Exception e) {
            logger.error("Error in bulk delete operation", e);

            // Return appropriate status code based on error type
            if (e.getMessage().contains("Unauthorized")) {
                return ResponseEntity.status(403).body(Map.of(
                        "success", false,
                        "error", e.getMessage()));
            } else {
                return ResponseEntity.status(500).body(Map.of(
                        "success", false,
                        "error", "Bulk delete failed: " + e.getMessage()));
            }
        }
    }

    private String buildDocumentContent(DocumentDto document) {
        StringBuilder content = new StringBuilder();
        content.append("DOCUMENT TITLE: ").append(document.getTitle()).append("\n");
        content.append("DOCUMENT TYPE: ").append(document.getType()).append("\n");
        content.append("VERSION: ").append(document.getVersion()).append("\n");
        content.append("CREATED: ").append(document.getCreatedAt()).append("\n");
        content.append("LAST UPDATED: ").append(document.getUpdatedAt()).append("\n");
        content.append("IS EDITED: ").append(document.getIsEdited()).append("\n\n");

        if (document.getPartyA() != null && !document.getPartyA().isEmpty()) {
            content.append("PARTY A: ").append(document.getPartyA()).append("\n");
        }
        if (document.getPartyB() != null && !document.getPartyB().isEmpty()) {
            content.append("PARTY B: ").append(document.getPartyB()).append("\n\n");
        }

        content.append("DOCUMENT CONTENT:\n");
        content.append("=".repeat(50)).append("\n");
        content.append(document.getContent()).append("\n");
        content.append("=".repeat(50)).append("\n\n");

        if (document.getTerms() != null && !document.getTerms().isEmpty()) {
            content.append("TERMS AND CONDITIONS:\n");
            content.append("-".repeat(30)).append("\n");
            content.append(document.getTerms()).append("\n");
        }

        return content.toString();
    }

    @PostMapping("/{documentId}/confirm-delete")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> confirmDelete(@PathVariable String documentId) {
        logger.info("Confirming delete for document: {}", documentId);

        try {
            User currentUser = getCurrentUser();

            // Get document details for confirmation
            DocumentDto document = documentService.getDocument(documentId, currentUser);

            // Return document details for confirmation dialog
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "document", Map.of(
                            "id", document.getId(),
                            "title", document.getTitle(),
                            "type", document.getType(),
                            "createdAt", document.getCreatedAt(),
                            "isEdited", document.getIsEdited(),
                            "version", document.getVersion(),
                            "contentPreview", document.getContent().length() > 200
                                    ? document.getContent().substring(0, 200) + "..."
                                    : document.getContent()),
                    "warnings", List.of(
                            "This action cannot be undone",
                            "All document data will be permanently removed",
                            document.getIsEdited()
                                    ? "This document has been modified (version " + document.getVersion() + ")"
                                    : null)
                            .stream().filter(w -> w != null).toList()));
        } catch (Exception e) {
            logger.error("Error confirming delete for document: {}", documentId, e);

            if (e.getMessage().contains("not found")) {
                return ResponseEntity.status(404).body(Map.of(
                        "success", false,
                        "error", e.getMessage()));
            } else if (e.getMessage().contains("Unauthorized")) {
                return ResponseEntity.status(403).body(Map.of(
                        "success", false,
                        "error", e.getMessage()));
            } else {
                return ResponseEntity.status(500).body(Map.of(
                        "success", false,
                        "error", "Failed to confirm delete: " + e.getMessage()));
            }
        }
    }

    @GetMapping("/status")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> getStatus() {
        logger.debug("Document service status check");
        return ResponseEntity.ok(Map.of(
                "status", "Document Service is running",
                "timestamp", System.currentTimeMillis(),
                "version", "2.1.0",
                "features", Map.of(
                        "documentSave", true,
                        "documentUpdate", true,
                        "documentEdit", true,
                        "documentDelete", true,
                        "bulkDelete", true,
                        "deleteConfirmation", true,
                        "versionControl", true,
                        "migration", true)));
    }

    @PostMapping("/migrate")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> migrateDocuments() {
        logger.info("Starting document migration");

        try {
            documentMigrationService.migrateDocuments();

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Document migration completed successfully"));
        } catch (Exception e) {
            logger.error("Error during document migration", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to migrate documents: " + e.getMessage()));
        }
    }

    @PostMapping("/cleanup")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> cleanupOrphanedDocuments() {
        logger.info("Starting orphaned document cleanup");

        try {
            documentMigrationService.cleanupOrphanedDocuments();

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Orphaned document cleanup completed successfully"));
        } catch (Exception e) {
            logger.error("Error during orphaned document cleanup", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to cleanup orphaned documents: " + e.getMessage()));
        }
    }

    private User getCurrentUser() {
        try {
            logger.info("Getting current user from SecurityContext");
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            logger.info("Authentication object: {}",
                    authentication != null ? authentication.getClass().getSimpleName() : "null");

            if (authentication != null) {
                logger.info("Authentication principal: {}",
                        authentication.getPrincipal() != null ? authentication.getPrincipal().getClass().getSimpleName()
                                : "null");

                if (authentication.getPrincipal() instanceof User) {
                    User user = (User) authentication.getPrincipal();
                    logger.info("Authenticated user: {}", user.getUsername());
                    return user;
                } else {
                    logger.warn("Authentication principal is not a User instance: {}", authentication.getPrincipal());
                }
            } else {
                logger.warn("No authentication found in SecurityContext");
            }

            // For development: return a default user if not authenticated
            logger.warn("No authenticated user found, using default user for development");
            User defaultUser = new User();
            defaultUser.setId("dev-user-id");
            defaultUser.setUsername("dev-user");
            defaultUser.setEmail("dev@example.com");
            defaultUser.setRoles(new HashSet<>());
            logger.info("Created default user: {}", defaultUser.getUsername());
            return defaultUser;
        } catch (Exception e) {
            logger.error("Error in getCurrentUser(): {}", e.getMessage(), e);
            throw e;
        }
    }

    @GetMapping("/test-simple")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> testSimpleDocument() {
        logger.info("Testing simple document operations");

        try {
            // Create a simple document
            SimpleDocument simpleDoc = new SimpleDocument(
                    "Test Document",
                    "This is a test document content",
                    "TEST",
                    "Party A",
                    "Party B",
                    "Test terms",
                    "test-user-id");

            SimpleDocument savedDoc = simpleDocumentRepository.save(simpleDoc);
            logger.info("Simple document created with ID: {}", savedDoc.getId());

            // Try to retrieve it
            SimpleDocument retrievedDoc = simpleDocumentRepository.findById(savedDoc.getId()).orElse(null);
            logger.info("Simple document retrieved: {}", retrievedDoc != null ? retrievedDoc.getTitle() : "null");

            // Try to delete it
            simpleDocumentRepository.deleteById(savedDoc.getId());
            logger.info("Simple document deleted successfully");

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Simple document operations successful",
                    "documentId", savedDoc.getId()));
        } catch (Exception e) {
            logger.error("Error in simple document test", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Simple document test failed: " + e.getMessage()));
        }
    }

    @PostMapping("/upload")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> uploadDocument(@RequestParam("file") MultipartFile file) {
        logger.info("Uploading document: name={}, size={}, type={}",
                file.getOriginalFilename(), file.getSize(), file.getContentType());

        try {
            User currentUser = getCurrentUser();
            String userId = currentUser != null ? currentUser.getId() : "anonymous";

            // Validate file type
            String contentType = file.getContentType();
            if (contentType == null || (!contentType.startsWith("image/") &&
                    !contentType.equals("application/pdf") &&
                    !contentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document") &&
                    !contentType.equals("application/msword"))) {
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "error", "Unsupported file type. Please upload JPG, PDF, or DOCX files."));
            }

            // Create upload directory if it doesn't exist
            String uploadDir = "uploads/documents";
            Path uploadPath = Paths.get(uploadDir);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            // Generate unique filename
            String originalFilename = file.getOriginalFilename();
            String fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
            String uniqueFilename = System.currentTimeMillis() + "_" + originalFilename;
            Path filePath = uploadPath.resolve(uniqueFilename);

            // Save file
            Files.copy(file.getInputStream(), filePath);

            // Create document record
            SimpleDocument document = new SimpleDocument();
            document.setTitle(originalFilename);
            document.setFileName(uniqueFilename);
            document.setFilePath(filePath.toString());
            document.setFileSize(file.getSize());
            document.setContentType(contentType);
            document.setUserId(userId);
            document.setCreatedAt(LocalDateTime.now());
            document.setUpdatedAt(LocalDateTime.now());
            document.setStatus("UPLOADED");

            SimpleDocument savedDocument = simpleDocumentRepository.save(document);

            logger.info("Document uploaded successfully: id={}, filename={}",
                    savedDocument.getId(), uniqueFilename);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Document uploaded successfully",
                    "documentId", savedDocument.getId(),
                    "filename", uniqueFilename,
                    "originalName", originalFilename,
                    "fileSize", file.getSize(),
                    "contentType", contentType,
                    "uploadDate", savedDocument.getCreatedAt().toString()));

        } catch (IOException e) {
            logger.error("Error saving file", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to save file: " + e.getMessage()));
        } catch (Exception e) {
            logger.error("Error uploading document", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Upload failed: " + e.getMessage()));
        }
    }

    @PostMapping("/analyze/{documentId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> analyzeDocument(@PathVariable String documentId) {
        logger.info("Analyzing document: id={}", documentId);

        try {
            User currentUser = getCurrentUser();
            String userId = currentUser != null ? currentUser.getId() : "anonymous";

            Optional<SimpleDocument> documentOpt = simpleDocumentRepository.findById(documentId);
            if (documentOpt.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            SimpleDocument document = documentOpt.get();
            // Allow access for anonymous users or document owners
            if (currentUser != null && !document.getUserId().equals(currentUser.getId())) {
                return ResponseEntity.status(403).body(Map.of(
                        "success", false,
                        "error", "Access denied"));
            }

            // Mock AI analysis result
            Map<String, Object> analysisResult = Map.of(
                    "documentType", "Legal Contract",
                    "confidence", 0.92,
                    "keyPoints", List.of(
                            "Contract between two parties",
                            "Payment terms clearly defined",
                            "Termination clause present",
                            "Liability limitations included"),
                    "redFlags", List.of(
                            "Missing force majeure clause",
                            "Unclear dispute resolution process"),
                    "suggestions", List.of(
                            "Add force majeure clause for unforeseen circumstances",
                            "Define clear dispute resolution mechanism",
                            "Include confidentiality clause",
                            "Specify governing law and jurisdiction"),
                    "riskScore", 7.5,
                    "overallRating", "Good");

            // Update document status
            document.setStatus("ANALYZED");
            document.setUpdatedAt(LocalDateTime.now());
            simpleDocumentRepository.save(document);

            logger.info("Document analysis completed: id={}", documentId);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Document analysis completed",
                    "analysis", analysisResult));

        } catch (Exception e) {
            logger.error("Error analyzing document", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Analysis failed: " + e.getMessage()));
        }
    }

    @GetMapping("/uploaded")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> getUploadedDocuments() {
        logger.info("Fetching uploaded documents");

        try {
            User currentUser = getCurrentUser();
            String userId = currentUser != null ? currentUser.getId() : "anonymous";

            List<SimpleDocument> documents = simpleDocumentRepository.findByUserId(userId);

            List<Map<String, Object>> documentList = documents.stream()
                    .map(doc -> {
                        Map<String, Object> docMap = new java.util.HashMap<>();
                        docMap.put("id", doc.getId());
                        docMap.put("title", doc.getTitle());
                        docMap.put("fileName", doc.getFileName());
                        docMap.put("fileSize", doc.getFileSize());
                        docMap.put("contentType", doc.getContentType());
                        docMap.put("status", doc.getStatus());
                        docMap.put("createdAt", doc.getCreatedAt().toString());
                        docMap.put("updatedAt", doc.getUpdatedAt().toString());
                        return docMap;
                    })
                    .collect(java.util.stream.Collectors.toList());

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "documents", documentList,
                    "count", documentList.size()));

        } catch (Exception e) {
            logger.error("Error fetching uploaded documents", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to fetch documents: " + e.getMessage()));
        }
    }

    @DeleteMapping("/uploaded/{documentId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Map<String, Object>> deleteUploadedDocument(@PathVariable String documentId) {
        logger.info("DELETE /uploaded/{} endpoint called", documentId);
        logger.info("Deleting uploaded document: {}", documentId);

        try {
            User currentUser = getCurrentUser();
            String userId = currentUser != null ? currentUser.getId() : "anonymous";
            logger.info("Current user ID: {}", userId);

            // Check if document exists and belongs to user
            Optional<SimpleDocument> document = simpleDocumentRepository.findById(documentId);
            logger.info("Document found in database: {}", document.isPresent());

            if (document.isEmpty()) {
                logger.error("Uploaded document not found with ID: {}", documentId);
                return ResponseEntity.status(404).body(Map.of(
                        "success", false,
                        "error", "Document not found"));
            }

            SimpleDocument doc = document.get();
            logger.info("Document user ID: {}, Current user ID: {}", doc.getUserId(), userId);

            // Check authorization - document must belong to current user
            if (!userId.equals(doc.getUserId())) {
                logger.warn("Unauthorized deletion attempt for uploaded document {} by user {}",
                        documentId, userId);
                return ResponseEntity.status(403).body(Map.of(
                        "success", false,
                        "error", "Unauthorized: You can only delete your own documents"));
            }

            logger.info("Authorization check passed for document deletion");

            // Delete the document
            simpleDocumentRepository.deleteById(documentId);

            // Also delete the physical file if it exists
            try {
                if (doc.getFileName() != null && !doc.getFileName().isEmpty()) {
                    String uploadDir = "uploads/documents";
                    Path filePath = Paths.get(uploadDir, doc.getFileName());
                    if (Files.exists(filePath)) {
                        Files.delete(filePath);
                        logger.info("Physical file deleted: {}", filePath);
                    }
                }
            } catch (IOException e) {
                logger.warn("Failed to delete physical file for document {}: {}", documentId, e.getMessage());
                // Don't fail the operation if file deletion fails
            }

            logger.info("Uploaded document {} deleted successfully by user {}", documentId, userId);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Document deleted successfully",
                    "deletedDocumentId", documentId));

        } catch (Exception e) {
            logger.error("Error deleting uploaded document: {}", documentId, e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to delete document: " + e.getMessage()));
        }
    }
}
