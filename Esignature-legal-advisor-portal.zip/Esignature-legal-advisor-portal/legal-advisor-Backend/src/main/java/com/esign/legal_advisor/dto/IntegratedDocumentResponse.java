package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Response DTO for integrated document operations
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IntegratedDocumentResponse {
    
    private String documentId;
    private String title;
    private String content;
    private String type;
    private String partyA;
    private String partyB;
    private String terms;
    
    // Status information
    private String status; // CREATED, ANALYZED, SIGNED, COMPLETED, ERROR
    private boolean success;
    private String message;
    
    // Timestamps
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Integer version;
    
    // Analysis results
    private DocumentAnalysisResult analysisResult;
    
    // Signing information
    private SigningMetadata signingMetadata;
    
    // Generated files
    private byte[] generatedPdf;
    private byte[] generatedDocx;
    private String documentUrl;
    
    // Metadata
    private Map<String, Object> metadata;
    
    // Document quality and risk
    private String documentQuality;
    private String riskLevel;
    
    // Error details (if any)
    private String errorCode;
    private String errorMessage;
    private Map<String, String> errorDetails;
}
