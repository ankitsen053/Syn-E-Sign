package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class GstVerificationDto {

    @NotBlank(message = "GST number is required")
    @Pattern(regexp = "^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$", message = "Invalid GST number format. GST should be 15 characters: 2 digits + 5 letters + 4 digits + 1 letter + 1 digit/letter + Z + 1 digit/letter (e.g., 27AAPFU0939F1Z5)")
    @Size(min = 15, max = 15, message = "GST number must be exactly 15 characters")
    private String gstNumber;

    @NotBlank(message = "Company name is required")
    @Size(min = 2, max = 100, message = "Company name must be between 2 and 100 characters")
    private String companyName;

    @NotBlank(message = "Uploadation is required")
    private String uploadation;

    // Optional fields for additional verification
    private String businessAddress;
    private String contactNumber;
    private String email;

    // Constructors
    public GstVerificationDto() {
    }

    public GstVerificationDto(String gstNumber, String companyName, String uploadation) {
        this.gstNumber = gstNumber;
        this.companyName = companyName;
        this.uploadation = uploadation;
    }

    public GstVerificationDto(String gstNumber, String companyName, String uploadation,
            String businessAddress, String contactNumber, String email) {
        this.gstNumber = gstNumber;
        this.companyName = companyName;
        this.uploadation = uploadation;
        this.businessAddress = businessAddress;
        this.contactNumber = contactNumber;
        this.email = email;
    }

    // Getters and Setters
    public String getGstNumber() {
        return gstNumber;
    }

    public void setGstNumber(String gstNumber) {
        this.gstNumber = gstNumber;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getUploadation() {
        return uploadation;
    }

    public void setUploadation(String uploadation) {
        this.uploadation = uploadation;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "GstVerificationDto{" +
                "gstNumber='" + maskGst(gstNumber) + '\'' +
                ", companyName='" + companyName + '\'' +
                ", uploadation='" + uploadation + '\'' +
                ", businessAddress='" + businessAddress + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", email='" + email + '\'' +
                '}';
    }

    private String maskGst(String gst) {
        if (gst == null || gst.length() < 4)
            return "****";
        return gst.substring(0, 2) + "****" + gst.substring(gst.length() - 2);
    }
}
