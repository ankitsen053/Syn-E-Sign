package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.JwtResponse;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.service.GoogleOAuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth/gmail")
@CrossOrigin(origins = "*", maxAge = 3600)
public class GmailOAuthController {

    private static final Logger logger = LoggerFactory.getLogger(GmailOAuthController.class);

    @Autowired
    private GoogleOAuthService googleOAuthService;

    @Value("${spring.security.oauth2.client.registration.google.client-id:}")
    private String clientId;

    @Value("${spring.security.oauth2.client.registration.google.client-secret:}")
    private String clientSecret;

    @GetMapping("/login")
    public ResponseEntity<MessageResponse> initiateGmailLogin() {
        try {
            // Generate Google OAuth URL
            String googleOAuthUrl = generateGoogleOAuthUrl();
            logger.info("Gmail OAuth login initiated");
            return ResponseEntity.ok(new MessageResponse(googleOAuthUrl));
        } catch (Exception e) {
            logger.error("Error generating Gmail OAuth URL", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to initiate Gmail login"));
        }
    }

    @GetMapping("/callback")
    public void handleGmailCallback(@RequestParam("code") String code,
            @RequestParam(value = "error", required = false) String error,
            HttpServletRequest request,
            HttpServletResponse response) throws IOException {
        try {
            if (error != null) {
                logger.error("Gmail OAuth error: {}", error);
                response.sendRedirect("http://localhost:5174/login?error=gmail_oauth_failed");
                return;
            }

            logger.info("Gmail OAuth callback received with code");

            // Exchange code for access token and get user info
            Map<String, String> userInfo = exchangeCodeForUserInfo(code);

            if (userInfo != null) {
                // Process the Gmail login
                JwtResponse jwtResponse = processGmailLogin(userInfo);

                // Redirect to frontend with JWT token
                String redirectUrl = "http://localhost:5174/oauth-callback?token=" + jwtResponse.getToken() +
                        "&type=" + jwtResponse.getType() +
                        "&username=" + URLEncoder.encode(jwtResponse.getUsername(), StandardCharsets.UTF_8) +
                        "&email=" + URLEncoder.encode(jwtResponse.getEmail(), StandardCharsets.UTF_8);

                response.sendRedirect(redirectUrl);
                logger.info("User successfully authenticated via Gmail OAuth");
            } else {
                logger.error("Failed to get user info from Gmail");
                response.sendRedirect("http://localhost:5174/login?error=gmail_oauth_failed");
            }
        } catch (Exception e) {
            logger.error("Error processing Gmail OAuth callback", e);
            response.sendRedirect("http://localhost:5174/login?error=gmail_oauth_failed");
        }
    }

    private String generateGoogleOAuthUrl() {
        String redirectUri = "http://localhost:8080/api/auth/gmail/callback";
        String scope = "openid email profile";

        return String.format(
                "https://accounts.google.com/o/oauth2/auth?" +
                        "client_id=%s&" +
                        "redirect_uri=%s&" +
                        "scope=%s&" +
                        "response_type=code&" +
                        "access_type=offline",
                clientId,
                URLEncoder.encode(redirectUri, StandardCharsets.UTF_8),
                URLEncoder.encode(scope, StandardCharsets.UTF_8));
    }

    private Map<String, String> exchangeCodeForUserInfo(String code) {
        try {
            // This is a simplified version - in production, you'd want to use a proper HTTP
            // client
            // For now, we'll return a mock user info for testing
            Map<String, String> userInfo = new HashMap<>();
            userInfo.put("email", "test@gmail.com");
            userInfo.put("name", "Test User");
            userInfo.put("picture", "https://via.placeholder.com/150");
            userInfo.put("sub", "123456789");

            logger.info("Mock user info generated for testing");
            return userInfo;
        } catch (Exception e) {
            logger.error("Error exchanging code for user info", e);
            return null;
        }
    }

    private JwtResponse processGmailLogin(Map<String, String> userInfo) {
        try {
            String email = userInfo.get("email");
            String name = userInfo.get("name");
            String picture = userInfo.get("picture");
            String googleId = userInfo.get("sub");

            // Use the existing GoogleOAuthService to process the login
            // For Gmail OAuth, assume email is verified by Google
            return googleOAuthService.processGmailLogin(email, name, googleId, picture, true);
        } catch (Exception e) {
            logger.error("Error processing Gmail login", e);
            throw new RuntimeException("Gmail login failed: " + e.getMessage());
        }
    }

    @GetMapping("/login-url")
    public ResponseEntity<MessageResponse> getGmailLoginUrl() {
        try {
            String gmailOAuthUrl = generateGoogleOAuthUrl();
            return ResponseEntity.ok(new MessageResponse(gmailOAuthUrl));
        } catch (Exception e) {
            logger.error("Error generating Gmail login URL", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to generate login URL"));
        }
    }
}
