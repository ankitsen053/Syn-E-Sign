package com.esign.legal_advisor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LegalAdvisorApplication {

  public static void main(String[] args) {
    SpringApplication.run(LegalAdvisorApplication.class, args);

  }
}