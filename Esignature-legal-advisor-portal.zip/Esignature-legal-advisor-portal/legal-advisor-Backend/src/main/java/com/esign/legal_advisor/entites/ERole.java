package com.esign.legal_advisor.entites;

public enum ERole {
	ROLE_USER,
	ROLE_COMPANY,
	ROLE_LAWYER,
	ROLE_SENIOR_LAWYER,
	ROLE_LEGAL_FIRM,
	ROLE_ADMIN
}
