package com.esign.legal_advisor.entites;

import java.time.LocalDateTime;

public class SignatureData {
    private String signerId;
    private String signerName;
    private String signerEmail;
    private String signatureImageBase64;
    private String signatureData; // JSON string containing signature coordinates
    private LocalDateTime signedAt;
    private String signerIpAddress;
    private String signatureMethod; // CANVAS, OTP, TEXT
    private String otpCode; // For OTP-based signatures
    private boolean isVerified;
    private String verificationNotes;

    public SignatureData() {
        this.signedAt = LocalDateTime.now();
        this.isVerified = false;
    }

    public SignatureData(String signerId, String signerName, String signerEmail,
            String signatureImageBase64, String signatureData,
            String signerIpAddress, String signatureMethod) {
        this();
        this.signerId = signerId;
        this.signerName = signerName;
        this.signerEmail = signerEmail;
        this.signatureImageBase64 = signatureImageBase64;
        this.signatureData = signatureData;
        this.signerIpAddress = signerIpAddress;
        this.signatureMethod = signatureMethod;
    }

    // Getters and Setters
    public String getSignerId() {
        return signerId;
    }

    public void setSignerId(String signerId) {
        this.signerId = signerId;
    }

    public String getSignerName() {
        return signerName;
    }

    public void setSignerName(String signerName) {
        this.signerName = signerName;
    }

    public String getSignerEmail() {
        return signerEmail;
    }

    public void setSignerEmail(String signerEmail) {
        this.signerEmail = signerEmail;
    }

    public String getSignatureImageBase64() {
        return signatureImageBase64;
    }

    public void setSignatureImageBase64(String signatureImageBase64) {
        this.signatureImageBase64 = signatureImageBase64;
    }

    public String getSignatureData() {
        return signatureData;
    }

    public void setSignatureData(String signatureData) {
        this.signatureData = signatureData;
    }

    public LocalDateTime getSignedAt() {
        return signedAt;
    }

    public void setSignedAt(LocalDateTime signedAt) {
        this.signedAt = signedAt;
    }

    public String getSignerIpAddress() {
        return signerIpAddress;
    }

    public void setSignerIpAddress(String signerIpAddress) {
        this.signerIpAddress = signerIpAddress;
    }

    public String getSignatureMethod() {
        return signatureMethod;
    }

    public void setSignatureMethod(String signatureMethod) {
        this.signatureMethod = signatureMethod;
    }

    public String getOtpCode() {
        return otpCode;
    }

    public void setOtpCode(String otpCode) {
        this.otpCode = otpCode;
    }

    public boolean isVerified() {
        return isVerified;
    }

    public void setVerified(boolean verified) {
        isVerified = verified;
    }

    public String getVerificationNotes() {
        return verificationNotes;
    }

    public void setVerificationNotes(String verificationNotes) {
        this.verificationNotes = verificationNotes;
    }
}



