package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.JwtResponse;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.repository.UserRepository;
import com.esign.legal_advisor.repository.RoleRepository;
import com.esign.legal_advisor.security.JwtUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import com.esign.legal_advisor.entites.Role;
import com.esign.legal_advisor.entites.ERole;

@Service
public class GoogleOAuthService {

    private static final Logger logger = LoggerFactory.getLogger(GoogleOAuthService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private GmailVerificationService gmailVerificationService;

    @Autowired
    private OTPService otpService;

    public JwtResponse processGoogleOAuthLogin(OAuth2AuthenticationToken authentication) {
        try {
            OAuth2User oauth2User = authentication.getPrincipal();

            // Extract and validate user information from OAuth2
            String email = oauth2User.getAttribute("email");
            String name = oauth2User.getAttribute("name");
            String picture = oauth2User.getAttribute("picture");
            String googleId = oauth2User.getAttribute("sub"); // Google's unique ID
            String emailVerified = oauth2User.getAttribute("email_verified");
            String givenName = oauth2User.getAttribute("given_name");
            String familyName = oauth2User.getAttribute("family_name");

            logger.info("Processing Google OAuth login for email: {}, verified: {}, googleId: {}",
                    email, emailVerified, googleId);

            // Validate essential OAuth data
            if (email == null || email.trim().isEmpty()) {
                throw new RuntimeException("Email is required for Google OAuth login");
            }
            if (googleId == null || googleId.trim().isEmpty()) {
                throw new RuntimeException("Google ID is required for OAuth login");
            }

            // Validate Gmail OAuth data comprehensively
            GmailVerificationService.GmailVerificationResult verificationResult = gmailVerificationService
                    .validateGmailOAuthData(email, googleId, name, picture);

            if (!verificationResult.isValid()) {
                throw new RuntimeException("Gmail OAuth validation failed: " + verificationResult.getErrorMessage());
            }

            // Check if email is verified by Google
            boolean isEmailVerifiedByGoogle = Boolean.TRUE.equals(emailVerified);
            if (!isEmailVerifiedByGoogle) {
                logger.warn("Email {} is not verified by Google, but proceeding with OAuth login", email);
            }

            // Use given_name and family_name if name is not available
            if ((name == null || name.trim().isEmpty()) &&
                    (givenName != null || familyName != null)) {
                name = (givenName != null ? givenName : "") +
                        (familyName != null ? " " + familyName : "").trim();
            }

            // For OAuth users, send OTP for additional verification
            otpService.generateAndSendOTP(email, "OAUTH_VERIFICATION");

            // Return a special response indicating OTP is required
            return new JwtResponse(
                    null, // No JWT yet
                    null, // No user ID yet
                    name,
                    email,
                    null, // No roles yet
                    "OTP_REQUIRED" // Special type indicating OTP needed
            );

        } catch (Exception e) {
            logger.error("Error processing Google OAuth login", e);
            throw new RuntimeException("Google OAuth login failed: " + e.getMessage());
        }
    }

    public JwtResponse processGmailLogin(String email, String name, String googleId, String picture,
            boolean isEmailVerifiedByGoogle) {
        try {
            logger.info("Processing Gmail login for email: {}, verified by Google: {}", email, isEmailVerifiedByGoogle);

            // Validate email
            if (email == null || email.trim().isEmpty()) {
                throw new RuntimeException("Email is required for Google OAuth login");
            }

            // Validate Gmail OAuth data comprehensively
            GmailVerificationService.GmailVerificationResult verificationResult = gmailVerificationService
                    .validateGmailOAuthData(email, googleId, name, picture);

            if (!verificationResult.isValid()) {
                throw new RuntimeException("Gmail OAuth validation failed: " + verificationResult.getErrorMessage());
            }

            // Check if user exists by email
            Optional<User> existingUserByEmail = userRepository.findByEmail(email);

            // Check if user exists by Google ID
            Optional<User> existingUserByGoogleId = userRepository.findByGoogleId(googleId);

            User user;

            if (existingUserByEmail.isPresent()) {
                // User exists by email - this is a registered user
                user = existingUserByEmail.get();
                logger.info("Found existing registered user by email: {}", email);

                // Update Google ID if not set (link Google account to existing user)
                if (user.getGoogleId() == null || user.getGoogleId().isEmpty()) {
                    user.setGoogleId(googleId);
                    logger.info("Linked Google account to existing user: {}", email);
                } else if (!googleId.equals(user.getGoogleId())) {
                    // Google ID mismatch - this could be a security issue
                    logger.warn("Google ID mismatch for user: {}. Existing: {}, New: {}",
                            email, user.getGoogleId(), googleId);
                    // For now, update to the new Google ID (user might have recreated Google
                    // account)
                    user.setGoogleId(googleId);
                }

                // Update profile information if available
                if (name != null && !name.trim().isEmpty() &&
                        (user.getFullName() == null || user.getFullName().trim().isEmpty())) {
                    user.setFullName(name);
                }
                if (picture != null && !picture.trim().isEmpty() &&
                        (user.getProfilePicture() == null || user.getProfilePicture().trim().isEmpty())) {
                    user.setProfilePicture(picture);
                }

                // Ensure user is enabled and email is verified
                user.setEnabled(true);
                // Only set email as verified if Google has verified it
                if (isEmailVerifiedByGoogle) {
                    user.setEmailVerified(true);
                    logger.info("Email {} verified by Google for existing user", email);
                } else {
                    logger.warn(
                            "Email {} not verified by Google for existing user, keeping current verification status",
                            email);
                }
                user.setUpdatedAt(java.time.LocalDateTime.now());

                userRepository.save(user);
                logger.info("Successfully processed OAuth login for existing registered user: {}", email);

            } else if (existingUserByGoogleId.isPresent()) {
                // User exists by Google ID but different email
                user = existingUserByGoogleId.get();
                logger.info("Found existing user by Google ID with different email. Old: {}, New: {}",
                        user.getEmail(), email);

                // Update email if it's different
                if (!email.equals(user.getEmail())) {
                    // Check if the new email is already taken by another user
                    Optional<User> emailConflict = userRepository.findByEmail(email);
                    if (emailConflict.isPresent()) {
                        throw new RuntimeException("Email " + email + " is already registered to another user");
                    }
                    user.setEmail(email);
                }

                // Update profile information
                if (name != null && !name.trim().isEmpty()) {
                    user.setFullName(name);
                }
                if (picture != null && !picture.trim().isEmpty()) {
                    user.setProfilePicture(picture);
                }

                user.setEnabled(true);
                // Only set email as verified if Google has verified it
                if (isEmailVerifiedByGoogle) {
                    user.setEmailVerified(true);
                    logger.info("Email {} verified by Google for user with Google ID", email);
                } else {
                    logger.warn(
                            "Email {} not verified by Google for user with Google ID, keeping current verification status",
                            email);
                }
                user.setUpdatedAt(java.time.LocalDateTime.now());

                userRepository.save(user);
                logger.info("Updated existing user with new email via OAuth: {}", email);

            } else {
                // Create new user from Gmail OAuth
                logger.info("Creating new user via Google OAuth: {}", email);
                user = createUserFromGoogleOAuth(email, name, googleId, picture, isEmailVerifiedByGoogle);
                userRepository.save(user);
                logger.info("Successfully created new user via Google OAuth: {}", email);
            }

            return createJwtResponse(user);

        } catch (Exception e) {
            logger.error("Error processing Gmail login for email: {}", email, e);
            throw new RuntimeException("Gmail login failed: " + e.getMessage());
        }
    }

    private User createUserFromGoogleOAuth(String email, String name, String googleId, String picture,
            boolean isEmailVerifiedByGoogle) {
        User user = new User();
        user.setEmail(email);
        user.setUsername(generateUsernameFromEmail(email));
        user.setFullName(name);
        user.setGoogleId(googleId);
        user.setProfilePicture(picture);
        user.setEmailVerified(isEmailVerifiedByGoogle);
        user.setEnabled(true);
        user.setPassword("GOOGLE_OAUTH_USER"); // Placeholder password for OAuth users

        // Set default role
        Set<Role> roles = new HashSet<>();
        Role userRole = roleRepository.findByName(ERole.ROLE_USER)
                .orElseGet(() -> roleRepository.save(new Role(ERole.ROLE_USER)));
        roles.add(userRole);
        user.setRoles(roles);

        logger.info("Created new user via Google OAuth - Email: {}, Verified: {}", email, isEmailVerifiedByGoogle);
        return user;
    }

    private String generateUsernameFromEmail(String email) {
        String baseUsername = email.split("@")[0];
        String username = baseUsername;
        int counter = 1;

        while (userRepository.existsByUsername(username)) {
            username = baseUsername + counter;
            counter++;
        }

        return username;
    }

    private JwtResponse createJwtResponse(User user) {
        // Create a simple authentication object for JWT generation
        String jwt = jwtUtils.generateJwtTokenFromUser(user);

        // Convert roles to string list
        List<String> roleStrings = user.getRoles().stream()
                .map(role -> role.getName().name())
                .collect(Collectors.toList());

        return new JwtResponse(
                jwt,
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                roleStrings,
                null); // No refresh token for OAuth users
    }

    public MessageResponse linkGoogleAccount(String email, String googleId) {
        try {
            Optional<User> userOpt = userRepository.findByEmail(email);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                user.setGoogleId(googleId);
                userRepository.save(user);
                return new MessageResponse("Google account linked successfully");
            } else {
                return new MessageResponse("Error: User not found");
            }
        } catch (Exception e) {
            logger.error("Error linking Google account", e);
            return new MessageResponse("Error: Failed to link Google account");
        }
    }

    /**
     * Public method to validate Gmail email (used by controller)
     */
    public boolean isValidGmailEmail(String email) {
        return gmailVerificationService.isValidGmailEmail(email);
    }

    /**
     * Verify OTP for OAuth login
     */
    public boolean verifyOTP(String email, String otp) {
        return otpService.verifyOTP(email, otp, "OAUTH_VERIFICATION");
    }

    /**
     * Resend OTP for OAuth login
     */
    public void resendOTP(String email) {
        otpService.generateAndSendOTP(email, "OAUTH_VERIFICATION");
    }

    /**
     * Complete OAuth login after OTP verification
     */
    public JwtResponse completeOAuthLogin(String email) {
        try {
            // Find user by email (should exist from OAuth flow)
            Optional<User> userOpt = userRepository.findByEmail(email);
            if (userOpt.isEmpty()) {
                throw new RuntimeException("User not found for email: " + email);
            }

            User user = userOpt.get();
            return createJwtResponse(user);
        } catch (Exception e) {
            logger.error("Error completing OAuth login for email: {}", email, e);
            throw new RuntimeException("Failed to complete OAuth login: " + e.getMessage());
        }
    }
}
