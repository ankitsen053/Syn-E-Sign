package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.*;
import com.esign.legal_advisor.entites.VerificationStatus;
import com.esign.legal_advisor.service.VerificationService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;

@RestController
@RequestMapping("/api/verification")
@CrossOrigin(origins = "*", maxAge = 3600)
public class VerificationController {

    private static final Logger logger = LoggerFactory.getLogger(VerificationController.class);

    @Autowired
    private VerificationService verificationService;

    @GetMapping("/status")
    public ResponseEntity<?> getVerificationStatus() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userId = authentication.getName();

            VerificationStatus status = verificationService.getVerificationStatus(userId);
            return ResponseEntity.ok(status);

        } catch (Exception e) {
            logger.error("Error getting verification status", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to get verification status"));
        }
    }

    @PostMapping(value = "/pan", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<MessageResponse> submitPanVerification(
            @RequestParam("panNumber") String panNumber,
            @RequestParam("documentFile") MultipartFile documentFile) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userId = authentication.getName();

            // Create DTO from form parameters
            PanVerificationDto panDto = new PanVerificationDto(panNumber, documentFile);
            MessageResponse response = verificationService.submitPanVerification(userId, panDto);

            if (response.getMessage().contains("Error:")) {
                return ResponseEntity.badRequest().body(response);
            }

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error submitting PAN verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to submit PAN verification"));
        }
    }

    @PostMapping(value = "/aadhar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<MessageResponse> submitAadharVerification(
            @RequestParam("aadharNumber") String aadharNumber,
            @RequestParam("documentFile") MultipartFile documentFile) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userId = authentication.getName();

            // Create DTO from form parameters
            AadharVerificationDto aadharDto = new AadharVerificationDto(aadharNumber, documentFile);
            MessageResponse response = verificationService.submitAadharVerification(userId, aadharDto);

            if (response.getMessage().contains("Error:")) {
                return ResponseEntity.badRequest().body(response);
            }

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error submitting Aadhar verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to submit Aadhar verification"));
        }
    }

    @PostMapping("/video")
    public ResponseEntity<MessageResponse> submitVideoVerification(@RequestParam("video") MultipartFile video,
            @RequestParam(value = "notes", required = false) String notes) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userId = authentication.getName();

            VideoVerificationDto videoDto = new VideoVerificationDto(video, notes);
            MessageResponse response = verificationService.submitVideoVerification(userId, videoDto);

            if (response.getMessage().contains("Error:")) {
                return ResponseEntity.badRequest().body(response);
            }

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error submitting video verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to submit video verification"));
        }
    }

    @PostMapping("/gst")
    public ResponseEntity<MessageResponse> submitGstVerification(@Valid @RequestBody GstVerificationDto gstDto) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userId = authentication.getName();

            MessageResponse response = verificationService.submitGstVerification(userId, gstDto);

            if (response.getMessage().contains("Error:")) {
                return ResponseEntity.badRequest().body(response);
            }

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error submitting GST verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to submit GST verification"));
        }
    }

    // Admin endpoints for managing verifications
    @PostMapping("/admin/pan/approve/{userId}")
    public ResponseEntity<MessageResponse> approvePanVerification(@PathVariable String userId) {
        try {
            MessageResponse response = verificationService.approvePanVerification(userId);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error approving PAN verification for user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to approve PAN verification"));
        }
    }

    @PostMapping("/admin/pan/reject/{userId}")
    public ResponseEntity<MessageResponse> rejectPanVerification(@PathVariable String userId,
            @RequestBody String reason) {
        try {
            MessageResponse response = verificationService.rejectPanVerification(userId, reason);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error rejecting PAN verification for user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to reject PAN verification"));
        }
    }

    @PostMapping("/admin/aadhar/approve/{userId}")
    public ResponseEntity<MessageResponse> approveAadharVerification(@PathVariable String userId) {
        try {
            MessageResponse response = verificationService.approveAadharVerification(userId);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error approving Aadhar verification for user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to approve Aadhar verification"));
        }
    }

    @PostMapping("/admin/aadhar/reject/{userId}")
    public ResponseEntity<MessageResponse> rejectAadharVerification(@PathVariable String userId,
            @RequestBody String reason) {
        try {
            MessageResponse response = verificationService.rejectAadharVerification(userId, reason);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error rejecting Aadhar verification for user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to reject Aadhar verification"));
        }
    }

    @PostMapping("/admin/video/approve/{userId}")
    public ResponseEntity<MessageResponse> approveVideoVerification(@PathVariable String userId) {
        try {
            MessageResponse response = verificationService.approveVideoVerification(userId);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error approving video verification for user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to approve video verification"));
        }
    }

    @PostMapping("/admin/video/reject/{userId}")
    public ResponseEntity<MessageResponse> rejectVideoVerification(@PathVariable String userId,
            @RequestBody String reason) {
        try {
            MessageResponse response = verificationService.rejectVideoVerification(userId, reason);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error rejecting video verification for user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to reject video verification"));
        }
    }

    @PostMapping("/admin/gst/approve/{userId}")
    public ResponseEntity<MessageResponse> approveGstVerification(@PathVariable String userId) {
        try {
            MessageResponse response = verificationService.approveGstVerification(userId);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error approving GST verification for user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to approve GST verification"));
        }
    }

    @PostMapping("/admin/gst/reject/{userId}")
    public ResponseEntity<MessageResponse> rejectGstVerification(@PathVariable String userId,
            @RequestBody String reason) {
        try {
            MessageResponse response = verificationService.rejectGstVerification(userId, reason);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error rejecting GST verification for user: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to reject GST verification"));
        }
    }
}
