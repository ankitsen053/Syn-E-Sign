package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.JwtResponse;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.service.GoogleOAuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@RequestMapping("/api/auth/oauth2")
@CrossOrigin(origins = "*", maxAge = 3600)
public class OAuthController {

    private static final Logger logger = LoggerFactory.getLogger(OAuthController.class);

    @Autowired
    private GoogleOAuthService googleOAuthService;

    @GetMapping("/google")
    public ResponseEntity<MessageResponse> initiateGoogleLogin() {
        logger.info("Google OAuth login initiated");
        String googleOAuthUrl = "/oauth2/authorization/google";
        return ResponseEntity.ok(new MessageResponse(googleOAuthUrl));
    }

    @GetMapping("/callback/google")
    public void handleGoogleCallback(Authentication authentication,
            HttpServletRequest request,
            HttpServletResponse response) throws IOException {
        try {
            logger.info("Google OAuth callback received");

            if (authentication instanceof OAuth2AuthenticationToken) {
                OAuth2AuthenticationToken oauthToken = (OAuth2AuthenticationToken) authentication;
                OAuth2User oauth2User = oauthToken.getPrincipal();

                // Extract user information for logging
                String email = oauth2User.getAttribute("email");
                String name = oauth2User.getAttribute("name");
                logger.info("Processing OAuth callback for email: {}, name: {}", email, name);

                JwtResponse jwtResponse = googleOAuthService.processGoogleOAuthLogin(oauthToken);

                // URL encode parameters to handle special characters
                String redirectUrl = "http://localhost:5173/oauth-callback?" +
                        "token=" + java.net.URLEncoder.encode(jwtResponse.getToken(), "UTF-8") +
                        "&type=" + java.net.URLEncoder.encode(jwtResponse.getType(), "UTF-8") +
                        "&username=" + java.net.URLEncoder.encode(jwtResponse.getUsername(), "UTF-8") +
                        "&email=" + java.net.URLEncoder.encode(jwtResponse.getEmail(), "UTF-8") +
                        "&id=" + java.net.URLEncoder.encode(jwtResponse.getId(), "UTF-8");

                response.sendRedirect(redirectUrl);
                logger.info("User successfully authenticated via Google OAuth: {} - Redirecting to frontend",
                        jwtResponse.getEmail());
            } else {
                logger.error("Invalid authentication token type: {}",
                        authentication != null ? authentication.getClass().getSimpleName() : "null");
                response.sendRedirect("http://localhost:5173/login?error=oauth_failed&reason=invalid_token_type");
            }
        } catch (Exception e) {
            logger.error("Error processing Google OAuth callback", e);
            String errorMessage = e.getMessage() != null ? e.getMessage() : "Unknown error occurred";
            response.sendRedirect("http://localhost:5173/login?error=oauth_failed&reason=" +
                    java.net.URLEncoder.encode(errorMessage, "UTF-8"));
        }
    }

    @PostMapping("/link-google")
    public ResponseEntity<MessageResponse> linkGoogleAccount(@RequestParam String email,
            @RequestParam String googleId) {
        logger.info("Linking Google account for email: {}", email);

        try {
            MessageResponse response = googleOAuthService.linkGoogleAccount(email, googleId);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error linking Google account", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to link Google account"));
        }
    }

    @GetMapping("/google-login-url")
    public ResponseEntity<MessageResponse> getGoogleLoginUrl() {
        String googleOAuthUrl = "/oauth2/authorization/google";
        return ResponseEntity.ok(new MessageResponse(googleOAuthUrl));
    }

    @GetMapping("/status")
    public ResponseEntity<MessageResponse> getOAuthStatus() {
        return ResponseEntity.ok(new MessageResponse("OAuth2 endpoints are available"));
    }

    @GetMapping("/test")
    public ResponseEntity<?> testOAuthConfiguration() {
        try {
            // Test if OAuth2 configuration is working
            String googleOAuthUrl = "/oauth2/authorization/google";
            return ResponseEntity.ok(new MessageResponse("OAuth2 configuration is working. Use: " + googleOAuthUrl));
        } catch (Exception e) {
            logger.error("OAuth2 configuration test failed", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("OAuth2 configuration test failed: " + e.getMessage()));
        }
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<?> verifyOTP(@RequestParam String email, @RequestParam String otp) {
        try {
            logger.info("Verifying OTP for email: {}", email);

            // Verify OTP
            boolean isValid = googleOAuthService.verifyOTP(email, otp);

            if (isValid) {
                // Process the actual OAuth login after OTP verification
                JwtResponse jwtResponse = googleOAuthService.completeOAuthLogin(email);
                return ResponseEntity.ok(jwtResponse);
            } else {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Invalid or expired OTP"));
            }
        } catch (Exception e) {
            logger.error("Error verifying OTP for email: {}", email, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error verifying OTP: " + e.getMessage()));
        }
    }

    @PostMapping("/resend-otp")
    public ResponseEntity<?> resendOTP(@RequestParam String email) {
        try {
            logger.info("Resending OTP for email: {}", email);

            googleOAuthService.resendOTP(email);
            return ResponseEntity.ok(new MessageResponse("OTP sent successfully"));
        } catch (Exception e) {
            logger.error("Error resending OTP for email: {}", email, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error resending OTP: " + e.getMessage()));
        }
    }
}
