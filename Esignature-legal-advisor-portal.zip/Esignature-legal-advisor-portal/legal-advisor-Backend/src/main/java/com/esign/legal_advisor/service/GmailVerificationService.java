package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.regex.Pattern;

@Service
public class GmailVerificationService {

    private static final Logger logger = LoggerFactory.getLogger(GmailVerificationService.class);

    @Autowired
    private UserRepository userRepository;

    // Gmail-specific validation patterns
    private static final Pattern GMAIL_EMAIL_PATTERN = Pattern.compile(
            "^[a-zA-Z0-9](?:[a-zA-Z0-9._-]*[a-zA-Z0-9])?@gmail\\.com$");

    private static final Pattern GOOGLE_ID_PATTERN = Pattern.compile(
            "^[0-9]{21}$");

    /**
     * Comprehensive Gmail email validation
     */
    public boolean isValidGmailEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }

        String trimmedEmail = email.trim().toLowerCase();

        // Basic email format validation
        if (!trimmedEmail.contains("@") || !trimmedEmail.contains(".")) {
            return false;
        }

        // Gmail domain validation
        if (!trimmedEmail.endsWith("@gmail.com")) {
            return false;
        }

        // Gmail-specific format validation
        if (!GMAIL_EMAIL_PATTERN.matcher(trimmedEmail).matches()) {
            return false;
        }

        // Additional Gmail rules
        String localPart = trimmedEmail.split("@")[0];

        // Gmail usernames cannot start or end with a dot
        if (localPart.startsWith(".") || localPart.endsWith(".")) {
            return false;
        }

        // Gmail usernames cannot have consecutive dots
        if (localPart.contains("..")) {
            return false;
        }

        // Gmail usernames length validation
        if (localPart.length() < 1 || localPart.length() > 64) {
            return false;
        }

        // Gmail usernames cannot contain certain special characters
        if (localPart.matches(".*[+].*")) {
            // Gmail aliases with + are valid, but we'll handle them specially
            String baseEmail = localPart.split("\\+")[0];
            if (baseEmail.length() < 1 || baseEmail.length() > 64) {
                return false;
            }
        }

        return true;
    }

    /**
     * Validates Google ID format
     */
    public boolean isValidGoogleId(String googleId) {
        if (googleId == null || googleId.trim().isEmpty()) {
            return false;
        }

        String trimmedGoogleId = googleId.trim();

        // Google IDs are typically 21 digits
        return GOOGLE_ID_PATTERN.matcher(trimmedGoogleId).matches();
    }

    /**
     * Verifies if a Gmail account is properly linked to a user
     */
    public boolean isGmailAccountLinked(String email, String googleId) {
        try {
            Optional<User> userByEmail = userRepository.findByEmail(email);
            Optional<User> userByGoogleId = userRepository.findByGoogleId(googleId);

            // Check if both email and Google ID belong to the same user
            if (userByEmail.isPresent() && userByGoogleId.isPresent()) {
                return userByEmail.get().getId().equals(userByGoogleId.get().getId());
            }

            // Check if user exists with either email or Google ID
            return userByEmail.isPresent() || userByGoogleId.isPresent();
        } catch (Exception e) {
            logger.error("Error checking Gmail account linkage for email: {}", email, e);
            return false;
        }
    }

    /**
     * Validates Gmail OAuth data integrity
     */
    public GmailVerificationResult validateGmailOAuthData(String email, String googleId, String name, String picture) {
        GmailVerificationResult result = new GmailVerificationResult();

        // Validate email
        if (!isValidGmailEmail(email)) {
            result.addError("Invalid Gmail email format: " + email);
        }

        // Validate Google ID
        if (!isValidGoogleId(googleId)) {
            result.addError("Invalid Google ID format: " + googleId);
        }

        // Validate name (optional but should be reasonable if provided)
        if (name != null && !name.trim().isEmpty()) {
            if (name.trim().length() > 100) {
                result.addError("Name is too long (max 100 characters)");
            }
        }

        // Validate picture URL (optional but should be valid if provided)
        if (picture != null && !picture.trim().isEmpty()) {
            if (!isValidPictureUrl(picture)) {
                result.addError("Invalid picture URL format");
            }
        }

        return result;
    }

    /**
     * Validates picture URL format
     */
    private boolean isValidPictureUrl(String url) {
        if (url == null || url.trim().isEmpty()) {
            return true; // Optional field
        }

        String trimmedUrl = url.trim();

        // Basic URL validation
        return trimmedUrl.startsWith("http://") ||
                trimmedUrl.startsWith("https://") ||
                trimmedUrl.startsWith("//");
    }

    /**
     * Result class for Gmail verification
     */
    public static class GmailVerificationResult {
        private boolean valid = true;
        private java.util.List<String> errors = new java.util.ArrayList<>();

        public void addError(String error) {
            this.valid = false;
            this.errors.add(error);
        }

        public boolean isValid() {
            return valid;
        }

        public java.util.List<String> getErrors() {
            return errors;
        }

        public String getErrorMessage() {
            return String.join("; ", errors);
        }
    }
}





