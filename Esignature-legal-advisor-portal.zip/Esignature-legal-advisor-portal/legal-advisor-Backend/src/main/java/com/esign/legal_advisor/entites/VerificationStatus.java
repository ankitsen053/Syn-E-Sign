package com.esign.legal_advisor.entites;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "verification_status")
public class VerificationStatus {

    @Id
    private String id;
    private String userId;
    private String email;

    // Email Verification
    private boolean emailVerified;
    private LocalDateTime emailVerifiedAt;

    // PAN Verification
    private boolean panVerified;
    private String panNumber;
    private String panDocumentUrl;
    private LocalDateTime panVerifiedAt;
    private String panVerificationStatus; // PENDING, APPROVED, REJECTED
    private String panVerificationDetails; // Additional details about verification

    // Aadhar Verification
    private boolean aadharVerified;
    private String aadharNumber;
    private String aadharDocumentUrl;
    private LocalDateTime aadharVerifiedAt;
    private String aadharVerificationStatus; // PENDING, APPROVED, REJECTED
    private String aadharVerificationDetails; // Additional details about verification

    // Video Verification
    private boolean videoVerified;
    private String videoVerificationUrl;
    private LocalDateTime videoVerifiedAt;
    private String videoVerificationStatus; // PENDING, APPROVED, REJECTED
    private String videoVerificationNotes;

    // GST Verification
    private boolean gstVerified;
    private String gstNumber;
    private String companyName;
    private String gstDocumentUrl;
    private LocalDateTime gstVerifiedAt;
    private String gstVerificationStatus; // PENDING, APPROVED, REJECTED
    private String gstVerificationDetails; // Additional details about verification
    private String businessAddress;
    private String contactNumber;
    private String companyEmail;

    // DigiLocker Integration
    private String digiLockerId; // 36-character DigiLocker ID
    private boolean digiLockerVerified;
    private LocalDateTime digiLockerVerifiedAt;
    private String digiLockerVerificationStatus; // PENDING, VERIFIED, FAILED
    private String digiLockerVerificationDetails;
    private int digiLockerDocumentsFound; // Number of documents found
    private boolean digiLockerAadhaarAvailable;
    private boolean digiLockerPanAvailable;
    private boolean digiLockerDrivingLicenseAvailable;
    private boolean digiLockerPassportAvailable;

    // Overall Verification
    private boolean fullyVerified;
    private LocalDateTime fullyVerifiedAt;
    private String overallStatus; // PENDING, PARTIAL, COMPLETED, REJECTED

    // Timestamps
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public VerificationStatus() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.emailVerified = false;
        this.panVerified = false;
        this.aadharVerified = false;
        this.videoVerified = false;
        this.gstVerified = false;
        this.fullyVerified = false;
        this.panVerificationStatus = "PENDING";
        this.aadharVerificationStatus = "PENDING";
        this.videoVerificationStatus = "PENDING";
        this.gstVerificationStatus = "PENDING";
        this.digiLockerVerified = false;
        this.digiLockerVerificationStatus = "PENDING";
        this.digiLockerDocumentsFound = 0;
        this.digiLockerAadhaarAvailable = false;
        this.digiLockerPanAvailable = false;
        this.digiLockerDrivingLicenseAvailable = false;
        this.digiLockerPassportAvailable = false;
        this.overallStatus = "PENDING";
    }

    public VerificationStatus(String userId, String email) {
        this();
        this.userId = userId;
        this.email = email;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isEmailVerified() {
        return emailVerified;
    }

    public void setEmailVerified(boolean emailVerified) {
        this.emailVerified = emailVerified;
        this.emailVerifiedAt = emailVerified ? LocalDateTime.now() : null;
        updateOverallStatus();
    }

    public LocalDateTime getEmailVerifiedAt() {
        return emailVerifiedAt;
    }

    public void setEmailVerifiedAt(LocalDateTime emailVerifiedAt) {
        this.emailVerifiedAt = emailVerifiedAt;
    }

    public boolean isPanVerified() {
        return panVerified;
    }

    public void setPanVerified(boolean panVerified) {
        this.panVerified = panVerified;
        this.panVerifiedAt = panVerified ? LocalDateTime.now() : null;
        updateOverallStatus();
    }

    public String getPanNumber() {
        return panNumber;
    }

    public void setPanNumber(String panNumber) {
        this.panNumber = panNumber;
    }

    public String getPanDocumentUrl() {
        return panDocumentUrl;
    }

    public void setPanDocumentUrl(String panDocumentUrl) {
        this.panDocumentUrl = panDocumentUrl;
    }

    public LocalDateTime getPanVerifiedAt() {
        return panVerifiedAt;
    }

    public void setPanVerifiedAt(LocalDateTime panVerifiedAt) {
        this.panVerifiedAt = panVerifiedAt;
    }

    public String getPanVerificationStatus() {
        return panVerificationStatus;
    }

    public void setPanVerificationStatus(String panVerificationStatus) {
        this.panVerificationStatus = panVerificationStatus;
        updateOverallStatus();
    }

    public String getPanVerificationDetails() {
        return panVerificationDetails;
    }

    public void setPanVerificationDetails(String panVerificationDetails) {
        this.panVerificationDetails = panVerificationDetails;
    }

    public boolean isAadharVerified() {
        return aadharVerified;
    }

    public void setAadharVerified(boolean aadharVerified) {
        this.aadharVerified = aadharVerified;
        this.aadharVerifiedAt = aadharVerified ? LocalDateTime.now() : null;
        updateOverallStatus();
    }

    public String getAadharNumber() {
        return aadharNumber;
    }

    public void setAadharNumber(String aadharNumber) {
        this.aadharNumber = aadharNumber;
    }

    public String getAadharDocumentUrl() {
        return aadharDocumentUrl;
    }

    public void setAadharDocumentUrl(String aadharDocumentUrl) {
        this.aadharDocumentUrl = aadharDocumentUrl;
    }

    public LocalDateTime getAadharVerifiedAt() {
        return aadharVerifiedAt;
    }

    public void setAadharVerifiedAt(LocalDateTime aadharVerifiedAt) {
        this.aadharVerifiedAt = aadharVerifiedAt;
    }

    public String getAadharVerificationStatus() {
        return aadharVerificationStatus;
    }

    public void setAadharVerificationStatus(String aadharVerificationStatus) {
        this.aadharVerificationStatus = aadharVerificationStatus;
        updateOverallStatus();
    }

    public String getAadharVerificationDetails() {
        return aadharVerificationDetails;
    }

    public void setAadharVerificationDetails(String aadharVerificationDetails) {
        this.aadharVerificationDetails = aadharVerificationDetails;
    }

    public boolean isVideoVerified() {
        return videoVerified;
    }

    public void setVideoVerified(boolean videoVerified) {
        this.videoVerified = videoVerified;
        this.videoVerifiedAt = videoVerified ? LocalDateTime.now() : null;
        updateOverallStatus();
    }

    public String getVideoVerificationUrl() {
        return videoVerificationUrl;
    }

    public void setVideoVerificationUrl(String videoVerificationUrl) {
        this.videoVerificationUrl = videoVerificationUrl;
    }

    public LocalDateTime getVideoVerifiedAt() {
        return videoVerifiedAt;
    }

    public void setVideoVerifiedAt(LocalDateTime videoVerifiedAt) {
        this.videoVerifiedAt = videoVerifiedAt;
    }

    public String getVideoVerificationStatus() {
        return videoVerificationStatus;
    }

    public void setVideoVerificationStatus(String videoVerificationStatus) {
        this.videoVerificationStatus = videoVerificationStatus;
        updateOverallStatus();
    }

    public String getVideoVerificationNotes() {
        return videoVerificationNotes;
    }

    public void setVideoVerificationNotes(String videoVerificationNotes) {
        this.videoVerificationNotes = videoVerificationNotes;
    }

    // GST Verification Getters and Setters
    public boolean isGstVerified() {
        return gstVerified;
    }

    public void setGstVerified(boolean gstVerified) {
        this.gstVerified = gstVerified;
    }

    public String getGstNumber() {
        return gstNumber;
    }

    public void setGstNumber(String gstNumber) {
        this.gstNumber = gstNumber;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getGstDocumentUrl() {
        return gstDocumentUrl;
    }

    public void setGstDocumentUrl(String gstDocumentUrl) {
        this.gstDocumentUrl = gstDocumentUrl;
    }

    public LocalDateTime getGstVerifiedAt() {
        return gstVerifiedAt;
    }

    public void setGstVerifiedAt(LocalDateTime gstVerifiedAt) {
        this.gstVerifiedAt = gstVerifiedAt;
    }

    public String getGstVerificationStatus() {
        return gstVerificationStatus;
    }

    public void setGstVerificationStatus(String gstVerificationStatus) {
        this.gstVerificationStatus = gstVerificationStatus;
        updateOverallStatus();
    }

    public String getGstVerificationDetails() {
        return gstVerificationDetails;
    }

    public void setGstVerificationDetails(String gstVerificationDetails) {
        this.gstVerificationDetails = gstVerificationDetails;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getCompanyEmail() {
        return companyEmail;
    }

    public void setCompanyEmail(String companyEmail) {
        this.companyEmail = companyEmail;
    }

    public boolean isFullyVerified() {
        return fullyVerified;
    }

    public void setFullyVerified(boolean fullyVerified) {
        this.fullyVerified = fullyVerified;
        this.fullyVerifiedAt = fullyVerified ? LocalDateTime.now() : null;
    }

    public LocalDateTime getFullyVerifiedAt() {
        return fullyVerifiedAt;
    }

    public void setFullyVerifiedAt(LocalDateTime fullyVerifiedAt) {
        this.fullyVerifiedAt = fullyVerifiedAt;
    }

    public String getOverallStatus() {
        return overallStatus;
    }

    public void setOverallStatus(String overallStatus) {
        this.overallStatus = overallStatus;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    // DigiLocker Getters and Setters
    public String getDigiLockerId() {
        return digiLockerId;
    }

    public void setDigiLockerId(String digiLockerId) {
        this.digiLockerId = digiLockerId;
    }

    public boolean isDigiLockerVerified() {
        return digiLockerVerified;
    }

    public void setDigiLockerVerified(boolean digiLockerVerified) {
        this.digiLockerVerified = digiLockerVerified;
        this.digiLockerVerifiedAt = digiLockerVerified ? LocalDateTime.now() : null;
        updateOverallStatus();
    }

    public LocalDateTime getDigiLockerVerifiedAt() {
        return digiLockerVerifiedAt;
    }

    public void setDigiLockerVerifiedAt(LocalDateTime digiLockerVerifiedAt) {
        this.digiLockerVerifiedAt = digiLockerVerifiedAt;
    }

    public String getDigiLockerVerificationStatus() {
        return digiLockerVerificationStatus;
    }

    public void setDigiLockerVerificationStatus(String digiLockerVerificationStatus) {
        this.digiLockerVerificationStatus = digiLockerVerificationStatus;
        updateOverallStatus();
    }

    public String getDigiLockerVerificationDetails() {
        return digiLockerVerificationDetails;
    }

    public void setDigiLockerVerificationDetails(String digiLockerVerificationDetails) {
        this.digiLockerVerificationDetails = digiLockerVerificationDetails;
    }

    public int getDigiLockerDocumentsFound() {
        return digiLockerDocumentsFound;
    }

    public void setDigiLockerDocumentsFound(int digiLockerDocumentsFound) {
        this.digiLockerDocumentsFound = digiLockerDocumentsFound;
    }

    public boolean isDigiLockerAadhaarAvailable() {
        return digiLockerAadhaarAvailable;
    }

    public void setDigiLockerAadhaarAvailable(boolean digiLockerAadhaarAvailable) {
        this.digiLockerAadhaarAvailable = digiLockerAadhaarAvailable;
    }

    public boolean isDigiLockerPanAvailable() {
        return digiLockerPanAvailable;
    }

    public void setDigiLockerPanAvailable(boolean digiLockerPanAvailable) {
        this.digiLockerPanAvailable = digiLockerPanAvailable;
    }

    public boolean isDigiLockerDrivingLicenseAvailable() {
        return digiLockerDrivingLicenseAvailable;
    }

    public void setDigiLockerDrivingLicenseAvailable(boolean digiLockerDrivingLicenseAvailable) {
        this.digiLockerDrivingLicenseAvailable = digiLockerDrivingLicenseAvailable;
    }

    public boolean isDigiLockerPassportAvailable() {
        return digiLockerPassportAvailable;
    }

    public void setDigiLockerPassportAvailable(boolean digiLockerPassportAvailable) {
        this.digiLockerPassportAvailable = digiLockerPassportAvailable;
    }

    private void updateOverallStatus() {
        int verifiedCount = 0;
        if (emailVerified)
            verifiedCount++;
        if (panVerified)
            verifiedCount++;
        if (aadharVerified)
            verifiedCount++;
        if (videoVerified)
            verifiedCount++;
        if (gstVerified)
            verifiedCount++;

        if (verifiedCount == 0) {
            this.overallStatus = "PENDING";
            this.fullyVerified = false;
        } else if (verifiedCount < 5) {
            this.overallStatus = "PARTIAL";
            this.fullyVerified = false;
        } else {
            this.overallStatus = "COMPLETED";
            this.fullyVerified = true;
            this.fullyVerifiedAt = LocalDateTime.now();
        }

        this.updatedAt = LocalDateTime.now();
    }
}
