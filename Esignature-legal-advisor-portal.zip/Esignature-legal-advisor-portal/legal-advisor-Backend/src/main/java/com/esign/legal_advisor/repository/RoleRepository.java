package com.esign.legal_advisor.repository;

import java.util.Optional;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.esign.legal_advisor.entites.ERole;
import com.esign.legal_advisor.entites.Role;

public interface RoleRepository extends MongoRepository<Role, String> {
  Optional<Role> findByName(ERole name);
}
