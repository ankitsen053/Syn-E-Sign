package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.*;
import com.esign.legal_advisor.dto.AgreementAnalysisResponse;
import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.entites.SignedAgreement;
import com.esign.legal_advisor.repository.UserRepository;
import com.esign.legal_advisor.security.UserDetailsImpl;
import com.esign.legal_advisor.service.LegalAgreementTemplateService;
import com.esign.legal_advisor.service.UnifiedDocumentWorkflowService;
import com.esign.legal_advisor.service.DocxService;
import com.esign.legal_advisor.service.PdfService;
import com.esign.legal_advisor.service.AgreementAnalysisService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.time.LocalDateTime;

/**
 * Controller for unified document workflow operations
 */
@RestController
@RequestMapping("/api/v1/workflow")
@CrossOrigin(origins = "*")
@Tag(name = "Unified Document Workflow", description = "Endpoints for unified document generation, analysis, and signing workflow")
@SecurityRequirement(name = "bearerAuth")
@RequiredArgsConstructor
@Slf4j
public class UnifiedWorkflowController {

    private final UnifiedDocumentWorkflowService workflowService;
    private final UserRepository userRepository;
    private final LegalAgreementTemplateService templateService;
    private final DocxService docxService;
    private final PdfService pdfService;
    private final AgreementAnalysisService agreementAnalysisService;

    /**
     * Execute complete document workflow (Generate -> Analyze -> Prepare for Signing)
     */
    @PostMapping("/execute")
    @Operation(summary = "Execute complete document workflow", 
               description = "Generates document content, analyzes it, and prepares it for signing in a single workflow")
    public ResponseEntity<IntegratedDocumentResponse> executeCompleteWorkflow(
            @Valid @RequestBody IntegratedDocumentRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Executing complete workflow for user: {}", userDetails.getEmail());
        
        User currentUser = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        IntegratedDocumentResponse response = workflowService.executeCompleteWorkflow(request, currentUser);
        return ResponseEntity.ok(response);
    }

    /**
     * Execute document signing workflow
     */
    @PostMapping("/sign")
    @Operation(summary = "Execute document signing workflow", 
               description = "Executes the signing workflow for an existing document")
    public ResponseEntity<SignatureVerificationResult> executeSigningWorkflow(
            @Valid @RequestBody IntegratedSignatureRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Executing signing workflow for document: {}", request.getDocumentId());
        
        User currentUser = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        SignatureVerificationResult result = workflowService.executeSigningWorkflow(request, currentUser);
        return ResponseEntity.ok(result);
    }

    /**
     * Get document insights and analytics
     */
    @GetMapping("/insights/{documentId}")
    @Operation(summary = "Get document insights", 
               description = "Retrieves comprehensive insights and analytics for a specific document")
    public ResponseEntity<DocumentInsights> getDocumentInsights(
            @PathVariable String documentId,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Getting insights for document: {}", documentId);
        
        User currentUser = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        DocumentInsights insights = workflowService.getDocumentInsights(documentId, currentUser);
        return ResponseEntity.ok(insights);
    }

    /**
     * Generate enhanced legal agreement with comprehensive terms and conditions
     */
    @PostMapping("/generate-enhanced-agreement")
    @Operation(summary = "Generate enhanced legal agreement", 
               description = "Generates a comprehensive legal agreement with detailed terms, conditions, and legal clauses like a lawyer would")
    public ResponseEntity<Map<String, Object>> generateEnhancedAgreement(
            @Valid @RequestBody EnhancedAgreementRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Generating enhanced agreement for user: {}", userDetails.getEmail());
        
        try {
            // Validate request
            if (!request.isValidForGeneration()) {
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Invalid request: missing required fields"));
            }
            
            if (!request.isWithinContentLimits()) {
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Request content exceeds maximum allowed length"));
            }
            
            // Generate enhanced agreement
            String agreement = templateService.generateEnhancedAgreement(request);
            
            // Get statistics
            Map<String, Object> statistics = templateService.getAgreementStatistics(agreement);
            
            // Prepare response
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("agreement", agreement);
            response.put("statistics", statistics);
            response.put("message", "Enhanced legal agreement generated successfully");
            response.put("generatedAt", java.time.LocalDateTime.now());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Error generating enhanced agreement: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to generate enhanced agreement: " + e.getMessage()));
        }
    }

    /**
     * Download enhanced legal agreement as DOCX document
     */
    @PostMapping("/download-enhanced-agreement-docx")
    @Operation(summary = "Download enhanced legal agreement as DOCX", 
               description = "Generates and downloads a comprehensive legal agreement as a Microsoft Word document")
    public ResponseEntity<byte[]> downloadEnhancedAgreementDocx(
            @Valid @RequestBody EnhancedAgreementRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Downloading enhanced agreement as DOCX for user: {}", userDetails.getEmail());
        
        try {
            // Validate request
            if (!request.isValidForGeneration()) {
                return ResponseEntity.badRequest().build();
            }
            
            if (!request.isWithinContentLimits()) {
                return ResponseEntity.badRequest().build();
            }
            
            // Generate enhanced agreement
            String agreement = templateService.generateEnhancedAgreement(request);
            
            // Generate DOCX document
            byte[] docxContent = docxService.generateDocx(
                request.getType(), 
                request.getPartyA(), 
                request.getPartyB(), 
                agreement
            );
            
            // Set response headers for file download
            String filename = String.format("%s_%s_%s_%s.docx", 
                request.getType().replaceAll("\\s+", "_"),
                request.getPartyA().replaceAll("\\s+", "_"),
                request.getPartyB().replaceAll("\\s+", "_"),
                java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"))
            );
            
            return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + filename + "\"")
                .header("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                .body(docxContent);
            
        } catch (Exception e) {
            log.error("Error generating DOCX for enhanced agreement: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Download enhanced legal agreement as PDF document
     */
    @PostMapping("/download-enhanced-agreement-pdf")
    @Operation(summary = "Download enhanced legal agreement as PDF", 
               description = "Generates and downloads a comprehensive legal agreement as a PDF document")
    public ResponseEntity<byte[]> downloadEnhancedAgreementPdf(
            @Valid @RequestBody EnhancedAgreementRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Downloading enhanced agreement as PDF for user: {}", userDetails.getEmail());
        
        try {
            // Validate request
            if (!request.isValidForGeneration()) {
                return ResponseEntity.badRequest().build();
            }
            
            if (!request.isWithinContentLimits()) {
                return ResponseEntity.badRequest().build();
            }
            
            // Generate enhanced agreement
            String agreement = templateService.generateEnhancedAgreement(request);
            
            // Create a temporary SignedAgreement object for PDF generation
            // Note: This is a workaround since PdfService expects SignedAgreement
            // In a real scenario, you might want to create a proper entity or modify PdfService
            SignedAgreement tempAgreement = new SignedAgreement();
            tempAgreement.setAgreementTitle(request.getTitle());
            tempAgreement.setAgreementType(request.getType());
            tempAgreement.setPartyA(request.getPartyA());
            tempAgreement.setPartyB(request.getPartyB());
            tempAgreement.setAgreementContent(agreement);
            tempAgreement.setSignedAt(java.time.LocalDateTime.now());
            tempAgreement.setSignerName("Generated Document");
            tempAgreement.setDocumentHash("generated-" + System.currentTimeMillis());
            tempAgreement.setSignatureHash("generated-" + System.currentTimeMillis());
            
            // Generate PDF document
            byte[] pdfContent = pdfService.generateSignedAgreementPdf(tempAgreement);
            
            // Set response headers for file download
            String filename = String.format("%s_%s_%s_%s.pdf", 
                request.getType().replaceAll("\\s+", "_"),
                request.getPartyA().replaceAll("\\s+", "_"),
                request.getPartyB().replaceAll("\\s+", "_"),
                java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"))
            );
            
            return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + filename + "\"")
                .header("Content-Type", "application/pdf")
                .body(pdfContent);
            
        } catch (Exception e) {
            log.error("Error generating PDF for enhanced agreement: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Download enhanced legal agreement as plain text
     */
    @PostMapping("/download-enhanced-agreement-text")
    @Operation(summary = "Download enhanced legal agreement as text", 
               description = "Generates and downloads a comprehensive legal agreement as a plain text file")
    public ResponseEntity<byte[]> downloadEnhancedAgreementText(
            @Valid @RequestBody EnhancedAgreementRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Downloading enhanced agreement as text for user: {}", userDetails.getEmail());
        
        try {
            // Validate request
            if (!request.isValidForGeneration()) {
                return ResponseEntity.badRequest().build();
            }
            
            if (!request.isWithinContentLimits()) {
                return ResponseEntity.badRequest().build();
            }
            
            // Generate enhanced agreement
            String agreement = templateService.generateEnhancedAgreement(request);
            
            // Convert to bytes for download
            byte[] textContent = agreement.getBytes("UTF-8");
            
            // Set response headers for file download
            String filename = String.format("%s_%s_%s_%s.txt", 
                request.getType().replaceAll("\\s+", "_"),
                request.getPartyA().replaceAll("\\s+", "_"),
                request.getPartyB().replaceAll("\\s+", "_"),
                java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"))
            );
            
            return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + filename + "\"")
                .header("Content-Type", "text/plain; charset=UTF-8")
                .body(textContent);
            
        } catch (Exception e) {
            log.error("Error generating text for enhanced agreement: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Download enhanced legal agreement as HTML document
     */
    @PostMapping("/download-enhanced-agreement-html")
    @Operation(summary = "Download enhanced legal agreement as HTML", 
               description = "Generates and downloads a comprehensive legal agreement as an HTML file for web viewing")
    public ResponseEntity<byte[]> downloadEnhancedAgreementHtml(
            @Valid @RequestBody EnhancedAgreementRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Downloading enhanced agreement as HTML for user: {}", userDetails.getEmail());
        
        try {
            // Validate request
            if (!request.isValidForGeneration()) {
                return ResponseEntity.badRequest().build();
            }
            
            if (!request.isWithinContentLimits()) {
                return ResponseEntity.badRequest().build();
            }
            
            // Generate enhanced agreement
            String agreement = templateService.generateEnhancedAgreement(request);
            
            // Convert to HTML format with proper styling
            String htmlContent = generateHtmlDocument(request, agreement);
            
            // Convert to bytes for download
            byte[] htmlBytes = htmlContent.getBytes("UTF-8");
            
            // Set response headers for file download
            String filename = String.format("%s_%s_%s_%s.html", 
                request.getType().replaceAll("\\s+", "_"),
                request.getPartyA().replaceAll("\\s+", "_"),
                request.getPartyB().replaceAll("\\s+", "_"),
                java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"))
            );
            
            return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + filename + "\"")
                .header("Content-Type", "text/html; charset=UTF-8")
                .body(htmlBytes);
            
        } catch (Exception e) {
            log.error("Error generating HTML for enhanced agreement: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Generate HTML document with proper styling
     */
    private String generateHtmlDocument(EnhancedAgreementRequest request, String agreement) {
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html>\n");
        html.append("<html lang=\"en\">\n");
        html.append("<head>\n");
        html.append("    <meta charset=\"UTF-8\">\n");
        html.append("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n");
        html.append("    <title>").append(request.getTitle()).append("</title>\n");
        html.append("    <style>\n");
        html.append("        body { font-family: 'Times New Roman', serif; margin: 40px; line-height: 1.6; }\n");
        html.append("        .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }\n");
        html.append("        .title { font-size: 24px; font-weight: bold; margin-bottom: 10px; }\n");
        html.append("        .parties { margin: 20px 0; }\n");
        html.append("        .content { white-space: pre-wrap; font-size: 14px; }\n");
        html.append("        .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #ccc; text-align: center; font-size: 12px; color: #666; }\n");
        html.append("        @media print { body { margin: 20px; } }\n");
        html.append("    </style>\n");
        html.append("</head>\n");
        html.append("<body>\n");
        html.append("    <div class=\"header\">\n");
        html.append("        <div class=\"title\">").append(request.getTitle()).append("</div>\n");
        html.append("        <div class=\"parties\">\n");
        html.append("            <strong>Party A:</strong> ").append(request.getPartyA()).append("<br>\n");
        html.append("            <strong>Party B:</strong> ").append(request.getPartyB()).append("\n");
        html.append("        </div>\n");
        html.append("        <div>Generated on: ").append(java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("MMMM dd, yyyy"))).append("</div>\n");
        html.append("    </div>\n");
        html.append("    <div class=\"content\">\n");
        html.append(agreement.replace("\n", "<br>"));
        html.append("    </div>\n");
        html.append("    <div class=\"footer\">\n");
        html.append("        This document was generated by the Legal Advisor System<br>\n");
        html.append("        Please review with qualified legal counsel before execution\n");
        html.append("    </div>\n");
        html.append("</body>\n");
        html.append("</html>");
        
        return html.toString();
    }

    /**
     * Upload and analyze legal agreement document
     */
    @PostMapping("/upload-and-analyze-agreement")
    @Operation(summary = "Upload and analyze legal agreement", 
               description = "Uploads a legal agreement document and performs comprehensive AI analysis")
    public ResponseEntity<AgreementAnalysisResponse> uploadAndAnalyzeAgreement(
            @Valid AgreementUploadRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Uploading and analyzing agreement for user: {}", userDetails.getEmail());
        
        try {
            User currentUser = userRepository.findById(userDetails.getId())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            
            // Perform comprehensive analysis
            AgreementAnalysisResponse analysis = agreementAnalysisService.analyzeAgreement(request, currentUser);
            
            return ResponseEntity.ok(analysis);
            
        } catch (Exception e) {
            log.error("Error uploading and analyzing agreement: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get agreement analysis by ID
     */
    @GetMapping("/agreement-analysis/{analysisId}")
    @Operation(summary = "Get agreement analysis", 
               description = "Retrieves the analysis results for a specific agreement")
    public ResponseEntity<AgreementAnalysisResponse> getAgreementAnalysis(
            @PathVariable String analysisId,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Getting agreement analysis: {} for user: {}", analysisId, userDetails.getEmail());
        
        try {
            User currentUser = userRepository.findById(userDetails.getId())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            
            // For now, return a placeholder response
            // In a real implementation, you would fetch from database
            AgreementAnalysisResponse analysis = AgreementAnalysisResponse.builder()
                .analysisId(analysisId)
                .status("COMPLETED")
                .title("Sample Agreement Analysis")
                .type("Service Agreement")
                .uploadedAt(java.time.LocalDateTime.now())
                .analyzedAt(java.time.LocalDateTime.now())
                .build();
            
            return ResponseEntity.ok(analysis);
            
        } catch (Exception e) {
            log.error("Error retrieving agreement analysis: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Search documents with advanced criteria
     */
    @PostMapping("/search")
    @Operation(summary = "Search documents", 
               description = "Searches documents using advanced criteria and returns unified responses")
    public ResponseEntity<List<IntegratedDocumentResponse>> searchDocuments(
            @Valid @RequestBody DocumentSearchRequest request,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Searching documents with criteria: {}", request);
        
        User currentUser = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        List<IntegratedDocumentResponse> results = workflowService.searchDocuments(request, currentUser);
        return ResponseEntity.ok(results);
    }

    /**
     * Get workflow status for a document
     */
    @GetMapping("/status/{documentId}")
    @Operation(summary = "Get workflow status", 
               description = "Retrieves the current status of the workflow for a specific document")
    public ResponseEntity<Map<String, Object>> getWorkflowStatus(
            @PathVariable String documentId,
            @AuthenticationPrincipal UserDetailsImpl userDetails) {
        
        log.info("Getting workflow status for document: {}", documentId);
        
        User currentUser = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        // Get document insights to extract workflow status
        DocumentInsights insights = workflowService.getDocumentInsights(documentId, currentUser);
        
        Map<String, Object> status = new HashMap<>();
        status.put("documentId", documentId);
        status.put("workflowStatus", "ACTIVE");
        status.put("currentStep", determineCurrentStep(insights));
        status.put("nextStep", determineNextStep(insights));
        status.put("progress", calculateProgress(insights));
        status.put("lastUpdated", insights.getLastUpdated());
        
        return ResponseEntity.ok(status);
    }

    /**
     * Determine current step in workflow
     */
    private String determineCurrentStep(DocumentInsights insights) {
        if (insights.getSigningHistory() != null && !insights.getSigningHistory().isEmpty()) {
            return "SIGNED";
        } else if (insights.getAnalysisHistory() != null && !insights.getAnalysisHistory().isEmpty()) {
            return "ANALYZED";
        } else {
            return "CREATED";
        }
    }

    /**
     * Determine next step in workflow
     */
    private String determineNextStep(DocumentInsights insights) {
        String currentStep = determineCurrentStep(insights);
        
        switch (currentStep) {
            case "CREATED":
                return "ANALYZE";
            case "ANALYZED":
                return "SIGN";
            case "SIGNED":
                return "COMPLETE";
            default:
                return "UNKNOWN";
        }
    }

    /**
     * Calculate workflow progress percentage
     */
    private int calculateProgress(DocumentInsights insights) {
        String currentStep = determineCurrentStep(insights);
        
        switch (currentStep) {
            case "CREATED":
                return 25;
            case "ANALYZED":
                return 75;
            case "SIGNED":
                return 100;
            default:
                return 0;
        }
    }

    /**
     * Health check endpoint for workflow service
     */
    @GetMapping("/health")
    @Operation(summary = "Workflow service health check", 
               description = "Checks if the workflow service is operational")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("service", "UnifiedDocumentWorkflowService");
        health.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(health);
    }
}
