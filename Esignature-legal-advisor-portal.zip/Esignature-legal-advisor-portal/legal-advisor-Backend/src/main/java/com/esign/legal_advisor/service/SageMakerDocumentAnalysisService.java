package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.sagemakerruntime.SageMakerRuntimeClient;
import software.amazon.awssdk.services.sagemakerruntime.model.InvokeEndpointRequest;
import software.amazon.awssdk.services.sagemakerruntime.model.InvokeEndpointResponse;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

@Service
@Slf4j
@RequiredArgsConstructor
public class SageMakerDocumentAnalysisService {

    private final SageMakerRuntimeClient sageMakerClient;
    private final ObjectMapper objectMapper;

    @Value("${aws.sagemaker.pan.endpoint.name:}")
    private String panEndpointName;

    @Value("${aws.sagemaker.aadhaar.endpoint.name:}")
    private String aadhaarEndpointName;

    @Value("${aws.sagemaker.content.type:application/json}")
    private String contentType;

    // Regex patterns for validation
    private static final Pattern PAN_PATTERN = Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]$");
    private static final Pattern AADHAAR_PATTERN = Pattern.compile("^[0-9]{4}\\s?[0-9]{4}\\s?[0-9]{4}$");

    /**
     * Analyze document using appropriate SageMaker endpoint
     */
    public DocumentAnalysisResponse analyzeDocument(DocumentAnalysisRequest request) {
        log.info("Starting document analysis for type: {}", request.getDocumentType());

        try {
            switch (request.getDocumentType().toUpperCase()) {
                case "PAN":
                    return analyzePanDocument(request);
                case "AADHAAR":
                    return analyzeAadhaarDocument(request);
                default:
                    return DocumentAnalysisResponse.failure(
                        request.getDocumentType(),
                        "Unsupported document type: " + request.getDocumentType()
                    );
            }
        } catch (Exception e) {
            log.error("Error analyzing document", e);
            return DocumentAnalysisResponse.failure(
                request.getDocumentType(),
                "Document analysis failed: " + e.getMessage()
            );
        }
    }

    /**
     * Analyze PAN document using SageMaker
     */
    private DocumentAnalysisResponse analyzePanDocument(DocumentAnalysisRequest request) {
        try {
            // Prepare input for SageMaker model
            Map<String, Object> modelInput = createPanModelInput(request);
            
            // Call SageMaker endpoint (or fallback to local processing if endpoint not configured)
            PanAnalysisResult analysisResult;
            if (panEndpointName != null && !panEndpointName.isEmpty()) {
                analysisResult = invokePanSageMakerEndpoint(modelInput);
            } else {
                log.warn("PAN SageMaker endpoint not configured, using local analysis");
                analysisResult = performLocalPanAnalysis(request.getExtractedText());
            }

            // Convert to response format
            return createPanAnalysisResponse(analysisResult, request);

        } catch (Exception e) {
            log.error("Error analyzing PAN document", e);
            return DocumentAnalysisResponse.failure("PAN", "PAN analysis failed: " + e.getMessage());
        }
    }

    /**
     * Analyze Aadhaar document using SageMaker
     */
    private DocumentAnalysisResponse analyzeAadhaarDocument(DocumentAnalysisRequest request) {
        try {
            // Prepare input for SageMaker model
            Map<String, Object> modelInput = createAadhaarModelInput(request);
            
            // Call SageMaker endpoint (or fallback to local processing if endpoint not configured)
            AadhaarAnalysisResult analysisResult;
            if (aadhaarEndpointName != null && !aadhaarEndpointName.isEmpty()) {
                analysisResult = invokeAadhaarSageMakerEndpoint(modelInput);
            } else {
                log.warn("Aadhaar SageMaker endpoint not configured, using local analysis");
                analysisResult = performLocalAadhaarAnalysis(request.getExtractedText());
            }

            // Convert to response format
            return createAadhaarAnalysisResponse(analysisResult, request);

        } catch (Exception e) {
            log.error("Error analyzing Aadhaar document", e);
            return DocumentAnalysisResponse.failure("AADHAAR", "Aadhaar analysis failed: " + e.getMessage());
        }
    }

    /**
     * Invoke PAN SageMaker endpoint
     */
    private PanAnalysisResult invokePanSageMakerEndpoint(Map<String, Object> input) throws JsonProcessingException {
        String inputJson = objectMapper.writeValueAsString(input);
        
        InvokeEndpointRequest endpointRequest = InvokeEndpointRequest.builder()
                .endpointName(panEndpointName)
                .contentType(contentType)
                .body(SdkBytes.fromString(inputJson, StandardCharsets.UTF_8))
                .build();

        InvokeEndpointResponse response = sageMakerClient.invokeEndpoint(endpointRequest);
        String responseBody = response.body().asUtf8String();
        
        log.info("PAN SageMaker response received: {} characters", responseBody.length());
        
        return parsePanSageMakerResponse(responseBody);
    }

    /**
     * Invoke Aadhaar SageMaker endpoint
     */
    private AadhaarAnalysisResult invokeAadhaarSageMakerEndpoint(Map<String, Object> input) throws JsonProcessingException {
        String inputJson = objectMapper.writeValueAsString(input);
        
        InvokeEndpointRequest endpointRequest = InvokeEndpointRequest.builder()
                .endpointName(aadhaarEndpointName)
                .contentType(contentType)
                .body(SdkBytes.fromString(inputJson, StandardCharsets.UTF_8))
                .build();

        InvokeEndpointResponse response = sageMakerClient.invokeEndpoint(endpointRequest);
        String responseBody = response.body().asUtf8String();
        
        log.info("Aadhaar SageMaker response received: {} characters", responseBody.length());
        
        return parseAadhaarSageMakerResponse(responseBody);
    }

    /**
     * Create input for PAN SageMaker model
     */
    private Map<String, Object> createPanModelInput(DocumentAnalysisRequest request) {
        Map<String, Object> input = new HashMap<>();
        input.put("text", request.getExtractedText());
        input.put("document_type", "PAN");
        input.put("customer_mobile", request.getCustomerMobile());
        if (request.getDocumentBase64() != null) {
            input.put("document_image", request.getDocumentBase64());
        }
        return input;
    }

    /**
     * Create input for Aadhaar SageMaker model
     */
    private Map<String, Object> createAadhaarModelInput(DocumentAnalysisRequest request) {
        Map<String, Object> input = new HashMap<>();
        input.put("text", request.getExtractedText());
        input.put("document_type", "AADHAAR");
        input.put("customer_mobile", request.getCustomerMobile());
        if (request.getDocumentBase64() != null) {
            input.put("document_image", request.getDocumentBase64());
        }
        return input;
    }

    /**
     * Parse PAN SageMaker response
     */
    private PanAnalysisResult parsePanSageMakerResponse(String responseBody) throws JsonProcessingException {
        JsonNode response = objectMapper.readTree(responseBody);
        
        PanAnalysisResult result = new PanAnalysisResult();
        
        // Extract fields from SageMaker response
        result.setPanNumber(getJsonStringValue(response, "pan_number"));
        result.setName(getJsonStringValue(response, "name"));
        result.setFatherName(getJsonStringValue(response, "father_name"));
        result.setDateOfBirth(getJsonStringValue(response, "date_of_birth"));
        result.setPanCardType(getJsonStringValue(response, "card_type"));
        
        // Extract confidence scores
        result.setPanNumberConfidence(getJsonDoubleValue(response, "pan_number_confidence"));
        result.setNameConfidence(getJsonDoubleValue(response, "name_confidence"));
        result.setFatherNameConfidence(getJsonDoubleValue(response, "father_name_confidence"));
        result.setDobConfidence(getJsonDoubleValue(response, "dob_confidence"));
        result.setDocumentAuthenticityScore(getJsonDoubleValue(response, "authenticity_score"));
        
        // Set validation flags
        result.setPanNumberValid(isValidPanNumber(result.getPanNumber()));
        result.setNameExtracted(result.getName() != null && !result.getName().trim().isEmpty());
        result.setFatherNameExtracted(result.getFatherName() != null && !result.getFatherName().trim().isEmpty());
        result.setDobExtracted(result.getDateOfBirth() != null && !result.getDateOfBirth().trim().isEmpty());
        
        return result;
    }

    /**
     * Parse Aadhaar SageMaker response
     */
    private AadhaarAnalysisResult parseAadhaarSageMakerResponse(String responseBody) throws JsonProcessingException {
        JsonNode response = objectMapper.readTree(responseBody);
        
        AadhaarAnalysisResult result = new AadhaarAnalysisResult();
        
        // Extract fields from SageMaker response
        result.setAadhaarNumber(getJsonStringValue(response, "aadhaar_number"));
        result.setName(getJsonStringValue(response, "name"));
        result.setFatherName(getJsonStringValue(response, "father_name"));
        result.setDateOfBirth(getJsonStringValue(response, "date_of_birth"));
        result.setGender(getJsonStringValue(response, "gender"));
        result.setAddress(getJsonStringValue(response, "address"));
        result.setMobileNumber(getJsonStringValue(response, "mobile_number"));
        
        // Extract confidence scores
        result.setAadhaarNumberConfidence(getJsonDoubleValue(response, "aadhaar_number_confidence"));
        result.setNameConfidence(getJsonDoubleValue(response, "name_confidence"));
        result.setFatherNameConfidence(getJsonDoubleValue(response, "father_name_confidence"));
        result.setDobConfidence(getJsonDoubleValue(response, "dob_confidence"));
        result.setGenderConfidence(getJsonDoubleValue(response, "gender_confidence"));
        result.setAddressConfidence(getJsonDoubleValue(response, "address_confidence"));
        result.setMobileConfidence(getJsonDoubleValue(response, "mobile_confidence"));
        result.setDocumentAuthenticityScore(getJsonDoubleValue(response, "authenticity_score"));
        
        // Set validation flags
        result.setAadhaarNumberValid(isValidAadhaarNumber(result.getAadhaarNumber()));
        result.setNameExtracted(result.getName() != null && !result.getName().trim().isEmpty());
        result.setFatherNameExtracted(result.getFatherName() != null && !result.getFatherName().trim().isEmpty());
        result.setDobExtracted(result.getDateOfBirth() != null && !result.getDateOfBirth().trim().isEmpty());
        result.setGenderExtracted(result.getGender() != null && !result.getGender().trim().isEmpty());
        result.setAddressExtracted(result.getAddress() != null && !result.getAddress().trim().isEmpty());
        result.setMobileExtracted(result.getMobileNumber() != null && !result.getMobileNumber().trim().isEmpty());
        
        // Security features
        result.setHologramDetected(getJsonBooleanValue(response, "hologram_detected"));
        result.setSecurityPrintingDetected(getJsonBooleanValue(response, "security_printing_detected"));
        result.setDigitalSignatureVerified(getJsonBooleanValue(response, "digital_signature_verified"));
        
        return result;
    }

    /**
     * Fallback local PAN analysis (when SageMaker endpoint not available)
     */
    private PanAnalysisResult performLocalPanAnalysis(String extractedText) {
        PanAnalysisResult result = new PanAnalysisResult();
        
        // Simple regex-based extraction for fallback
        String[] lines = extractedText.split("\\n");
        
        for (String line : lines) {
            String upperLine = line.toUpperCase().trim();
            
            // Look for PAN number pattern
            if (PAN_PATTERN.matcher(upperLine.replaceAll("\\s", "")).find()) {
                String[] words = upperLine.split("\\s+");
                for (String word : words) {
                    if (PAN_PATTERN.matcher(word).matches()) {
                        result.setPanNumber(word);
                        result.setPanNumberValid(true);
                        result.setPanNumberConfidence(0.9);
                        break;
                    }
                }
            }
            
            // Simple name extraction (this would be much more sophisticated in real implementation)
            if (upperLine.contains("NAME") && result.getName() == null) {
                String[] parts = line.split(":");
                if (parts.length > 1) {
                    result.setName(parts[1].trim());
                    result.setNameExtracted(true);
                    result.setNameConfidence(0.7);
                }
            }
        }
        
        // Set default values for missing fields
        if (result.getPanNumber() == null) {
            result.setPanNumber("UNKNOWN");
            result.setPanNumberValid(false);
            result.setPanNumberConfidence(0.0);
        }
        
        result.setDocumentAuthenticityScore(0.8);
        result.setDocumentQuality("GOOD");
        
        return result;
    }

    /**
     * Fallback local Aadhaar analysis (when SageMaker endpoint not available)
     */
    private AadhaarAnalysisResult performLocalAadhaarAnalysis(String extractedText) {
        AadhaarAnalysisResult result = new AadhaarAnalysisResult();
        
        // Simple regex-based extraction for fallback
        String[] lines = extractedText.split("\\n");
        
        for (String line : lines) {
            String cleanLine = line.trim().replaceAll("\\s+", " ");
            
            // Look for Aadhaar number pattern
            if (AADHAAR_PATTERN.matcher(cleanLine).find()) {
                String[] words = cleanLine.split("\\s+");
                for (String word : words) {
                    if (word.matches("\\d{4}") && cleanLine.contains(word)) {
                        // Find complete Aadhaar number
                        String aadhaarCandidate = cleanLine.replaceAll("[^0-9\\s]", "").trim();
                        if (aadhaarCandidate.length() >= 12) {
                            result.setAadhaarNumber(aadhaarCandidate.substring(0, 12));
                            result.setAadhaarNumberValid(true);
                            result.setAadhaarNumberConfidence(0.9);
                            break;
                        }
                    }
                }
            }
        }
        
        // Set default values for missing fields
        if (result.getAadhaarNumber() == null) {
            result.setAadhaarNumber("UNKNOWN");
            result.setAadhaarNumberValid(false);
            result.setAadhaarNumberConfidence(0.0);
        }
        
        result.setDocumentAuthenticityScore(0.8);
        result.setDocumentQuality("GOOD");
        
        return result;
    }

    /**
     * Create PAN analysis response
     */
    private DocumentAnalysisResponse createPanAnalysisResponse(PanAnalysisResult panResult, DocumentAnalysisRequest request) {
        Map<String, Object> extractedData = new HashMap<>();
        extractedData.put("pan_number", panResult.getPanNumber());
        extractedData.put("name", panResult.getName());
        extractedData.put("father_name", panResult.getFatherName());
        extractedData.put("date_of_birth", panResult.getDateOfBirth());
        extractedData.put("pan_card_type", panResult.getPanCardType());
        
        Map<String, String> validationResults = new HashMap<>();
        validationResults.put("pan_number_valid", String.valueOf(panResult.isPanNumberValid()));
        validationResults.put("name_extracted", String.valueOf(panResult.isNameExtracted()));
        validationResults.put("father_name_extracted", String.valueOf(panResult.isFatherNameExtracted()));
        validationResults.put("dob_extracted", String.valueOf(panResult.isDobExtracted()));
        validationResults.put("document_quality", panResult.getDocumentQuality());
        
        DocumentAnalysisResponse response = DocumentAnalysisResponse.success(
            "PAN", 
            extractedData, 
            panResult.getDocumentAuthenticityScore(),
            validationResults
        );
        
        response.setModelName("pan-document-analyzer");
        response.setVerified(panResult.isPanNumberValid() && panResult.getDocumentAuthenticityScore() >= request.getConfidenceThreshold());
        
        return response;
    }

    /**
     * Create Aadhaar analysis response
     */
    private DocumentAnalysisResponse createAadhaarAnalysisResponse(AadhaarAnalysisResult aadhaarResult, DocumentAnalysisRequest request) {
        Map<String, Object> extractedData = new HashMap<>();
        extractedData.put("aadhaar_number", aadhaarResult.getAadhaarNumber());
        extractedData.put("name", aadhaarResult.getName());
        extractedData.put("father_name", aadhaarResult.getFatherName());
        extractedData.put("date_of_birth", aadhaarResult.getDateOfBirth());
        extractedData.put("gender", aadhaarResult.getGender());
        extractedData.put("address", aadhaarResult.getAddress());
        extractedData.put("mobile_number", aadhaarResult.getMobileNumber());
        
        Map<String, String> validationResults = new HashMap<>();
        validationResults.put("aadhaar_number_valid", String.valueOf(aadhaarResult.isAadhaarNumberValid()));
        validationResults.put("name_extracted", String.valueOf(aadhaarResult.isNameExtracted()));
        validationResults.put("father_name_extracted", String.valueOf(aadhaarResult.isFatherNameExtracted()));
        validationResults.put("dob_extracted", String.valueOf(aadhaarResult.isDobExtracted()));
        validationResults.put("gender_extracted", String.valueOf(aadhaarResult.isGenderExtracted()));
        validationResults.put("address_extracted", String.valueOf(aadhaarResult.isAddressExtracted()));
        validationResults.put("mobile_extracted", String.valueOf(aadhaarResult.isMobileExtracted()));
        validationResults.put("document_quality", aadhaarResult.getDocumentQuality());
        validationResults.put("hologram_detected", String.valueOf(aadhaarResult.isHologramDetected()));
        validationResults.put("security_printing_detected", String.valueOf(aadhaarResult.isSecurityPrintingDetected()));
        validationResults.put("digital_signature_verified", String.valueOf(aadhaarResult.isDigitalSignatureVerified()));
        
        DocumentAnalysisResponse response = DocumentAnalysisResponse.success(
            "AADHAAR", 
            extractedData, 
            aadhaarResult.getDocumentAuthenticityScore(),
            validationResults
        );
        
        response.setModelName("aadhaar-document-analyzer");
        response.setVerified(aadhaarResult.isAadhaarNumberValid() && aadhaarResult.getDocumentAuthenticityScore() >= request.getConfidenceThreshold());
        
        return response;
    }

    // Utility methods
    private String getJsonStringValue(JsonNode node, String fieldName) {
        JsonNode field = node.get(fieldName);
        return field != null && !field.isNull() ? field.asText() : null;
    }

    private Double getJsonDoubleValue(JsonNode node, String fieldName) {
        JsonNode field = node.get(fieldName);
        return field != null && !field.isNull() ? field.asDouble() : null;
    }

    private Boolean getJsonBooleanValue(JsonNode node, String fieldName) {
        JsonNode field = node.get(fieldName);
        return field != null && !field.isNull() ? field.asBoolean() : false;
    }

    private boolean isValidPanNumber(String pan) {
        return pan != null && PAN_PATTERN.matcher(pan.toUpperCase().trim()).matches();
    }

    private boolean isValidAadhaarNumber(String aadhaar) {
        if (aadhaar == null) return false;
        String cleanAadhaar = aadhaar.replaceAll("\\s", "");
        return cleanAadhaar.matches("\\d{12}");
    }
}
