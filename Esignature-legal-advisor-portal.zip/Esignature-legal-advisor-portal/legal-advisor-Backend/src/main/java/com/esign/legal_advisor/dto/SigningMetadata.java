package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO for document signing metadata
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SigningMetadata {
    
    private String documentId;
    private boolean signed;
    private LocalDateTime signedAt;
    private String signingUrl;
    private LocalDateTime expiresAt;
    
    // Signing status
    private String signingStatus;
    private String documentHash;
    
    // Signer information
    private String signerName;
    private String signerEmail;
    private String signerIpAddress;
    private String signedAgreementId;
    
    // Signature fields
    private List<SignatureField> signatureFields;
    private List<String> requiredSigners;
    private List<String> completedSigners;
    
    // Verification
    private SignatureVerificationResult verificationResult;
    
    // Generated documents
    private byte[] signedPdf;
    private String signedDocumentUrl;
    
    // Audit trail
    private List<SigningEvent> signingEvents;
}
