package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.LegalDocument;
import com.esign.legal_advisor.repository.DocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Service
public class DocumentMigrationService {

    private static final Logger logger = LoggerFactory.getLogger(DocumentMigrationService.class);

    @Autowired
    private DocumentRepository documentRepository;

    /**
     * Migrate existing documents to fix null user references
     * This method should be called once to fix existing data
     */
    public void migrateDocuments() {
        try {
            logger.info("Starting document migration...");

            List<LegalDocument> allDocuments = documentRepository.findAll();
            int migratedCount = 0;
            int errorCount = 0;

            for (LegalDocument document : allDocuments) {
                try {
                    // If document has no userId but has user reference, set userId
                    if (document.getUserId() == null && document.getUser() != null) {
                        document.setUserId(document.getUser().getId());
                        documentRepository.save(document);
                        migratedCount++;
                        logger.debug("Migrated document: {}", document.getId());
                    }
                    // If document has userId but no user reference, keep userId
                    else if (document.getUserId() != null && document.getUser() == null) {
                        logger.debug("Document {} has userId but no user reference - keeping userId", document.getId());
                    }
                    // If document has both, ensure they match
                    else if (document.getUserId() != null && document.getUser() != null) {
                        if (!document.getUserId().equals(document.getUser().getId())) {
                            document.setUserId(document.getUser().getId());
                            documentRepository.save(document);
                            migratedCount++;
                            logger.debug("Fixed userId mismatch for document: {}", document.getId());
                        }
                    }
                    // If document has neither, mark as orphaned
                    else {
                        logger.warn("Document {} has no user reference or userId - marking as orphaned",
                                document.getId());
                        document.setUserId("orphaned");
                        documentRepository.save(document);
                        migratedCount++;
                    }
                } catch (Exception e) {
                    errorCount++;
                    logger.error("Error migrating document {}: {}", document.getId(), e.getMessage());
                }
            }

            logger.info("Document migration completed. Migrated: {}, Errors: {}", migratedCount, errorCount);

        } catch (Exception e) {
            logger.error("Error during document migration", e);
            throw new RuntimeException("Failed to migrate documents: " + e.getMessage());
        }
    }

    /**
     * Clean up orphaned documents (documents with no valid user)
     */
    public void cleanupOrphanedDocuments() {
        try {
            logger.info("Starting orphaned document cleanup...");

            List<LegalDocument> orphanedDocuments = documentRepository.findByUserId("orphaned");
            int deletedCount = 0;

            for (LegalDocument document : orphanedDocuments) {
                try {
                    documentRepository.delete(document);
                    deletedCount++;
                    logger.debug("Deleted orphaned document: {}", document.getId());
                } catch (Exception e) {
                    logger.error("Error deleting orphaned document {}: {}", document.getId(), e.getMessage());
                }
            }

            logger.info("Orphaned document cleanup completed. Deleted: {}", deletedCount);

        } catch (Exception e) {
            logger.error("Error during orphaned document cleanup", e);
            throw new RuntimeException("Failed to cleanup orphaned documents: " + e.getMessage());
        }
    }
}
