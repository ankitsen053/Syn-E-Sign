package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.JwtResponse;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.service.GoogleOAuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/auth/simple-gmail")
@CrossOrigin(origins = "*", maxAge = 3600)
public class SimpleGmailController {

    private static final Logger logger = LoggerFactory.getLogger(SimpleGmailController.class);

    @Autowired
    private GoogleOAuthService googleOAuthService;

    @GetMapping("/login")
    public ResponseEntity<MessageResponse> initiateSimpleGmailLogin() {
        try {
            // For testing purposes, we'll create a mock Gmail login
            logger.info("Simple Gmail login initiated");

            // Generate a simple Google OAuth URL (this would need real credentials)
            String googleOAuthUrl = "https://accounts.google.com/o/oauth2/auth?" +
                    "client_id=YOUR_CLIENT_ID&" +
                    "redirect_uri="
                    + URLEncoder.encode("http://localhost:8080/api/auth/simple-gmail/callback", StandardCharsets.UTF_8)
                    + "&" +
                    "scope=" + URLEncoder.encode("openid email profile", StandardCharsets.UTF_8) + "&" +
                    "response_type=code&" +
                    "access_type=offline";

            return ResponseEntity.ok(new MessageResponse(googleOAuthUrl));
        } catch (Exception e) {
            logger.error("Error generating simple Gmail OAuth URL", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to initiate Gmail login"));
        }
    }

    @GetMapping("/callback")
    public void handleSimpleGmailCallback(@RequestParam(value = "code", required = false) String code,
            @RequestParam(value = "error", required = false) String error,
            HttpServletResponse response) throws IOException {
        try {
            if (error != null) {
                logger.error("Simple Gmail OAuth error: {}", error);
                response.sendRedirect("http://localhost:5174/login?error=gmail_oauth_failed");
                return;
            }

            logger.info("Simple Gmail OAuth callback received");

            // For testing, we'll create a mock user
            String email = "test.user@gmail.com";
            String name = "Test User";
            String googleId = "123456789";
            String picture = "https://via.placeholder.com/150";

            // Process the Gmail login
            JwtResponse jwtResponse = googleOAuthService.processGmailLogin(email, name, googleId, picture, true);

            // Redirect to frontend with JWT token
            String redirectUrl = "http://localhost:5174/oauth-callback?token=" + jwtResponse.getToken() +
                    "&type=" + jwtResponse.getType() +
                    "&username=" + URLEncoder.encode(jwtResponse.getUsername(), StandardCharsets.UTF_8) +
                    "&email=" + URLEncoder.encode(jwtResponse.getEmail(), StandardCharsets.UTF_8);

            response.sendRedirect(redirectUrl);
            logger.info("User successfully authenticated via simple Gmail OAuth");

        } catch (Exception e) {
            logger.error("Error processing simple Gmail OAuth callback", e);
            response.sendRedirect("http://localhost:5174/login?error=gmail_oauth_failed");
        }
    }

    @GetMapping("/test-login")
    public ResponseEntity<MessageResponse> testGmailLogin() {
        try {
            logger.info("Test Gmail login initiated");

            // Create a test user directly
            String email = "test.user@gmail.com";
            String name = "Test User";
            String googleId = "123456789";
            String picture = "https://via.placeholder.com/150";

            JwtResponse jwtResponse = googleOAuthService.processGmailLogin(email, name, googleId, picture, true);

            return ResponseEntity
                    .ok(new MessageResponse("Test Gmail login successful. Token: " + jwtResponse.getToken()));

        } catch (Exception e) {
            logger.error("Error in test Gmail login", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: " + e.getMessage()));
        }
    }

    @GetMapping("/login-url")
    public ResponseEntity<MessageResponse> getSimpleGmailLoginUrl() {
        try {
            String gmailOAuthUrl = "https://accounts.google.com/o/oauth2/auth?" +
                    "client_id=YOUR_CLIENT_ID&" +
                    "redirect_uri="
                    + URLEncoder.encode("http://localhost:8080/api/auth/simple-gmail/callback", StandardCharsets.UTF_8)
                    + "&" +
                    "scope=" + URLEncoder.encode("openid email profile", StandardCharsets.UTF_8) + "&" +
                    "response_type=code&" +
                    "access_type=offline";

            return ResponseEntity.ok(new MessageResponse(gmailOAuthUrl));
        } catch (Exception e) {
            logger.error("Error generating simple Gmail login URL", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to generate login URL"));
        }
    }
}
