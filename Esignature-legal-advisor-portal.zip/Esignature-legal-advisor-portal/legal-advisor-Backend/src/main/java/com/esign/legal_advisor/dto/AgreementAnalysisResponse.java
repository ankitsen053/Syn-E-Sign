package com.esign.legal_advisor.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * DTO for agreement analysis responses
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AgreementAnalysisResponse {

    private String analysisId;
    private String documentId;
    private String title;
    private String type;
    private String status; // PENDING, IN_PROGRESS, COMPLETED, FAILED
    
    // Analysis results
    private LegalComplianceAnalysis legalCompliance;
    private RiskAssessmentAnalysis riskAssessment;
    private ClarityAndStructureAnalysis clarityAndStructure;
    private DocumentSummary summary;
    private List<IssueHighlight> issues;
    private List<ImprovementSuggestion> improvements;
    
    // Metadata
    private LocalDateTime uploadedAt;
    private LocalDateTime analyzedAt;
    private String analysisModel;
    private String analysisVersion;
    private Map<String, Object> additionalData;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LegalComplianceAnalysis {
        private String overallStatus; // COMPLIANT, NON_COMPLIANT, PARTIAL
        private double complianceScore; // 0.0 to 1.0
        private List<String> compliantAreas;
        private List<String> nonCompliantAreas;
        private List<String> recommendations;
        private String governingLaw;
        private String jurisdiction;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RiskAssessmentAnalysis {
        private String overallRiskLevel; // LOW, MEDIUM, HIGH, CRITICAL
        private double riskScore; // 0.0 to 1.0
        private List<RiskFactor> identifiedRisks;
        private List<String> riskMitigationStrategies;
        private String insuranceRecommendations;
        private String liabilityAssessment;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RiskFactor {
        private String riskType;
        private String description;
        private String severity; // LOW, MEDIUM, HIGH, CRITICAL
        private String probability; // LOW, MEDIUM, HIGH
        private String impact;
        private String mitigation;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ClarityAndStructureAnalysis {
        private double clarityScore; // 0.0 to 1.0
        private double structureScore; // 0.0 to 1.0
        private List<String> strengths;
        private List<String> weaknesses;
        private List<String> readabilityIssues;
        private String overallAssessment;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DocumentSummary {
        private String executiveSummary;
        private String keyTerms;
        private String obligations;
        private String rights;
        private String terminationClauses;
        private String disputeResolution;
        private int totalClauses;
        private int totalPages;
        private String estimatedReadingTime;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class IssueHighlight {
        private String issueType; // LEGAL, STRUCTURAL, CLARITY, COMPLIANCE
        private String severity; // LOW, MEDIUM, HIGH, CRITICAL
        private String description;
        private String location; // Section/Clause reference
        private String impact;
        private String suggestedAction;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ImprovementSuggestion {
        private String category; // LEGAL, STRUCTURAL, CLARITY, COMPLIANCE
        private String priority; // LOW, MEDIUM, HIGH
        private String suggestion;
        private String rationale;
        private String implementation;
        private String expectedBenefit;
    }
}
