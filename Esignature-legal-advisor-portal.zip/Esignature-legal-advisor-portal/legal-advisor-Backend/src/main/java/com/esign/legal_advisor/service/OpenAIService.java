package com.esign.legal_advisor.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class OpenAIService {

    private static final Logger logger = LoggerFactory.getLogger(OpenAIService.class);

    @Value("${openai.api.key}")
    private String apiKey;

    @Value("${openai.api.url}")
    private String apiUrl;

    @Value("${openai.model:gpt-4}")
    private String model;

    @Value("${openai.max-tokens:4000}")
    private int maxTokens;

    @Value("${openai.temperature:0.1}")
    private double temperature;

    @Value("${openai.timeout.seconds:120}")
    private int timeoutSeconds;

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    public OpenAIService() {
        this.restTemplate = new RestTemplate();
        this.objectMapper = new ObjectMapper();

        // Set timeout for RestTemplate
        this.restTemplate.getRequestFactory();
    }

    /**
     * Generate legal agreement using OpenAI GPT-4
     */
    public String generateLegalAgreement(String agreementType, String partyA, String partyB, String terms) {
        logger.info("Generating legal agreement using OpenAI: {} between {} and {}", agreementType, partyA, partyB);

        String prompt = buildAgreementPrompt(agreementType, partyA, partyB, terms);

        try {
            String response = callOpenAI(prompt);
            logger.info("Successfully generated legal agreement using OpenAI");
            return response;
        } catch (Exception e) {
            logger.error("Error generating legal agreement with OpenAI: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to generate legal agreement: " + e.getMessage());
        }
    }

    /**
     * Perform comprehensive legal document analysis
     */
    public String analyzeLegalDocument(String documentContent) {
        logger.info("Performing comprehensive legal document analysis using OpenAI");

        String prompt = buildAnalysisPrompt(documentContent);

        try {
            String analysis = callOpenAI(prompt);
            logger.info("Successfully analyzed legal document using OpenAI");
            return analysis;
        } catch (Exception e) {
            logger.error("Error analyzing legal document with OpenAI: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to analyze legal document: " + e.getMessage());
        }
    }

    /**
     * Assess legal compliance of a document
     */
    public String assessLegalCompliance(String documentContent, String jurisdiction) {
        logger.info("Assessing legal compliance for jurisdiction: {}", jurisdiction);

        String prompt = buildCompliancePrompt(documentContent, jurisdiction);

        try {
            String assessment = callOpenAI(prompt);
            logger.info("Successfully assessed legal compliance using OpenAI");
            return assessment;
        } catch (Exception e) {
            logger.error("Error assessing legal compliance with OpenAI: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to assess legal compliance: " + e.getMessage());
        }
    }

    /**
     * Perform legal risk analysis
     */
    public String performRiskAnalysis(String documentContent) {
        logger.info("Performing legal risk analysis using OpenAI");

        String prompt = buildRiskAnalysisPrompt(documentContent);

        try {
            String riskAnalysis = callOpenAI(prompt);
            logger.info("Successfully performed legal risk analysis using OpenAI");
            return riskAnalysis;
        } catch (Exception e) {
            logger.error("Error performing legal risk analysis with OpenAI: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to perform legal risk analysis: " + e.getMessage());
        }
    }

    /**
     * Highlight potential legal issues in a document
     */
    public String highlightLegalIssues(String documentContent) {
        logger.info("Highlighting legal issues using OpenAI");

        String prompt = buildIssueHighlightPrompt(documentContent);

        try {
            String issues = callOpenAI(prompt);
            logger.info("Successfully highlighted legal issues using OpenAI");
            return issues;
        } catch (Exception e) {
            logger.error("Error highlighting legal issues with OpenAI: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to highlight legal issues: " + e.getMessage());
        }
    }

    /**
     * Call OpenAI API with the given prompt
     */
    private String callOpenAI(String prompt) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", model);
        requestBody.put("messages", List.of(
                Map.of("role", "user", "content", prompt)));
        requestBody.put("max_tokens", maxTokens);
        requestBody.put("temperature", temperature);

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(
                    apiUrl + "/chat/completions",
                    entity,
                    String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());
                return jsonResponse.path("choices").get(0).path("message").path("content").asText();
            } else {
                throw new RuntimeException("OpenAI API returned status: " + response.getStatusCode());
            }
        } catch (Exception e) {
            logger.error("Error calling OpenAI API: {}", e.getMessage(), e);
            throw new RuntimeException("OpenAI API call failed: " + e.getMessage());
        }
    }

    /**
     * Build professional legal agreement generation prompt
     */
    private String buildAgreementPrompt(String agreementType, String partyA, String partyB, String terms) {
        return String.format("""
                You are a professional legal expert specializing in contract law and legal document drafting.

                Generate a comprehensive, legally sound %s between:
                - Party A: %s
                - Party B: %s

                Specific Terms: %s

                Requirements:
                1. Use professional legal language and terminology
                2. Include all essential clauses for this type of agreement
                3. Ensure compliance with standard legal practices
                4. Include appropriate dispute resolution mechanisms
                5. Add termination and breach clauses
                6. Include governing law and jurisdiction clauses
                7. Ensure the document is enforceable and legally binding
                8. Use clear, precise language to avoid ambiguity
                9. Include signature blocks and execution requirements
                10. Add confidentiality provisions where appropriate

                Structure the agreement with:
                - Title and parties identification
                - Recitals/Background
                - Definitions (if needed)
                - Main terms and conditions
                - Payment/consideration terms (if applicable)
                - Duration and termination
                - Dispute resolution
                - General provisions
                - Execution/signature section

                Generate a complete, professional legal agreement that would be acceptable in a commercial setting.
                """, agreementType, partyA, partyB, terms);
    }

    /**
     * Build comprehensive legal document analysis prompt for professional lawyers
     */
    private String buildAnalysisPrompt(String documentContent) {
        return String.format(
                """
                        You are a senior partner at a top-tier law firm with 25+ years of experience in contract law, corporate law, and legal document review. You have handled complex commercial transactions, M&A deals, and high-stakes litigation.

                        Perform a comprehensive legal analysis of the following document with the depth and precision expected by senior legal professionals:

                        %s

                        Provide a detailed legal memorandum covering:

                        1. EXECUTIVE SUMMARY:
                        - Document type, purpose, and commercial context
                        - Parties involved, their roles, and business relationship
                        - Key commercial terms and financial implications
                        - Overall legal risk assessment and recommendation

                        2. LEGAL STRUCTURE ANALYSIS:
                        - Contract formation elements (offer, acceptance, consideration)
                        - Governing law and jurisdiction adequacy
                        - Dispute resolution mechanisms and enforceability
                        - Amendment and termination procedures
                        - Assignment and transfer restrictions

                        3. COMMERCIAL TERMS REVIEW:
                        - Payment terms and financial obligations
                        - Performance standards and deliverables
                        - Timeline and milestone provisions
                        - Intellectual property rights and ownership
                        - Confidentiality and non-disclosure obligations

                        4. RISK ASSESSMENT & LIABILITY:
                        - Liability limitations and indemnification adequacy
                        - Force majeure and business continuity provisions
                        - Insurance requirements and coverage gaps
                        - Regulatory compliance and industry standards
                        - Potential dispute scenarios and resolution costs

                        5. LEGAL STRENGTHS:
                        - Well-drafted protective clauses
                        - Clear performance standards and metrics
                        - Adequate dispute resolution mechanisms
                        - Proper legal formalities and execution requirements
                        - Industry best practices implementation

                        6. CRITICAL LEGAL WEAKNESSES:
                        - Ambiguous or unenforceable language
                        - Missing essential legal protections
                        - Inadequate liability and risk allocation
                        - Compliance gaps and regulatory risks
                        - Potential unconscionability or unfair terms

                        7. STRATEGIC RECOMMENDATIONS:
                        - Specific clause improvements with sample language
                        - Additional protective provisions needed
                        - Risk mitigation strategies and alternatives
                        - Negotiation priorities and fallback positions
                        - Implementation timeline and resource requirements

                        8. COMPLIANCE & REGULATORY ANALYSIS:
                        - Applicable laws and regulations compliance
                        - Industry-specific requirements adherence
                        - Data protection and privacy law compliance
                        - Anti-corruption and ethics requirements
                        - International law considerations (if applicable)

                        Provide professional, actionable legal insights with specific recommendations that would be valuable for senior legal decision-making and client advisory purposes.
                        """,
                documentContent);
    }

    /**
     * Build legal compliance assessment prompt
     */
    private String buildCompliancePrompt(String documentContent, String jurisdiction) {
        return String.format("""
                You are a compliance specialist and legal expert with deep knowledge of %s law and regulations.

                Assess the legal compliance of the following document for %s jurisdiction:

                %s

                Provide a detailed compliance assessment including:

                1. REGULATORY COMPLIANCE:
                - Applicable laws and regulations
                - Compliance status assessment
                - Required disclosures presence
                - Mandatory clause inclusion

                2. JURISDICTIONAL REQUIREMENTS:
                - Local law compatibility
                - Court system recognition
                - Enforcement mechanisms
                - Legal formalities compliance

                3. INDUSTRY STANDARDS:
                - Sector-specific regulations
                - Professional standards adherence
                - Best practice implementation
                - Industry code compliance

                4. COMPLIANCE GAPS:
                - Missing regulatory requirements
                - Non-compliant provisions
                - Risk areas identification
                - Correction priorities

                5. REMEDIATION PLAN:
                - Specific actions required
                - Timeline for compliance
                - Resource requirements
                - Implementation steps

                Provide a professional compliance report with clear recommendations for achieving full legal compliance.
                """, jurisdiction, jurisdiction, documentContent);
    }

    /**
     * Build legal risk analysis prompt
     */
    private String buildRiskAnalysisPrompt(String documentContent) {
        return String.format("""
                You are a legal risk management expert specializing in contract risk assessment and mitigation.

                Perform a comprehensive legal risk analysis of the following document:

                %s

                Provide a detailed risk assessment covering:

                1. CONTRACTUAL RISKS:
                - Performance risks
                - Delivery/milestone risks
                - Payment and financial risks
                - Termination risks

                2. LIABILITY RISKS:
                - Indemnification exposure
                - Limitation of liability adequacy
                - Insurance requirements
                - Third-party claims exposure

                3. OPERATIONAL RISKS:
                - Business continuity risks
                - Intellectual property risks
                - Confidentiality breaches
                - Regulatory compliance risks

                4. LEGAL RISKS:
                - Enforceability concerns
                - Jurisdiction and governing law risks
                - Dispute resolution adequacy
                - Breach consequences

                5. FINANCIAL RISKS:
                - Cost overrun exposure
                - Revenue recognition issues
                - Currency/exchange risks
                - Credit and collection risks

                6. RISK MITIGATION:
                - Recommended protective clauses
                - Insurance requirements
                - Performance guarantees
                - Monitoring mechanisms

                Provide a professional risk assessment with specific recommendations for risk mitigation and management.
                """, documentContent);
    }

    /**
     * Build enhanced legal issue highlighting prompt for professional lawyers
     */
    private String buildIssueHighlightPrompt(String documentContent) {
        return String.format(
                """
                        You are a senior legal counsel with 20+ years of experience in contract law, corporate law, and legal document review. You have expertise in identifying critical legal issues that could lead to disputes, enforceability problems, or regulatory violations.

                        Perform a comprehensive legal issue analysis of the following document:

                        %s

                        Analyze and categorize issues with the precision and detail expected by professional lawyers:

                        1. CRITICAL LEGAL ISSUES (Immediate legal attention required):
                        - Enforceability problems (unconscionable terms, illegal provisions)
                        - Missing essential legal elements (consideration, mutual assent, capacity)
                        - Conflicting or contradictory provisions
                        - Invalid clauses that violate public policy
                        - Missing governing law and jurisdiction clauses
                        - Inadequate dispute resolution mechanisms
                        - Breach of statutory requirements

                        2. HIGH-RISK ISSUES (Significant legal exposure):
                        - Ambiguous language creating interpretation disputes
                        - Inadequate liability protections and indemnification
                        - Unfair or unconscionable terms favoring one party
                        - Missing force majeure or termination clauses
                        - Inadequate intellectual property protections
                        - Compliance gaps with applicable regulations
                        - Missing confidentiality and non-disclosure provisions

                        3. MODERATE LEGAL ISSUES (Standard practice improvements):
                        - Suboptimal clause structure and organization
                        - Missing industry-standard provisions
                        - Unclear definitions and terminology
                        - Inadequate performance standards and metrics
                        - Missing change management procedures
                        - Insufficient record-keeping requirements

                        4. MINOR ISSUES (Drafting and style improvements):
                        - Formatting and numbering inconsistencies
                        - Non-standard legal language usage
                        - Redundant or unnecessary provisions
                        - Style and clarity improvements

                        For each issue identified, provide:
                        - EXACT clause/section reference with line numbers
                        - CLEAR legal problem description
                        - SPECIFIC potential legal consequences
                        - DETAILED recommended solution with sample language
                        - PRIORITY level and urgency
                        - RELEVANT case law or regulatory references (if applicable)
                        - ESTIMATED risk level (Low/Medium/High/Critical)

                        Present findings in a professional legal memorandum format suitable for senior counsel review, with executive summary and detailed analysis sections.
                        """,
                documentContent);
    }

    /**
     * Check if OpenAI service is properly configured
     */
    public boolean isConfigured() {
        boolean configured = apiKey != null &&
                !apiKey.trim().isEmpty() &&
                !"YOUR_OPENAI_API_KEY".equals(apiKey) &&
                apiKey.startsWith("sk-");

        logger.debug("OpenAI configuration check: configured={}, hasKey={}", configured, apiKey != null);
        return configured;
    }

    /**
     * Test OpenAI connectivity
     */
    public Map<String, Object> testConnection() {
        Map<String, Object> result = new HashMap<>();

        try {
            if (!isConfigured()) {
                result.put("success", false);
                result.put("message", "OpenAI API key not configured");
                return result;
            }

            String testResponse = callOpenAI("Test connection. Please respond with 'OpenAI connection successful'.");

            result.put("success", true);
            result.put("message", "OpenAI connection successful");
            result.put("model", model);
            result.put("response", testResponse);

        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "OpenAI connection failed: " + e.getMessage());
            logger.error("OpenAI connection test failed", e);
        }

        return result;
    }
}
