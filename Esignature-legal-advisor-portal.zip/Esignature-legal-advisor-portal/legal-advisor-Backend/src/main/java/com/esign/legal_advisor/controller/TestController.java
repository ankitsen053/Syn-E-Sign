package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.service.AiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/test")
@CrossOrigin(origins = "*")
public class TestController {

    @Autowired
    private AiService aiService;

    @GetMapping("/health")
    public String health() {
        return "Application is running!";
    }

    @PostMapping("/agreement")
    public ResponseEntity<?> testAgreement() {
        try {
            String result = aiService.generateAgreement(
                "Service Agreement", 
                "Test Company A", 
                "Test Company B", 
                "This is a test agreement for validation purposes"
            );
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Agreement generated successfully");
            response.put("agreement", result);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Failed to create agreement: " + e.getMessage());
            
            return ResponseEntity.status(500).body(response);
        }
    }
}
