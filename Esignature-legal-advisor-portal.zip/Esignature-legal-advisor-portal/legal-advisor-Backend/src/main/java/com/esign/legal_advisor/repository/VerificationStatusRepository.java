package com.esign.legal_advisor.repository;

import com.esign.legal_advisor.entites.VerificationStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface VerificationStatusRepository extends MongoRepository<VerificationStatus, String> {

    Optional<VerificationStatus> findByUserId(String userId);

    Optional<VerificationStatus> findByEmail(String email);

    boolean existsByUserId(String userId);

    boolean existsByEmail(String email);

    // Pagination and filtering methods
    Page<VerificationStatus> findByOverallStatus(String overallStatus, Pageable pageable);

    long countByOverallStatus(String overallStatus);
}
