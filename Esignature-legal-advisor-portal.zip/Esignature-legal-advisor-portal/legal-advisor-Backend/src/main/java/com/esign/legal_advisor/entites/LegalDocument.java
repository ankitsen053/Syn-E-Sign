package com.esign.legal_advisor.entites;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DBRef;
import java.time.LocalDateTime;
import java.util.Map;

@Document(collection = "documents")
public class LegalDocument {

    @Id
    private String id;

    private String title;

    private String content;

    private String type;

    private String partyA;

    private String partyB;

    private String terms;

    @DBRef(lazy = true)
    private User user;

    private String userId; // Add userId field for easier querying

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private Boolean isEdited = false;

    private Integer version = 1;
    
    // Analysis and signature metadata
    private String analysisStatus; // PENDING, ANALYZED, FAILED
    private String analysisType; // PAN, AADHAAR, GENERAL, CONTRACT, etc.
    private Double analysisConfidenceScore;
    private LocalDateTime lastAnalyzedAt;
    
    // Signing metadata
    private String signingStatus; // DRAFT, PENDING_SIGNATURE, SIGNED, COMPLETED
    private String signedAgreementId;
    private LocalDateTime lastSignedAt;
    private String lastSignerName;
    private String lastSignerEmail;
    
    // Document metadata
    private String documentHash;
    private String documentQuality; // GOOD, MEDIUM, POOR
    private String riskLevel; // LOW, MEDIUM, HIGH
    private Map<String, Object> metadata;

    // Constructors
    public LegalDocument() {
    }

    public LegalDocument(String title, String content, String type, String partyA, String partyB, String terms,
            User user) {
        this.title = title;
        this.content = content;
        this.type = type;
        this.partyA = partyA;
        this.partyB = partyB;
        this.terms = terms;
        this.user = user;
        this.userId = user != null ? user.getId() : null;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPartyA() {
        return partyA;
    }

    public void setPartyA(String partyA) {
        this.partyA = partyA;
    }

    public String getPartyB() {
        return partyB;
    }

    public void setPartyB(String partyB) {
        this.partyB = partyB;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
        this.userId = user != null ? user.getId() : null;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Boolean getIsEdited() {
        return isEdited;
    }

    public void setIsEdited(Boolean isEdited) {
        this.isEdited = isEdited;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
    
    // Analysis metadata getters and setters
    public String getAnalysisStatus() {
        return analysisStatus;
    }

    public void setAnalysisStatus(String analysisStatus) {
        this.analysisStatus = analysisStatus;
    }

    public String getAnalysisType() {
        return analysisType;
    }

    public void setAnalysisType(String analysisType) {
        this.analysisType = analysisType;
    }

    public Double getAnalysisConfidenceScore() {
        return analysisConfidenceScore;
    }

    public void setAnalysisConfidenceScore(Double analysisConfidenceScore) {
        this.analysisConfidenceScore = analysisConfidenceScore;
    }

    public LocalDateTime getLastAnalyzedAt() {
        return lastAnalyzedAt;
    }

    public void setLastAnalyzedAt(LocalDateTime lastAnalyzedAt) {
        this.lastAnalyzedAt = lastAnalyzedAt;
    }
    
    // Signing metadata getters and setters
    public String getSigningStatus() {
        return signingStatus;
    }

    public void setSigningStatus(String signingStatus) {
        this.signingStatus = signingStatus;
    }

    public String getSignedAgreementId() {
        return signedAgreementId;
    }

    public void setSignedAgreementId(String signedAgreementId) {
        this.signedAgreementId = signedAgreementId;
    }

    public LocalDateTime getLastSignedAt() {
        return lastSignedAt;
    }

    public void setLastSignedAt(LocalDateTime lastSignedAt) {
        this.lastSignedAt = lastSignedAt;
    }

    public String getLastSignerName() {
        return lastSignerName;
    }

    public String getLastSignerEmail() {
        return lastSignerEmail;
    }

    public void setLastSignerEmail(String lastSignerEmail) {
        this.lastSignerEmail = lastSignerEmail;
    }
    
    // Document metadata getters and setters
    public String getDocumentHash() {
        return documentHash;
    }

    public void setDocumentHash(String documentHash) {
        this.documentHash = documentHash;
    }

    public String getDocumentQuality() {
        return documentQuality;
    }

    public void setDocumentQuality(String documentQuality) {
        this.documentQuality = documentQuality;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }

    // Helper methods
    public void incrementVersion() {
        this.version++;
        this.updatedAt = LocalDateTime.now();
        this.isEdited = true;
    }
    
    public void markAsAnalyzed(String analysisType, Double confidenceScore) {
        this.analysisStatus = "ANALYZED";
        this.analysisType = analysisType;
        this.analysisConfidenceScore = confidenceScore;
        this.lastAnalyzedAt = LocalDateTime.now();
    }
    
    public void markAsSigned(String signedAgreementId, String signerName, String signerEmail) {
        this.signingStatus = "SIGNED";
        this.signedAgreementId = signedAgreementId;
        this.lastSignedAt = LocalDateTime.now();
        this.lastSignerName = signerName;
        this.lastSignerEmail = signerEmail;
    }
    
    public void updateDocumentQuality(String quality, String riskLevel) {
        this.documentQuality = quality;
        this.riskLevel = riskLevel;
    }
}
