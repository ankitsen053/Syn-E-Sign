package com.esign.legal_advisor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.io.InputStream;

@Service
public class AiService {
    private static final Logger logger = LoggerFactory.getLogger(AiService.class);

    @Autowired
    private OpenAIService openAIService;

    @Autowired
    private HuggingFaceService huggingFaceService;

    @Autowired
    private LocalModelService localModelService;

    @Autowired
    private LegalAgreementTemplateService templateService;

    @Value("${ai.service.provider:local}")
    private String aiProvider;

    @Value("${ai.service.fallback.enabled:false}")
    private boolean fallbackEnabled;

    public String generateAgreement(String type, String partyA, String partyB, String terms) {
        logger.info("Starting agreement generation: type={}, partyA={}, partyB={}", type, partyA, partyB);

        // First, generate the comprehensive template-based agreement
        String templateAgreement = templateService.generateComprehensiveAgreement(type, partyA, partyB, terms, null);

        // Try to enhance with AI if available
        if ("huggingface".equals(aiProvider) && huggingFaceService.isConfigured()) {
            try {
                logger.info("Attempting to enhance agreement using HuggingFace ChatGPT-2.V2 model");
                String enhancedContent = huggingFaceService.generateLegalAgreement(type, partyA, partyB, terms);
                if (enhancedContent != null && !enhancedContent.trim().isEmpty()) {
                    // Merge AI-enhanced content with template
                    return mergeAiContentWithTemplate(templateAgreement, enhancedContent, type);
                }
            } catch (Exception e) {
                logger.warn("HuggingFace enhancement failed, using template: {}", e.getMessage());
            }
        } else if ("local".equals(aiProvider) && localModelService.isConfigured()) {
            try {
                logger.info("Attempting to enhance agreement using local ChatGPT-2.V2 model");
                String enhancedContent = localModelService.generateLegalAgreement(type, partyA, partyB, terms);
                if (enhancedContent != null && !enhancedContent.trim().isEmpty()) {
                    // Merge AI-enhanced content with template
                    return mergeAiContentWithTemplate(templateAgreement, enhancedContent, type);
                }
            } catch (Exception e) {
                logger.warn("Local model enhancement failed, using template: {}", e.getMessage());
            }
        } else if ("openai".equals(aiProvider) && openAIService.isConfigured()) {
            try {
                logger.info("Attempting to enhance agreement using OpenAI");
                String enhancedContent = openAIService.generateLegalAgreement(type, partyA, partyB, terms);
                if (enhancedContent != null && !enhancedContent.trim().isEmpty()) {
                    // Merge AI-enhanced content with template
                    return mergeAiContentWithTemplate(templateAgreement, enhancedContent, type);
                }
            } catch (Exception e) {
                logger.warn("OpenAI enhancement failed, using template: {}", e.getMessage());
            }
        }

        // Try local model fallback if enabled
        if (fallbackEnabled) {
            try {
                logger.info("Using local ChatGPT-2.V2 model fallback for agreement enhancement");
                String enhancedContent = localModelService.generateLegalAgreement(type, partyA, partyB, terms);
                if (enhancedContent != null && !enhancedContent.trim().isEmpty()) {
                    return mergeAiContentWithTemplate(templateAgreement, enhancedContent, type);
                }
            } catch (Exception e) {
                logger.warn("Local model enhancement failed, using template: {}", e.getMessage());
            }
        }

        // Return template-based agreement if no AI enhancement is available
        logger.info("Using comprehensive template-based agreement");
        return templateAgreement;
    }

    public String analyzeDocument(String content) {
        try {
            if ("local".equals(aiProvider) && localModelService.isConfigured()) {
                logger.info("Analyzing document using local ChatGPT-2.V2 model");
                return localModelService.analyzeLegalDocument(content);
            } else if ("openai".equals(aiProvider) && openAIService.isConfigured()) {
                logger.info("Analyzing document using OpenAI");
                return openAIService.analyzeLegalDocument(content);
            } else if ("huggingface".equals(aiProvider) && huggingFaceService.isConfigured()) {
                logger.info("Analyzing document using HuggingFace ChatGPT-2.V2");
                return huggingFaceService.analyzeLegalDocument(content);
            } else if (fallbackEnabled) {
                logger.info("Using local model fallback for document analysis");
                return localModelService.analyzeLegalDocument(content);
            } else {
                throw new RuntimeException("AI service not configured and fallback disabled");
            }
        } catch (Exception e) {
            logger.error("Error analyzing document with AI service", e);
            if (fallbackEnabled) {
                logger.info("Attempting fallback to mock analysis");
                return generateMockAnalysis(content);
            }
            throw new RuntimeException("Failed to analyze document: " + e.getMessage());
        }
    }

    /**
     * Enhanced comprehensive legal analysis
     */
    public Map<String, Object> performComprehensiveLegalAnalysis(String content) {
        Map<String, Object> analysis = new HashMap<>();

        try {
            // Basic analysis
            analysis.put("overallAnalysis", analyzeDocument(content));

            // Risk analysis
            analysis.put("riskAnalysis", performRiskAnalysis(content));

            // Issue highlighting
            analysis.put("issues", highlightIssues(content));

            // Compliance assessment
            analysis.put("complianceAssessment", assessCompliance(content, "IN"));

            // Legal score calculation
            analysis.put("legalScore", calculateLegalScore(content));

            // Recommendations
            analysis.put("recommendations", generateRecommendations(content));

            // Missing clauses detection
            analysis.put("missingClauses", detectMissingClauses(content));

            return analysis;

        } catch (Exception e) {
            logger.error("Error in comprehensive legal analysis", e);
            analysis.put("error", "Analysis failed: " + e.getMessage());
            return analysis;
        }
    }

    /**
     * Calculate legal document score (0-100)
     */
    private int calculateLegalScore(String content) {
        int score = 0;

        // Check for essential elements
        if (content.toLowerCase().contains("agreement") || content.toLowerCase().contains("contract"))
            score += 10;
        if (content.toLowerCase().contains("party") && content.toLowerCase().contains("party"))
            score += 10;
        if (content.toLowerCase().contains("terms") || content.toLowerCase().contains("conditions"))
            score += 10;
        if (content.toLowerCase().contains("signature") || content.toLowerCase().contains("sign"))
            score += 10;

        // Check for legal clauses
        if (content.toLowerCase().contains("liability"))
            score += 5;
        if (content.toLowerCase().contains("termination"))
            score += 5;
        if (content.toLowerCase().contains("confidentiality"))
            score += 5;
        if (content.toLowerCase().contains("dispute") || content.toLowerCase().contains("arbitration"))
            score += 5;
        if (content.toLowerCase().contains("governing law"))
            score += 5;
        if (content.toLowerCase().contains("force majeure"))
            score += 5;

        // Check for completeness
        if (content.length() > 1000)
            score += 10;
        if (content.length() > 2000)
            score += 10;

        // Check for professional language
        if (content.contains("WHEREAS") || content.contains("NOW, THEREFORE"))
            score += 10;

        return Math.min(score, 100);
    }

    /**
     * Generate legal recommendations
     */
    private List<String> generateRecommendations(String content) {
        List<String> recommendations = new ArrayList<>();

        if (!content.toLowerCase().contains("liability")) {
            recommendations.add("Add liability limitation clauses to protect both parties");
        }

        if (!content.toLowerCase().contains("termination")) {
            recommendations.add("Include clear termination conditions and procedures");
        }

        if (!content.toLowerCase().contains("confidentiality")) {
            recommendations.add("Add confidentiality provisions for sensitive information");
        }

        if (!content.toLowerCase().contains("dispute") && !content.toLowerCase().contains("arbitration")) {
            recommendations.add("Include dispute resolution mechanism (arbitration or mediation)");
        }

        if (!content.toLowerCase().contains("governing law")) {
            recommendations.add("Specify governing law and jurisdiction for legal disputes");
        }

        if (!content.toLowerCase().contains("force majeure")) {
            recommendations.add("Add force majeure clause for unforeseen circumstances");
        }

        if (!content.toLowerCase().contains("intellectual property")) {
            recommendations.add("Include intellectual property rights and ownership clauses");
        }

        if (!content.toLowerCase().contains("data protection") && !content.toLowerCase().contains("privacy")) {
            recommendations.add("Add data protection and privacy compliance provisions");
        }

        return recommendations;
    }

    /**
     * Detect missing essential legal clauses
     */
    private List<String> detectMissingClauses(String content) {
        List<String> missing = new ArrayList<>();

        String[] essentialClauses = {
                "liability limitation",
                "termination clause",
                "confidentiality",
                "dispute resolution",
                "governing law",
                "force majeure",
                "intellectual property",
                "data protection",
                "indemnification",
                "severability"
        };

        for (String clause : essentialClauses) {
            if (!content.toLowerCase().contains(clause.replace(" ", "")) &&
                    !content.toLowerCase().contains(clause.replace(" ", "_"))) {
                missing.add(clause);
            }
        }

        return missing;
    }

    public String highlightIssues(String content) {
        try {
            if ("local".equals(aiProvider) && localModelService.isConfigured()) {
                logger.info("Highlighting issues using local ChatGPT-2.V2 model");
                return localModelService.highlightLegalIssues(content);
            } else if ("openai".equals(aiProvider) && openAIService.isConfigured()) {
                logger.info("Highlighting issues using OpenAI");
                return openAIService.highlightLegalIssues(content);
            } else if (fallbackEnabled) {
                logger.info("Using local model fallback for issue highlighting");
                return localModelService.highlightLegalIssues(content);
            } else {
                throw new RuntimeException("AI service not configured and fallback disabled");
            }
        } catch (Exception e) {
            logger.error("Error highlighting issues with AI service", e);
            if (fallbackEnabled) {
                logger.info("Attempting fallback to mock issue highlighting");
                return generateMockIssues(content);
            }
            throw new RuntimeException("Failed to highlight issues: " + e.getMessage());
        }
    }

    public String generateDocumentContent(Map<String, Object> context) {
        String type = (String) context.getOrDefault("type", "General Agreement");
        String partyA = (String) context.getOrDefault("partyA", "Party A");
        String partyB = (String) context.getOrDefault("partyB", "Party B");
        String terms = (String) context.getOrDefault("terms", "");
        String prompt = (String) context.getOrDefault("prompt", "");

        logger.info("Generating document content for type: {}", type);

        try {
            // Create a comprehensive prompt for document generation
            String fullPrompt = String.format(
                    "Generate a professional %s document with the following details:\n" +
                            "Party A: %s\n" +
                            "Party B: %s\n" +
                            "Terms: %s\n" +
                            "Additional Instructions: %s\n" +
                            "Please create a complete, legally formatted document.",
                    type, partyA, partyB, terms, prompt);

            if ("openai".equals(aiProvider) && openAIService.isConfigured()) {
                logger.info("Generating document content using OpenAI");
                return openAIService.generateLegalAgreement(type, partyA, partyB, terms);
            } else if (fallbackEnabled) {
                logger.info("Using HuggingFace fallback for document content generation");
                return huggingFaceService.generateLegalAgreement(type, partyA, partyB, terms);
            } else {
                // Use the existing agreement generation method as fallback
                return generateAgreement(type, partyA, partyB, terms);
            }
        } catch (Exception e) {
            logger.error("Error generating document content", e);
            if (fallbackEnabled) {
                return generateAgreement(type, partyA, partyB, terms);
            }
            throw new RuntimeException("Failed to generate document content: " + e.getMessage());
        }
    }

    public String performRiskAnalysis(String content) {
        try {
            if ("local".equals(aiProvider) && localModelService.isConfigured()) {
                logger.info("Performing risk analysis using local ChatGPT-2.V2 model");
                return localModelService.performRiskAnalysis(content);
            } else if ("openai".equals(aiProvider) && openAIService.isConfigured()) {
                logger.info("Performing risk analysis using OpenAI");
                return openAIService.performRiskAnalysis(content);
            } else if (fallbackEnabled) {
                logger.info("Using local model fallback for risk analysis");
                return localModelService.performRiskAnalysis(content);
            } else {
                throw new RuntimeException("AI service not configured and fallback disabled");
            }
        } catch (Exception e) {
            logger.error("Error performing risk analysis with AI service", e);
            if (fallbackEnabled) {
                logger.info("Attempting fallback to mock risk analysis");
                return generateMockRiskAnalysis(content);
            }
            throw new RuntimeException("Failed to perform risk analysis: " + e.getMessage());
        }
    }

    public String assessCompliance(String content, String jurisdiction) {
        try {
            if ("local".equals(aiProvider) && localModelService.isConfigured()) {
                logger.info("Assessing compliance using local ChatGPT-2.V2 model for jurisdiction: {}", jurisdiction);
                return localModelService.assessLegalCompliance(content, jurisdiction);
            } else if ("openai".equals(aiProvider) && openAIService.isConfigured()) {
                logger.info("Assessing compliance using OpenAI for jurisdiction: {}", jurisdiction);
                return openAIService.assessLegalCompliance(content, jurisdiction);
            } else if (fallbackEnabled) {
                logger.info("Using local model fallback for compliance assessment");
                return localModelService.assessLegalCompliance(content, jurisdiction);
            } else {
                throw new RuntimeException("AI service not configured and fallback disabled");
            }
        } catch (Exception e) {
            logger.error("Error assessing compliance with AI service", e);
            if (fallbackEnabled) {
                logger.info("Attempting fallback to mock compliance assessment");
                return generateMockComplianceAssessment(content, jurisdiction);
            }
            throw new RuntimeException("Failed to assess compliance: " + e.getMessage());
        }
    }

    /**
     * Extract text from uploaded document and analyze it
     */
    public String analyzeDocumentFromFile(MultipartFile file) {
        try {
            logger.info("Processing uploaded document: {}", file.getOriginalFilename());

            // Extract text from document
            String extractedText;
            if ("openai".equals(aiProvider) && openAIService.isConfigured()) {
                // For OpenAI, we use HuggingFace's text extraction capability
                extractedText = extractTextFromFile(file);
            } else {
                extractedText = extractTextFromFile(file);
            }

            logger.info("Successfully extracted {} characters from document", extractedText.length());

            // Analyze the extracted text
            return analyzeDocument(extractedText);
        } catch (Exception e) {
            logger.error("Error processing document from file", e);
            return "Error processing document: " + e.getMessage();
        }
    }

    /**
     * Get AI service status and configuration
     */
    public Map<String, Object> getServiceStatus() {
        Map<String, Object> status = new HashMap<>();

        status.put("primaryProvider", aiProvider);
        status.put("fallbackEnabled", fallbackEnabled);

        // OpenAI status
        if (openAIService.isConfigured()) {
            Map<String, Object> openAIStatus = openAIService.testConnection();
            status.put("openai", openAIStatus);
        } else {
            status.put("openai", Map.of("configured", false, "message", "API key not configured"));
        }

        // Gemini status (if enabled)
        try {
            status.put("gemini", Map.of("configured", true, "message", "Available as fallback"));
        } catch (Exception e) {
            status.put("gemini", Map.of("configured", false, "message", "Not available"));
        }

        return status;
    }

    /**
     * Check if AI service is available
     */
    public boolean isSpringAiAvailable() {
        return localModelService.isConfigured();
    }

    private String generateMockAgreement(String type, String partyA, String partyB, String terms) {
        StringBuilder agreement = new StringBuilder();
        agreement.append("LEGAL AGREEMENT\n\n");
        agreement.append("AGREEMENT TYPE: ").append(type).append("\n\n");
        agreement.append("This agreement is made and entered into on this date between:\n\n");
        agreement.append("PARTY A: ").append(partyA).append("\n");
        agreement.append("PARTY B: ").append(partyB).append("\n\n");
        agreement.append("TERMS AND CONDITIONS:\n");
        agreement.append(terms).append("\n\n");
        agreement.append("ADDITIONAL STANDARD CLAUSES:\n\n");
        agreement.append(
                "1. CONFIDENTIALITY: Both parties agree to maintain confidentiality of all proprietary information.\n\n");
        agreement.append(
                "2. TERMINATION: This agreement may be terminated by either party with 30 days written notice.\n\n");
        agreement.append(
                "3. DISPUTE RESOLUTION: Any disputes shall be resolved through arbitration in accordance with applicable laws.\n\n");
        agreement.append(
                "4. GOVERNING LAW: This agreement shall be governed by the laws of the jurisdiction where Party A is located.\n\n");
        agreement
                .append("5. ENTIRE AGREEMENT: This document constitutes the entire agreement between the parties.\n\n");
        agreement.append("6. AMENDMENTS: Any amendments must be in writing and signed by both parties.\n\n");
        agreement.append(
                "7. SEVERABILITY: If any provision is found to be invalid, the remaining provisions shall remain in effect.\n\n");
        agreement.append(
                "8. FORCE MAJEURE: Neither party shall be liable for delays due to circumstances beyond their control.\n\n");
        agreement.append("SIGNATURES:\n\n");
        agreement.append("Party A: _________________ Date: _______________\n");
        agreement.append("Party B: _________________ Date: _______________\n");

        return agreement.toString();
    }

    private String generateMockAnalysis(String content) {
        return String.format("""
                DOCUMENT ANALYSIS REPORT

                OVERALL ASSESSMENT:
                The document appears to be a standard legal agreement with moderate complexity.
                Overall legal soundness: GOOD

                KEY FINDINGS:
                - Document structure is appropriate for the agreement type
                - Standard legal clauses are present
                - Language is generally clear and unambiguous

                POTENTIAL CONCERNS:
                - Consider adding more specific termination conditions
                - Liability limitations could be more clearly defined
                - Dispute resolution process could be more detailed

                MISSING ELEMENTS:
                - Force majeure clause (recommended for business agreements)
                - Intellectual property rights (if applicable)
                - Data protection provisions (if handling personal data)

                RECOMMENDATIONS:
                1. Add specific performance metrics and timelines
                2. Include detailed payment terms and schedules
                3. Define clear breach conditions and remedies
                4. Consider adding non-compete clauses if relevant
                5. Include insurance requirements if applicable

                RISK LEVEL: MEDIUM
                """);
    }

    private String generateMockIssues(String content) {
        return String.format("""
                LEGAL ISSUES HIGHLIGHTED

                CRITICAL ISSUES:
                1. AMBIGUOUS LANGUAGE: Clause 3 uses vague terms that could lead to interpretation disputes
                2. MISSING TERMINATION CLAUSE: No clear conditions for contract termination
                3. INSUFFICIENT LIABILITY PROTECTION: Limited liability provisions may not provide adequate protection

                MODERATE ISSUES:
                4. UNFAIR TERMS: Payment terms heavily favor one party
                5. COMPLIANCE CONCERNS: Missing data protection compliance language
                6. DISPUTE RESOLUTION: Arbitration clause lacks specificity

                MINOR ISSUES:
                7. FORMATTING: Inconsistent numbering in sections
                8. DEFINITIONS: Some terms lack clear definitions

                RECOMMENDATIONS:
                - Rewrite Clause 3 with specific, measurable terms
                - Add comprehensive termination conditions
                - Include GDPR compliance language if applicable
                - Specify arbitration rules and venue
                - Add force majeure provisions
                """);
    }

    private String generateMockRiskAnalysis(String content) {
        return String.format("""
                RISK ANALYSIS REPORT

                CONTRACTUAL RISKS:
                - Performance Risk: MEDIUM (Probability: MEDIUM, Impact: HIGH)
                - Payment Risk: LOW (Probability: LOW, Impact: MEDIUM)
                - Termination Risk: MEDIUM (Probability: MEDIUM, Impact: HIGH)
                - Liability Risk: HIGH (Probability: MEDIUM, Impact: HIGH)

                LEGAL RISKS:
                - Regulatory Compliance: MEDIUM (Probability: MEDIUM, Impact: HIGH)
                - Statutory Violations: LOW (Probability: LOW, Impact: HIGH)
                - Jurisdictional Issues: LOW (Probability: LOW, Impact: MEDIUM)

                OPERATIONAL RISKS:
                - Implementation Challenges: MEDIUM (Probability: HIGH, Impact: MEDIUM)
                - Resource Requirements: LOW (Probability: MEDIUM, Impact: LOW)
                - Timeline Risks: MEDIUM (Probability: HIGH, Impact: MEDIUM)

                REPUTATIONAL RISKS:
                - Public Perception: LOW (Probability: LOW, Impact: MEDIUM)
                - Stakeholder Impact: MEDIUM (Probability: MEDIUM, Impact: HIGH)

                TECHNICAL RISKS:
                - Data Security: MEDIUM (Probability: MEDIUM, Impact: HIGH)
                - Intellectual Property: LOW (Probability: LOW, Impact: HIGH)

                OVERALL RISK SCORE: 6/10 (MEDIUM-HIGH)

                MITIGATION STRATEGIES:
                1. Add specific performance metrics and monitoring
                2. Include comprehensive liability limitations
                3. Define clear dispute resolution procedures
                4. Add data protection and security clauses
                5. Include force majeure provisions
                """);
    }

    private String generateMockComplianceAssessment(String content, String jurisdiction) {
        return String.format("""
                COMPLIANCE ASSESSMENT REPORT

                JURISDICTION: %s

                CONTRACT LAW COMPLIANCE:
                Status: COMPLIANT
                - Essential elements of contract present
                - Offer, acceptance, and consideration identified
                - Legal capacity of parties established

                DATA PROTECTION COMPLIANCE:
                Status: PARTIAL
                - Missing GDPR compliance language
                - No data processing agreements
                - Recommendations: Add data protection clauses

                CONSUMER PROTECTION COMPLIANCE:
                Status: COMPLIANT
                - Fair terms and conditions
                - Clear pricing and payment terms
                - Appropriate dispute resolution mechanisms

                EMPLOYMENT LAW COMPLIANCE:
                Status: N/A
                - Not applicable to this contract type

                INTELLECTUAL PROPERTY COMPLIANCE:
                Status: PARTIAL
                - Basic IP protection present
                - Missing detailed IP assignment clauses
                - Recommendations: Add comprehensive IP provisions

                TAX AND FINANCIAL COMPLIANCE:
                Status: COMPLIANT
                - Payment terms clearly defined
                - Tax obligations addressed
                - Financial reporting requirements specified

                OVERALL COMPLIANCE STATUS: MOSTLY COMPLIANT

                RECOMMENDATIONS:
                1. Add GDPR compliance language
                2. Include comprehensive IP clauses
                3. Specify data processing agreements
                4. Add regulatory reporting requirements
                """, jurisdiction);
    }

    /**
     * Merge AI-enhanced content with template agreement
     */
    private String mergeAiContentWithTemplate(String templateAgreement, String aiContent, String type) {
        logger.info("Merging AI-enhanced content with template agreement");

        try {
            // Extract key sections from AI content
            String enhancedTerms = extractEnhancedTerms(aiContent);
            String enhancedClauses = extractEnhancedClauses(aiContent);

            // Create enhanced agreement by combining template with AI enhancements
            StringBuilder enhancedAgreement = new StringBuilder();

            // Add template header and recitals
            String[] templateParts = templateAgreement.split("ARTICLE IV - TERMS AND CONDITIONS");
            if (templateParts.length > 0) {
                enhancedAgreement.append(templateParts[0]);
            }

            // Add enhanced terms and conditions
            enhancedAgreement.append("ARTICLE IV - TERMS AND CONDITIONS\n\n");
            enhancedAgreement.append("4.1 Enhanced Terms (AI-Generated):\n\n");
            enhancedAgreement.append(enhancedTerms != null ? enhancedTerms : "Standard terms apply.\n\n");

            enhancedAgreement.append("4.2 Enhanced Legal Clauses (AI-Generated):\n\n");
            enhancedAgreement.append(enhancedClauses != null ? enhancedClauses : "Standard legal clauses apply.\n\n");

            // Add remaining template sections
            if (templateParts.length > 1) {
                String[] remainingParts = templateParts[1].split("ARTICLE V - SIGNATURES");
                if (remainingParts.length > 1) {
                    enhancedAgreement.append("4.3 Standard Compliance Requirements:\n\n");
                    enhancedAgreement.append(remainingParts[0].replace("4.1 Specific Terms.", "")
                            .replace("4.2 Additional Details.", ""));
                    enhancedAgreement.append("\n\nARTICLE V - SIGNATURES");
                    enhancedAgreement.append(remainingParts[1]);
                }
            }

            String finalAgreement = enhancedAgreement.toString();

            // Ensure we don't exceed AI content limits
            if (finalAgreement.length() > 8000) { // Slightly higher limit for enhanced content
                logger.warn("Enhanced agreement length ({}) exceeds limit, truncating", finalAgreement.length());
                finalAgreement = finalAgreement.substring(0, 7900)
                        + "\n\n[Content truncated due to length limitations]";
            }

            return finalAgreement;

        } catch (Exception e) {
            logger.error("Error merging AI content with template: {}", e.getMessage());
            return templateAgreement; // Fallback to template if merging fails
        }
    }

    /**
     * Extract enhanced terms from AI content
     */
    private String extractEnhancedTerms(String aiContent) {
        if (aiContent == null || aiContent.trim().isEmpty()) {
            return null;
        }

        // Look for terms-related content in AI response
        String[] keywords = { "terms", "conditions", "obligations", "requirements", "specifications" };
        for (String keyword : keywords) {
            if (aiContent.toLowerCase().contains(keyword)) {
                // Extract relevant section (limit to reasonable length)
                int startIndex = aiContent.toLowerCase().indexOf(keyword);
                int endIndex = Math.min(startIndex + 1000, aiContent.length());
                return aiContent.substring(startIndex, endIndex);
            }
        }

        return aiContent.substring(0, Math.min(500, aiContent.length())); // Return first 500 chars if no keywords found
    }

    /**
     * Extract enhanced clauses from AI content
     */
    private String extractEnhancedClauses(String aiContent) {
        if (aiContent == null || aiContent.trim().isEmpty()) {
            return null;
        }

        // Look for legal clause content in AI response
        String[] keywords = { "clause", "provision", "section", "article", "governing", "dispute", "liability" };
        for (String keyword : keywords) {
            if (aiContent.toLowerCase().contains(keyword)) {
                // Extract relevant section (limit to reasonable length)
                int startIndex = aiContent.toLowerCase().indexOf(keyword);
                int endIndex = Math.min(startIndex + 800, aiContent.length());
                return aiContent.substring(startIndex, endIndex);
            }
        }

        return aiContent.substring(0, Math.min(400, aiContent.length())); // Return first 400 chars if no keywords found
    }

    /**
     * Extract text from uploaded file using Apache Tika
     */
    public String extractTextFromFile(MultipartFile file) {
        try {
            logger.info("Extracting text from file: {} ({} bytes)", file.getOriginalFilename(), file.getSize());

            // Use Apache Tika for robust text extraction from various file formats
            Tika tika = new Tika();

            // Set maximum text length to prevent memory issues
            tika.setMaxStringLength(1000000); // 1MB limit

            try (InputStream inputStream = file.getInputStream()) {
                String extractedText = tika.parseToString(inputStream);

                if (extractedText == null || extractedText.trim().isEmpty()) {
                    logger.warn("No text content extracted from file: {}", file.getOriginalFilename());
                    return "No readable text content found in the uploaded file. Please ensure the file contains text content.";
                }

                // Clean up the extracted text
                extractedText = extractedText.trim();

                logger.info("Successfully extracted {} characters from file: {}",
                        extractedText.length(), file.getOriginalFilename());

                return extractedText;

            } catch (TikaException e) {
                logger.error("Tika parsing error for file: {}", file.getOriginalFilename(), e);
                throw new RuntimeException("Failed to parse file content: " + e.getMessage());
            }

        } catch (IOException e) {
            logger.error("IO error extracting text from file: {}", file.getOriginalFilename(), e);
            throw new RuntimeException("Failed to read file: " + e.getMessage());
        } catch (Exception e) {
            logger.error("Unexpected error extracting text from file: {}", file.getOriginalFilename(), e);
            throw new RuntimeException("Failed to extract text from file: " + e.getMessage());
        }
    }
}
