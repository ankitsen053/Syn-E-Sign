package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.entites.SignedAgreement;
import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.entites.VerificationStatus;
import com.esign.legal_advisor.service.AdminService;
import com.esign.legal_advisor.service.SignatureService;
import com.esign.legal_advisor.service.VerificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private AdminService adminService;

    @Autowired
    private VerificationService verificationService;

    @Autowired
    private SignatureService signatureService;

    /**
     * Get admin dashboard statistics
     */
    @GetMapping("/dashboard")
    public ResponseEntity<?> getAdminDashboard() {
        logger.info("Getting admin dashboard statistics");

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            Map<String, Object> dashboard = adminService.getDashboardStatistics();
            return ResponseEntity.ok(dashboard);

        } catch (Exception e) {
            logger.error("Error getting admin dashboard", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to get dashboard: " + e.getMessage()));
        }
    }

    /**
     * Get all users with pagination
     */
    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "username") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            @RequestParam(required = false) String userType,
            @RequestParam(required = false) String verificationStatus) {

        logger.info("Getting all users with pagination: page={}, size={}", page, size);

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            Map<String, Object> response = adminService.getAllUsers(page, size, sortBy, sortDir, userType,
                    verificationStatus);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting all users", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to get users: " + e.getMessage()));
        }
    }

    /**
     * Get user details by ID
     */
    @GetMapping("/users/{userId}")
    public ResponseEntity<?> getUserDetails(@PathVariable String userId) {
        logger.info("Getting user details for ID: {}", userId);

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            Optional<User> user = adminService.getUserById(userId);
            if (user.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new MessageResponse("User not found"));
            }

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("user", user.get());
            response.put("verificationStatus", verificationService.getVerificationStatus(userId));

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting user details", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to get user details: " + e.getMessage()));
        }
    }

    /**
     * Update user verification status
     */
    @PutMapping("/users/{userId}/verification")
    public ResponseEntity<?> updateUserVerification(
            @PathVariable String userId,
            @RequestBody Map<String, Object> request) {

        logger.info("Updating user verification for ID: {}", userId);

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            String verificationType = (String) request.get("verificationType");
            String status = (String) request.get("status");
            String notes = (String) request.get("notes");

            MessageResponse response = adminService.updateUserVerification(userId, verificationType, status, notes);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error updating user verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to update verification: " + e.getMessage()));
        }
    }

    /**
     * Get all verification requests
     */
    @GetMapping("/verifications")
    public ResponseEntity<?> getAllVerificationRequests(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String type) {

        logger.info("Getting all verification requests");

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            Map<String, Object> response = adminService.getAllVerificationRequests(page, size, status, type);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting verification requests", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to get verification requests: " + e.getMessage()));
        }
    }

    /**
     * Approve verification request
     */
    @PostMapping("/verifications/{userId}/approve")
    public ResponseEntity<?> approveVerification(
            @PathVariable String userId,
            @RequestBody Map<String, Object> request) {

        logger.info("Approving verification for user: {}", userId);

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            String verificationType = (String) request.get("verificationType");
            String notes = (String) request.get("notes");

            MessageResponse response = adminService.approveVerification(userId, verificationType, notes);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error approving verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to approve verification: " + e.getMessage()));
        }
    }

    /**
     * Reject verification request
     */
    @PostMapping("/verifications/{userId}/reject")
    public ResponseEntity<?> rejectVerification(
            @PathVariable String userId,
            @RequestBody Map<String, Object> request) {

        logger.info("Rejecting verification for user: {}", userId);

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            String verificationType = (String) request.get("verificationType");
            String reason = (String) request.get("reason");

            MessageResponse response = adminService.rejectVerification(userId, verificationType, reason);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error rejecting verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to reject verification: " + e.getMessage()));
        }
    }

    /**
     * Get all agreements with pagination
     */
    @GetMapping("/agreements")
    public ResponseEntity<?> getAllAgreements(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String type) {

        logger.info("Getting all agreements");

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            Map<String, Object> response = adminService.getAllAgreements(page, size, status, type);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting agreements", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to get agreements: " + e.getMessage()));
        }
    }

    /**
     * Get agreement details
     */
    @GetMapping("/agreements/{agreementId}")
    public ResponseEntity<?> getAgreementDetails(@PathVariable String agreementId) {
        logger.info("Getting agreement details for ID: {}", agreementId);

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            Optional<SignedAgreement> agreement = signatureService.getSignedAgreement(agreementId);
            if (agreement.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new MessageResponse("Agreement not found"));
            }

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("agreement", agreement.get());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting agreement details", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to get agreement details: " + e.getMessage()));
        }
    }

    /**
     * Get system statistics
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getSystemStatistics() {
        logger.info("Getting system statistics");

        try {
            if (!isAdmin()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            Map<String, Object> statistics = adminService.getSystemStatistics();
            return ResponseEntity.ok(statistics);

        } catch (Exception e) {
            logger.error("Error getting system statistics", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to get statistics: " + e.getMessage()));
        }
    }

    /**
     * Check if current user is admin
     */
    private boolean isAdmin() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.getPrincipal() instanceof User) {
                User user = (User) authentication.getPrincipal();
                return user.getAuthorities().stream()
                        .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));
            }
            return false;
        } catch (Exception e) {
            logger.error("Error checking admin status", e);
            return false;
        }
    }
}



