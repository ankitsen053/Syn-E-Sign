package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.SignatureRequestDto;
import com.esign.legal_advisor.dto.SignatureVerificationResult;
import com.esign.legal_advisor.entites.SignedAgreement;
import com.esign.legal_advisor.entites.SignatureData;
import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.repository.SignedAgreementRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class SignatureService {

    private static final Logger logger = LoggerFactory.getLogger(SignatureService.class);

    @Autowired
    private SignedAgreementRepository signedAgreementRepository;

    @Autowired
    private PdfService pdfService;

    /**
     * Create a new signed agreement
     */
    public SignedAgreement createSignedAgreement(SignatureRequestDto request, User signer) {
        logger.info("Creating signed agreement for user: {}", signer.getUsername());

        try {
            // Create new signed agreement
            SignedAgreement signedAgreement = new SignedAgreement(
                    request.getAgreementTitle(),
                    request.getAgreementContent(),
                    request.getAgreementType(),
                    request.getPartyA(),
                    request.getPartyB(),
                    request.getTerms(),
                    signer);

            // Set signature data
            signedAgreement.setSignatureImageBase64(request.getSignatureImageBase64());
            signedAgreement.setSignatureData(request.getSignatureData());
            signedAgreement.setSignerName(request.getSignerName());
            signedAgreement.setSignerEmail(request.getSignerEmail());
            signedAgreement.setSignerIpAddress(request.getSignerIpAddress());

            // Generate document and signature hashes
            String documentHash = generateDocumentHash(request.getAgreementContent());
            String signatureHash = generateSignatureHash(request.getSignatureImageBase64());

            signedAgreement.setDocumentHash(documentHash);
            signedAgreement.setSignatureHash(signatureHash);

            // Mark as signed
            signedAgreement.markAsSigned();

            // Save to database
            SignedAgreement savedAgreement = signedAgreementRepository.save(signedAgreement);

            logger.info("Signed agreement created successfully with ID: {}", savedAgreement.getId());
            return savedAgreement;

        } catch (Exception e) {
            logger.error("Error creating signed agreement", e);
            throw new RuntimeException("Failed to create signed agreement: " + e.getMessage());
        }
    }

    /**
     * Create a new signed agreement with basic parameters (for workflow
     * integration)
     */
    public SignedAgreement createSignedAgreement(String documentId, String signerName, String signerEmail,
            String signatureData) {
        logger.info("Creating signed agreement for document: {} by signer: {}", documentId, signerName);

        try {
            // Create new signed agreement with basic info
            SignedAgreement signedAgreement = new SignedAgreement();
            signedAgreement.setAgreementTitle("Document: " + documentId);
            signedAgreement.setAgreementContent("Document content for: " + documentId);
            signedAgreement.setAgreementType("WORKFLOW_DOCUMENT");
            signedAgreement.setPartyA("Party A");
            signedAgreement.setPartyB("Party B");
            signedAgreement.setTerms("Terms for document: " + documentId);

            // Set signature data
            signedAgreement.setSignatureData(signatureData);
            signedAgreement.setSignerName(signerName);
            signedAgreement.setSignerEmail(signerEmail);
            signedAgreement.setSignerIpAddress("127.0.0.1"); // Default IP

            // Generate document and signature hashes
            String documentHash = generateDocumentHash(signedAgreement.getAgreementContent());
            String signatureHash = generateSignatureHash(signatureData);

            signedAgreement.setDocumentHash(documentHash);
            signedAgreement.setSignatureHash(signatureHash);

            // Mark as signed
            signedAgreement.markAsSigned();

            // Save to database
            SignedAgreement savedAgreement = signedAgreementRepository.save(signedAgreement);

            logger.info("Signed agreement created successfully with ID: {} for document: {}", savedAgreement.getId(),
                    documentId);
            return savedAgreement;

        } catch (Exception e) {
            logger.error("Error creating signed agreement for document: {}", documentId, e);
            throw new RuntimeException("Failed to create signed agreement: " + e.getMessage());
        }
    }

    /**
     * Get signed agreement by ID
     */
    public Optional<SignedAgreement> getSignedAgreement(String agreementId) {
        return signedAgreementRepository.findById(agreementId);
    }

    /**
     * Get all signed agreements for a user
     */
    public List<SignedAgreement> getUserSignedAgreements(String userId) {
        return signedAgreementRepository.findBySignerIdOrderByCreatedAtDesc(userId);
    }

    /**
     * Get signed agreements by status
     */
    public List<SignedAgreement> getSignedAgreementsByStatus(String status) {
        return signedAgreementRepository.findByStatusOrderByCreatedAtDesc(status);
    }

    /**
     * Get all signed agreements (SIGNED or COMPLETED)
     */
    public List<SignedAgreement> getAllSignedAgreements() {
        return signedAgreementRepository.findByStatusInOrderByCreatedAtDesc(List.of("SIGNED", "COMPLETED"));
    }

    /**
     * Generate PDF for signed agreement
     */
    public byte[] generateSignedPdf(String agreementId) {
        logger.info("Generating PDF for signed agreement: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signedAgreementRepository.findById(agreementId);
            if (agreementOpt.isEmpty()) {
                throw new RuntimeException("Signed agreement not found: " + agreementId);
            }

            SignedAgreement agreement = agreementOpt.get();

            // Generate PDF with signature
            byte[] pdfBytes = pdfService.generateSignedAgreementPdf(agreement);

            logger.info("PDF generated successfully for agreement: {}", agreementId);
            return pdfBytes;

        } catch (Exception e) {
            logger.error("Error generating PDF for signed agreement", e);
            throw new RuntimeException("Failed to generate PDF: " + e.getMessage());
        }
    }

    /**
     * Verify document integrity
     */
    public boolean verifyDocumentIntegrity(String agreementId) {
        logger.info("Verifying document integrity for agreement: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signedAgreementRepository.findById(agreementId);
            if (agreementOpt.isEmpty()) {
                return false;
            }

            SignedAgreement agreement = agreementOpt.get();

            // Generate current document hash
            String currentDocumentHash = generateDocumentHash(agreement.getAgreementContent());

            // Compare with stored hash
            boolean documentValid = currentDocumentHash.equals(agreement.getDocumentHash());

            logger.info("Document integrity verification result: {}", documentValid);
            return documentValid;

        } catch (Exception e) {
            logger.error("Error verifying document integrity", e);
            return false;
        }
    }

    /**
     * Verify signature integrity
     */
    public SignatureVerificationResult verifySignatureIntegrity(String agreementId) {
        logger.info("Verifying signature integrity for agreement: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signedAgreementRepository.findById(agreementId);
            if (agreementOpt.isEmpty()) {
                return SignatureVerificationResult.builder()
                        .documentIntegrityValid(false)
                        .signatureIntegrityValid(false)
                        .overallValid(false)
                        .verificationMessage("Agreement not found")
                        .verifiedAt(LocalDateTime.now())
                        .build();
            }

            SignedAgreement agreement = agreementOpt.get();

            // Generate current signature hash
            String currentSignatureHash = generateSignatureHash(agreement.getSignatureImageBase64());

            // Compare with stored hash
            boolean signatureValid = currentSignatureHash.equals(agreement.getSignatureHash());

            // Generate document hash for integrity verification
            String currentDocumentHash = generateDocumentHash(agreement.getAgreementContent());
            boolean documentValid = currentDocumentHash.equals(agreement.getDocumentHash());

            // Create verification result
            SignatureVerificationResult result = SignatureVerificationResult.builder()
                    .documentIntegrityValid(documentValid)
                    .signatureIntegrityValid(signatureValid)
                    .timestampValid(true) // Assuming timestamp is always valid for now
                    .signerIdentityVerified(true) // Assuming identity is verified for now
                    .overallValid(documentValid && signatureValid)
                    .documentHash(agreement.getDocumentHash())
                    .signatureHash(agreement.getSignatureHash())
                    .verifiedAt(LocalDateTime.now())
                    .verificationMethod("HASH_VERIFICATION")
                    .verificationMessage(
                            signatureValid ? "Signature verification successful" : "Signature verification failed")
                    .build();

            logger.info("Signature integrity verification result: {}", result.isOverallValid());
            return result;

        } catch (Exception e) {
            logger.error("Error verifying signature integrity", e);
            return SignatureVerificationResult.builder()
                    .documentIntegrityValid(false)
                    .signatureIntegrityValid(false)
                    .overallValid(false)
                    .verificationMessage("Verification error: " + e.getMessage())
                    .verifiedAt(LocalDateTime.now())
                    .build();
        }
    }

    /**
     * Complete an agreement (mark as completed)
     */
    public SignedAgreement completeAgreement(String agreementId) {
        logger.info("Completing agreement: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signedAgreementRepository.findById(agreementId);
            if (agreementOpt.isEmpty()) {
                throw new RuntimeException("Signed agreement not found: " + agreementId);
            }

            SignedAgreement agreement = agreementOpt.get();
            agreement.markAsCompleted();

            SignedAgreement savedAgreement = signedAgreementRepository.save(agreement);

            logger.info("Agreement completed successfully: {}", agreementId);
            return savedAgreement;

        } catch (Exception e) {
            logger.error("Error completing agreement", e);
            throw new RuntimeException("Failed to complete agreement: " + e.getMessage());
        }
    }

    /**
     * Delete signed agreement
     */
    public boolean deleteSignedAgreement(String agreementId) {
        logger.info("Deleting signed agreement: {}", agreementId);

        try {
            if (signedAgreementRepository.existsById(agreementId)) {
                signedAgreementRepository.deleteById(agreementId);
                logger.info("Signed agreement deleted successfully: {}", agreementId);
                return true;
            } else {
                logger.warn("Signed agreement not found for deletion: {}", agreementId);
                return false;
            }
        } catch (Exception e) {
            logger.error("Error deleting signed agreement", e);
            return false;
        }
    }

    /**
     * Generate document hash for integrity verification
     */
    private String generateDocumentHash(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            logger.error("Error generating document hash", e);
            throw new RuntimeException("Failed to generate document hash");
        }
    }

    /**
     * Generate signature hash for integrity verification
     */
    private String generateSignatureHash(String signatureImageBase64) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(signatureImageBase64.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            logger.error("Error generating signature hash", e);
            throw new RuntimeException("Failed to generate signature hash");
        }
    }

    /**
     * Get statistics for signed agreements
     */
    public long getTotalSignedAgreements() {
        return signedAgreementRepository.countByStatus("SIGNED") +
                signedAgreementRepository.countByStatus("COMPLETED");
    }

    public long getDraftAgreements() {
        return signedAgreementRepository.countByStatus("DRAFT");
    }

    public long getUserAgreementCount(String userId) {
        return signedAgreementRepository.countBySignerId(userId);
    }

    /**
     * Create multi-party agreement
     */
    public SignedAgreement createMultiPartyAgreement(String agreementTitle, String agreementContent,
            String agreementType, String partyA, String partyB, String terms, String initiatorId,
            List<String> requiredSigners, String signingInstructions, Integer expirationDays) {
        logger.info("Creating multi-party agreement: {} by user: {}", agreementTitle, initiatorId);

        try {
            SignedAgreement agreement = new SignedAgreement();
            agreement.setAgreementTitle(agreementTitle);
            agreement.setAgreementContent(agreementContent);
            agreement.setAgreementType(agreementType);
            agreement.setPartyA(partyA);
            agreement.setPartyB(partyB);
            agreement.setTerms(terms);
            agreement.setInitiatorId(initiatorId);
            agreement.setRequiredSigners(requiredSigners != null ? requiredSigners : new ArrayList<>());
            agreement.setSigningInstructions(signingInstructions);
            agreement.setExpiresAt(LocalDateTime.now().plusDays(expirationDays != null ? expirationDays : 30));
            agreement.setWorkflowStatus("DRAFT");
            agreement.setStatus("DRAFT");

            SignedAgreement savedAgreement = signedAgreementRepository.save(agreement);
            logger.info("Multi-party agreement created successfully with ID: {}", savedAgreement.getId());
            return savedAgreement;

        } catch (Exception e) {
            logger.error("Error creating multi-party agreement", e);
            throw new RuntimeException("Failed to create multi-party agreement: " + e.getMessage());
        }
    }

    /**
     * Add signature to multi-party agreement
     */
    public SignedAgreement addSignatureToMultiPartyAgreement(String agreementId, SignatureData signature) {
        logger.info("Adding signature to multi-party agreement: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signedAgreementRepository.findById(agreementId);
            if (agreementOpt.isEmpty()) {
                throw new RuntimeException("Agreement not found: " + agreementId);
            }

            SignedAgreement agreement = agreementOpt.get();
            agreement.addSignature(signature);

            SignedAgreement savedAgreement = signedAgreementRepository.save(agreement);
            logger.info("Signature added successfully to agreement: {}", agreementId);
            return savedAgreement;

        } catch (Exception e) {
            logger.error("Error adding signature to multi-party agreement", e);
            throw new RuntimeException("Failed to add signature: " + e.getMessage());
        }
    }

    /**
     * Send signing invitations
     */
    public void sendSigningInvitations(String agreementId, List<String> signerEmails, String customMessage) {
        logger.info("Sending signing invitations for agreement: {} to {} signers", agreementId, signerEmails.size());

        try {
            // TODO: Implement email service integration
            // For now, just log the invitation details
            for (String email : signerEmails) {
                logger.info("Sending invitation to {} for agreement: {} with message: {}",
                        email, agreementId, customMessage);
            }

            logger.info("Signing invitations sent successfully for agreement: {}", agreementId);

        } catch (Exception e) {
            logger.error("Error sending signing invitations", e);
            throw new RuntimeException("Failed to send invitations: " + e.getMessage());
        }
    }
}
