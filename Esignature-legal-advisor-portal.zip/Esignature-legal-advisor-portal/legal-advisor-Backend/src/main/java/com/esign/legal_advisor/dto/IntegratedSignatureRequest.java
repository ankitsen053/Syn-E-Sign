package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Email;

/**
 * Request DTO for signing documents with integrated e-signature
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IntegratedSignatureRequest {

    @NotBlank(message = "Document ID is required")
    private String documentId;

    @NotBlank(message = "Signature image is required")
    private String signatureImageBase64;

    private String signatureData; // Additional signature metadata

    @NotBlank(message = "Signer name is required")
    private String signerName;

    @Email(message = "Valid email is required")
    @NotBlank(message = "Signer email is required")
    private String signerEmail;

    private String signerIpAddress;

    // Signature options
    private boolean generatePdf = true;
    private boolean includeTimestamp = true;
    private boolean verifySignature = true;

    // Additional authentication
    private String authenticationMethod; // OTP, BIOMETRIC, PASSWORD
    private String authenticationToken;

    // Consent and declarations
    private boolean consentGiven;
    private String consentText;
    private String signerRole; // PARTY_A, PARTY_B, WITNESS

    // Location data (optional)
    private Double latitude;
    private Double longitude;
    private String locationAddress;
}
