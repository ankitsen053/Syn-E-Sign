package com.esign.legal_advisor.service;

import org.apache.poi.xwpf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class DocxService {

    private static final Logger logger = LoggerFactory.getLogger(DocxService.class);
    
    // Constants for better document formatting
    private static final int TITLE_FONT_SIZE = 18;
    private static final int HEADER_FONT_SIZE = 14;
    private static final int BODY_FONT_SIZE = 11;
    private static final int SMALL_FONT_SIZE = 10;
    private static final String FONT_FAMILY = "Arial";
    private static final String GRAY_COLOR = "666666";

    /**
     * Generate DOCX document from agreement content with optimized processing
     */
    public byte[] generateDocx(String agreementType, String party1, String party2, String content) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting DOCX generation for agreement: {} between {} and {}", agreementType, party1, party2);
        
        try (XWPFDocument document = new XWPFDocument()) {
            
            // Configure document properties for better compatibility
            document.getProperties().getCoreProperties().setTitle(agreementType + " Agreement");
            document.getProperties().getCoreProperties().setCreator("Legal Advisor System");

            // Add title with enhanced formatting
            addTitle(document, agreementType);
            
            // Add parties information
            addParties(document, party1, party2);
            
            // Add date
            addDate(document);
            
            // Add spacing
            document.createParagraph();
            
            // Process content with optimized parsing
            processContent(document, content);
            
            // Add signature section
            addSignatureSection(document);
            
            // Generate byte array with optimized buffer
            byte[] result = generateByteArray(document);
            
            long endTime = System.currentTimeMillis();
            logger.info("DOCX generation completed successfully in {}ms, size: {} bytes", 
                (endTime - startTime), result.length);
            
            return result;

        } catch (IOException e) {
            logger.error("Error generating DOCX document", e);
            throw new RuntimeException("Failed to generate DOCX document: " + e.getMessage(), e);
        } catch (Exception e) {
            logger.error("Unexpected error during DOCX generation", e);
            throw new RuntimeException("Unexpected error during DOCX generation: " + e.getMessage(), e);
        }
    }

    /**
     * Add title with enhanced formatting
     */
    private void addTitle(XWPFDocument document, String agreementType) {
        XWPFParagraph title = document.createParagraph();
        title.setAlignment(ParagraphAlignment.CENTER);
        title.setSpacingBefore(400);
        title.setSpacingAfter(400);
        
        XWPFRun titleRun = title.createRun();
        titleRun.setText(agreementType + " Agreement");
        titleRun.setBold(true);
        titleRun.setFontSize(TITLE_FONT_SIZE);
        titleRun.setFontFamily(FONT_FAMILY);
        titleRun.setColor("000000");
    }

    /**
     * Add parties information
     */
    private void addParties(XWPFDocument document, String party1, String party2) {
        XWPFParagraph parties = document.createParagraph();
        parties.setAlignment(ParagraphAlignment.CENTER);
        parties.setSpacingAfter(300);
        
        XWPFRun partiesRun = parties.createRun();
        partiesRun.setText("Between " + party1 + " and " + party2);
        partiesRun.setFontSize(BODY_FONT_SIZE);
        partiesRun.setFontFamily(FONT_FAMILY);
        partiesRun.setColor("333333");
    }

    /**
     * Add date with proper formatting
     */
    private void addDate(XWPFDocument document) {
        XWPFParagraph date = document.createParagraph();
        date.setAlignment(ParagraphAlignment.CENTER);
        date.setSpacingAfter(400);
        
        XWPFRun dateRun = date.createRun();
        dateRun.setText("Date: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")));
        dateRun.setFontSize(SMALL_FONT_SIZE);
        dateRun.setFontFamily(FONT_FAMILY);
        dateRun.setColor(GRAY_COLOR);
    }

    /**
     * Process content with optimized parsing and formatting
     */
    private void processContent(XWPFDocument document, String content) {
        if (content == null || content.trim().isEmpty()) {
            logger.warn("Empty content provided for DOCX generation");
            addEmptyContentMessage(document);
            return;
        }

        // Split content into sections for better processing
        String[] sections = content.split("\n\n");
        logger.debug("Processing {} content sections", sections.length);
        
        for (int i = 0; i < sections.length; i++) {
            String section = sections[i].trim();
            if (section.isEmpty()) {
                continue;
            }
            
            try {
                processSection(document, section, i);
            } catch (Exception e) {
                logger.warn("Error processing section {}: {}", i, e.getMessage());
                // Add fallback content for problematic sections
                addFallbackSection(document, section);
            }
        }
    }

    /**
     * Process individual content section
     */
    private void processSection(XWPFDocument document, String section, int sectionIndex) {
        XWPFParagraph paragraph = document.createParagraph();
        XWPFRun run = paragraph.createRun();

        if (section.startsWith("**") && section.endsWith("**")) {
            // Bold headers
            String headerText = section.replace("**", "").trim();
            run.setText(headerText);
            run.setBold(true);
            run.setFontSize(HEADER_FONT_SIZE);
            run.setFontFamily(FONT_FAMILY);
            run.setColor("000000");
            paragraph.setSpacingBefore(400);
            paragraph.setSpacingAfter(200);
            
        } else if (section.startsWith("- ")) {
            // Bullet points
            run.setText("• " + section.substring(2));
            run.setFontSize(BODY_FONT_SIZE);
            run.setFontFamily(FONT_FAMILY);
            paragraph.setSpacingAfter(100);
            
        } else if (section.matches("^\\d+\\..*")) {
            // Numbered lists
            run.setText(section);
            run.setFontSize(BODY_FONT_SIZE);
            run.setFontFamily(FONT_FAMILY);
            paragraph.setSpacingAfter(100);
            
        } else if (section.startsWith("#")) {
            // Markdown-style headers
            String headerText = section.replaceAll("^#+\\s*", "").trim();
            run.setText(headerText);
            run.setBold(true);
            run.setFontSize(HEADER_FONT_SIZE);
            run.setFontFamily(FONT_FAMILY);
            run.setColor("000000");
            paragraph.setSpacingBefore(300);
            paragraph.setSpacingAfter(200);
            
        } else {
            // Regular text
            run.setText(section);
            run.setFontSize(BODY_FONT_SIZE);
            run.setFontFamily(FONT_FAMILY);
            paragraph.setSpacingAfter(150);
        }
    }

    /**
     * Add fallback content for problematic sections
     */
    private void addFallbackSection(XWPFDocument document, String section) {
        XWPFParagraph paragraph = document.createParagraph();
        XWPFRun run = paragraph.createRun();
        
        // Truncate very long sections to prevent issues
        String safeText = section.length() > 1000 ? section.substring(0, 1000) + "..." : section;
        run.setText(safeText);
        run.setFontSize(BODY_FONT_SIZE);
        run.setFontFamily(FONT_FAMILY);
        run.setColor("666666");
        paragraph.setSpacingAfter(150);
    }

    /**
     * Add empty content message
     */
    private void addEmptyContentMessage(XWPFDocument document) {
        XWPFParagraph paragraph = document.createParagraph();
        paragraph.setAlignment(ParagraphAlignment.CENTER);
        
        XWPFRun run = paragraph.createRun();
        run.setText("No content available for this document.");
        run.setFontSize(BODY_FONT_SIZE);
        run.setFontFamily(FONT_FAMILY);
        run.setColor(GRAY_COLOR);
        run.setItalic(true);
    }

    /**
     * Add signature section with proper formatting
     */
    private void addSignatureSection(XWPFDocument document) {
        // Add spacing before signature
        document.createParagraph();
        
        // Signature line
        XWPFParagraph signature = document.createParagraph();
        signature.setAlignment(ParagraphAlignment.CENTER);
        signature.setSpacingBefore(400);
        
        XWPFRun signatureRun = signature.createRun();
        signatureRun.setText("_________________________");
        signatureRun.setFontSize(BODY_FONT_SIZE);
        signatureRun.setFontFamily(FONT_FAMILY);
        signatureRun.setColor("000000");
        
        // Signature label
        XWPFParagraph signatureLabel = document.createParagraph();
        signatureLabel.setAlignment(ParagraphAlignment.CENTER);
        signatureLabel.setSpacingAfter(200);
        
        XWPFRun signatureLabelRun = signatureLabel.createRun();
        signatureLabelRun.setText("Signature");
        signatureLabelRun.setFontSize(SMALL_FONT_SIZE);
        signatureLabelRun.setFontFamily(FONT_FAMILY);
        signatureLabelRun.setColor(GRAY_COLOR);
        
        // Add date line
        XWPFParagraph dateLine = document.createParagraph();
        dateLine.setAlignment(ParagraphAlignment.CENTER);
        
        XWPFRun dateLineRun = dateLine.createRun();
        dateLineRun.setText("Date: _________________");
        dateLineRun.setFontSize(SMALL_FONT_SIZE);
        dateLineRun.setFontFamily(FONT_FAMILY);
        dateLineRun.setColor(GRAY_COLOR);
    }

    /**
     * Generate byte array with optimized buffer
     */
    private byte[] generateByteArray(XWPFDocument document) throws IOException {
        // Use larger buffer for better performance with large documents
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream(8192)) {
            document.write(outputStream);
            outputStream.flush();
            return outputStream.toByteArray();
        }
    }

    /**
     * Generate DOCX with custom content (for testing and debugging)
     */
    public byte[] generateCustomDocx(String title, String content) {
        logger.info("Generating custom DOCX with title: {}", title);
        
        try (XWPFDocument document = new XWPFDocument()) {
            
            // Add custom title
            XWPFParagraph titlePara = document.createParagraph();
            titlePara.setAlignment(ParagraphAlignment.CENTER);
            XWPFRun titleRun = titlePara.createRun();
            titleRun.setText(title);
            titleRun.setBold(true);
            titleRun.setFontSize(TITLE_FONT_SIZE);
            titleRun.setFontFamily(FONT_FAMILY);
            
            // Add content
            if (content != null && !content.trim().isEmpty()) {
                processContent(document, content);
            }
            
            return generateByteArray(document);
            
        } catch (IOException e) {
            logger.error("Error generating custom DOCX", e);
            throw new RuntimeException("Failed to generate custom DOCX: " + e.getMessage(), e);
        }
    }
}
