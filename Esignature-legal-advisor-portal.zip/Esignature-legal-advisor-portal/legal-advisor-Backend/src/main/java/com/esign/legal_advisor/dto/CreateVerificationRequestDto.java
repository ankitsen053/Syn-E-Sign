package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

public class CreateVerificationRequestDto {

    @NotEmpty(message = "At least one document type must be requested")
    private List<String> requestedDocuments; // AADHAAR, PAN, DRIVING_LICENSE, PASSPORT

    @Size(max = 200, message = "Verification purpose cannot exceed 200 characters")
    private String verificationPurpose = "Document verification for legal services";

    @Email(message = "Please provide a valid email address")
    private String customerEmail;

    @Pattern(regexp = "^[+]?[0-9]{10,15}$", message = "Please provide a valid mobile number")
    private String customerMobile;

    @Size(max = 100, message = "Customer name cannot exceed 100 characters")
    private String customerName;

    private boolean consentRequired = true;

    @Pattern(regexp = "^https?://.*", message = "Webhook URL must be a valid HTTP/HTTPS URL")
    private String webhookUrl;

    private int linkExpiryHours = 24; // Default 24 hours

    // Constructors
    public CreateVerificationRequestDto() {}

    public CreateVerificationRequestDto(List<String> requestedDocuments, String customerMobile) {
        this.requestedDocuments = requestedDocuments;
        this.customerMobile = customerMobile;
    }

    // Getters and Setters
    public List<String> getRequestedDocuments() {
        return requestedDocuments;
    }

    public void setRequestedDocuments(List<String> requestedDocuments) {
        this.requestedDocuments = requestedDocuments;
    }

    public String getVerificationPurpose() {
        return verificationPurpose;
    }

    public void setVerificationPurpose(String verificationPurpose) {
        this.verificationPurpose = verificationPurpose;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getCustomerMobile() {
        return customerMobile;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public boolean isConsentRequired() {
        return consentRequired;
    }

    public void setConsentRequired(boolean consentRequired) {
        this.consentRequired = consentRequired;
    }

    public String getWebhookUrl() {
        return webhookUrl;
    }

    public void setWebhookUrl(String webhookUrl) {
        this.webhookUrl = webhookUrl;
    }

    public int getLinkExpiryHours() {
        return linkExpiryHours;
    }

    public void setLinkExpiryHours(int linkExpiryHours) {
        this.linkExpiryHours = linkExpiryHours;
    }

    // Validation methods
    public boolean isValidDocumentType(String documentType) {
        return List.of("AADHAAR", "PAN", "DRIVING_LICENSE", "PASSPORT").contains(documentType.toUpperCase());
    }

    public boolean hasValidDocumentTypes() {
        return requestedDocuments != null && 
               requestedDocuments.stream().allMatch(this::isValidDocumentType);
    }

    @Override
    public String toString() {
        return "CreateVerificationRequestDto{" +
                "requestedDocuments=" + requestedDocuments +
                ", verificationPurpose='" + verificationPurpose + '\'' +
                ", customerEmail='" + customerEmail + '\'' +
                ", customerMobile='" + (customerMobile != null ? customerMobile.replaceAll(".(?=.{4})", "*") : null) + '\'' +
                ", customerName='" + customerName + '\'' +
                ", consentRequired=" + consentRequired +
                ", webhookUrl='" + webhookUrl + '\'' +
                ", linkExpiryHours=" + linkExpiryHours +
                '}';
    }
}
