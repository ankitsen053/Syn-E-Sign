package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Request DTO for searching documents
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentSearchRequest {
    
    private String searchTerm;
    private String documentType;
    private List<String> statuses; // DRAFT, SIGNED, ANALYZED, COMPLETED
    
    // Date filters
    private LocalDateTime createdAfter;
    private LocalDateTime createdBefore;
    private LocalDateTime signedAfter;
    private LocalDateTime signedBefore;
    
    // Parties filter
    private String partyName;
    private boolean includePartyA = true;
    private boolean includePartyB = true;
    
    // Analysis filters
    private boolean onlyAnalyzed;
    private Double minConfidenceScore;
    private boolean onlyVerified;
    
    // Signing filters
    private boolean onlySigned;
    private boolean onlyUnsigned;
    
    // Pagination
    private int page = 0;
    private int size = 20;
    private String sortBy = "createdAt";
    private String sortDirection = "DESC";
}
