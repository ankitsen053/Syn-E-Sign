package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.*;
import org.springframework.web.multipart.MultipartFile;
import java.time.LocalDateTime;

public class DocumentScannerDto {

    @NotBlank(message = "Document content is required")
    @Size(min = 10, max = 50000, message = "Document content must be between 10 and 50,000 characters")
    private String documentContent;

    @NotBlank(message = "Document type is required")
    @Pattern(regexp = "^(CONTRACT|AGREEMENT|NDA|MOU|LEASE|LICENSE|POLICY|OTHER)$", message = "Document type must be one of: CONTRACT, AGREEMENT, NDA, MOU, LEASE, LICENSE, POLICY, OTHER")
    private String documentType;

    @Size(max = 200, message = "Document title must not exceed 200 characters")
    private String documentTitle;

    @Size(max = 1000, message = "Description must not exceed 1000 characters")
    private String description;

    // File upload support
    private MultipartFile documentFile;

    // Analysis preferences
    private boolean includeRiskAnalysis = true;
    private boolean includeComplianceCheck = true;
    private boolean includeClauseAnalysis = true;
    private boolean includeRecommendations = true;

    // Document metadata
    private String language = "en";
    private String jurisdiction = "IN"; // Default to India
    private String industry;
    private String parties;

    // Timestamps
    private LocalDateTime scanTimestamp;
    private LocalDateTime expiryDate;

    // Constructor
    public DocumentScannerDto() {
        this.scanTimestamp = LocalDateTime.now();
    }

    // Getters and Setters
    public String getDocumentContent() {
        return documentContent;
    }

    public void setDocumentContent(String documentContent) {
        this.documentContent = documentContent;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType != null ? documentType.toUpperCase() : null;
    }

    public String getDocumentTitle() {
        return documentTitle;
    }

    public void setDocumentTitle(String documentTitle) {
        this.documentTitle = documentTitle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MultipartFile getDocumentFile() {
        return documentFile;
    }

    public void setDocumentFile(MultipartFile documentFile) {
        this.documentFile = documentFile;
    }

    public boolean isIncludeRiskAnalysis() {
        return includeRiskAnalysis;
    }

    public void setIncludeRiskAnalysis(boolean includeRiskAnalysis) {
        this.includeRiskAnalysis = includeRiskAnalysis;
    }

    public boolean isIncludeComplianceCheck() {
        return includeComplianceCheck;
    }

    public void setIncludeComplianceCheck(boolean includeComplianceCheck) {
        this.includeComplianceCheck = includeComplianceCheck;
    }

    public boolean isIncludeClauseAnalysis() {
        return includeClauseAnalysis;
    }

    public void setIncludeClauseAnalysis(boolean includeClauseAnalysis) {
        this.includeClauseAnalysis = includeClauseAnalysis;
    }

    public boolean isIncludeRecommendations() {
        return includeRecommendations;
    }

    public void setIncludeRecommendations(boolean includeRecommendations) {
        this.includeRecommendations = includeRecommendations;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language != null ? language.toLowerCase() : "en";
    }

    public String getJurisdiction() {
        return jurisdiction;
    }

    public void setJurisdiction(String jurisdiction) {
        this.jurisdiction = jurisdiction != null ? jurisdiction.toUpperCase() : "IN";
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getParties() {
        return parties;
    }

    public void setParties(String parties) {
        this.parties = parties;
    }

    public LocalDateTime getScanTimestamp() {
        return scanTimestamp;
    }

    public void setScanTimestamp(LocalDateTime scanTimestamp) {
        this.scanTimestamp = scanTimestamp;
    }

    public LocalDateTime getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDateTime expiryDate) {
        this.expiryDate = expiryDate;
    }

    // Helper methods
    public boolean hasFile() {
        return documentFile != null && !documentFile.isEmpty();
    }

    public String getFileExtension() {
        if (hasFile()) {
            String fileName = documentFile.getOriginalFilename();
            if (fileName != null && fileName.contains(".")) {
                return fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
            }
        }
        return null;
    }

    public boolean isSupportedFileType() {
        String extension = getFileExtension();
        return extension != null &&
                (extension.equals("pdf") || extension.equals("doc") ||
                        extension.equals("docx") || extension.equals("txt"));
    }

    public long getFileSize() {
        return hasFile() ? documentFile.getSize() : 0;
    }

    public boolean isFileSizeValid() {
        long maxSize = 10 * 1024 * 1024; // 10MB
        return getFileSize() <= maxSize;
    }
}
