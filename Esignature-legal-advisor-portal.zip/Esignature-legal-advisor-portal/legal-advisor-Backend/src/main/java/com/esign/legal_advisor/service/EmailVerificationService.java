package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.EmailVerification;
import com.esign.legal_advisor.repository.EmailVerificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;
import java.util.Random;

@Service
public class EmailVerificationService {
    
    private static final Logger logger = LoggerFactory.getLogger(EmailVerificationService.class);
    
    @Autowired
    private EmailVerificationRepository emailVerificationRepository;
    
    @Autowired
    private EmailService emailService;
    
    public String generateAndSendOtp(String email) {
        try {
            // Generate 6-digit OTP
            String otp = generateOtp();
            
            // Delete any existing verification for this email
            emailVerificationRepository.deleteByEmail(email);
            
            // Create new verification record
            EmailVerification verification = new EmailVerification(email, otp);
            emailVerificationRepository.save(verification);
            
            // Send OTP email
            emailService.sendOtpEmail(email, otp);
            
            logger.info("OTP generated and sent for email: {}", email);
            return otp; // Return OTP for testing purposes (remove in production)
        } catch (Exception e) {
            logger.error("Failed to generate and send OTP for email: {}", email, e);
            throw new RuntimeException("Failed to send OTP: " + e.getMessage());
        }
    }
    
    public boolean verifyOtp(String email, String otp) {
        try {
            Optional<EmailVerification> verificationOpt = emailVerificationRepository.findByEmailAndOtp(email, otp);
            
            if (verificationOpt.isEmpty()) {
                logger.warn("Invalid OTP attempt for email: {}", email);
                return false;
            }
            
            EmailVerification verification = verificationOpt.get();
            
            // Check if OTP is expired
            if (verification.isExpired()) {
                logger.warn("Expired OTP attempt for email: {}", email);
                emailVerificationRepository.delete(verification);
                return false;
            }
            
            // Check if max attempts reached
            if (verification.isMaxAttemptsReached()) {
                logger.warn("Max attempts reached for email: {}", email);
                emailVerificationRepository.delete(verification);
                return false;
            }
            
            // Increment attempts
            verification.incrementAttempts();
            
            if (verification.getOtp().equals(otp)) {
                // OTP is correct
                verification.setVerified(true);
                emailVerificationRepository.save(verification);
                logger.info("OTP verified successfully for email: {}", email);
                return true;
            } else {
                // OTP is incorrect
                emailVerificationRepository.save(verification);
                logger.warn("Incorrect OTP attempt for email: {}", email);
                return false;
            }
        } catch (Exception e) {
            logger.error("Error verifying OTP for email: {}", email, e);
            return false;
        }
    }
    
    public boolean isEmailVerified(String email) {
        try {
            Optional<EmailVerification> verificationOpt = emailVerificationRepository.findByEmail(email);
            return verificationOpt.isPresent() && verificationOpt.get().isVerified();
        } catch (Exception e) {
            logger.error("Error checking email verification status for: {}", email, e);
            return false;
        }
    }
    
    public void markEmailAsVerified(String email) {
        try {
            Optional<EmailVerification> verificationOpt = emailVerificationRepository.findByEmail(email);
            if (verificationOpt.isPresent()) {
                EmailVerification verification = verificationOpt.get();
                verification.setVerified(true);
                emailVerificationRepository.save(verification);
                logger.info("Email marked as verified: {}", email);
            }
        } catch (Exception e) {
            logger.error("Error marking email as verified: {}", email, e);
        }
    }
    
    public void resendOtp(String email) {
        try {
            // Delete existing verification
            emailVerificationRepository.deleteByEmail(email);
            
            // Generate and send new OTP
            generateAndSendOtp(email);
            logger.info("OTP resent for email: {}", email);
        } catch (Exception e) {
            logger.error("Failed to resend OTP for email: {}", email, e);
            throw new RuntimeException("Failed to resend OTP: " + e.getMessage());
        }
    }
    
    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000); // Generate 6-digit number
        return String.valueOf(otp);
    }

    public String generateOtpManually(String email) {
        try {
            // Generate 6-digit OTP
            String otp = generateOtp();
            
            // Delete any existing verification for this email
            emailVerificationRepository.deleteByEmail(email);
            
            // Create new verification record
            EmailVerification verification = new EmailVerification(email, otp);
            emailVerificationRepository.save(verification);
            
            logger.info("OTP generated manually for email: {} - OTP: {}", email, otp);
            return otp;
        } catch (Exception e) {
            logger.error("Failed to generate OTP manually for email: {}", email, e);
            throw new RuntimeException("Failed to generate OTP: " + e.getMessage());
        }
    }
    
    public void cleanupExpiredVerifications() {
        try {
            // This method can be called periodically to clean up expired verifications
            // For now, we'll handle cleanup during verification attempts
            logger.info("Cleanup of expired verifications completed");
        } catch (Exception e) {
            logger.error("Error during cleanup of expired verifications", e);
        }
    }
}
