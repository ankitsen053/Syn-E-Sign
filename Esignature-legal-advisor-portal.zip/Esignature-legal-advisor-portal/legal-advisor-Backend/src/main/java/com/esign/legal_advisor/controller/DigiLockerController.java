package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.DigiLockerVerificationDto;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.service.VerificationService;
import com.esign.legal_advisor.service.DigiLockerService;
import com.esign.legal_advisor.service.DigiLockerService.DigiLockerVerificationResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.validation.Valid;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/digilocker")
@CrossOrigin(origins = "*", maxAge = 3600)
public class DigiLockerController {

    private static final Logger logger = LoggerFactory.getLogger(DigiLockerController.class);

    @Autowired
    private VerificationService verificationService;

    @Autowired
    private DigiLockerService digiLockerService;

    /**
     * Submit DigiLocker verification with DigiLocker ID
     */
    @PostMapping("/verify")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> verifyDigiLocker(@Valid @RequestBody DigiLockerVerificationDto request, 
                                              BindingResult bindingResult,
                                              Authentication authentication) {
        try {
            // Handle validation errors
            if (bindingResult.hasErrors()) {
                String errorMessages = bindingResult.getAllErrors().stream()
                        .map(error -> error.getDefaultMessage())
                        .collect(Collectors.joining("; "));
                logger.warn("Validation failed for DigiLocker verification: {}", errorMessages);
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Validation failed: " + errorMessages));
            }

            String userId = authentication.getName();
            logger.info("DigiLocker verification request from user: {} with DigiLocker ID: {}", 
                       userId, request.getMaskedDigiLockerId());

            MessageResponse response = verificationService.submitDigiLockerVerification(userId, request);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error processing DigiLocker verification", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to process DigiLocker verification. " + e.getMessage()));
        }
    }

    /**
     * Get DigiLocker verification status for the current user
     */
    @GetMapping("/status")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getDigiLockerStatus(Authentication authentication) {
        try {
            String userId = authentication.getName();
            Map<String, Object> status = verificationService.getComprehensiveVerificationStatus(userId);
            
            if (status.containsKey("digiLockerVerification")) {
                return ResponseEntity.ok(status.get("digiLockerVerification"));
            } else {
                return ResponseEntity.ok(Map.of(
                    "verified", false,
                    "status", "PENDING",
                    "message", "DigiLocker verification not started"
                ));
            }
            
        } catch (Exception e) {
            logger.error("Error fetching DigiLocker status", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to fetch DigiLocker status. " + e.getMessage()));
        }
    }

    /**
     * Fetch specific document details from DigiLocker
     */
    @GetMapping("/document/{documentType}")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getDocumentDetails(@PathVariable String documentType, 
                                               Authentication authentication) {
        try {
            String userId = authentication.getName();
            logger.info("Fetching DigiLocker document details for user: {} and document type: {}", 
                       userId, documentType);

            Map<String, Object> result = verificationService.fetchDigiLockerDocumentDetails(userId, documentType);
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            logger.error("Error fetching document details", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to fetch document details. " + e.getMessage()));
        }
    }

    /**
     * Test DigiLocker connection and API
     */
    @GetMapping("/test/{digiLockerId}")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> testDigiLockerConnection(@PathVariable String digiLockerId,
                                                     Authentication authentication) {
        try {
            logger.info("Testing DigiLocker connection for user: {} with DigiLocker ID: {}", 
                       authentication.getName(), digiLockerId.substring(0, 8) + "****");

            DigiLockerVerificationResult result = digiLockerService.verifyDigiLockerId(digiLockerId);
            
            Map<String, Object> response = Map.of(
                "success", result.isSuccess(),
                "documentsFound", result.getTotalDocuments(),
                "aadhaarAvailable", result.getAadhaarDocument() != null,
                "panAvailable", result.getPanDocument() != null,
                "drivingLicenseAvailable", result.getDrivingLicenseDocument() != null,
                "passportAvailable", result.getPassportDocument() != null,
                "message", result.isSuccess() ? "DigiLocker connection successful" : result.getErrorMessage()
            );
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error testing DigiLocker connection", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to test DigiLocker connection. " + e.getMessage()));
        }
    }

    /**
     * Get all available documents from DigiLocker without saving
     */
    @PostMapping("/preview")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> previewDigiLockerDocuments(@Valid @RequestBody DigiLockerVerificationDto request,
                                                        BindingResult bindingResult,
                                                        Authentication authentication) {
        try {
            // Handle validation errors
            if (bindingResult.hasErrors()) {
                String errorMessages = bindingResult.getAllErrors().stream()
                        .map(error -> error.getDefaultMessage())
                        .collect(Collectors.joining("; "));
                logger.warn("Validation failed for DigiLocker preview: {}", errorMessages);
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Validation failed: " + errorMessages));
            }

            String userId = authentication.getName();
            logger.info("Preview DigiLocker documents for user: {} with DigiLocker ID: {}", 
                       userId, request.getMaskedDigiLockerId());

            DigiLockerVerificationResult result = digiLockerService.verifyDigiLockerId(request.getDigiLockerId());
            
            if (result.isSuccess()) {
                Map<String, Object> response = Map.of(
                    "success", true,
                    "totalDocuments", result.getTotalDocuments(),
                    "documents", result.getDocuments(),
                    "aadhaarDocument", result.getAadhaarDocument(),
                    "panDocument", result.getPanDocument(),
                    "drivingLicenseDocument", result.getDrivingLicenseDocument(),
                    "passportDocument", result.getPassportDocument(),
                    "verificationTime", result.getVerificationTime()
                );
                
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("DigiLocker preview failed: " + result.getErrorMessage()));
            }
            
        } catch (Exception e) {
            logger.error("Error previewing DigiLocker documents", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to preview DigiLocker documents. " + e.getMessage()));
        }
    }

    /**
     * Validate DigiLocker ID format
     */
    @PostMapping("/validate-id")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> validateDigiLockerId(@RequestBody Map<String, String> request) {
        try {
            String digiLockerId = request.get("digiLockerId");
            
            if (digiLockerId == null || digiLockerId.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("valid", false, "message", "DigiLocker ID is required"));
            }
            
            boolean valid = digiLockerId.length() == 36 && 
                           digiLockerId.matches("^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$");
            
            Map<String, Object> response = Map.of(
                "valid", valid,
                "message", valid ? "Valid DigiLocker ID format" : "Invalid DigiLocker ID format. Expected: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
                "length", digiLockerId.length()
            );
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error validating DigiLocker ID", e);
            return ResponseEntity.badRequest()
                    .body(Map.of("valid", false, "message", "Error validating DigiLocker ID"));
        }
    }

    /**
     * Health check for DigiLocker service
     */
    @GetMapping("/health")
    public ResponseEntity<?> healthCheck() {
        try {
            Map<String, Object> health = Map.of(
                "service", "DigiLocker Integration",
                "status", "UP",
                "timestamp", java.time.LocalDateTime.now(),
                "supportedDocuments", java.util.Arrays.asList("AADHAAR", "PAN", "DRIVING_LICENSE", "PASSPORT"),
                "features", java.util.Arrays.asList(
                    "Document verification",
                    "Auto-verification",
                    "Real-time document fetching",
                    "Mock data for development"
                )
            );
            
            return ResponseEntity.ok(health);
            
        } catch (Exception e) {
            logger.error("Error in DigiLocker health check", e);
            return ResponseEntity.badRequest()
                    .body(Map.of("service", "DigiLocker Integration", "status", "DOWN", "error", e.getMessage()));
        }
    }
}
