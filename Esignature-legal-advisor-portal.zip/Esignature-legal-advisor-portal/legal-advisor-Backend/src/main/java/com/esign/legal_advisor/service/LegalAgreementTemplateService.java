package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.EnhancedAgreementRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Service that provides comprehensive legal agreement templates
 * with proper terms and conditions, working like a lawyer would
 */
@Service
@Slf4j
public class LegalAgreementTemplateService {

    private static final int MAX_AGREEMENT_LENGTH = 5000; // AI content limit
    private static final int MAX_TERMS_LENGTH = 2000; // Terms limit

    /**
     * Generate comprehensive legal agreement with proper structure
     */
    public String generateComprehensiveAgreement(String type, String partyA, String partyB, String terms,
            String additionalDetails) {
        log.info("Generating comprehensive legal agreement for type: {}", type);

        // Validate input lengths to respect AI limitations
        validateInputLengths(partyA, partyB, terms, additionalDetails);

        StringBuilder agreement = new StringBuilder();

        // Header
        agreement.append(generateHeader(type, partyA, partyB));

        // Recitals
        agreement.append(generateRecitals(type, partyA, partyB, terms));

        // Main agreement body
        agreement.append(generateAgreementBody(type, partyA, partyB, terms));

        // Standard legal clauses
        agreement.append(generateStandardClauses());

        // Terms and conditions
        agreement.append(generateTermsAndConditions(terms, additionalDetails));

        // Signature section
        agreement.append(generateSignatureSection(partyA, partyB));

        // Footer
        agreement.append(generateFooter());

        String finalAgreement = agreement.toString();

        // Ensure we don't exceed AI content limits
        if (finalAgreement.length() > MAX_AGREEMENT_LENGTH) {
            log.warn("Agreement length ({}) exceeds limit ({}), truncating", finalAgreement.length(),
                    MAX_AGREEMENT_LENGTH);
            finalAgreement = finalAgreement.substring(0, MAX_AGREEMENT_LENGTH - 100)
                    + "\n\n[Content truncated due to length limitations]";
        }

        return finalAgreement;
    }

    /**
     * Generate enhanced legal agreement with detailed specifications
     */
    public String generateEnhancedAgreement(EnhancedAgreementRequest request) {
        log.info("Generating enhanced legal agreement for type: {}", request.getType());

        // Validate request
        if (!request.isValidForGeneration()) {
            throw new IllegalArgumentException("Invalid request: missing required fields");
        }

        if (!request.isWithinContentLimits()) {
            throw new IllegalArgumentException("Request content exceeds maximum allowed length");
        }

        StringBuilder agreement = new StringBuilder();

        // Enhanced header with jurisdiction
        agreement.append(generateEnhancedHeader(request));

        // Enhanced recitals
        agreement.append(generateEnhancedRecitals(request));

        // Enhanced agreement body
        agreement.append(generateEnhancedAgreementBody(request));

        // Enhanced legal clauses
        agreement.append(generateEnhancedLegalClauses(request));

        // Enhanced terms and conditions
        agreement.append(generateEnhancedTermsAndConditions(request));

        // Additional legal sections
        agreement.append(generateAdditionalLegalSections(request));

        // Compliance and risk sections
        if (request.isIncludeComplianceChecklist()) {
            agreement.append(generateComplianceSection(request));
        }

        if (request.isIncludeRiskAssessment()) {
            agreement.append(generateRiskAssessmentSection(request));
        }

        // Signature section
        agreement.append(generateEnhancedSignatureSection(request));

        // Footer
        agreement.append(generateEnhancedFooter(request));

        String finalAgreement = agreement.toString();

        // Ensure we don't exceed enhanced content limits
        if (finalAgreement.length() > MAX_AGREEMENT_LENGTH * 2) { // Allow more content for enhanced agreements
            log.warn("Enhanced agreement length ({}) exceeds limit, truncating", finalAgreement.length());
            finalAgreement = finalAgreement.substring(0, MAX_AGREEMENT_LENGTH * 2 - 100)
                    + "\n\n[Content truncated due to length limitations]";
        }

        return finalAgreement;
    }

    /**
     * Generate agreement header
     */
    private String generateHeader(String type, String partyA, String partyB) {
        return String.format(
                """
                        %s AGREEMENT

                        This %s Agreement (the "Agreement") is made and entered into on %s (the "Effective Date") by and between:

                        %s, hereinafter referred to as "Party A" or "the First Party"
                        AND
                        %s, hereinafter referred to as "Party B" or "the Second Party"

                        (collectively referred to as "Parties" and individually as "Party")

                        """,
                type.toUpperCase(),
                type,
                LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")),
                partyA != null ? partyA : "_________________",
                partyB != null ? partyB : "_________________");
    }

    /**
     * Generate recitals section
     */
    private String generateRecitals(String type, String partyA, String partyB, String terms) {
        return String.format(
                """
                        RECITALS

                        WHEREAS, the Parties desire to enter into a %s relationship;

                        WHEREAS, Party A and Party B wish to establish the terms and conditions governing their %s;

                        WHEREAS, the Parties have agreed to the following terms and conditions;

                        NOW, THEREFORE, in consideration of the mutual promises and covenants contained herein, the Parties agree as follows:

                        """,
                type, type);
    }

    /**
     * Generate main agreement body
     */
    private String generateAgreementBody(String type, String partyA, String partyB, String terms) {
        return String.format(
                """
                        ARTICLE I - PURPOSE AND SCOPE

                        1.1 Purpose. This Agreement establishes the terms and conditions for the %s between the Parties.

                        1.2 Scope. The scope of this Agreement includes all activities, services, and obligations related to the %s.

                        ARTICLE II - OBLIGATIONS OF PARTIES

                        2.1 Party A Obligations. Party A shall:
                           (a) Comply with all applicable laws and regulations;
                           (b) Perform all obligations in good faith and with due diligence;
                           (c) Maintain appropriate insurance coverage as required;
                           (d) Provide timely communication and updates as necessary.

                        2.2 Party B Obligations. Party B shall:
                           (a) Comply with all applicable laws and regulations;
                           (b) Perform all obligations in good faith and with due diligence;
                           (c) Maintain appropriate insurance coverage as required;
                           (d) Provide timely communication and updates as necessary.

                        """,
                type, type);
    }

    /**
     * Generate standard legal clauses
     */
    private String generateStandardClauses() {
        return """
                ARTICLE III - STANDARD LEGAL CLAUSES

                3.1 Governing Law. This Agreement shall be governed by and construed in accordance with the laws of the jurisdiction where this Agreement is executed.

                3.2 Dispute Resolution. Any disputes arising under this Agreement shall be resolved through:
                   (a) Good faith negotiations between the Parties;
                   (b) Mediation with a neutral third party;
                   (c) Binding arbitration if mediation fails;
                   (d) Legal proceedings as a last resort.

                3.3 Force Majeure. Neither Party shall be liable for any failure or delay in performance due to circumstances beyond their reasonable control.

                3.4 Severability. If any provision of this Agreement is held to be invalid or unenforceable, the remaining provisions shall continue in full force and effect.

                3.5 Entire Agreement. This Agreement constitutes the entire understanding between the Parties and supersedes all prior agreements, representations, or understandings.

                3.6 Amendments. This Agreement may only be amended in writing and signed by both Parties.

                3.7 Assignment. Neither Party may assign this Agreement without the prior written consent of the other Party.

                """;
    }

    /**
     * Generate terms and conditions section
     */
    private String generateTermsAndConditions(String terms, String additionalDetails) {
        StringBuilder termsSection = new StringBuilder();
        termsSection.append("ARTICLE IV - TERMS AND CONDITIONS\n\n");

        if (terms != null && !terms.trim().isEmpty()) {
            // Truncate terms if they exceed the limit
            String processedTerms = terms.length() > MAX_TERMS_LENGTH
                    ? terms.substring(0, MAX_TERMS_LENGTH - 100) + " [Terms truncated due to length limitations]"
                    : terms;

            termsSection.append("4.1 Specific Terms. The following specific terms apply to this Agreement:\n\n");
            termsSection.append(processedTerms).append("\n\n");
        }

        if (additionalDetails != null && !additionalDetails.trim().isEmpty()) {
            termsSection.append("4.2 Additional Details. Additional details and specifications:\n\n");
            termsSection.append(additionalDetails).append("\n\n");
        }

        termsSection.append("""
                4.3 Compliance Requirements. Both Parties shall comply with:
                   (a) All applicable federal, state, and local laws and regulations;
                   (b) Industry standards and best practices;
                   (c) Any specific requirements outlined in this Agreement.

                4.4 Performance Standards. All services and obligations shall be performed:
                   (a) In a professional and workmanlike manner;
                   (b) In accordance with generally accepted industry standards;
                   (c) Within the timeframes specified in this Agreement.

                """);

        return termsSection.toString();
    }

    /**
     * Generate signature section
     */
    private String generateSignatureSection(String partyA, String partyB) {
        return String.format("""
                ARTICLE V - SIGNATURES AND EFFECTIVE DATE

                IN WITNESS WHEREOF, the Parties have executed this Agreement as of the Effective Date.

                PARTY A: %s

                By: _________________________
                Name: _______________________
                Title: ______________________
                Date: _______________________

                PARTY B: %s

                By: _________________________
                Name: _______________________
                Title: ______________________
                Date: _______________________

                """,
                partyA != null ? partyA : "_________________",
                partyB != null ? partyB : "_________________");
    }

    /**
     * Generate footer
     */
    private String generateFooter() {
        return """
                FOOTER

                This Agreement has been prepared for legal purposes and should be reviewed by qualified legal counsel before execution.

                Document generated on: """
                + LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")) + """

                        --- END OF AGREEMENT ---
                        """;
    }

    /**
     * Validate input lengths to respect AI limitations
     */
    private void validateInputLengths(String partyA, String partyB, String terms, String additionalDetails) {
        int totalLength = 0;
        totalLength += partyA != null ? partyA.length() : 0;
        totalLength += partyB != null ? partyB.length() : 0;
        totalLength += terms != null ? terms.length() : 0;
        totalLength += additionalDetails != null ? additionalDetails.length() : 0;

        if (totalLength > MAX_AGREEMENT_LENGTH) {
            log.warn("Total input length ({}) exceeds maximum allowed length ({}), content may be truncated",
                    totalLength, MAX_AGREEMENT_LENGTH);
        }
    }

        /**
     * Get agreement statistics
     */
    public Map<String, Object> getAgreementStatistics(String agreement) {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalLength", agreement.length());
        stats.put("wordCount", agreement.split("\\s+").length);
        stats.put("paragraphCount", agreement.split("\\n\\n").length);
        stats.put("withinLimits", agreement.length() <= MAX_AGREEMENT_LENGTH);
        stats.put("maxLength", MAX_AGREEMENT_LENGTH);
        stats.put("remainingCapacity", MAX_AGREEMENT_LENGTH - agreement.length());
        
        return stats;
    }
    
    // Enhanced agreement generation methods
    
    private String generateEnhancedHeader(EnhancedAgreementRequest request) {
        return String.format("""
            %s AGREEMENT
            
            This %s Agreement (the "Agreement") is made and entered into on %s (the "Effective Date") by and between:
            
            %s, hereinafter referred to as "Party A" or "the First Party"
            AND
            %s, hereinafter referred to as "Party B" or "the Second Party"
            
            (collectively referred to as "Parties" and individually as "Party")
            
            %s
            
            """, 
            request.getType().toUpperCase(), 
            request.getType(), 
            LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")),
            request.getPartyA(),
            request.getPartyB(),
            request.getJurisdiction() != null ? "JURISDICTION: " + request.getJurisdiction() : ""
        );
    }
    
    private String generateEnhancedRecitals(EnhancedAgreementRequest request) {
        return String.format("""
            RECITALS
            
            WHEREAS, the Parties desire to enter into a %s relationship;
            
            WHEREAS, Party A and Party B wish to establish the terms and conditions governing their %s;
            
            WHEREAS, the Parties have agreed to the following terms and conditions;
            
            %s
            
            NOW, THEREFORE, in consideration of the mutual promises and covenants contained herein, the Parties agree as follows:
            
            """, 
            request.getType(), 
            request.getType(),
            request.getSpecialConditions() != null ? "WHEREAS, " + request.getSpecialConditions() + ";" : ""
        );
    }
    
    private String generateEnhancedAgreementBody(EnhancedAgreementRequest request) {
        return String.format("""
            ARTICLE I - PURPOSE AND SCOPE
            
            1.1 Purpose. This Agreement establishes the terms and conditions for the %s between the Parties.
            
            1.2 Scope. The scope of this Agreement includes all activities, services, and obligations related to the %s.
            
            %s
            
            ARTICLE II - OBLIGATIONS OF PARTIES
            
            2.1 Party A Obligations. Party A shall:
               (a) Comply with all applicable laws and regulations;
               (b) Perform all obligations in good faith and with due diligence;
               (c) Maintain appropriate insurance coverage as required;
               (d) Provide timely communication and updates as necessary;
               %s
            
            2.2 Party B Obligations. Party B shall:
               (a) Comply with all applicable laws and regulations;
               (b) Perform all obligations in good faith and with due diligence;
               (c) Maintain appropriate insurance coverage as required;
               (d) Provide timely communication and updates as necessary;
               %s
            
            """, 
            request.getType(), 
            request.getType(),
            request.getPerformanceMetrics() != null ? "1.3 Performance Metrics. " + request.getPerformanceMetrics() : "",
            request.getPaymentTerms() != null ? "(e) " + request.getPaymentTerms() : "",
            request.getDeliveryTerms() != null ? "(e) " + request.getDeliveryTerms() : ""
        );
    }
    
    private String generateEnhancedLegalClauses(EnhancedAgreementRequest request) {
        StringBuilder clauses = new StringBuilder();
        clauses.append("ARTICLE III - ENHANCED LEGAL CLAUSES\n\n");
        
        if (request.getGoverningLaw() != null) {
            clauses.append("3.1 Governing Law. ").append(request.getGoverningLaw()).append("\n\n");
        } else {
            clauses.append("3.1 Governing Law. This Agreement shall be governed by and construed in accordance with the laws of the jurisdiction where this Agreement is executed.\n\n");
        }
        
        if (request.getDisputeResolution() != null) {
            clauses.append("3.2 Dispute Resolution. ").append(request.getDisputeResolution()).append("\n\n");
        } else {
            clauses.append("3.2 Dispute Resolution. Any disputes arising under this Agreement shall be resolved through good faith negotiations, mediation, and if necessary, binding arbitration.\n\n");
        }
        
        if (request.getTerminationClauses() != null) {
            clauses.append("3.3 Termination. ").append(request.getTerminationClauses()).append("\n\n");
        }
        
        if (request.getLiabilityLimitations() != null) {
            clauses.append("3.4 Liability Limitations. ").append(request.getLiabilityLimitations()).append("\n\n");
        }
        
        if (request.getConfidentialityTerms() != null) {
            clauses.append("3.5 Confidentiality. ").append(request.getConfidentialityTerms()).append("\n\n");
        }
        
        if (request.getIntellectualPropertyTerms() != null) {
            clauses.append("3.6 Intellectual Property. ").append(request.getIntellectualPropertyTerms()).append("\n\n");
        }
        
        if (request.getDataProtectionTerms() != null) {
            clauses.append("3.7 Data Protection. ").append(request.getDataProtectionTerms()).append("\n\n");
        }
        
        if (request.getForceMajeureTerms() != null) {
            clauses.append("3.8 Force Majeure. ").append(request.getForceMajeureTerms()).append("\n\n");
        }
        
        if (request.getAssignmentTerms() != null) {
            clauses.append("3.9 Assignment. ").append(request.getAssignmentTerms()).append("\n\n");
        }
        
        if (request.getAmendmentTerms() != null) {
            clauses.append("3.10 Amendments. ").append(request.getAmendmentTerms()).append("\n\n");
        }
        
        if (request.getSeverabilityTerms() != null) {
            clauses.append("3.11 Severability. ").append(request.getSeverabilityTerms()).append("\n\n");
        }
        
        if (request.getEntireAgreementTerms() != null) {
            clauses.append("3.12 Entire Agreement. ").append(request.getEntireAgreementTerms()).append("\n\n");
        }
        
        return clauses.toString();
    }
    
    private String generateEnhancedTermsAndConditions(EnhancedAgreementRequest request) {
        StringBuilder termsSection = new StringBuilder();
        termsSection.append("ARTICLE IV - ENHANCED TERMS AND CONDITIONS\n\n");
        
        if (request.getTerms() != null && !request.getTerms().trim().isEmpty()) {
            termsSection.append("4.1 Specific Terms. The following specific terms apply to this Agreement:\n\n");
            termsSection.append(request.getTerms()).append("\n\n");
        }
        
        if (request.getAdditionalDetails() != null && !request.getAdditionalDetails().trim().isEmpty()) {
            termsSection.append("4.2 Additional Details. Additional details and specifications:\n\n");
            termsSection.append(request.getAdditionalDetails()).append("\n\n");
        }
        
        if (request.getWarrantyTerms() != null) {
            termsSection.append("4.3 Warranty Terms. ").append(request.getWarrantyTerms()).append("\n\n");
        }
        
        if (request.getInsuranceRequirements() != null) {
            termsSection.append("4.4 Insurance Requirements. ").append(request.getInsuranceRequirements()).append("\n\n");
        }
        
        termsSection.append("""
            4.5 Standard Compliance Requirements. Both Parties shall comply with:
               (a) All applicable federal, state, and local laws and regulations;
               (b) Industry standards and best practices;
               (c) Any specific requirements outlined in this Agreement.
            
            4.6 Performance Standards. All services and obligations shall be performed:
               (a) In a professional and workmanlike manner;
               (b) In accordance with generally accepted industry standards;
               (c) Within the timeframes specified in this Agreement.
            
            """);
        
        return termsSection.toString();
    }
    
    private String generateAdditionalLegalSections(EnhancedAgreementRequest request) {
        StringBuilder sections = new StringBuilder();
        
        if (request.getComplianceRequirements() != null && !request.getComplianceRequirements().isEmpty()) {
            sections.append("ARTICLE V - COMPLIANCE REQUIREMENTS\n\n");
            sections.append("5.1 Regulatory Compliance. The Parties shall comply with the following requirements:\n\n");
            for (int i = 0; i < request.getComplianceRequirements().size(); i++) {
                sections.append(String.format("   (%s) %s\n", (char)('a' + i), request.getComplianceRequirements().get(i)));
            }
            sections.append("\n");
        }
        
        if (request.getRegulatoryStandards() != null && !request.getRegulatoryStandards().isEmpty()) {
            sections.append("5.2 Regulatory Standards. The following standards apply:\n\n");
            request.getRegulatoryStandards().forEach((key, value) -> 
                sections.append(String.format("   - %s: %s\n", key, value)));
            sections.append("\n");
        }
        
        if (request.getIndustryStandards() != null && !request.getIndustryStandards().isEmpty()) {
            sections.append("5.3 Industry Standards. The following industry standards apply:\n\n");
            for (int i = 0; i < request.getIndustryStandards().size(); i++) {
                sections.append(String.format("   (%s) %s\n", (i + 1), request.getIndustryStandards().get(i)));
            }
            sections.append("\n");
        }
        
        return sections.toString();
    }
    
    private String generateComplianceSection(EnhancedAgreementRequest request) {
        return """
            ARTICLE VI - COMPLIANCE CHECKLIST
            
            6.1 Legal Compliance Checklist:
               □ Contract formation requirements met
               □ Essential terms clearly defined
               □ Governing law specified
               □ Dispute resolution procedures established
               □ Termination provisions included
               □ Liability limitations specified
               □ Confidentiality provisions included
               □ Intellectual property terms defined
               □ Data protection requirements addressed
               □ Force majeure provisions included
            
            6.2 Regulatory Compliance:
               □ Industry-specific regulations addressed
               □ Data protection laws compliance
               □ Financial regulations (if applicable)
               □ Employment law compliance (if applicable)
               □ Tax compliance requirements
            
            6.3 Risk Mitigation:
               □ Insurance requirements specified
               □ Indemnification provisions included
               □ Limitation of liability clauses
               □ Force majeure protection
               □ Dispute resolution mechanisms
            
            """;
    }
    
    private String generateRiskAssessmentSection(EnhancedAgreementRequest request) {
        StringBuilder riskSection = new StringBuilder();
        riskSection.append("ARTICLE VII - RISK ASSESSMENT AND MITIGATION\n\n");
        
        if (request.getRiskAssessment() != null) {
            riskSection.append("7.1 Risk Assessment. ").append(request.getRiskAssessment()).append("\n\n");
        }
        
        if (request.getRiskMitigationStrategies() != null && !request.getRiskMitigationStrategies().isEmpty()) {
            riskSection.append("7.2 Risk Mitigation Strategies:\n\n");
            for (int i = 0; i < request.getRiskMitigationStrategies().size(); i++) {
                riskSection.append(String.format("   (%s) %s\n", (i + 1), request.getRiskMitigationStrategies().get(i)));
            }
            riskSection.append("\n");
        }
        
        if (request.getInsuranceCoverage() != null) {
            riskSection.append("7.3 Insurance Coverage. ").append(request.getInsuranceCoverage()).append("\n\n");
        }
        
        return riskSection.toString();
    }
    
    private String generateEnhancedSignatureSection(EnhancedAgreementRequest request) {
        return String.format("""
            ARTICLE VIII - SIGNATURES AND EFFECTIVE DATE
            
            IN WITNESS WHEREOF, the Parties have executed this Agreement as of the Effective Date.
            
            PARTY A: %s
            
            By: _________________________
            Name: _______________________
            Title: ______________________
            Date: _______________________
            
            PARTY B: %s
            
            By: _________________________
            Name: _______________________
            Title: ______________________
            Date: _______________________
            
            """, 
            request.getPartyA(),
            request.getPartyB()
        );
    }
    
    private String generateEnhancedFooter(EnhancedAgreementRequest request) {
        return """
            FOOTER
            
            This Agreement has been prepared for legal purposes and should be reviewed by qualified legal counsel before execution.
            
            Document generated on: """ + LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")) + """
            
            Enhanced Agreement Features:
            - Comprehensive legal structure
            - Detailed terms and conditions
            - Compliance requirements
            - Risk assessment and mitigation
            - Industry-specific provisions
            
            --- END OF ENHANCED AGREEMENT ---
            """;
    }
}
