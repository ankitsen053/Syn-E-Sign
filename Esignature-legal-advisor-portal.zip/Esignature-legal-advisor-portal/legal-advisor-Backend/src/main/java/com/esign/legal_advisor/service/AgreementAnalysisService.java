package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.AgreementAnalysisResponse;
import com.esign.legal_advisor.dto.AgreementUploadRequest;
import com.esign.legal_advisor.entites.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Service for analyzing uploaded legal agreements using AI
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AgreementAnalysisService {

    private final AiService aiService;
    private final DocumentTextExtractionService textExtractionService;

    /**
     * Analyze uploaded agreement document
     */
    public AgreementAnalysisResponse analyzeAgreement(AgreementUploadRequest request, User user) {
        log.info("Starting agreement analysis for user: {} and document: {}", user.getEmail(), request.getTitle());

        try {
            // Extract text from uploaded document
            String documentText = extractDocumentText(request.getDocumentFile());

            // Perform comprehensive analysis
            AgreementAnalysisResponse response = AgreementAnalysisResponse.builder()
                    .analysisId(generateAnalysisId())
                    .documentId(generateDocumentId())
                    .title(request.getTitle())
                    .type(request.getType())
                    .status("IN_PROGRESS")
                    .uploadedAt(LocalDateTime.now())
                    .analysisModel("AI_ENHANCED")
                    .analysisVersion("1.0")
                    .build();

            // Perform analysis based on user preferences
            if (request.isAnalyzeForLegalCompliance()) {
                response.setLegalCompliance(analyzeLegalCompliance(documentText, request));
            }

            if (request.isAnalyzeForRiskAssessment()) {
                response.setRiskAssessment(analyzeRiskAssessment(documentText, request));
            }

            if (request.isAnalyzeForClarityAndStructure()) {
                response.setClarityAndStructure(analyzeClarityAndStructure(documentText));
            }

            if (request.isGenerateSummary()) {
                response.setSummary(generateDocumentSummary(documentText, request));
            }

            if (request.isHighlightIssues()) {
                response.setIssues(identifyIssues(documentText, request));
            }

            if (request.isSuggestImprovements()) {
                response.setImprovements(suggestImprovements(documentText, request));
            }

            // Update status and timestamp
            response.setStatus("COMPLETED");
            response.setAnalyzedAt(LocalDateTime.now());

            log.info("Agreement analysis completed successfully for: {}", request.getTitle());
            return response;

        } catch (Exception e) {
            log.error("Error analyzing agreement: {}", e.getMessage(), e);
            return AgreementAnalysisResponse.builder()
                    .analysisId(generateAnalysisId())
                    .title(request.getTitle())
                    .status("FAILED")
                    .uploadedAt(LocalDateTime.now())
                    .additionalData(Map.of("error", e.getMessage()))
                    .build();
        }
    }

    /**
     * Extract text from uploaded document
     */
    private String extractDocumentText(MultipartFile file) throws IOException {
        log.info("Extracting text from document: {} ({} bytes)", file.getOriginalFilename(), file.getSize());

        String fileExtension = getFileExtension(file.getOriginalFilename());
        String extractedText = "";

        switch (fileExtension.toLowerCase()) {
            case "pdf":
                extractedText = textExtractionService.extractTextFromDocument(file);
                break;
            case "docx":
                // For DOCX, we'll need to implement this or use a different approach
                // For now, extract as document and handle the format
                extractedText = textExtractionService.extractTextFromDocument(file);
                break;
            case "txt":
                extractedText = new String(file.getBytes());
                break;
            case "html":
            case "htm":
                // For HTML, extract as text for now
                extractedText = new String(file.getBytes());
                break;
            default:
                throw new IllegalArgumentException("Unsupported file format: " + fileExtension);
        }

        log.info("Text extraction completed. Extracted {} characters", extractedText.length());
        return extractedText;
    }

    /**
     * Analyze legal compliance
     */
    private AgreementAnalysisResponse.LegalComplianceAnalysis analyzeLegalCompliance(String documentText,
            AgreementUploadRequest request) {
        log.info("Analyzing legal compliance for agreement: {}", request.getTitle());

        try {
            // Use AI service to analyze legal compliance
            String prompt = String.format("""
                    Analyze the following legal agreement for legal compliance:

                    Agreement Type: %s
                    Jurisdiction: %s
                    Governing Law: %s

                    Document Content:
                    %s

                    Please provide:
                    1. Overall compliance status (COMPLIANT/NON_COMPLIANT/PARTIAL)
                    2. Compliance score (0.0 to 1.0)
                    3. List of compliant areas
                    4. List of non-compliant areas
                    5. Specific recommendations for compliance
                    6. Governing law analysis
                    7. Jurisdiction considerations

                    Format the response as structured data.
                    """,
                    request.getType(),
                    request.getJurisdiction() != null ? request.getJurisdiction() : "Not specified",
                    request.getGoverningLaw() != null ? request.getGoverningLaw() : "Not specified",
                    documentText.substring(0, Math.min(documentText.length(), 4000)) // Limit text for AI
            );

            String aiResponse = aiService.analyzeDocument(prompt);

            // Parse AI response and create compliance analysis
            return parseLegalComplianceResponse(aiResponse, request);

        } catch (Exception e) {
            log.error("Error in legal compliance analysis: {}", e.getMessage());
            return createDefaultLegalComplianceAnalysis(request);
        }
    }

    /**
     * Analyze risk assessment
     */
    private AgreementAnalysisResponse.RiskAssessmentAnalysis analyzeRiskAssessment(String documentText,
            AgreementUploadRequest request) {
        log.info("Analyzing risk assessment for agreement: {}", request.getTitle());

        try {
            String prompt = String.format("""
                    Analyze the following legal agreement for risk assessment:

                    Agreement Type: %s
                    Industry: %s
                    Contract Value: %s

                    Document Content:
                    %s

                    Please provide:
                    1. Overall risk level (LOW/MEDIUM/HIGH/CRITICAL)
                    2. Risk score (0.0 to 1.0)
                    3. Identified risk factors with severity and probability
                    4. Risk mitigation strategies
                    5. Insurance recommendations
                    6. Liability assessment

                    Format the response as structured data.
                    """,
                    request.getType(),
                    request.getIndustry() != null ? request.getIndustry() : "Not specified",
                    request.getContractValue() != null ? request.getContractValue() : "Not specified",
                    documentText.substring(0, Math.min(documentText.length(), 4000)));

            String aiResponse = aiService.analyzeDocument(prompt);
            return parseRiskAssessmentResponse(aiResponse, request);

        } catch (Exception e) {
            log.error("Error in risk assessment analysis: {}", e.getMessage());
            return createDefaultRiskAssessmentAnalysis(request);
        }
    }

    /**
     * Analyze clarity and structure
     */
    private AgreementAnalysisResponse.ClarityAndStructureAnalysis analyzeClarityAndStructure(String documentText) {
        log.info("Analyzing clarity and structure of agreement");

        try {
            String prompt = String.format("""
                    Analyze the following legal agreement for clarity and structure:

                    Document Content:
                    %s

                    Please provide:
                    1. Clarity score (0.0 to 1.0)
                    2. Structure score (0.0 to 1.0)
                    3. Strengths of the document
                    4. Weaknesses and areas for improvement
                    5. Readability issues
                    6. Overall assessment

                    Format the response as structured data.
                    """,
                    documentText.substring(0, Math.min(documentText.length(), 4000)));

            String aiResponse = aiService.analyzeDocument(prompt);
            return parseClarityAndStructureResponse(aiResponse);

        } catch (Exception e) {
            log.error("Error in clarity and structure analysis: {}", e.getMessage());
            return createDefaultClarityAndStructureAnalysis();
        }
    }

    /**
     * Generate document summary
     */
    private AgreementAnalysisResponse.DocumentSummary generateDocumentSummary(String documentText,
            AgreementUploadRequest request) {
        log.info("Generating document summary for agreement: {}", request.getTitle());

        try {
            String prompt = String.format("""
                    Generate a comprehensive summary of the following legal agreement:

                    Agreement Type: %s
                    Document Content:
                    %s

                    Please provide:
                    1. Executive summary
                    2. Key terms and conditions
                    3. Main obligations
                    4. Rights and responsibilities
                    5. Termination clauses
                    6. Dispute resolution mechanisms
                    7. Estimated reading time

                    Format the response as structured data.
                    """,
                    request.getType(),
                    documentText.substring(0, Math.min(documentText.length(), 4000)));

            String aiResponse = aiService.analyzeDocument(prompt);
            return parseDocumentSummaryResponse(aiResponse, documentText);

        } catch (Exception e) {
            log.error("Error generating document summary: {}", e.getMessage());
            return createDefaultDocumentSummary(documentText);
        }
    }

    /**
     * Identify issues in the document
     */
    private List<AgreementAnalysisResponse.IssueHighlight> identifyIssues(String documentText,
            AgreementUploadRequest request) {
        log.info("Identifying issues in agreement: {}", request.getTitle());

        try {
            String prompt = String.format("""
                    Identify potential issues in the following legal agreement:

                    Agreement Type: %s
                    Document Content:
                    %s

                    Please identify:
                    1. Legal issues (compliance, enforceability)
                    2. Structural issues (organization, flow)
                    3. Clarity issues (ambiguity, confusion)
                    4. Compliance issues (regulatory, statutory)

                    For each issue, provide:
                    - Issue type
                    - Severity (LOW/MEDIUM/HIGH/CRITICAL)
                    - Description
                    - Location reference
                    - Impact assessment
                    - Suggested action

                    Format the response as structured data.
                    """,
                    request.getType(),
                    documentText.substring(0, Math.min(documentText.length(), 4000)));

            String aiResponse = aiService.analyzeDocument(prompt);
            return parseIssuesResponse(aiResponse);

        } catch (Exception e) {
            log.error("Error identifying issues: {}", e.getMessage());
            return createDefaultIssuesList();
        }
    }

    /**
     * Suggest improvements for the document
     */
    private List<AgreementAnalysisResponse.ImprovementSuggestion> suggestImprovements(String documentText,
            AgreementUploadRequest request) {
        log.info("Suggesting improvements for agreement: {}", request.getTitle());

        try {
            String prompt = String.format("""
                    Suggest improvements for the following legal agreement:

                    Agreement Type: %s
                    Document Content:
                    %s

                    Please provide:
                    1. Legal improvements (compliance, enforceability)
                    2. Structural improvements (organization, clarity)
                    3. Clarity improvements (readability, understanding)
                    4. Compliance improvements (regulatory, statutory)

                    For each suggestion, provide:
                    - Category
                    - Priority (LOW/MEDIUM/HIGH)
                    - Specific suggestion
                    - Rationale
                    - Implementation guidance
                    - Expected benefit

                    Format the response as structured data.
                    """,
                    request.getType(),
                    documentText.substring(0, Math.min(documentText.length(), 4000)));

            String aiResponse = aiService.analyzeDocument(prompt);
            return parseImprovementsResponse(aiResponse);

        } catch (Exception e) {
            log.error("Error suggesting improvements: {}", e.getMessage());
            return createDefaultImprovementsList();
        }
    }

    // Helper methods for parsing AI responses and creating default analyses
    private AgreementAnalysisResponse.LegalComplianceAnalysis parseLegalComplianceResponse(String aiResponse,
            AgreementUploadRequest request) {
        // This would parse the AI response and extract structured data
        // For now, returning a default analysis
        return createDefaultLegalComplianceAnalysis(request);
    }

    private AgreementAnalysisResponse.RiskAssessmentAnalysis parseRiskAssessmentResponse(String aiResponse,
            AgreementUploadRequest request) {
        return createDefaultRiskAssessmentAnalysis(request);
    }

    private AgreementAnalysisResponse.ClarityAndStructureAnalysis parseClarityAndStructureResponse(String aiResponse) {
        return createDefaultClarityAndStructureAnalysis();
    }

    private AgreementAnalysisResponse.DocumentSummary parseDocumentSummaryResponse(String aiResponse,
            String documentText) {
        return createDefaultDocumentSummary(documentText);
    }

    private List<AgreementAnalysisResponse.IssueHighlight> parseIssuesResponse(String aiResponse) {
        return createDefaultIssuesList();
    }

    private List<AgreementAnalysisResponse.ImprovementSuggestion> parseImprovementsResponse(String aiResponse) {
        return createDefaultImprovementsList();
    }

    // Default analysis creators
    private AgreementAnalysisResponse.LegalComplianceAnalysis createDefaultLegalComplianceAnalysis(
            AgreementUploadRequest request) {
        return AgreementAnalysisResponse.LegalComplianceAnalysis.builder()
                .overallStatus("ANALYSIS_PENDING")
                .complianceScore(0.0)
                .compliantAreas(Arrays.asList("Analysis in progress"))
                .nonCompliantAreas(Arrays.asList("Analysis in progress"))
                .recommendations(Arrays.asList("Complete AI analysis for detailed compliance assessment"))
                .governingLaw(request.getGoverningLaw())
                .jurisdiction(request.getJurisdiction())
                .build();
    }

    private AgreementAnalysisResponse.RiskAssessmentAnalysis createDefaultRiskAssessmentAnalysis(
            AgreementUploadRequest request) {
        return AgreementAnalysisResponse.RiskAssessmentAnalysis.builder()
                .overallRiskLevel("ANALYSIS_PENDING")
                .riskScore(0.0)
                .identifiedRisks(Arrays.asList(
                        AgreementAnalysisResponse.RiskFactor.builder()
                                .riskType("ANALYSIS_PENDING")
                                .description("Risk assessment in progress")
                                .severity("UNKNOWN")
                                .probability("UNKNOWN")
                                .impact("Analysis required")
                                .mitigation("Complete AI analysis")
                                .build()))
                .riskMitigationStrategies(Arrays.asList("Complete risk analysis for detailed assessment"))
                .insuranceRecommendations("Analysis required")
                .liabilityAssessment("Analysis required")
                .build();
    }

    private AgreementAnalysisResponse.ClarityAndStructureAnalysis createDefaultClarityAndStructureAnalysis() {
        return AgreementAnalysisResponse.ClarityAndStructureAnalysis.builder()
                .clarityScore(0.0)
                .structureScore(0.0)
                .strengths(Arrays.asList("Analysis in progress"))
                .weaknesses(Arrays.asList("Analysis in progress"))
                .readabilityIssues(Arrays.asList("Analysis required"))
                .overallAssessment("Analysis in progress")
                .build();
    }

    private AgreementAnalysisResponse.DocumentSummary createDefaultDocumentSummary(String documentText) {
        return AgreementAnalysisResponse.DocumentSummary.builder()
                .executiveSummary("Document analysis in progress")
                .keyTerms("Analysis required")
                .obligations("Analysis required")
                .rights("Analysis required")
                .terminationClauses("Analysis required")
                .disputeResolution("Analysis required")
                .totalClauses(0)
                .totalPages(1)
                .estimatedReadingTime("Analysis required")
                .build();
    }

    private List<AgreementAnalysisResponse.IssueHighlight> createDefaultIssuesList() {
        return Arrays.asList(
                AgreementAnalysisResponse.IssueHighlight.builder()
                        .issueType("ANALYSIS_PENDING")
                        .severity("UNKNOWN")
                        .description("Issue analysis in progress")
                        .location("Document-wide")
                        .impact("Analysis required")
                        .suggestedAction("Complete AI analysis")
                        .build());
    }

    private List<AgreementAnalysisResponse.ImprovementSuggestion> createDefaultImprovementsList() {
        return Arrays.asList(
                AgreementAnalysisResponse.ImprovementSuggestion.builder()
                        .category("ANALYSIS_PENDING")
                        .priority("MEDIUM")
                        .suggestion("Complete AI analysis for detailed improvement suggestions")
                        .rationale("Analysis required to identify specific areas for improvement")
                        .implementation("Run comprehensive AI analysis")
                        .expectedBenefit("Detailed improvement recommendations")
                        .build());
    }

    // Utility methods
    private String generateAnalysisId() {
        return "ANALYSIS_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 8);
    }

    private String generateDocumentId() {
        return "DOC_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 8);
    }

    private String getFileExtension(String filename) {
        if (filename == null || filename.lastIndexOf(".") == -1) {
            return "";
        }
        return filename.substring(filename.lastIndexOf(".") + 1);
    }
}
