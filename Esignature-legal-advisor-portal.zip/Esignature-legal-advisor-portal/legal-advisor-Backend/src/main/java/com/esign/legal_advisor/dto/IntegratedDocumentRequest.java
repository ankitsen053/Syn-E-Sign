package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import jakarta.validation.constraints.NotBlank;
import java.util.Map;

/**
 * Request DTO for creating documents with integrated features
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IntegratedDocumentRequest {

    @NotBlank(message = "Document title is required")
    private String title;

    private String content;

    @NotBlank(message = "Document type is required")
    private String type;

    private String partyA;
    private String partyB;
    private String terms;

    // Generation options
    private boolean generateContent = false;
    private String prompt;
    private Map<String, Object> generationContext;

    // Analysis options
    private boolean analyzeDocument = false;
    private String analysisType; // PAN, AADHAAR, GENERAL, CONTRACT, etc.
    private Double confidenceThreshold;

    // Signing options
    private boolean prepareForSigning = false;
    private boolean requireBothParties = true;

    // Document format options
    private String outputFormat = "PDF"; // PDF, DOCX, HTML
    private boolean includeWatermark = false;

    // Metadata
    private Map<String, String> metadata;
    private String templateId; // For template-based generation
}
