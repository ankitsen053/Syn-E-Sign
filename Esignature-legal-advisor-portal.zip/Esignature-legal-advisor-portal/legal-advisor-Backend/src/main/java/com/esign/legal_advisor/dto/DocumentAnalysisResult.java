package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * DTO for document analysis results
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentAnalysisResult {
    
    private String documentId;
    private String analysisType;
    private Map<String, Object> extractedData;
    private Double confidenceScore;
    private Map<String, String> validationResults;
    private boolean verified;
    private LocalDateTime analyzedAt;
    
    // Specific analysis results
    private String documentQuality;
    private Double authenticityScore;
    private Map<String, Double> fieldConfidenceScores;
    
    // Compliance checks
    private boolean complianceCheckPassed;
    private Map<String, Boolean> complianceChecks;
    
    // Risk assessment
    private String riskLevel; // LOW, MEDIUM, HIGH
    private Map<String, String> riskFactors;
    
    // AI insights
    private String summary;
    private Map<String, String> keyFindings;
    private Map<String, String> recommendations;
    
    // Model information
    private String modelName;
    private String modelVersion;
}
