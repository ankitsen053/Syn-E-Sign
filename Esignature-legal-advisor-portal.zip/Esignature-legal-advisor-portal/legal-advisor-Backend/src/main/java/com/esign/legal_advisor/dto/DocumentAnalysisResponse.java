package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDateTime;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocumentAnalysisResponse {
    
    private boolean success;
    private boolean verified;
    private String documentType;
    private Double confidenceScore;
    private String errorMessage;
    private LocalDateTime processedAt;
    
    // Extracted document fields
    private Map<String, Object> extractedData;
    
    // Validation results
    private Map<String, String> validationResults;
    
    // SageMaker model information
    private String modelName;
    private String modelVersion;
    
    public static DocumentAnalysisResponse success(String documentType, Map<String, Object> extractedData, 
                                                 Double confidenceScore, Map<String, String> validationResults) {
        DocumentAnalysisResponse response = new DocumentAnalysisResponse();
        response.setSuccess(true);
        response.setVerified(confidenceScore >= 0.8); // Default threshold
        response.setDocumentType(documentType);
        response.setExtractedData(extractedData);
        response.setConfidenceScore(confidenceScore);
        response.setValidationResults(validationResults);
        response.setProcessedAt(LocalDateTime.now());
        return response;
    }
    
    public static DocumentAnalysisResponse failure(String documentType, String errorMessage) {
        DocumentAnalysisResponse response = new DocumentAnalysisResponse();
        response.setSuccess(false);
        response.setVerified(false);
        response.setDocumentType(documentType);
        response.setErrorMessage(errorMessage);
        response.setProcessedAt(LocalDateTime.now());
        return response;
    }
}
