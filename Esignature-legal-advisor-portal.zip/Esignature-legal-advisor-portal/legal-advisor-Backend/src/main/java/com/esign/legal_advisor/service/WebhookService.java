package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.DigiLockerVerificationRequest;
import com.esign.legal_advisor.service.DigiLockerService.DigiLockerVerificationResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class WebhookService {

    private static final Logger logger = LoggerFactory.getLogger(WebhookService.class);

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Send verification completion webhook to merchant
     */
    public boolean sendVerificationWebhook(DigiLockerVerificationRequest request, DigiLockerVerificationResult verificationResult) {
        try {
            if (request.getWebhookUrl() == null || request.getWebhookUrl().isEmpty()) {
                logger.debug("No webhook URL configured for request: {}", request.getId());
                return false;
            }

            logger.info("Sending verification webhook for request: {} to URL: {}", 
                       request.getId(), request.getWebhookUrl());

            // Prepare webhook payload
            Map<String, Object> webhookPayload = createWebhookPayload(request, verificationResult);

            // Set headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("User-Agent", "LegalAdvisor-DigiLocker-Webhook/1.0");
            headers.set("X-Webhook-Event", "verification.completed");
            headers.set("X-Webhook-Timestamp", String.valueOf(System.currentTimeMillis()));

            // Create request
            HttpEntity<Map<String, Object>> httpRequest = new HttpEntity<>(webhookPayload, headers);

            // Send webhook with timeout
            ResponseEntity<String> response = restTemplate.exchange(
                request.getWebhookUrl(),
                HttpMethod.POST,
                httpRequest,
                String.class
            );

            if (response.getStatusCode().is2xxSuccessful()) {
                request.setWebhookSent(true);
                logger.info("Webhook sent successfully for request: {} - Response: {}", 
                           request.getId(), response.getStatusCode());
                return true;
            } else {
                logger.warn("Webhook failed for request: {} - Status: {}, Response: {}", 
                           request.getId(), response.getStatusCode(), response.getBody());
                return false;
            }

        } catch (Exception e) {
            logger.error("Error sending webhook for request: {} to URL: {}", 
                        request.getId(), request.getWebhookUrl(), e);
            return false;
        }
    }

    /**
     * Create webhook payload
     */
    private Map<String, Object> createWebhookPayload(DigiLockerVerificationRequest request, DigiLockerVerificationResult verificationResult) {
        Map<String, Object> payload = new HashMap<>();
        
        // Event information
        payload.put("event", "verification.completed");
        payload.put("timestamp", LocalDateTime.now());
        payload.put("webhook_id", java.util.UUID.randomUUID().toString());

        // Request information
        Map<String, Object> requestData = new HashMap<>();
        requestData.put("id", request.getId());
        requestData.put("verification_token", request.getVerificationToken());
        requestData.put("merchant_user_id", request.getMerchantUserId());
        requestData.put("status", request.getStatus().toString());
        requestData.put("requested_documents", request.getRequestedDocuments());
        requestData.put("verification_purpose", request.getVerificationPurpose());
        requestData.put("created_at", request.getCreatedAt());
        requestData.put("completed_at", request.getCompletedAt());
        
        // Customer information (masked)
        Map<String, Object> customerData = new HashMap<>();
        customerData.put("name", request.getCustomerName());
        customerData.put("email", request.getCustomerEmail());
        customerData.put("mobile", maskMobile(request.getCustomerMobile()));
        requestData.put("customer", customerData);

        payload.put("verification_request", requestData);

        // Verification results
        if (verificationResult != null && verificationResult.isSuccess()) {
            Map<String, Object> results = new HashMap<>();
            results.put("success", verificationResult.isSuccess());
            results.put("digilocker_id", maskDigiLockerId(verificationResult.getDigiLockerId()));
            results.put("total_documents", verificationResult.getTotalDocuments());
            results.put("verification_time", verificationResult.getVerificationTime());

            // Document availability
            Map<String, Object> documents = new HashMap<>();
            documents.put("aadhaar_available", verificationResult.getAadhaarDocument() != null);
            documents.put("pan_available", verificationResult.getPanDocument() != null);
            documents.put("driving_license_available", verificationResult.getDrivingLicenseDocument() != null);
            documents.put("passport_available", verificationResult.getPassportDocument() != null);
            results.put("documents", documents);

            // Add document details if available
            if (verificationResult.getAadhaarDocument() != null) {
                Map<String, Object> aadhaarInfo = new HashMap<>();
                aadhaarInfo.put("document_type", verificationResult.getAadhaarDocument().getDocumentType());
                aadhaarInfo.put("issuer", verificationResult.getAadhaarDocument().getIssuer());
                aadhaarInfo.put("verified", verificationResult.getAadhaarDocument().isVerified());
                aadhaarInfo.put("issue_date", verificationResult.getAadhaarDocument().getIssueDate());
                results.put("aadhaar_document", aadhaarInfo);
            }

            if (verificationResult.getPanDocument() != null) {
                Map<String, Object> panInfo = new HashMap<>();
                panInfo.put("document_type", verificationResult.getPanDocument().getDocumentType());
                panInfo.put("issuer", verificationResult.getPanDocument().getIssuer());
                panInfo.put("verified", verificationResult.getPanDocument().isVerified());
                panInfo.put("issue_date", verificationResult.getPanDocument().getIssueDate());
                results.put("pan_document", panInfo);
            }

            payload.put("verification_results", results);
        } else {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("error_message", request.getErrorMessage());
            payload.put("verification_results", error);
        }

        return payload;
    }

    /**
     * Send webhook for failed verification
     */
    public boolean sendFailureWebhook(DigiLockerVerificationRequest request, String errorMessage) {
        try {
            if (request.getWebhookUrl() == null || request.getWebhookUrl().isEmpty()) {
                return false;
            }

            logger.info("Sending failure webhook for request: {} to URL: {}", 
                       request.getId(), request.getWebhookUrl());

            Map<String, Object> payload = new HashMap<>();
            payload.put("event", "verification.failed");
            payload.put("timestamp", LocalDateTime.now());
            payload.put("webhook_id", java.util.UUID.randomUUID().toString());

            Map<String, Object> requestData = new HashMap<>();
            requestData.put("id", request.getId());
            requestData.put("verification_token", request.getVerificationToken());
            requestData.put("merchant_user_id", request.getMerchantUserId());
            requestData.put("status", request.getStatus().toString());
            requestData.put("error_message", errorMessage);
            requestData.put("created_at", request.getCreatedAt());
            requestData.put("failed_at", LocalDateTime.now());

            payload.put("verification_request", requestData);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("X-Webhook-Event", "verification.failed");

            HttpEntity<Map<String, Object>> httpRequest = new HttpEntity<>(payload, headers);

            ResponseEntity<String> response = restTemplate.exchange(
                request.getWebhookUrl(),
                HttpMethod.POST,
                httpRequest,
                String.class
            );

            boolean success = response.getStatusCode().is2xxSuccessful();
            if (success) {
                request.setWebhookSent(true);
                logger.info("Failure webhook sent successfully for request: {}", request.getId());
            }

            return success;

        } catch (Exception e) {
            logger.error("Error sending failure webhook for request: {}", request.getId(), e);
            return false;
        }
    }

    /**
     * Test webhook endpoint
     */
    public boolean testWebhookEndpoint(String webhookUrl) {
        try {
            Map<String, Object> testPayload = new HashMap<>();
            testPayload.put("event", "webhook.test");
            testPayload.put("timestamp", LocalDateTime.now());
            testPayload.put("message", "This is a test webhook from Legal Advisor DigiLocker service");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("X-Webhook-Event", "webhook.test");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(testPayload, headers);

            ResponseEntity<String> response = restTemplate.exchange(
                webhookUrl,
                HttpMethod.POST,
                request,
                String.class
            );

            return response.getStatusCode().is2xxSuccessful();

        } catch (Exception e) {
            logger.error("Error testing webhook endpoint: {}", webhookUrl, e);
            return false;
        }
    }

    // Helper methods
    private String maskMobile(String mobile) {
        if (mobile == null || mobile.length() < 4) return null;
        return mobile.substring(0, 2) + "****" + mobile.substring(mobile.length() - 2);
    }

    private String maskDigiLockerId(String digiLockerId) {
        if (digiLockerId == null || digiLockerId.length() < 8) return null;
        return digiLockerId.substring(0, 8) + "****" + digiLockerId.substring(digiLockerId.length() - 4);
    }
}
