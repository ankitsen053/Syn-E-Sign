package com.esign.legal_advisor.dto;

import org.springframework.web.multipart.MultipartFile;

public class VideoVerificationDto {
    
    private MultipartFile video;
    private String notes;
    
    public VideoVerificationDto() {}
    
    public VideoVerificationDto(MultipartFile video, String notes) {
        this.video = video;
        this.notes = notes;
    }
    
    public MultipartFile getVideo() {
        return video;
    }
    
    public void setVideo(MultipartFile video) {
        this.video = video;
    }
    
    public String getNotes() {
        return notes;
    }
    
    public void setNotes(String notes) {
        this.notes = notes;
    }
}
