package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.dto.SignatureRequestDto;
import com.esign.legal_advisor.dto.SignatureVerificationResult;
import com.esign.legal_advisor.entites.SignedAgreement;
import com.esign.legal_advisor.entites.SignatureData;
import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.service.SignatureService;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/signature")
@CrossOrigin(origins = "*")
public class SignatureController {

    private static final Logger logger = LoggerFactory.getLogger(SignatureController.class);

    @Autowired
    private SignatureService signatureService;

    /**
     * Create multi-party agreement
     */
    @PostMapping("/create-multi-party")
    public ResponseEntity<?> createMultiPartyAgreement(@RequestBody Map<String, Object> request,
            HttpServletRequest httpRequest) {
        logger.info("Creating multi-party agreement");

        try {
            User currentUser = getCurrentUser();
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("User not authenticated"));
            }

            // Extract request data
            String agreementTitle = (String) request.get("agreementTitle");
            String agreementContent = (String) request.get("agreementContent");
            String agreementType = (String) request.get("agreementType");
            String partyA = (String) request.get("partyA");
            String partyB = (String) request.get("partyB");
            String terms = (String) request.get("terms");
            @SuppressWarnings("unchecked")
            List<String> requiredSigners = (List<String>) request.get("requiredSigners");
            String signingInstructions = (String) request.get("signingInstructions");
            Integer expirationDays = (Integer) request.getOrDefault("expirationDays", 30);

            if (agreementTitle == null || agreementContent == null || requiredSigners == null
                    || requiredSigners.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Agreement title, content, and required signers are required"));
            }

            // Create multi-party agreement
            SignedAgreement agreement = signatureService.createMultiPartyAgreement(
                    agreementTitle, agreementContent, agreementType, partyA, partyB, terms,
                    currentUser.getId(), requiredSigners, signingInstructions, expirationDays);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Multi-party agreement created successfully");
            response.put("agreementId", agreement.getId());
            response.put("workflowStatus", agreement.getWorkflowStatus());
            response.put("requiredSigners", agreement.getRequiredSigners());
            response.put("expiresAt", agreement.getExpiresAt());

            logger.info("Multi-party agreement created successfully with ID: {}", agreement.getId());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error creating multi-party agreement", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to create multi-party agreement: " + e.getMessage()));
        }
    }

    /**
     * Sign an agreement (single or multi-party)
     */
    @PostMapping("/sign")
    public ResponseEntity<?> signAgreement(@RequestBody SignatureRequestDto request, HttpServletRequest httpRequest) {
        logger.info("Processing signature request for agreement: {}", request.getAgreementTitle());

        try {
            // Get current user
            User currentUser = getCurrentUser();
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("User not authenticated"));
            }

            // Set IP address if not provided
            if (request.getSignerIpAddress() == null || request.getSignerIpAddress().trim().isEmpty()) {
                String clientIp = getClientIpAddress(httpRequest);
                request.setSignerIpAddress(clientIp);
            }

            // Create signed agreement
            SignedAgreement signedAgreement = signatureService.createSignedAgreement(request, currentUser);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Agreement signed successfully");
            response.put("agreementId", signedAgreement.getId());
            response.put("signedAt", signedAgreement.getSignedAt());
            response.put("documentHash", signedAgreement.getDocumentHash());
            response.put("signatureHash", signedAgreement.getSignatureHash());

            logger.info("Agreement signed successfully with ID: {}", signedAgreement.getId());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error signing agreement", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to sign agreement: " + e.getMessage()));
        }
    }

    /**
     * Get signed agreement by ID
     */
    @GetMapping("/{agreementId}")
    public ResponseEntity<?> getSignedAgreement(@PathVariable String agreementId) {
        logger.info("Retrieving signed agreement: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signatureService.getSignedAgreement(agreementId);
            if (agreementOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new MessageResponse("Signed agreement not found"));
            }

            SignedAgreement agreement = agreementOpt.get();
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("agreement", agreement);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error retrieving signed agreement", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to retrieve signed agreement: " + e.getMessage()));
        }
    }

    /**
     * Get all signed agreements for current user
     */
    @GetMapping("/user/agreements")
    public ResponseEntity<?> getUserSignedAgreements() {
        logger.info("Retrieving signed agreements for current user");

        try {
            User currentUser = getCurrentUser();
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("User not authenticated"));
            }

            List<SignedAgreement> agreements = signatureService.getUserSignedAgreements(currentUser.getId());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("agreements", agreements);
            response.put("count", agreements.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error retrieving user signed agreements", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to retrieve signed agreements: " + e.getMessage()));
        }
    }

    /**
     * Get all signed agreements (admin only)
     */
    @GetMapping("/admin/all")
    public ResponseEntity<?> getAllSignedAgreements() {
        logger.info("Retrieving all signed agreements (admin)");

        try {
            User currentUser = getCurrentUser();
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("User not authenticated"));
            }

            // Check if user has admin role
            boolean isAdmin = currentUser.getAuthorities().stream()
                    .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

            if (!isAdmin) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new MessageResponse("Access denied. Admin role required."));
            }

            List<SignedAgreement> agreements = signatureService.getAllSignedAgreements();

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("agreements", agreements);
            response.put("count", agreements.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error retrieving all signed agreements", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to retrieve signed agreements: " + e.getMessage()));
        }
    }

    /**
     * Download signed agreement as PDF
     */
    @GetMapping("/{agreementId}/download")
    public ResponseEntity<?> downloadSignedAgreement(@PathVariable String agreementId) {
        logger.info("Downloading signed agreement as PDF: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signatureService.getSignedAgreement(agreementId);
            if (agreementOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new MessageResponse("Signed agreement not found"));
            }

            SignedAgreement agreement = agreementOpt.get();

            // Generate enhanced document with signature
            byte[] documentBytes = signatureService.generateSignedPdf(agreementId);

            // Set response headers for file download (HTML format for better signature
            // display)
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_HTML);
            headers.setContentDispositionFormData("attachment",
                    String.format("signed_agreement_%s.html", agreementId));
            headers.setContentLength(documentBytes.length);

            logger.info("Enhanced document generated successfully for agreement: {}", agreementId);
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(documentBytes);

        } catch (Exception e) {
            logger.error("Error downloading signed agreement", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to download signed agreement: " + e.getMessage()));
        }
    }

    /**
     * Verify document integrity
     */
    @GetMapping("/{agreementId}/verify")
    public ResponseEntity<?> verifyAgreementIntegrity(@PathVariable String agreementId) {
        logger.info("Verifying agreement integrity: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signatureService.getSignedAgreement(agreementId);
            if (agreementOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new MessageResponse("Signed agreement not found"));
            }

            SignedAgreement agreement = agreementOpt.get();

            // Verify document and signature integrity
            boolean documentValid = signatureService.verifyDocumentIntegrity(agreementId);
            SignatureVerificationResult signatureResult = signatureService.verifySignatureIntegrity(agreementId);
            boolean signatureValid = signatureResult.isOverallValid();
            boolean overallValid = documentValid && signatureValid;

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("agreementId", agreementId);
            response.put("documentValid", documentValid);
            response.put("signatureValid", signatureValid);
            response.put("overallValid", overallValid);
            response.put("documentHash", agreement.getDocumentHash());
            response.put("signatureHash", agreement.getSignatureHash());
            response.put("signerName", agreement.getSignerName());
            response.put("signerEmail", agreement.getSignerEmail());
            response.put("signedAt", agreement.getSignedAt());
            response.put("signedAtFormatted",
                    agreement.getSignedAt().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy 'at' HH:mm:ss")));
            response.put("ipAddress", agreement.getSignerIpAddress());
            response.put("status", agreement.getStatus());
            response.put("agreementType", agreement.getAgreementType());
            response.put("agreementTitle", agreement.getAgreementTitle());

            // Authentication details
            Map<String, Object> authDetails = new HashMap<>();
            authDetails.put("digitalSignaturePresent",
                    agreement.getSignatureImageBase64() != null && !agreement.getSignatureImageBase64().isEmpty());
            authDetails.put("hashVerificationPassed", documentValid && signatureValid);
            authDetails.put("tamperDetected", !(documentValid && signatureValid));
            authDetails.put("signatureMethod", "Digital Canvas Signature");
            authDetails.put("encryptionAlgorithm", "SHA-256");
            response.put("authentication", authDetails);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error verifying agreement integrity", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to verify agreement integrity: " + e.getMessage()));
        }
    }

    /**
     * Get signature image for display/verification
     */
    @GetMapping("/{agreementId}/signature")
    public ResponseEntity<?> getSignatureImage(@PathVariable String agreementId) {
        logger.info("Retrieving signature image for agreement: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signatureService.getSignedAgreement(agreementId);
            if (agreementOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new MessageResponse("Signed agreement not found"));
            }

            SignedAgreement agreement = agreementOpt.get();

            if (agreement.getSignatureImageBase64() == null || agreement.getSignatureImageBase64().isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new MessageResponse("Signature image not found"));
            }

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("signatureImage", agreement.getSignatureImageBase64());
            response.put("signerName", agreement.getSignerName());
            response.put("signedAt", agreement.getSignedAt());
            response.put("signedAtFormatted",
                    agreement.getSignedAt().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy 'at' HH:mm:ss")));
            response.put("agreementId", agreementId);
            response.put("agreementTitle", agreement.getAgreementTitle());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error retrieving signature image", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to retrieve signature image: " + e.getMessage()));
        }
    }

    /**
     * Complete an agreement
     */
    @PostMapping("/{agreementId}/complete")
    public ResponseEntity<?> completeAgreement(@PathVariable String agreementId) {
        logger.info("Completing agreement: {}", agreementId);

        try {
            User currentUser = getCurrentUser();
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("User not authenticated"));
            }

            SignedAgreement completedAgreement = signatureService.completeAgreement(agreementId);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Agreement completed successfully");
            response.put("agreementId", completedAgreement.getId());
            response.put("status", completedAgreement.getStatus());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error completing agreement", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to complete agreement: " + e.getMessage()));
        }
    }

    /**
     * Delete signed agreement
     */
    @DeleteMapping("/{agreementId}")
    public ResponseEntity<?> deleteSignedAgreement(@PathVariable String agreementId) {
        logger.info("Deleting signed agreement: {}", agreementId);

        try {
            // Validate agreement ID
            if (agreementId == null || agreementId.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Agreement ID is required"));
            }

            if (agreementId.length() < 10 || agreementId.length() > 50) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Invalid agreement ID format"));
            }

            User currentUser = getCurrentUser();
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("User not authenticated"));
            }

            // Check if agreement exists and belongs to user
            Optional<SignedAgreement> agreementOpt = signatureService.getSignedAgreement(agreementId);
            if (agreementOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new MessageResponse("Agreement not found"));
            }

            SignedAgreement agreement = agreementOpt.get();

            // Verify ownership (if user system is enabled)
            // For now, we'll allow deletion by any authenticated user
            // In production, add ownership check:
            // agreement.getUserId().equals(currentUser.getId())

            boolean deleted = signatureService.deleteSignedAgreement(agreementId);

            if (deleted) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "Agreement deleted successfully");
                response.put("agreementId", agreementId);
                logger.info("Agreement deleted successfully by user: {} for agreement: {}",
                        currentUser.getUsername(), agreementId);
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new MessageResponse("Failed to delete agreement"));
            }

        } catch (IllegalArgumentException e) {
            logger.warn("Invalid delete request for agreement {}: {}", agreementId, e.getMessage());
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Invalid request: " + e.getMessage()));
        } catch (Exception e) {
            logger.error("Error deleting signed agreement: {}", agreementId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to delete agreement. Please try again."));
        }
    }

    /**
     * Get multi-party agreement status
     */
    @GetMapping("/multi-party/{agreementId}/status")
    public ResponseEntity<?> getMultiPartyAgreementStatus(@PathVariable String agreementId) {
        logger.info("Getting multi-party agreement status: {}", agreementId);

        try {
            Optional<SignedAgreement> agreementOpt = signatureService.getSignedAgreement(agreementId);
            if (agreementOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new MessageResponse("Agreement not found"));
            }

            SignedAgreement agreement = agreementOpt.get();

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("agreementId", agreementId);
            response.put("workflowStatus", agreement.getWorkflowStatus());
            response.put("requiredSigners", agreement.getRequiredSigners());
            response.put("completedSigners", agreement.getCompletedSigners());
            response.put("remainingSignatures", agreement.getRemainingSignatures());
            response.put("isFullySigned", agreement.isFullySigned());
            response.put("isExpired", agreement.isExpired());
            response.put("expiresAt", agreement.getExpiresAt());
            response.put("signingInstructions", agreement.getSigningInstructions());
            response.put("signatures", agreement.getSignatures());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error getting multi-party agreement status", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to get agreement status: " + e.getMessage()));
        }
    }

    /**
     * Add signature to multi-party agreement
     */
    @PostMapping("/multi-party/{agreementId}/sign")
    public ResponseEntity<?> addSignatureToMultiPartyAgreement(
            @PathVariable String agreementId,
            @RequestBody Map<String, Object> request,
            HttpServletRequest httpRequest) {
        logger.info("Adding signature to multi-party agreement: {}", agreementId);

        try {
            User currentUser = getCurrentUser();
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("User not authenticated"));
            }

            String signatureImageBase64 = (String) request.get("signatureImageBase64");
            String signatureData = (String) request.get("signatureData");
            String signatureMethod = (String) request.getOrDefault("signatureMethod", "CANVAS");
            String otpCode = (String) request.get("otpCode");

            if (signatureImageBase64 == null || signatureImageBase64.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Signature image is required"));
            }

            // Create signature data
            SignatureData signature = new SignatureData(
                    currentUser.getId(),
                    currentUser.getFullName() != null ? currentUser.getFullName() : currentUser.getUsername(),
                    currentUser.getEmail(),
                    signatureImageBase64,
                    signatureData,
                    getClientIpAddress(httpRequest),
                    signatureMethod);

            if (otpCode != null) {
                signature.setOtpCode(otpCode);
            }

            // Add signature to agreement
            SignedAgreement updatedAgreement = signatureService.addSignatureToMultiPartyAgreement(agreementId,
                    signature);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Signature added successfully");
            response.put("agreementId", agreementId);
            response.put("workflowStatus", updatedAgreement.getWorkflowStatus());
            response.put("remainingSignatures", updatedAgreement.getRemainingSignatures());
            response.put("isFullySigned", updatedAgreement.isFullySigned());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error adding signature to multi-party agreement", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to add signature: " + e.getMessage()));
        }
    }

    /**
     * Send signing invitation
     */
    @PostMapping("/multi-party/{agreementId}/send-invitation")
    public ResponseEntity<?> sendSigningInvitation(
            @PathVariable String agreementId,
            @RequestBody Map<String, Object> request) {
        logger.info("Sending signing invitation for agreement: {}", agreementId);

        try {
            User currentUser = getCurrentUser();
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("User not authenticated"));
            }

            @SuppressWarnings("unchecked")
            List<String> signerEmails = (List<String>) request.get("signerEmails");
            String customMessage = (String) request.get("customMessage");

            if (signerEmails == null || signerEmails.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Signer emails are required"));
            }

            // Send invitations
            signatureService.sendSigningInvitations(agreementId, signerEmails, customMessage);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Signing invitations sent successfully");
            response.put("agreementId", agreementId);
            response.put("invitedSigners", signerEmails);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error sending signing invitation", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to send invitation: " + e.getMessage()));
        }
    }

    /**
     * Get signature statistics
     */
    @GetMapping("/stats")
    public ResponseEntity<?> getSignatureStats() {
        logger.info("Retrieving signature statistics");

        try {
            User currentUser = getCurrentUser();
            if (currentUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("User not authenticated"));
            }

            long totalSigned = signatureService.getTotalSignedAgreements();
            long drafts = signatureService.getDraftAgreements();
            long userAgreements = signatureService.getUserAgreementCount(currentUser.getId());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("totalSigned", totalSigned);
            response.put("drafts", drafts);
            response.put("userAgreements", userAgreements);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error retrieving signature statistics", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Failed to retrieve signature statistics: " + e.getMessage()));
        }
    }

    /**
     * Get current authenticated user
     */
    private User getCurrentUser() {
        try {
            logger.info("Getting current user from SecurityContext");
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            logger.info("Authentication object: {}",
                    authentication != null ? authentication.getClass().getSimpleName() : "null");

            if (authentication != null) {
                logger.info("Authentication principal: {}",
                        authentication.getPrincipal() != null ? authentication.getPrincipal().getClass().getSimpleName()
                                : "null");

                if (authentication.getPrincipal() instanceof User) {
                    User user = (User) authentication.getPrincipal();
                    logger.info("Authenticated user: {}", user.getUsername());
                    return user;
                } else {
                    logger.warn("Authentication principal is not a User instance: {}", authentication.getPrincipal());
                }
            } else {
                logger.warn("No authentication found in SecurityContext");
            }

            // For development: return a default user if not authenticated
            logger.warn("No authenticated user found, using default user for development");
            User defaultUser = new User();
            defaultUser.setId("dev-user-id");
            defaultUser.setUsername("dev-user");
            defaultUser.setEmail("dev@example.com");
            defaultUser.setFullName("Development User");
            defaultUser.setRoles(new HashSet<>());
            logger.info("Created default user: {}", defaultUser.getUsername());
            return defaultUser;
        } catch (Exception e) {
            logger.error("Error in getCurrentUser(): {}", e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Get client IP address
     */
    private String getClientIpAddress(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty() && !"unknown".equalsIgnoreCase(xForwardedFor)) {
            return xForwardedFor.split(",")[0];
        }

        String xRealIp = request.getHeader("X-Real-IP");
        if (xRealIp != null && !xRealIp.isEmpty() && !"unknown".equalsIgnoreCase(xRealIp)) {
            return xRealIp;
        }

        return request.getRemoteAddr();
    }
}
