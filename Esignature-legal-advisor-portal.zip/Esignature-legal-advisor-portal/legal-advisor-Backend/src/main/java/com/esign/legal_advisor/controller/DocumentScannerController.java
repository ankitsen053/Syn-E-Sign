package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.DocumentScannerDto;
import com.esign.legal_advisor.service.DocumentScannerService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/scanner")
@CrossOrigin(origins = "*", maxAge = 3600)
public class DocumentScannerController {

    private static final Logger logger = LoggerFactory.getLogger(DocumentScannerController.class);
    private final DocumentScannerService documentScannerService;

    public DocumentScannerController(DocumentScannerService documentScannerService) {
        this.documentScannerService = documentScannerService;
    }

    @PostMapping("/scan")
    public ResponseEntity<?> scanDocument(@Valid @RequestBody DocumentScannerDto scannerDto,
            BindingResult bindingResult) {
        try {
            // Validation error handling
            if (bindingResult.hasErrors()) {
                Map<String, String> validationErrors = new HashMap<>();
                for (FieldError error : bindingResult.getFieldErrors()) {
                    validationErrors.put(error.getField(), error.getDefaultMessage());
                }

                logger.warn("Document scanner validation failed");
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "error", "Validation failed",
                        "validationErrors", validationErrors));
            }

            logger.info("Starting document scan for type: {}", scannerDto.getDocumentType());

            Map<String, Object> result = documentScannerService.scanDocument(scannerDto);

            if ((Boolean) result.get("success")) {
                logger.info("Document scan completed successfully");
                return ResponseEntity.ok(result);
            } else {
                logger.error("Document scan failed: {}", result.get("error"));
                return ResponseEntity.status(500).body(result);
            }

        } catch (Exception e) {
            logger.error("Error during document scan", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to scan document: " + e.getMessage()));
        }
    }

    @PostMapping("/scan-file")
    public ResponseEntity<?> scanDocumentFile(@RequestParam("file") MultipartFile file,
            @RequestParam("documentType") String documentType,
            @RequestParam(value = "documentTitle", required = false) String documentTitle,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "includeRiskAnalysis", defaultValue = "true") boolean includeRiskAnalysis,
            @RequestParam(value = "includeComplianceCheck", defaultValue = "true") boolean includeComplianceCheck,
            @RequestParam(value = "includeClauseAnalysis", defaultValue = "true") boolean includeClauseAnalysis,
            @RequestParam(value = "includeRecommendations", defaultValue = "true") boolean includeRecommendations,
            @RequestParam(value = "jurisdiction", defaultValue = "IN") String jurisdiction,
            @RequestParam(value = "language", defaultValue = "en") String language) {
        try {
            logger.info("Starting file-based document scan for file: {}", file.getOriginalFilename());

            // Validate file
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "error", "File is empty"));
            }

            // Create scanner DTO
            DocumentScannerDto scannerDto = new DocumentScannerDto();
            scannerDto.setDocumentFile(file);
            scannerDto.setDocumentType(documentType);
            scannerDto.setDocumentTitle(documentTitle);
            scannerDto.setDescription(description);
            scannerDto.setIncludeRiskAnalysis(includeRiskAnalysis);
            scannerDto.setIncludeComplianceCheck(includeComplianceCheck);
            scannerDto.setIncludeClauseAnalysis(includeClauseAnalysis);
            scannerDto.setIncludeRecommendations(includeRecommendations);
            scannerDto.setJurisdiction(jurisdiction);
            scannerDto.setLanguage(language);

            // Validate file type and size
            if (!scannerDto.isSupportedFileType()) {
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "error", "Unsupported file type. Supported types: PDF, DOC, DOCX, TXT"));
            }

            if (!scannerDto.isFileSizeValid()) {
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "error", "File size too large. Maximum size: 10MB"));
            }

            // Set a placeholder content for file-based scanning
            scannerDto.setDocumentContent("Document content will be extracted from uploaded file.");

            Map<String, Object> result = documentScannerService.scanDocument(scannerDto);

            if ((Boolean) result.get("success")) {
                logger.info("File-based document scan completed successfully");
                return ResponseEntity.ok(result);
            } else {
                logger.error("File-based document scan failed: {}", result.get("error"));
                return ResponseEntity.status(500).body(result);
            }

        } catch (Exception e) {
            logger.error("Error during file-based document scan", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to scan document file: " + e.getMessage()));
        }
    }

    @GetMapping("/supported-types")
    public ResponseEntity<?> getSupportedFileTypes() {
        try {
            Map<String, Object> supportedTypes = Map.of(
                    "success", true,
                    "supportedTypes", Map.of(
                            "pdf", "Portable Document Format",
                            "doc", "Microsoft Word Document",
                            "docx", "Microsoft Word Open XML Document",
                            "txt", "Plain Text File"),
                    "maxFileSize", "10MB",
                    "maxContentLength", "50,000 characters");

            return ResponseEntity.ok(supportedTypes);

        } catch (Exception e) {
            logger.error("Error getting supported file types", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to get supported file types: " + e.getMessage()));
        }
    }

    @GetMapping("/document-types")
    public ResponseEntity<?> getSupportedDocumentTypes() {
        try {
            Map<String, Object> documentTypes = Map.of(
                    "success", true,
                    "documentTypes", Map.of(
                            "CONTRACT", "General contract documents",
                            "AGREEMENT", "Service or business agreements",
                            "NDA", "Non-Disclosure Agreements",
                            "MOU", "Memorandum of Understanding",
                            "LEASE", "Property or equipment lease agreements",
                            "LICENSE", "Software or intellectual property licenses",
                            "POLICY", "Company policies and procedures",
                            "OTHER", "Other legal documents"));

            return ResponseEntity.ok(documentTypes);

        } catch (Exception e) {
            logger.error("Error getting document types", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to get document types: " + e.getMessage()));
        }
    }

    @GetMapping("/jurisdictions")
    public ResponseEntity<?> getSupportedJurisdictions() {
        try {
            Map<String, Object> jurisdictions = Map.of(
                    "success", true,
                    "jurisdictions", Map.of(
                            "IN", "India",
                            "US", "United States",
                            "UK", "United Kingdom",
                            "CA", "Canada",
                            "AU", "Australia",
                            "EU", "European Union"),
                    "default", "IN");

            return ResponseEntity.ok(jurisdictions);

        } catch (Exception e) {
            logger.error("Error getting jurisdictions", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "error", "Failed to get jurisdictions: " + e.getMessage()));
        }
    }

    @PostMapping("/health")
    public ResponseEntity<?> checkScannerHealth() {
        try {
            Map<String, Object> health = Map.of(
                    "success", true,
                    "status", "HEALTHY",
                    "service", "Document Scanner Service",
                    "version", "1.0.0",
                    "features", Map.of(
                            "fileUpload", true,
                            "textAnalysis", true,
                            "riskAnalysis", true,
                            "complianceCheck", true,
                            "clauseAnalysis", true,
                            "recommendations", true),
                    "timestamp", System.currentTimeMillis());

            return ResponseEntity.ok(health);

        } catch (Exception e) {
            logger.error("Error checking scanner health", e);
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "status", "UNHEALTHY",
                    "error", "Scanner health check failed: " + e.getMessage()));
        }
    }
}
