package com.esign.legal_advisor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Autowired
    private JavaMailSender mailSender;

    public void sendOtpEmail(String to, String otp) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject("Email Verification - Legal Advisor");
            message.setText(generateOtpEmailContent(otp));

            logger.info("Attempting to send OTP email to: {}", to);
            mailSender.send(message);
            logger.info("OTP email sent successfully to: {}", to);
        } catch (Exception e) {
            logger.error("Failed to send OTP email to: {} - Error: {}", to, e.getMessage());
            logger.error("Email configuration - Host: smtp.gmail.com, Port: 587, Username: anshtalreja025@gmail.com");
            throw new RuntimeException("Failed to send email: " + e.getMessage());
        }
    }

    private String generateOtpEmailContent(String otp) {
        return String.format(
                "🔐 Email Verification - Legal Advisor\n\n" +
                        "Hello,\n\n" +
                        "Thank you for signing up with Legal Advisor! To complete your registration and access your account, please verify your email address.\n\n"
                        +
                        "📧 Your verification code is:\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "                    %s\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                        "⏰ This code will expire in 10 minutes for security reasons.\n\n" +
                        "🔒 Security Tips:\n" +
                        "• Never share this code with anyone\n" +
                        "• Our team will never ask for this code\n" +
                        "• If you didn't request this verification, please ignore this email\n\n" +
                        "📱 How to verify:\n" +
                        "1. Copy the verification code above\n" +
                        "2. Go back to the Legal Advisor application\n" +
                        "3. Enter the code in the verification field\n" +
                        "4. Click 'Verify Email'\n\n" +
                        "Need help? Contact our support team.\n\n" +
                        "Best regards,\n" +
                        "The Legal Advisor Team\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                otp);
    }

    public void sendWelcomeEmail(String to, String username) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject("Welcome to Legal Advisor!");
            message.setText(generateWelcomeEmailContent(username));

            mailSender.send(message);
            logger.info("Welcome email sent successfully to: {}", to);
        } catch (Exception e) {
            logger.error("Failed to send welcome email to: {}", to, e);
            // Don't throw exception for welcome email as it's not critical
        }
    }

    public void sendLoginOtpEmail(String to, String otp) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject("🔐 Two-Factor Authentication - Legal Advisor");
            message.setText(generateLoginOtpEmailContent(otp));

            mailSender.send(message);
            logger.info("Login OTP email sent successfully to: {}", to);
        } catch (Exception e) {
            logger.error("Failed to send login OTP email to: {}", to, e);
            throw new RuntimeException("Failed to send login OTP email: " + e.getMessage());
        }
    }

    public void sendFileOtpEmail(String to, String otp, String fileName) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject("📄 File Access Verification - Legal Advisor");
            message.setText(generateFileOtpEmailContent(otp, fileName));

            mailSender.send(message);
            logger.info("File OTP email sent successfully to: {} for file: {}", to, fileName);
        } catch (Exception e) {
            logger.error("Failed to send file OTP email to: {}", to, e);
            throw new RuntimeException("Failed to send file OTP email: " + e.getMessage());
        }
    }

    private String generateWelcomeEmailContent(String username) {
        return String.format(
                "🎉 Welcome to Legal Advisor!\n\n" +
                        "Hello %s,\n\n" +
                        "Congratulations! Your account has been successfully verified and activated. You now have full access to all features of Legal Advisor.\n\n"
                        +
                        "🚀 What you can do now:\n" +
                        "• Generate legal documents with AI assistance\n" +
                        "• Analyze existing documents for potential issues\n" +
                        "• Manage your document library securely\n" +
                        "• Access your profile and customize settings\n" +
                        "• Get AI-powered legal advice and insights\n\n" +
                        "🔐 Your account is now secure and ready to use.\n\n" +
                        "📞 Need help? Our support team is here to assist you.\n\n" +
                        "Best regards,\n" +
                        "The Legal Advisor Team\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                username);
    }

    private String generateLoginOtpEmailContent(String otp) {
        return String.format(
                "🔐 Two-Factor Authentication - Legal Advisor\n\n" +
                        "Hello,\n\n" +
                        "A login attempt was made to your Legal Advisor account. To complete the login process, please enter the verification code below.\n\n"
                        +
                        "📧 Your verification code is:\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "                    %s\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                        "⏰ This code will expire in 10 minutes for security reasons.\n\n" +
                        "🔒 Security Tips:\n" +
                        "• Never share this code with anyone\n" +
                        "• Our team will never ask for this code\n" +
                        "• If you didn't attempt to login, please change your password immediately\n\n" +
                        "📱 How to verify:\n" +
                        "1. Copy the verification code above\n" +
                        "2. Go back to the Legal Advisor application\n" +
                        "3. Enter the code in the verification field\n" +
                        "4. Click 'Verify Login'\n\n" +
                        "Need help? Contact our support team.\n\n" +
                        "Best regards,\n" +
                        "The Legal Advisor Team\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                otp);
    }

    private String generateFileOtpEmailContent(String otp, String fileName) {
        return String.format(
                "📄 File Access Verification - Legal Advisor\n\n" +
                        "Hello,\n\n" +
                        "A request was made to access the file '%s' in your Legal Advisor account. To proceed with the file operation, please enter the verification code below.\n\n"
                        +
                        "📧 Your verification code is:\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "                    %s\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                        "⏰ This code will expire in 15 minutes for security reasons.\n\n" +
                        "🔒 Security Tips:\n" +
                        "• Never share this code with anyone\n" +
                        "• Our team will never ask for this code\n" +
                        "• If you didn't request file access, please contact support immediately\n\n" +
                        "📱 How to verify:\n" +
                        "1. Copy the verification code above\n" +
                        "2. Go back to the Legal Advisor application\n" +
                        "3. Enter the code in the verification field\n" +
                        "4. Click 'Verify File Access'\n\n" +
                        "Need help? Contact our support team.\n\n" +
                        "Best regards,\n" +
                        "The Legal Advisor Team\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                fileName, otp);
    }

    /**
     * Send HTML email
     */
    public void sendHtmlEmail(String to, String subject, String htmlContent) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(htmlContent, true); // true indicates HTML content
            
            logger.info("Attempting to send HTML email to: {}", to);
            mailSender.send(message);
            logger.info("HTML email sent successfully to: {}", to);
        } catch (MessagingException e) {
            logger.error("Failed to send HTML email to: {} - Error: {}", to, e.getMessage());
            throw new RuntimeException("Failed to send HTML email: " + e.getMessage());
        } catch (Exception e) {
            logger.error("Failed to send HTML email to: {} - Error: {}", to, e.getMessage());
            throw new RuntimeException("Failed to send email: " + e.getMessage());
        }
    }
}
