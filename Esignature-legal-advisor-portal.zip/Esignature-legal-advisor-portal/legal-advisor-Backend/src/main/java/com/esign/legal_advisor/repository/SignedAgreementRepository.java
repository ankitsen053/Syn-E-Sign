package com.esign.legal_advisor.repository;

import com.esign.legal_advisor.entites.SignedAgreement;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface SignedAgreementRepository extends MongoRepository<SignedAgreement, String> {

    // Find agreements by signer
    List<SignedAgreement> findBySignerIdOrderByCreatedAtDesc(String signerId);

    // Find agreements by status
    List<SignedAgreement> findByStatusOrderByCreatedAtDesc(String status);

    // Find agreements by signer and status
    List<SignedAgreement> findBySignerIdAndStatusOrderByCreatedAtDesc(String signerId, String status);

    // Find agreements by agreement type
    List<SignedAgreement> findByAgreementTypeOrderByCreatedAtDesc(String agreementType);

    // Find signed agreements (where status is SIGNED or COMPLETED)
    List<SignedAgreement> findByStatusInOrderByCreatedAtDesc(List<String> statuses);

    // Find by document hash (for verification)
    Optional<SignedAgreement> findByDocumentHash(String documentHash);

    // Find by signature hash (for verification)
    Optional<SignedAgreement> findBySignatureHash(String signatureHash);

    // Count agreements by status
    long countByStatus(String status);

    // Count agreements by signer
    long countBySignerId(String signerId);

    // Additional methods for workflow integration
    List<SignedAgreement> findByDocumentIdOrderByCreatedAtDesc(String documentId);

    Optional<SignedAgreement> findFirstByDocumentIdOrderByCreatedAtDesc(String documentId);

    // Pagination methods
    Page<SignedAgreement> findByStatus(String status, Pageable pageable);

    long countByCreatedAtAfter(LocalDateTime date);

    long countByUpdatedAtAfter(LocalDateTime date);
}
