package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.DocumentScannerDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class DocumentScannerService {

    private static final Logger logger = LoggerFactory.getLogger(DocumentScannerService.class);

    public Map<String, Object> scanDocument(DocumentScannerDto scannerDto) {
        logger.info("Starting document scan for type: {}", scannerDto.getDocumentType());

        Map<String, Object> result = new HashMap<>();

        try {
            // Extract text from file if provided
            String extractedText = "";
            if (scannerDto.hasFile()) {
                extractedText = extractTextFromFile(scannerDto.getDocumentFile());
                // Combine with provided content
                String combinedContent = scannerDto.getDocumentContent() + "\n\n" + extractedText;
                scannerDto.setDocumentContent(combinedContent);
            }

            // Perform comprehensive analysis
            Map<String, Object> analysis = performComprehensiveAnalysis(scannerDto);

            result.put("success", true);
            result.put("scanTimestamp", LocalDateTime.now());
            result.put("documentType", scannerDto.getDocumentType());
            result.put("documentTitle", scannerDto.getDocumentTitle());
            result.put("analysis", analysis);
            result.put("metadata", generateMetadata(scannerDto));

            logger.info("Document scan completed successfully");

        } catch (Exception e) {
            logger.error("Error during document scan", e);
            result.put("success", false);
            result.put("error", "Failed to scan document: " + e.getMessage());
        }

        return result;
    }

    private String extractTextFromFile(MultipartFile file) throws IOException {
        logger.info("Extracting text from file: {}", file.getOriginalFilename());

        String fileName = file.getOriginalFilename();
        if (fileName == null) {
            throw new IOException("Invalid file name");
        }

        String extension = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();

        switch (extension) {
            case "txt":
                return new String(file.getBytes(), StandardCharsets.UTF_8);
            case "pdf":
                return extractTextFromPdf(file);
            case "doc":
            case "docx":
                return extractTextFromWord(file);
            default:
                throw new IOException("Unsupported file type: " + extension);
        }
    }

    private String extractTextFromPdf(MultipartFile file) throws IOException {
        // Mock PDF text extraction - in production, use Apache PDFBox or similar
        logger.info("Mock PDF text extraction");
        return "EXTRACTED PDF CONTENT\n\nThis is a mock extraction of text from PDF document. " +
                "In production, this would use Apache PDFBox or similar library to extract actual text content.";
    }

    private String extractTextFromWord(MultipartFile file) throws IOException {
        // Mock Word document text extraction - in production, use Apache POI
        logger.info("Mock Word document text extraction");
        return "EXTRACTED WORD DOCUMENT CONTENT\n\nThis is a mock extraction of text from Word document. " +
                "In production, this would use Apache POI to extract actual text content.";
    }

    private Map<String, Object> performComprehensiveAnalysis(DocumentScannerDto scannerDto) {
        Map<String, Object> analysis = new HashMap<>();

        String content = scannerDto.getDocumentContent();

        // Document Structure Analysis
        analysis.put("structure", analyzeDocumentStructure(content));

        // Legal Risk Analysis
        if (scannerDto.isIncludeRiskAnalysis()) {
            analysis.put("riskAnalysis", analyzeLegalRisks(content, scannerDto.getDocumentType()));
        }

        // Compliance Check
        if (scannerDto.isIncludeComplianceCheck()) {
            analysis.put("complianceCheck", checkCompliance(content, scannerDto.getJurisdiction()));
        }

        // Clause Analysis
        if (scannerDto.isIncludeClauseAnalysis()) {
            analysis.put("clauseAnalysis", analyzeClauses(content));
        }

        // Recommendations
        if (scannerDto.isIncludeRecommendations()) {
            analysis.put("recommendations", generateRecommendations(content, scannerDto.getDocumentType()));
        }

        // Key Information Extraction
        analysis.put("keyInformation", extractKeyInformation(content));

        // Document Summary
        analysis.put("summary", generateDocumentSummary(content, scannerDto.getDocumentType()));

        return analysis;
    }

    private Map<String, Object> analyzeDocumentStructure(String content) {
        Map<String, Object> structure = new HashMap<>();

        // Count sections, paragraphs, etc.
        String[] paragraphs = content.split("\n\n");
        String[] sentences = content.split("[.!?]+");

        structure.put("totalParagraphs", paragraphs.length);
        structure.put("totalSentences", sentences.length);
        structure.put("totalWords", content.split("\\s+").length);
        structure.put("totalCharacters", content.length());

        // Identify document sections
        List<String> sections = new ArrayList<>();
        String[] lines = content.split("\n");
        for (String line : lines) {
            if (line.trim().matches("^[A-Z][A-Z\\s]+$") && line.trim().length() > 3) {
                sections.add(line.trim());
            }
        }
        structure.put("identifiedSections", sections);

        return structure;
    }

    private Map<String, Object> analyzeLegalRisks(String content, String documentType) {
        Map<String, Object> risks = new HashMap<>();

        List<Map<String, Object>> riskList = new ArrayList<>();

        // High-risk keywords detection
        String[] highRiskKeywords = { "unlimited liability", "force majeure", "termination without cause",
                "non-compete", "confidentiality breach", "penalty clause" };

        for (String keyword : highRiskKeywords) {
            if (content.toLowerCase().contains(keyword.toLowerCase())) {
                Map<String, Object> risk = new HashMap<>();
                risk.put("type", "HIGH_RISK_KEYWORD");
                risk.put("keyword", keyword);
                risk.put("description", "Document contains high-risk keyword: " + keyword);
                risk.put("severity", "HIGH");
                riskList.add(risk);
            }
        }

        // Missing essential clauses
        String[] essentialClauses = { "governing law", "dispute resolution", "termination", "liability" };
        List<String> missingClauses = new ArrayList<>();

        for (String clause : essentialClauses) {
            if (!content.toLowerCase().contains(clause.toLowerCase())) {
                missingClauses.add(clause);
            }
        }

        if (!missingClauses.isEmpty()) {
            Map<String, Object> risk = new HashMap<>();
            risk.put("type", "MISSING_ESSENTIAL_CLAUSES");
            risk.put("missingClauses", missingClauses);
            risk.put("description", "Document is missing essential legal clauses");
            risk.put("severity", "MEDIUM");
            riskList.add(risk);
        }

        risks.put("totalRisks", riskList.size());
        risks.put("risks", riskList);
        risks.put("overallRiskLevel", calculateOverallRiskLevel(riskList));

        return risks;
    }

    private String calculateOverallRiskLevel(List<Map<String, Object>> risks) {
        int highRisks = 0, mediumRisks = 0, lowRisks = 0;

        for (Map<String, Object> risk : risks) {
            String severity = (String) risk.get("severity");
            switch (severity) {
                case "HIGH" -> highRisks++;
                case "MEDIUM" -> mediumRisks++;
                case "LOW" -> lowRisks++;
            }
        }

        if (highRisks > 0)
            return "HIGH";
        if (mediumRisks > 2)
            return "MEDIUM";
        return "LOW";
    }

    private Map<String, Object> checkCompliance(String content, String jurisdiction) {
        Map<String, Object> compliance = new HashMap<>();

        List<Map<String, Object>> complianceIssues = new ArrayList<>();

        // India-specific compliance checks
        if ("IN".equals(jurisdiction)) {
            // Check for mandatory clauses in Indian contracts
            if (!content.toLowerCase().contains("governing law") && !content.toLowerCase().contains("indian law")) {
                Map<String, Object> issue = new HashMap<>();
                issue.put("type", "MISSING_GOVERNING_LAW");
                issue.put("description", "Document should specify Indian law as governing law");
                issue.put("recommendation", "Add governing law clause specifying Indian law");
                complianceIssues.add(issue);
            }
        }

        compliance.put("jurisdiction", jurisdiction);
        compliance.put("totalIssues", complianceIssues.size());
        compliance.put("issues", complianceIssues);
        compliance.put("isCompliant", complianceIssues.isEmpty());

        return compliance;
    }

    private Map<String, Object> analyzeClauses(String content) {
        Map<String, Object> clauses = new HashMap<>();

        List<Map<String, Object>> clauseList = new ArrayList<>();

        // Identify and analyze key clauses
        String[] clauseTypes = { "confidentiality", "non-compete", "termination", "liability", "force majeure" };

        for (String clauseType : clauseTypes) {
            if (content.toLowerCase().contains(clauseType.toLowerCase())) {
                Map<String, Object> clause = new HashMap<>();
                clause.put("type", clauseType.toUpperCase());
                clause.put("present", true);
                clause.put("analysis", "Clause found in document");
                clauseList.add(clause);
            }
        }

        clauses.put("totalClauses", clauseList.size());
        clauses.put("clauses", clauseList);

        return clauses;
    }

    private List<String> generateRecommendations(String content, String documentType) {
        List<String> recommendations = new ArrayList<>();

        // General recommendations
        if (content.length() < 500) {
            recommendations.add("Consider adding more detailed terms and conditions");
        }

        if (!content.toLowerCase().contains("governing law")) {
            recommendations.add("Add a governing law clause to specify applicable jurisdiction");
        }

        if (!content.toLowerCase().contains("dispute resolution")) {
            recommendations.add("Include dispute resolution mechanism (arbitration/mediation)");
        }

        // Document type specific recommendations
        switch (documentType) {
            case "NDA" -> {
                recommendations.add("Ensure confidentiality obligations are clearly defined");
                recommendations.add("Specify the duration of confidentiality obligations");
                recommendations.add("Include exceptions to confidentiality (public information, etc.)");
            }
            case "AGREEMENT" -> {
                recommendations.add("Clearly define the scope of work or services");
                recommendations.add("Include payment terms and schedule");
                recommendations.add("Specify termination conditions");
            }
            case "LEASE" -> {
                recommendations.add("Include security deposit terms");
                recommendations.add("Specify maintenance responsibilities");
                recommendations.add("Include renewal and termination provisions");
            }
        }

        return recommendations;
    }

    private Map<String, Object> extractKeyInformation(String content) {
        Map<String, Object> keyInfo = new HashMap<>();

        // Extract dates
        List<String> dates = new ArrayList<>();
        String[] words = content.split("\\s+");
        for (String word : words) {
            if (word.matches("\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}")) {
                dates.add(word);
            }
        }
        keyInfo.put("dates", dates);

        // Extract amounts/money
        List<String> amounts = new ArrayList<>();
        for (String word : words) {
            if (word.matches(".*\\$\\d+.*") || word.matches(".*\\d+\\s*(USD|INR|EUR).*")) {
                amounts.add(word);
            }
        }
        keyInfo.put("amounts", amounts);

        // Extract parties (simple heuristic)
        List<String> parties = new ArrayList<>();
        for (String word : words) {
            if (word.matches(".*[A-Z][a-z]+.*") && word.length() > 3 &&
                    (word.toLowerCase().contains("ltd") || word.toLowerCase().contains("inc") ||
                            word.toLowerCase().contains("corp") || word.toLowerCase().contains("company"))) {
                parties.add(word);
            }
        }
        keyInfo.put("parties", parties);

        return keyInfo;
    }

    private String generateDocumentSummary(String content, String documentType) {
        return String.format("This %s document contains %d words and %d paragraphs. " +
                "The document appears to be a standard %s with typical legal clauses. " +
                "Key sections include terms and conditions, obligations, and dispute resolution mechanisms.",
                documentType.toLowerCase(),
                content.split("\\s+").length,
                content.split("\n\n").length,
                documentType.toLowerCase());
    }

    private Map<String, Object> generateMetadata(DocumentScannerDto scannerDto) {
        Map<String, Object> metadata = new HashMap<>();

        metadata.put("scanTimestamp", scannerDto.getScanTimestamp());
        metadata.put("documentType", scannerDto.getDocumentType());
        metadata.put("language", scannerDto.getLanguage());
        metadata.put("jurisdiction", scannerDto.getJurisdiction());
        metadata.put("industry", scannerDto.getIndustry());
        metadata.put("parties", scannerDto.getParties());
        metadata.put("hasFile", scannerDto.hasFile());

        if (scannerDto.hasFile()) {
            metadata.put("fileName", scannerDto.getDocumentFile().getOriginalFilename());
            metadata.put("fileSize", scannerDto.getFileSize());
            metadata.put("fileExtension", scannerDto.getFileExtension());
        }

        return metadata;
    }
}
