package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.*;
import com.esign.legal_advisor.service.AuthService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/signup")
    public ResponseEntity<MessageResponse> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
        logger.info("User registration attempt for username: {}", signUpRequest.getUsername());

        try {
            MessageResponse response = authService.registerUser(signUpRequest);
            if (response.getMessage().contains("Error:")) {
                return ResponseEntity.badRequest().body(response);
            }
            logger.info("User registered successfully: {}", signUpRequest.getUsername());
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            logger.error("Error during user registration", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Registration failed. Please try again later."));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
        logger.info("Login attempt for username/email: {}", loginRequest.getUsername());

        try {
            JwtResponse response = authService.authenticateUser(loginRequest);
            logger.info("User '{}' logged in successfully - 2FA OTP sent to email", loginRequest.getUsername());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.warn("Login failed for '{}': {}", loginRequest.getUsername(), e.getMessage());

            // Provide more specific error messages
            String errorMessage = "Error: Invalid username/email or password";
            if (e.getMessage().contains("Account is disabled")) {
                errorMessage = "Error: Account is disabled. Please contact support.";
            } else if (e.getMessage().contains("User not found")) {
                errorMessage = "Error: User not found with the provided username or email.";
            }

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new MessageResponse(errorMessage));
        }
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refreshToken(@Valid @RequestBody RefreshTokenRequest request) {
        logger.debug("Token refresh attempt");
        try {
            JwtResponse response = authService.refreshAccessToken(request.getRefreshToken());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.warn("Token refresh failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new MessageResponse("Error: Invalid or expired refresh token"));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<MessageResponse> logout(@RequestBody RefreshTokenRequest request) {
        logger.info("Logout attempt");
        try {
            MessageResponse response = authService.logoutUser(request.getRefreshToken());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error during logout", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Logout failed"));
        }
    }

    @PostMapping("/verify-email")
    public ResponseEntity<MessageResponse> verifyEmail(@Valid @RequestBody EmailVerificationDto verificationDto) {
        logger.info("Email verification attempt for: {}", verificationDto.getEmail());

        try {
            MessageResponse response = authService.verifyEmail(verificationDto.getEmail(), verificationDto.getOtp());
            if (response.getMessage().contains("Error:")) {
                return ResponseEntity.badRequest().body(response);
            }
            logger.info("Email verified successfully: {}", verificationDto.getEmail());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error during email verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Email verification failed. Please try again later."));
        }
    }

    @PostMapping("/resend-otp")
    public ResponseEntity<MessageResponse> resendOtp(@Valid @RequestBody EmailVerificationDto verificationDto) {
        logger.info("OTP resend attempt for: {}", verificationDto.getEmail());

        try {
            MessageResponse response = authService.resendOtp(verificationDto.getEmail());
            if (response.getMessage().contains("Error:")) {
                return ResponseEntity.badRequest().body(response);
            }
            logger.info("OTP resent successfully: {}", verificationDto.getEmail());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error during OTP resend", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to resend OTP. Please try again later."));
        }
    }

    @GetMapping("/verification-status/{email}")
    public ResponseEntity<VerificationStatusDto> getVerificationStatus(@PathVariable String email) {
        logger.info("Verification status check for: {}", email);

        try {
            VerificationStatusDto response = authService.getVerificationStatus(email);
            if ("ERROR".equals(response.getStatus()) || "NOT_FOUND".equals(response.getStatus())) {
                return ResponseEntity.badRequest().body(response);
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error checking verification status", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new VerificationStatusDto(email, false, false, "Failed to check verification status",
                            "ERROR"));
        }
    }

    @GetMapping("/test-email")
    public ResponseEntity<Map<String, Object>> testEmail() {
        logger.info("Testing email configuration");

        try {
            Map<String, Object> result = new HashMap<>();

            // Test email sending
            try {
                authService.testEmailService();
                result.put("emailTest", "SUCCESS");
                result.put("emailMessage", "Email service is working correctly");
            } catch (Exception e) {
                result.put("emailTest", "FAILED");
                result.put("emailMessage", "Email service failed: " + e.getMessage());
            }

            result.put("timestamp", System.currentTimeMillis());
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("Error testing email", e);
            Map<String, Object> errorResult = new HashMap<>();
            errorResult.put("emailTest", "ERROR");
            errorResult.put("emailMessage", "Error testing email: " + e.getMessage());
            errorResult.put("timestamp", System.currentTimeMillis());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResult);
        }
    }

    @GetMapping("/signup-status")
    public ResponseEntity<Map<String, Object>> getSignupStatus() {
        logger.info("Getting signup system status");

        try {
            Map<String, Object> status = new HashMap<>();

            // Check if development mode is enabled
            boolean developmentMode = authService.isDevelopmentMode();
            status.put("developmentMode", developmentMode);

            // Check email service status
            boolean emailServiceEnabled = authService.isEmailServiceEnabled();
            status.put("emailServiceEnabled", emailServiceEnabled);

            // Check verification service status
            boolean verificationServiceEnabled = authService.isVerificationServiceEnabled();
            status.put("verificationServiceEnabled", verificationServiceEnabled);

            // Overall system status
            String systemStatus = "OPERATIONAL";
            String message = "All signup and verification services are working properly";

            if (!emailServiceEnabled) {
                systemStatus = "DEGRADED";
                message = "Email service is not available - using development mode";
            }

            if (developmentMode) {
                systemStatus = "DEVELOPMENT";
                message = "System running in development mode - email verification skipped";
            }

            status.put("systemStatus", systemStatus);
            status.put("message", message);
            status.put("timestamp", System.currentTimeMillis());

            return ResponseEntity.ok(status);
        } catch (Exception e) {
            logger.error("Error getting signup status", e);
            Map<String, Object> errorStatus = new HashMap<>();
            errorStatus.put("systemStatus", "ERROR");
            errorStatus.put("message", "Failed to check signup system status: " + e.getMessage());
            errorStatus.put("timestamp", System.currentTimeMillis());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorStatus);
        }
    }

    @GetMapping("/profile")
    public ResponseEntity<UserDto> getCurrentUserProfile() {
        logger.info("Getting current user profile");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                logger.warn("No authenticated user found");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }

            String username = authentication.getName();
            logger.info("Username from authentication: {}", username);

            UserDto userProfile = authService.getCurrentUserProfile(username);
            logger.info("Retrieved profile for user: {}", userProfile.getUsername());
            return ResponseEntity.ok(userProfile);
        } catch (Exception e) {
            logger.error("Error getting user profile: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/profile")
    public ResponseEntity<Map<String, Object>> updateProfile(@RequestBody Map<String, Object> profileData) {
        logger.info("Updating user profile");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                logger.warn("No authenticated user found");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("success", false, "message", "Authentication required"));
            }

            String username = authentication.getName();
            UserDto updatedUser = authService.updateUserProfile(username, profileData);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Profile updated successfully",
                    "user", updatedUser));
        } catch (Exception e) {
            logger.error("Error updating user profile: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("success", false, "message", "Failed to update profile: " + e.getMessage()));
        }
    }

    @PutMapping("/change-password")
    public ResponseEntity<Map<String, Object>> changePassword(@RequestBody Map<String, String> passwordData) {
        logger.info("Changing user password");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                logger.warn("No authenticated user found");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("success", false, "message", "Authentication required"));
            }

            String username = authentication.getName();
            String currentPassword = passwordData.get("currentPassword");
            String newPassword = passwordData.get("newPassword");

            if (currentPassword == null || newPassword == null) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "message", "Current password and new password are required"));
            }

            boolean success = authService.changePassword(username, currentPassword, newPassword);

            if (success) {
                return ResponseEntity.ok(Map.of(
                        "success", true,
                        "message", "Password changed successfully"));
            } else {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "message", "Current password is incorrect"));
            }
        } catch (Exception e) {
            logger.error("Error changing password: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("success", false, "message", "Failed to change password: " + e.getMessage()));
        }
    }

    @PostMapping("/upload-profile-picture")
    public ResponseEntity<Map<String, Object>> uploadProfilePicture(@RequestParam("file") MultipartFile file) {
        logger.info("Uploading profile picture");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                logger.warn("No authenticated user found");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("success", false, "message", "Authentication required"));
            }

            String username = authentication.getName();

            // Validate file
            if (file.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "message", "File is empty"));
            }

            // Check file type
            String contentType = file.getContentType();
            if (contentType == null || !contentType.startsWith("image/")) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "message", "File must be an image"));
            }

            // Check file size (max 5MB)
            if (file.getSize() > 5 * 1024 * 1024) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "message", "File size must be less than 5MB"));
            }

            // For now, we'll store the file as base64 in the database
            // In production, you'd want to store files in cloud storage or file system
            String base64Image = "data:" + contentType + ";base64," +
                    java.util.Base64.getEncoder().encodeToString(file.getBytes());

            // Update user profile with new picture
            Map<String, Object> profileData = Map.of("profilePicture", base64Image);
            UserDto updatedUser = authService.updateUserProfile(username, profileData);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Profile picture uploaded successfully",
                    "user", updatedUser));
        } catch (Exception e) {
            logger.error("Error uploading profile picture: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("success", false, "message", "Failed to upload profile picture: " + e.getMessage()));
        }
    }

    @GetMapping("/preferences")
    public ResponseEntity<Map<String, Object>> getUserPreferences() {
        logger.info("Getting user preferences");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                logger.warn("No authenticated user found");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("success", false, "message", "Authentication required"));
            }

            String username = authentication.getName();
            Map<String, Object> preferences = authService.getUserPreferences(username);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "preferences", preferences));
        } catch (Exception e) {
            logger.error("Error getting user preferences: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("success", false, "message", "Failed to get preferences: " + e.getMessage()));
        }
    }

    @PutMapping("/preferences")
    public ResponseEntity<Map<String, Object>> updateUserPreferences(@RequestBody Map<String, Object> preferencesData) {
        logger.info("Updating user preferences");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                logger.warn("No authenticated user found");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("success", false, "message", "Authentication required"));
            }

            String username = authentication.getName();
            Map<String, Object> updatedPreferences = authService.updateUserPreferences(username, preferencesData);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Preferences updated successfully",
                    "preferences", updatedPreferences));
        } catch (Exception e) {
            logger.error("Error updating user preferences: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("success", false, "message", "Failed to update preferences: " + e.getMessage()));
        }
    }

    @GetMapping("/test-profile")
    public ResponseEntity<Map<String, Object>> testProfile() {
        logger.info("Testing profile endpoint");

        try {
            Map<String, Object> result = new HashMap<>();
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            if (authentication == null) {
                result.put("error", "No authentication found");
                return ResponseEntity.ok(result);
            }

            result.put("username", authentication.getName());
            result.put("authenticated", authentication.isAuthenticated());
            result.put("authorities", authentication.getAuthorities().stream().map(Object::toString).toList());

            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("Error in test profile: {}", e.getMessage(), e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }
}
