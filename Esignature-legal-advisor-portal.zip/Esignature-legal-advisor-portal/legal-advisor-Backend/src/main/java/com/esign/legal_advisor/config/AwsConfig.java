package com.esign.legal_advisor.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sagemakerruntime.SageMakerRuntimeClient;

@Configuration
public class AwsConfig {

    @Value("${aws.access.key.id:}")
    private String awsAccessKeyId;

    @Value("${aws.secret.access.key:}")
    private String awsSecretAccessKey;

    @Value("${aws.region:us-east-1}")
    private String awsRegion;

    @Bean
    public SageMakerRuntimeClient sageMakerRuntimeClient() {
        // If credentials are provided, use them; otherwise, use default credential chain
        if (awsAccessKeyId != null && !awsAccessKeyId.isEmpty() && 
            awsSecretAccessKey != null && !awsSecretAccessKey.isEmpty()) {
            
            AwsBasicCredentials awsCredentials = AwsBasicCredentials.create(awsAccessKeyId, awsSecretAccessKey);
            
            return SageMakerRuntimeClient.builder()
                    .region(Region.of(awsRegion))
                    .credentialsProvider(StaticCredentialsProvider.create(awsCredentials))
                    .build();
        } else {
            // Use default credential chain (IAM roles, environment variables, etc.)
            return SageMakerRuntimeClient.builder()
                    .region(Region.of(awsRegion))
                    .build();
        }
    }
}
