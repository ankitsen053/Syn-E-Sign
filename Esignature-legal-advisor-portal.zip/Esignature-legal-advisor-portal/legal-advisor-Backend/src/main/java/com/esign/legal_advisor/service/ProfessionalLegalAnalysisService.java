package com.esign.legal_advisor.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ProfessionalLegalAnalysisService {

    private static final Logger logger = LoggerFactory.getLogger(ProfessionalLegalAnalysisService.class);

    @Autowired
    private HuggingFaceService huggingFaceService;

    /**
     * Perform professional-grade legal document analysis for lawyers
     */
    public Map<String, Object> performProfessionalLegalAnalysis(String documentContent, String userType) {
        Map<String, Object> analysis = new HashMap<>();

        try {
            logger.info("Performing professional legal analysis for user type: {}", userType);

            // Enhanced analysis based on user type
            if (isLawyerUser(userType)) {
                analysis = performLawyerGradeAnalysis(documentContent);
            } else {
                analysis = performStandardAnalysis(documentContent);
            }

            // Add professional metadata
            analysis.put("analysisType", "PROFESSIONAL_LEGAL");
            analysis.put("analysisVersion", "2.0");
            analysis.put("userType", userType);
            analysis.put("timestamp", System.currentTimeMillis());

            return analysis;

        } catch (Exception e) {
            logger.error("Error in professional legal analysis", e);
            analysis.put("error", "Professional analysis failed: " + e.getMessage());
            return analysis;
        }
    }

    /**
     * Perform lawyer-grade analysis with enhanced accuracy
     */
    private Map<String, Object> performLawyerGradeAnalysis(String documentContent) {
        Map<String, Object> analysis = new HashMap<>();

        try {
            // Comprehensive legal analysis
            analysis.put("executiveSummary", huggingFaceService.analyzeLegalDocument(documentContent));

            // Enhanced issue detection
            analysis.put("criticalIssues", huggingFaceService.highlightLegalIssues(documentContent));

            // Risk assessment
            analysis.put("riskAnalysis", huggingFaceService.performRiskAnalysis(documentContent));

            // Compliance assessment
            analysis.put("complianceAssessment", huggingFaceService.assessLegalCompliance(documentContent, "IN"));

            // Professional recommendations
            analysis.put("professionalRecommendations", generateProfessionalRecommendations(documentContent));

            // Legal score with detailed breakdown
            analysis.put("legalScore", calculateProfessionalLegalScore(documentContent));

            // Missing clauses analysis
            analysis.put("missingClauses", identifyMissingClauses(documentContent));

            // Enforceability assessment
            analysis.put("enforceabilityAssessment", assessEnforceability(documentContent));

            return analysis;

        } catch (Exception e) {
            logger.error("Error in lawyer-grade analysis", e);
            throw new RuntimeException("Lawyer-grade analysis failed: " + e.getMessage());
        }
    }

    /**
     * Perform standard analysis for non-lawyer users
     */
    private Map<String, Object> performStandardAnalysis(String documentContent) {
        Map<String, Object> analysis = new HashMap<>();

        try {
            analysis.put("overallAnalysis", huggingFaceService.analyzeLegalDocument(documentContent));
            analysis.put("issues", huggingFaceService.highlightLegalIssues(documentContent));
            analysis.put("riskAnalysis", huggingFaceService.performRiskAnalysis(documentContent));
            analysis.put("complianceAssessment", huggingFaceService.assessLegalCompliance(documentContent, "IN"));

            return analysis;

        } catch (Exception e) {
            logger.error("Error in standard analysis", e);
            throw new RuntimeException("Standard analysis failed: " + e.getMessage());
        }
    }

    /**
     * Generate professional recommendations for lawyers
     */
    private String generateProfessionalRecommendations(String documentContent) {
        String prompt = String.format("""
                You are a senior legal partner providing strategic recommendations to fellow lawyers.

                Based on the following document analysis:

                %s

                Provide professional recommendations including:

                1. IMMEDIATE ACTIONS REQUIRED:
                - Critical issues needing immediate attention
                - Legal risks requiring urgent mitigation
                - Compliance gaps requiring immediate correction

                2. STRATEGIC RECOMMENDATIONS:
                - Long-term legal strategy considerations
                - Client advisory recommendations
                - Risk management improvements

                3. NEGOTIATION GUIDANCE:
                - Key negotiation points and priorities
                - Fallback positions and alternatives
                - Client protection strategies

                4. IMPLEMENTATION ROADMAP:
                - Phased approach to document improvement
                - Resource requirements and timeline
                - Success metrics and monitoring

                Provide actionable, professional guidance suitable for senior legal counsel.
                """, documentContent);

        try {
            return huggingFaceService.analyzeLegalDocument(prompt);
        } catch (Exception e) {
            logger.error("Error generating professional recommendations", e);
            return "Professional recommendations generation failed: " + e.getMessage();
        }
    }

    /**
     * Calculate professional legal score with detailed breakdown
     */
    private Map<String, Object> calculateProfessionalLegalScore(String documentContent) {
        Map<String, Object> score = new HashMap<>();

        try {
            // This would typically involve more sophisticated scoring algorithms
            // For now, we'll use a simplified approach
            int overallScore = 75; // Base score

            // Adjust based on document analysis
            if (documentContent.contains("governing law"))
                overallScore += 5;
            if (documentContent.contains("dispute resolution"))
                overallScore += 5;
            if (documentContent.contains("termination"))
                overallScore += 5;
            if (documentContent.contains("confidentiality"))
                overallScore += 5;
            if (documentContent.contains("indemnification"))
                overallScore += 5;

            score.put("overallScore", Math.min(100, overallScore));
            score.put("structureScore", 80);
            score.put("clarityScore", 75);
            score.put("completenessScore", 70);
            score.put("enforceabilityScore", 85);
            score.put("riskMitigationScore", 75);

            return score;

        } catch (Exception e) {
            logger.error("Error calculating professional legal score", e);
            score.put("overallScore", 0);
            score.put("error", "Score calculation failed");
            return score;
        }
    }

    /**
     * Identify missing clauses for professional lawyers
     */
    private String identifyMissingClauses(String documentContent) {
        String prompt = String.format("""
                You are a legal expert identifying missing essential clauses in legal documents.

                Analyze the following document for missing clauses:

                %s

                Identify and prioritize missing clauses:

                1. CRITICAL MISSING CLAUSES:
                - Essential legal protections
                - Required statutory provisions
                - Fundamental contract elements

                2. IMPORTANT MISSING CLAUSES:
                - Standard industry protections
                - Risk mitigation provisions
                - Operational requirements

                3. RECOMMENDED CLAUSES:
                - Best practice provisions
                - Additional protections
                - Efficiency improvements

                For each missing clause, provide:
                - Clause name and purpose
                - Priority level
                - Sample language
                - Legal rationale

                Present in professional legal format.
                """, documentContent);

        try {
            return huggingFaceService.analyzeLegalDocument(prompt);
        } catch (Exception e) {
            logger.error("Error identifying missing clauses", e);
            return "Missing clauses analysis failed: " + e.getMessage();
        }
    }

    /**
     * Assess document enforceability
     */
    private String assessEnforceability(String documentContent) {
        String prompt = String.format("""
                You are a legal expert assessing document enforceability in courts.

                Assess the enforceability of the following document:

                %s

                Provide enforceability assessment covering:

                1. CONTRACT FORMATION:
                - Offer, acceptance, consideration
                - Mutual assent and meeting of minds
                - Legal capacity of parties

                2. LEGAL VALIDITY:
                - Compliance with applicable laws
                - Public policy considerations
                - Unconscionability analysis

                3. ENFORCEMENT MECHANISMS:
                - Dispute resolution adequacy
                - Remedies and damages
                - Performance standards

                4. RISK FACTORS:
                - Potential challenges to enforceability
                - Weaknesses in legal structure
                - Recommendations for improvement

                Provide professional legal assessment with specific recommendations.
                """, documentContent);

        try {
            return huggingFaceService.analyzeLegalDocument(prompt);
        } catch (Exception e) {
            logger.error("Error assessing enforceability", e);
            return "Enforceability assessment failed: " + e.getMessage();
        }
    }

    /**
     * Check if user is a lawyer type
     */
    private boolean isLawyerUser(String userType) {
        return userType != null && (userType.equals("LAWYER") ||
                userType.equals("SENIOR_LAWYER") ||
                userType.equals("LEGAL_FIRM"));
    }
}
