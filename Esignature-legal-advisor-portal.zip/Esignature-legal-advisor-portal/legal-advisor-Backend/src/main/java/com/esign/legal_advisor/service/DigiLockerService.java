package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.DocumentAnalysisRequest;
import com.esign.legal_advisor.dto.DocumentAnalysisResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.Base64;

@Service
@RequiredArgsConstructor
public class DigiLockerService {

    private static final Logger logger = LoggerFactory.getLogger(DigiLockerService.class);

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final DocumentTextExtractionService textExtractionService;
    private final SageMakerDocumentAnalysisService sageMakerAnalysisService;

    // DigiLocker API Configuration
    @Value("${digilocker.api.url:https://api.digitallocker.gov.in}")
    private String digiLockerApiUrl;

    @Value("${digilocker.client.id:}")
    private String clientId;

    @Value("${digilocker.client.secret:}")
    private String clientSecret;

    @Value("${digilocker.api.key:}")
    private String apiKey;

    // Document Upload Configuration
    @Value("${digilocker.upload.directory:uploads/documents}")
    private String uploadDirectory;

    @Value("${digilocker.upload.max-size:10485760}") // 10MB default
    private long maxFileSize;

    @Value("${digilocker.upload.allowed-types:pdf,jpg,jpeg,png}")
    private String allowedFileTypes;

    // Supported document types
    private static final List<String> SUPPORTED_DOCUMENT_TYPES = List.of(
            "AADHAAR", "PAN", "DRIVING_LICENSE", "PASSPORT", "VOTER_ID", "RATION_CARD");

    // Allowed file extensions
    private static final List<String> ALLOWED_EXTENSIONS = List.of(
            "pdf", "jpg", "jpeg", "png", "tiff", "bmp");

    // DigiLocker API Endpoints
    private static final String DOCUMENTS_ENDPOINT = "/1/documents";
    private static final String AADHAAR_ENDPOINT = "/1/aadhaar";
    private static final String PAN_ENDPOINT = "/1/pan";

    /**
     * Legacy method for backward compatibility - verifies DigiLocker ID
     */
    public DigiLockerVerificationResult verifyDigiLockerId(String digiLockerId) {
        logger.info("Legacy DigiLocker ID verification for ID: {}", maskDigiLockerId(digiLockerId));

        DigiLockerVerificationResult result = new DigiLockerVerificationResult();
        result.setVerificationTime(LocalDateTime.now());
        result.setDigiLockerId(digiLockerId);

        // Return mock successful result for backward compatibility
        result.setSuccess(true);
        result.setTotalDocuments(2);
        result.setDocuments(new ArrayList<>());

        // Create mock documents
        DigiLockerDocument aadhaarDoc = new DigiLockerDocument();
        aadhaarDoc.setDocumentType("AADHAAR");
        aadhaarDoc.setVerified(true);

        DigiLockerDocument panDoc = new DigiLockerDocument();
        panDoc.setDocumentType("PAN");
        panDoc.setVerified(true);

        result.setAadhaarDocument(aadhaarDoc);
        result.setPanDocument(panDoc);

        return result;
    }

    /**
     * Process uploaded document for verification
     */
    public DigiLockerVerificationResult processUploadedDocument(
            String documentType,
            MultipartFile documentFile,
            String customerMobile,
            String verificationToken) {

        logger.info("Starting document upload processing for type: {}, customer: {}, token: {}",
                documentType, maskMobileNumber(customerMobile),
                verificationToken.substring(0, 8) + "****");

        DigiLockerVerificationResult result = new DigiLockerVerificationResult();
        result.setVerificationTime(LocalDateTime.now());
        result.setDocuments(new ArrayList<>());

        try {
            // Validate document type
            if (!SUPPORTED_DOCUMENT_TYPES.contains(documentType.toUpperCase())) {
                result.setSuccess(false);
                result.setErrorMessage("Unsupported document type: " + documentType);
                return result;
            }

            // Validate file upload
            DocumentUploadValidation validation = validateDocumentUpload(documentFile, documentType);
            if (!validation.isValid()) {
                result.setSuccess(false);
                result.setErrorMessage(validation.getErrorMessage());
                return result;
            }

            // Save uploaded document
            UploadedDocumentInfo uploadInfo = saveUploadedDocument(documentFile, documentType, verificationToken);

            // Process and verify document content
            DocumentVerificationResult docResult = processDocumentContent(uploadInfo, documentType, customerMobile);

            // Create DigiLocker document representation
            DigiLockerDocument document = createDocumentFromUpload(uploadInfo, docResult, documentType);
            result.getDocuments().add(document);

            // Set document type specific results
            switch (documentType.toUpperCase()) {
                case "AADHAAR":
                    result.setAadhaarDocument(document);
                    break;
                case "PAN":
                    result.setPanDocument(document);
                    break;
                case "DRIVING_LICENSE":
                    result.setDrivingLicenseDocument(document);
                    break;
                case "PASSPORT":
                    result.setPassportDocument(document);
                    break;
            }

            result.setSuccess(true);
            result.setTotalDocuments(1);
            result.setDigiLockerId(generateDocumentId(customerMobile, documentType));

            logger.info("Document upload processing completed successfully for type: {} - File: {}",
                    documentType, uploadInfo.getOriginalFileName());

        } catch (Exception e) {
            logger.error("Error during document upload processing for type: {}", documentType, e);
            result.setSuccess(false);
            result.setErrorMessage("Document processing failed: " + e.getMessage());
        }

        return result;
    }

    /**
     * Fetch Aadhaar details using DigiLocker ID
     */
    public AadhaarDetails fetchAadhaarDetails(String digiLockerId) {
        logger.info("Fetching Aadhaar details for DigiLocker ID: {}", maskDigiLockerId(digiLockerId));

        try {
            HttpHeaders headers = createHeaders();

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("digilocker_id", digiLockerId);
            requestBody.put("consent", "Y");
            requestBody.put("consent_text", "I hereby give my consent to fetch my Aadhaar details from DigiLocker");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    digiLockerApiUrl + AADHAAR_ENDPOINT, request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());
                return parseAadhaarDetails(jsonResponse);
            }

        } catch (Exception e) {
            logger.error("Error fetching Aadhaar details from DigiLocker", e);
            // Return mock data for development
            return createMockAadhaarDetails(digiLockerId);
        }

        return null;
    }

    /**
     * Fetch PAN details using DigiLocker ID
     */
    public PanDetails fetchPanDetails(String digiLockerId) {
        logger.info("Fetching PAN details for DigiLocker ID: {}", maskDigiLockerId(digiLockerId));

        try {
            HttpHeaders headers = createHeaders();

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("digilocker_id", digiLockerId);
            requestBody.put("consent", "Y");
            requestBody.put("consent_text", "I hereby give my consent to fetch my PAN details from DigiLocker");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(
                    digiLockerApiUrl + PAN_ENDPOINT, request, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());
                return parsePanDetails(jsonResponse);
            }

        } catch (Exception e) {
            logger.error("Error fetching PAN details from DigiLocker", e);
            // Return mock data for development
            return createMockPanDetails(digiLockerId);
        }

        return null;
    }

    /**
     * Fetch all available documents for a DigiLocker ID
     */
    private List<DigiLockerDocument> fetchUserDocuments(String digiLockerId) throws Exception {
        HttpHeaders headers = createHeaders();

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("digilocker_id", digiLockerId);

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

        ResponseEntity<String> response = restTemplate.postForEntity(
                digiLockerApiUrl + DOCUMENTS_ENDPOINT, request, String.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            JsonNode jsonResponse = objectMapper.readTree(response.getBody());
            return parseDocumentsList(jsonResponse);
        }

        throw new RuntimeException("Failed to fetch documents from DigiLocker");
    }

    /**
     * Create HTTP headers for DigiLocker API requests
     */
    private HttpHeaders createHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        if (apiKey != null && !apiKey.isEmpty()) {
            headers.set("Authorization", "Bearer " + apiKey);
        }

        if (clientId != null && !clientId.isEmpty()) {
            headers.set("X-Client-Id", clientId);
        }

        return headers;
    }

    /**
     * Validate DigiLocker ID format
     */
    private boolean isValidDigiLockerId(String digiLockerId) {
        if (digiLockerId == null)
            return false;

        // Remove hyphens for validation
        String cleanId = digiLockerId.replace("-", "");

        // Should be 32 hexadecimal characters
        return cleanId.length() == 32 &&
                cleanId.matches("^[a-fA-F0-9]{32}$");
    }

    /**
     * Normalize DigiLocker ID to standard format with hyphens
     */
    private String normalizeDigiLockerId(String digiLockerId) {
        if (digiLockerId == null)
            return null;

        // Remove existing hyphens
        String cleanId = digiLockerId.replace("-", "");

        // Add hyphens in standard UUID format: 8-4-4-4-12
        if (cleanId.length() == 32) {
            return String.format("%s-%s-%s-%s-%s",
                    cleanId.substring(0, 8),
                    cleanId.substring(8, 12),
                    cleanId.substring(12, 16),
                    cleanId.substring(16, 20),
                    cleanId.substring(20, 32));
        }

        return digiLockerId; // Return as-is if not 32 characters
    }

    /**
     * Mask DigiLocker ID for logging
     */
    private String maskDigiLockerId(String digiLockerId) {
        if (digiLockerId == null || digiLockerId.length() < 8)
            return "****";
        String normalized = normalizeDigiLockerId(digiLockerId);
        if (normalized == null || normalized.length() < 8)
            return "****";
        return normalized.substring(0, 8) + "****" + normalized.substring(normalized.length() - 4);
    }

    /**
     * Parse documents list from DigiLocker API response
     */
    private List<DigiLockerDocument> parseDocumentsList(JsonNode response) {
        List<DigiLockerDocument> documents = new ArrayList<>();

        if (response.has("documents") && response.get("documents").isArray()) {
            for (JsonNode docNode : response.get("documents")) {
                DigiLockerDocument doc = new DigiLockerDocument();
                doc.setDocumentId(docNode.path("document_id").asText());
                doc.setDocumentType(docNode.path("type").asText());
                doc.setDocumentName(docNode.path("name").asText());
                doc.setIssuer(docNode.path("issuer").asText());
                doc.setIssueDate(docNode.path("issue_date").asText());
                doc.setVerified(docNode.path("verified").asBoolean());
                documents.add(doc);
            }
        }

        return documents;
    }

    /**
     * Extract Aadhaar document from documents list
     */
    private DigiLockerDocument extractAadhaarDocument(List<DigiLockerDocument> documents, String digiLockerId) {
        return documents.stream()
                .filter(doc -> "AADHAAR".equalsIgnoreCase(doc.getDocumentType()) ||
                        doc.getDocumentName().toLowerCase().contains("aadhaar"))
                .findFirst()
                .orElse(null);
    }

    /**
     * Extract PAN document from documents list
     */
    private DigiLockerDocument extractPanDocument(List<DigiLockerDocument> documents, String digiLockerId) {
        return documents.stream()
                .filter(doc -> "PAN".equalsIgnoreCase(doc.getDocumentType()) ||
                        doc.getDocumentName().toLowerCase().contains("pan"))
                .findFirst()
                .orElse(null);
    }

    /**
     * Extract Driving License document from documents list
     */
    private DigiLockerDocument extractDrivingLicenseDocument(List<DigiLockerDocument> documents, String digiLockerId) {
        return documents.stream()
                .filter(doc -> "DRIVING_LICENSE".equalsIgnoreCase(doc.getDocumentType()) ||
                        doc.getDocumentName().toLowerCase().contains("driving") ||
                        doc.getDocumentName().toLowerCase().contains("license"))
                .findFirst()
                .orElse(null);
    }

    /**
     * Extract Passport document from documents list
     */
    private DigiLockerDocument extractPassportDocument(List<DigiLockerDocument> documents, String digiLockerId) {
        return documents.stream()
                .filter(doc -> "PASSPORT".equalsIgnoreCase(doc.getDocumentType()) ||
                        doc.getDocumentName().toLowerCase().contains("passport"))
                .findFirst()
                .orElse(null);
    }

    /**
     * Parse Aadhaar details from API response
     */
    private AadhaarDetails parseAadhaarDetails(JsonNode response) {
        AadhaarDetails details = new AadhaarDetails();

        if (response.has("data")) {
            JsonNode data = response.get("data");
            details.setAadhaarNumber(data.path("aadhaar_number").asText());
            details.setName(data.path("name").asText());
            details.setFatherName(data.path("father_name").asText());
            details.setDateOfBirth(data.path("dob").asText());
            details.setGender(data.path("gender").asText());
            details.setAddress(data.path("address").asText());
            details.setMobileNumber(data.path("mobile").asText());
            details.setEmailId(data.path("email").asText());
            details.setVerified(data.path("verified").asBoolean(true));
        }

        return details;
    }

    /**
     * Parse PAN details from API response
     */
    private PanDetails parsePanDetails(JsonNode response) {
        PanDetails details = new PanDetails();

        if (response.has("data")) {
            JsonNode data = response.get("data");
            details.setPanNumber(data.path("pan_number").asText());
            details.setName(data.path("name").asText());
            details.setFatherName(data.path("father_name").asText());
            details.setDateOfBirth(data.path("dob").asText());
            details.setVerified(data.path("verified").asBoolean(true));
        }

        return details;
    }

    /**
     * Create mock DigiLocker verification for development
     */
    private DigiLockerVerificationResult createMockDigiLockerVerification(String digiLockerId) {
        logger.info("Creating mock DigiLocker verification for development");

        DigiLockerVerificationResult result = new DigiLockerVerificationResult();
        result.setDigiLockerId(digiLockerId);
        result.setSuccess(true);
        result.setVerificationTime(LocalDateTime.now());
        result.setTotalDocuments(4);

        // Mock documents
        List<DigiLockerDocument> mockDocuments = new ArrayList<>();

        // Mock Aadhaar
        DigiLockerDocument aadhaar = new DigiLockerDocument();
        aadhaar.setDocumentId("AADHAAR_" + System.currentTimeMillis());
        aadhaar.setDocumentType("AADHAAR");
        aadhaar.setDocumentName("Aadhaar Card");
        aadhaar.setIssuer("UIDAI");
        aadhaar.setIssueDate("2020-01-15");
        aadhaar.setVerified(true);
        mockDocuments.add(aadhaar);

        // Mock PAN
        DigiLockerDocument pan = new DigiLockerDocument();
        pan.setDocumentId("PAN_" + System.currentTimeMillis());
        pan.setDocumentType("PAN");
        pan.setDocumentName("PAN Card");
        pan.setIssuer("Income Tax Department");
        pan.setIssueDate("2019-05-10");
        pan.setVerified(true);
        mockDocuments.add(pan);

        result.setDocuments(mockDocuments);
        result.setAadhaarDocument(aadhaar);
        result.setPanDocument(pan);

        return result;
    }

    /**
     * Create mock Aadhaar details for development
     */
    private AadhaarDetails createMockAadhaarDetails(String digiLockerId) {
        AadhaarDetails details = new AadhaarDetails();
        details.setAadhaarNumber("123456789012");
        details.setName("John Doe");
        details.setFatherName("James Doe");
        details.setDateOfBirth("1990-01-01");
        details.setGender("Male");
        details.setAddress("123 Main Street, City, State - 123456");
        details.setMobileNumber("+91-9876543210");
        details.setEmailId("john.doe@example.com");
        details.setVerified(true);
        return details;
    }

    /**
     * Create mock PAN details for development
     */
    private PanDetails createMockPanDetails(String digiLockerId) {
        PanDetails details = new PanDetails();
        details.setPanNumber("ABCDE1234F");
        details.setName("John Doe");
        details.setFatherName("James Doe");
        details.setDateOfBirth("1990-01-01");
        details.setVerified(true);
        return details;
    }

    // Inner classes for data structures

    public static class DigiLockerVerificationResult {
        private String digiLockerId;
        private boolean success;
        private String errorMessage;
        private LocalDateTime verificationTime;
        private int totalDocuments;
        private List<DigiLockerDocument> documents;
        private DigiLockerDocument aadhaarDocument;
        private DigiLockerDocument panDocument;
        private DigiLockerDocument drivingLicenseDocument;
        private DigiLockerDocument passportDocument;

        // Getters and Setters
        public String getDigiLockerId() {
            return digiLockerId;
        }

        public void setDigiLockerId(String digiLockerId) {
            this.digiLockerId = digiLockerId;
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }

        public LocalDateTime getVerificationTime() {
            return verificationTime;
        }

        public void setVerificationTime(LocalDateTime verificationTime) {
            this.verificationTime = verificationTime;
        }

        public int getTotalDocuments() {
            return totalDocuments;
        }

        public void setTotalDocuments(int totalDocuments) {
            this.totalDocuments = totalDocuments;
        }

        public List<DigiLockerDocument> getDocuments() {
            return documents;
        }

        public void setDocuments(List<DigiLockerDocument> documents) {
            this.documents = documents;
        }

        public DigiLockerDocument getAadhaarDocument() {
            return aadhaarDocument;
        }

        public void setAadhaarDocument(DigiLockerDocument aadhaarDocument) {
            this.aadhaarDocument = aadhaarDocument;
        }

        public DigiLockerDocument getPanDocument() {
            return panDocument;
        }

        public void setPanDocument(DigiLockerDocument panDocument) {
            this.panDocument = panDocument;
        }

        public DigiLockerDocument getDrivingLicenseDocument() {
            return drivingLicenseDocument;
        }

        public void setDrivingLicenseDocument(DigiLockerDocument drivingLicenseDocument) {
            this.drivingLicenseDocument = drivingLicenseDocument;
        }

        public DigiLockerDocument getPassportDocument() {
            return passportDocument;
        }

        public void setPassportDocument(DigiLockerDocument passportDocument) {
            this.passportDocument = passportDocument;
        }
    }

    public static class DigiLockerDocument {
        private String documentId;
        private String documentType;
        private String documentName;
        private String issuer;
        private String issueDate;
        private boolean verified;

        // Additional fields for upload functionality
        private String documentIssuer;
        private long documentSize;
        private String documentFormat;
        private String verificationStatus;
        private String documentUrl;
        private Map<String, Object> metadata;

        // Getters and Setters
        public String getDocumentId() {
            return documentId;
        }

        public void setDocumentId(String documentId) {
            this.documentId = documentId;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }

        public String getDocumentName() {
            return documentName;
        }

        public void setDocumentName(String documentName) {
            this.documentName = documentName;
        }

        public String getIssuer() {
            return issuer;
        }

        public void setIssuer(String issuer) {
            this.issuer = issuer;
        }

        public String getIssueDate() {
            return issueDate;
        }

        public void setIssueDate(String issueDate) {
            this.issueDate = issueDate;
        }

        public boolean isVerified() {
            return verified;
        }

        public void setVerified(boolean verified) {
            this.verified = verified;
        }

        // Additional getters and setters for upload functionality
        public String getDocumentIssuer() {
            return documentIssuer;
        }

        public void setDocumentIssuer(String documentIssuer) {
            this.documentIssuer = documentIssuer;
        }

        public long getDocumentSize() {
            return documentSize;
        }

        public void setDocumentSize(long documentSize) {
            this.documentSize = documentSize;
        }

        public String getDocumentFormat() {
            return documentFormat;
        }

        public void setDocumentFormat(String documentFormat) {
            this.documentFormat = documentFormat;
        }

        public String getVerificationStatus() {
            return verificationStatus;
        }

        public void setVerificationStatus(String verificationStatus) {
            this.verificationStatus = verificationStatus;
        }

        public String getDocumentUrl() {
            return documentUrl;
        }

        public void setDocumentUrl(String documentUrl) {
            this.documentUrl = documentUrl;
        }

        public Map<String, Object> getMetadata() {
            return metadata;
        }

        public void setMetadata(Map<String, Object> metadata) {
            this.metadata = metadata;
        }
    }

    /**
     * Validate uploaded document file
     */
    private DocumentUploadValidation validateDocumentUpload(MultipartFile file, String documentType) {
        DocumentUploadValidation validation = new DocumentUploadValidation();

        if (file == null || file.isEmpty()) {
            validation.setValid(false);
            validation.setErrorMessage("No file uploaded");
            return validation;
        }

        // Check file size
        if (file.getSize() > maxFileSize) {
            validation.setValid(false);
            validation.setErrorMessage("File size exceeds maximum limit of " + (maxFileSize / 1024 / 1024) + "MB");
            return validation;
        }

        // Check file extension
        String filename = file.getOriginalFilename();
        if (filename == null || !hasValidExtension(filename)) {
            validation.setValid(false);
            validation.setErrorMessage("Invalid file type. Allowed types: " + ALLOWED_EXTENSIONS);
            return validation;
        }

        validation.setValid(true);
        return validation;
    }

    /**
     * Check if file has valid extension
     */
    private boolean hasValidExtension(String filename) {
        String extension = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
        return ALLOWED_EXTENSIONS.contains(extension);
    }

    /**
     * Save uploaded document to storage
     */
    private UploadedDocumentInfo saveUploadedDocument(MultipartFile file, String documentType, String verificationToken)
            throws IOException {
        // Create upload directory if not exists
        Path uploadPath = Paths.get(uploadDirectory);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        // Generate unique filename
        String originalFilename = file.getOriginalFilename();
        String extension = originalFilename.substring(originalFilename.lastIndexOf('.'));
        String uniqueFilename = UUID.randomUUID().toString() + extension;

        // Save file
        Path filePath = uploadPath.resolve(uniqueFilename);
        Files.copy(file.getInputStream(), filePath);

        // Create upload info
        UploadedDocumentInfo uploadInfo = new UploadedDocumentInfo();
        uploadInfo.setOriginalFileName(originalFilename);
        uploadInfo.setStoredFileName(uniqueFilename);
        uploadInfo.setFilePath(filePath.toString());
        uploadInfo.setFileSize(file.getSize());
        uploadInfo.setContentType(file.getContentType());
        uploadInfo.setDocumentType(documentType);
        uploadInfo.setVerificationToken(verificationToken);
        uploadInfo.setUploadTime(LocalDateTime.now());

        logger.info("Document saved successfully: {} -> {}", originalFilename, uniqueFilename);
        return uploadInfo;
    }

    /**
     * Process document content for verification using SageMaker AI models
     */
    private DocumentVerificationResult processDocumentContent(UploadedDocumentInfo uploadInfo, String documentType,
            String customerMobile) {
        DocumentVerificationResult result = new DocumentVerificationResult();
        result.setDocumentType(documentType);
        result.setProcessedAt(LocalDateTime.now());

        try {
            logger.info("Starting AI-powered document analysis for type: {}", documentType);

            // Step 1: Extract text from uploaded file using OCR/PDF parsing
            String extractedText = extractTextFromUploadedFile(uploadInfo);

            if (extractedText == null || extractedText.trim().isEmpty()) {
                result.setSuccess(false);
                result.setErrorMessage("No text could be extracted from the document");
                return result;
            }

            // Step 2: Analyze document using SageMaker models (for PAN/Aadhaar)
            if ("AADHAAR".equals(documentType.toUpperCase()) || "PAN".equals(documentType.toUpperCase())) {
                result = processSageMakerAnalysis(uploadInfo, extractedText, documentType, customerMobile);
            } else {
                // Fallback for other document types
                result = processOtherDocumentTypes(uploadInfo, extractedText, documentType, customerMobile);
            }

            if (result.isSuccess()) {
                logger.info("AI document analysis completed successfully for type: {} with confidence: {}",
                        documentType, result.getConfidenceScore());
            }

        } catch (Exception e) {
            logger.error("Error processing document content with AI models", e);
            result.setSuccess(false);
            result.setErrorMessage("AI document analysis failed: " + e.getMessage());
        }

        return result;
    }

    /**
     * Extract text from uploaded file using OCR/PDF parsing
     */
    private String extractTextFromUploadedFile(UploadedDocumentInfo uploadInfo) throws IOException {
        logger.info("Extracting text from file: {}", uploadInfo.getOriginalFileName());

        // Create a temporary MultipartFile representation for text extraction
        byte[] fileContent = Files.readAllBytes(Paths.get(uploadInfo.getFilePath()));

        // For now, use a simple text extraction approach
        // In a real implementation, you'd pass the actual MultipartFile to
        // textExtractionService
        String extractedText = performBasicTextExtraction(fileContent, uploadInfo.getOriginalFileName());

        if (textExtractionService.isValidExtractedText(extractedText)) {
            return textExtractionService.cleanExtractedText(extractedText);
        } else {
            logger.warn("Extracted text validation failed for file: {}", uploadInfo.getOriginalFileName());
            return extractedText; // Return anyway, let SageMaker handle it
        }
    }

    /**
     * Basic text extraction as fallback
     */
    private String performBasicTextExtraction(byte[] fileContent, String fileName) {
        try {
            if (fileName != null && fileName.toLowerCase().endsWith(".pdf")) {
                // For PDFs, you could use PDFBox here
                return "PDF_CONTENT_PLACEHOLDER"; // Simplified for this example
            } else {
                // For images, you could use Tesseract here
                return "IMAGE_CONTENT_PLACEHOLDER"; // Simplified for this example
            }
        } catch (Exception e) {
            logger.error("Basic text extraction failed", e);
            return "EXTRACTION_FAILED";
        }
    }

    /**
     * Process document using SageMaker AI models
     */
    private DocumentVerificationResult processSageMakerAnalysis(UploadedDocumentInfo uploadInfo,
            String extractedText,
            String documentType,
            String customerMobile) {
        try {
            // Read file content for base64 encoding
            byte[] fileContent = Files.readAllBytes(Paths.get(uploadInfo.getFilePath()));
            String base64Content = Base64.getEncoder().encodeToString(fileContent);

            // Create SageMaker analysis request
            DocumentAnalysisRequest analysisRequest = new DocumentAnalysisRequest();
            analysisRequest.setDocumentType(documentType);
            analysisRequest.setExtractedText(extractedText);
            analysisRequest.setCustomerMobile(customerMobile);
            analysisRequest.setDocumentBase64(base64Content);
            analysisRequest.setConfidenceThreshold(0.8);

            // Call SageMaker service
            DocumentAnalysisResponse analysisResponse = sageMakerAnalysisService.analyzeDocument(analysisRequest);

            // Convert SageMaker response to DocumentVerificationResult
            return convertSageMakerResponseToResult(analysisResponse, documentType);

        } catch (Exception e) {
            logger.error("SageMaker analysis failed for document type: {}", documentType, e);

            // Fallback to mock processing
            logger.warn("Falling back to mock processing for document type: {}", documentType);
            return createMockVerificationResult(documentType, customerMobile, extractedText);
        }
    }

    /**
     * Convert SageMaker response to DocumentVerificationResult
     */
    private DocumentVerificationResult convertSageMakerResponseToResult(DocumentAnalysisResponse sageMakerResponse,
            String documentType) {
        DocumentVerificationResult result = new DocumentVerificationResult();
        result.setDocumentType(documentType);
        result.setSuccess(sageMakerResponse.isSuccess());
        result.setVerified(sageMakerResponse.isVerified());
        result.setProcessedAt(sageMakerResponse.getProcessedAt());
        result.setConfidenceScore(sageMakerResponse.getConfidenceScore());
        result.setExtractedData(sageMakerResponse.getExtractedData());

        if (!sageMakerResponse.isSuccess()) {
            result.setErrorMessage(sageMakerResponse.getErrorMessage());
        }

        return result;
    }

    /**
     * Create mock verification result as fallback
     */
    private DocumentVerificationResult createMockVerificationResult(String documentType,
            String customerMobile,
            String extractedText) {
        DocumentVerificationResult result = new DocumentVerificationResult();
        result.setDocumentType(documentType);
        result.setSuccess(true);
        result.setVerified(true);
        result.setProcessedAt(LocalDateTime.now());
        result.setConfidenceScore(0.75); // Lower confidence for mock data

        Map<String, Object> extractedData = new HashMap<>();
        extractedData.put("document_type", documentType);
        extractedData.put("mobile", customerMobile);
        extractedData.put("extraction_method", "fallback_mock");

        if ("AADHAAR".equals(documentType.toUpperCase())) {
            extractedData.put("aadhaar_number",
                    "****-****-" + customerMobile.substring(Math.max(0, customerMobile.length() - 4)));
            extractedData.put("name", "Mock Customer Name");
            extractedData.put("father_name", "Mock Father Name");
            extractedData.put("date_of_birth", "01/01/1990");
            extractedData.put("gender", "M");
            extractedData.put("address", "Mock Customer Address");
        } else if ("PAN".equals(documentType.toUpperCase())) {
            extractedData.put("pan_number", "ABCDE1234F");
            extractedData.put("name", "Mock Customer Name");
            extractedData.put("father_name", "Mock Father Name");
            extractedData.put("date_of_birth", "01/01/1990");
        }

        result.setExtractedData(extractedData);
        return result;
    }

    /**
     * Process other document types (non-PAN/Aadhaar)
     */
    private DocumentVerificationResult processOtherDocumentTypes(UploadedDocumentInfo uploadInfo,
            String extractedText,
            String documentType,
            String customerMobile) {
        switch (documentType.toUpperCase()) {
            case "DRIVING_LICENSE":
                return processDrivingLicenseDocument(extractedText, customerMobile);
            case "PASSPORT":
                return processPassportDocument(extractedText, customerMobile);
            default:
                return createGenericVerificationResult(documentType, customerMobile, extractedText);
        }
    }

    /**
     * Create generic verification result for unsupported document types
     */
    private DocumentVerificationResult createGenericVerificationResult(String documentType,
            String customerMobile,
            String extractedText) {
        DocumentVerificationResult result = new DocumentVerificationResult();
        result.setDocumentType(documentType);
        result.setSuccess(true);
        result.setVerified(true);
        result.setProcessedAt(LocalDateTime.now());
        result.setConfidenceScore(0.8);

        Map<String, Object> extractedData = new HashMap<>();
        extractedData.put("document_type", documentType);
        extractedData.put("mobile", customerMobile);
        extractedData.put("text_length", extractedText.length());
        extractedData.put("processing_method", "generic");

        result.setExtractedData(extractedData);
        return result;
    }

    /**
     * Create DigiLocker document from upload
     */
    private DigiLockerDocument createDocumentFromUpload(UploadedDocumentInfo uploadInfo,
            DocumentVerificationResult verificationResult, String documentType) {
        DigiLockerDocument document = new DigiLockerDocument();
        document.setDocumentId(UUID.randomUUID().toString());
        document.setDocumentType(documentType);
        document.setDocumentName(uploadInfo.getOriginalFileName());
        document.setDocumentIssuer("UPLOADED_DOCUMENT");
        document.setIssueDate(LocalDateTime.now().toString());
        document.setDocumentSize(uploadInfo.getFileSize());
        document.setDocumentFormat(getFileExtension(uploadInfo.getOriginalFileName()));
        document.setVerified(verificationResult.isVerified());
        document.setVerificationStatus(verificationResult.isVerified() ? "VERIFIED" : "PENDING");
        document.setDocumentUrl("file:///" + uploadInfo.getFilePath()); // Local file reference

        // Add extracted data as metadata
        if (verificationResult.getExtractedData() != null) {
            document.setMetadata(verificationResult.getExtractedData());
        }

        return document;
    }

    /**
     * Generate document ID for uploaded documents
     */
    private String generateDocumentId(String customerMobile, String documentType) {
        return documentType + "_" + customerMobile.substring(Math.max(0, customerMobile.length() - 4)) + "_"
                + System.currentTimeMillis();
    }

    /**
     * Get file extension
     */
    private String getFileExtension(String filename) {
        return filename.substring(filename.lastIndexOf('.') + 1).toUpperCase();
    }

    /**
     * Mask mobile number for logging
     */
    private String maskMobileNumber(String mobile) {
        if (mobile == null || mobile.length() < 4) {
            return "****";
        }
        return mobile.substring(0, 2) + "****" + mobile.substring(mobile.length() - 2);
    }

    // Note: processAadhaarDocument and processPanDocument are now handled
    // by processSageMakerAnalysis method above

    /**
     * Process Driving License document (mock implementation)
     */
    private DocumentVerificationResult processDrivingLicenseDocument(String extractedText, String customerMobile) {
        DocumentVerificationResult result = new DocumentVerificationResult();
        result.setDocumentType("DRIVING_LICENSE");
        result.setVerified(true);
        result.setSuccess(true);
        result.setProcessedAt(LocalDateTime.now());

        // Mock extracted data
        Map<String, Object> extractedData = new HashMap<>();
        extractedData.put("license_number",
                "DL" + customerMobile.substring(Math.max(0, customerMobile.length() - 4)) + "123456");
        extractedData.put("name", "Customer Name");
        extractedData.put("father_name", "Father Name");
        extractedData.put("date_of_birth", "01/01/1990");
        extractedData.put("address", "Customer Address");
        extractedData.put("issue_date", "01/01/2020");
        extractedData.put("expiry_date", "01/01/2040");
        extractedData.put("mobile", customerMobile);
        extractedData.put("text_length", extractedText.length());

        result.setExtractedData(extractedData);
        result.setConfidenceScore(0.90);

        return result;
    }

    /**
     * Process Passport document (mock implementation)
     */
    private DocumentVerificationResult processPassportDocument(String extractedText, String customerMobile) {
        DocumentVerificationResult result = new DocumentVerificationResult();
        result.setDocumentType("PASSPORT");
        result.setVerified(true);
        result.setSuccess(true);
        result.setProcessedAt(LocalDateTime.now());

        // Mock extracted data
        Map<String, Object> extractedData = new HashMap<>();
        extractedData.put("passport_number",
                "P" + customerMobile.substring(Math.max(0, customerMobile.length() - 4)) + "567890");
        extractedData.put("name", "Customer Name");
        extractedData.put("father_name", "Father Name");
        extractedData.put("date_of_birth", "01/01/1990");
        extractedData.put("place_of_birth", "India");
        extractedData.put("issue_date", "01/01/2015");
        extractedData.put("expiry_date", "01/01/2025");
        extractedData.put("mobile", customerMobile);
        extractedData.put("text_length", extractedText.length());

        result.setExtractedData(extractedData);
        result.setConfidenceScore(0.93);

        return result;
    }

    // Helper classes for upload processing
    public static class DocumentUploadValidation {
        private boolean valid;
        private String errorMessage;

        public boolean isValid() {
            return valid;
        }

        public void setValid(boolean valid) {
            this.valid = valid;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }
    }

    public static class UploadedDocumentInfo {
        private String originalFileName;
        private String storedFileName;
        private String filePath;
        private long fileSize;
        private String contentType;
        private String documentType;
        private String verificationToken;
        private LocalDateTime uploadTime;

        // Getters and setters
        public String getOriginalFileName() {
            return originalFileName;
        }

        public void setOriginalFileName(String originalFileName) {
            this.originalFileName = originalFileName;
        }

        public String getStoredFileName() {
            return storedFileName;
        }

        public void setStoredFileName(String storedFileName) {
            this.storedFileName = storedFileName;
        }

        public String getFilePath() {
            return filePath;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public long getFileSize() {
            return fileSize;
        }

        public void setFileSize(long fileSize) {
            this.fileSize = fileSize;
        }

        public String getContentType() {
            return contentType;
        }

        public void setContentType(String contentType) {
            this.contentType = contentType;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }

        public String getVerificationToken() {
            return verificationToken;
        }

        public void setVerificationToken(String verificationToken) {
            this.verificationToken = verificationToken;
        }

        public LocalDateTime getUploadTime() {
            return uploadTime;
        }

        public void setUploadTime(LocalDateTime uploadTime) {
            this.uploadTime = uploadTime;
        }
    }

    public static class DocumentVerificationResult {
        private String documentType;
        private boolean verified;
        private boolean success;
        private String errorMessage;
        private Map<String, Object> extractedData;
        private double confidenceScore;
        private LocalDateTime processedAt;

        // Getters and setters
        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }

        public boolean isVerified() {
            return verified;
        }

        public void setVerified(boolean verified) {
            this.verified = verified;
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }

        public Map<String, Object> getExtractedData() {
            return extractedData;
        }

        public void setExtractedData(Map<String, Object> extractedData) {
            this.extractedData = extractedData;
        }

        public double getConfidenceScore() {
            return confidenceScore;
        }

        public void setConfidenceScore(double confidenceScore) {
            this.confidenceScore = confidenceScore;
        }

        public LocalDateTime getProcessedAt() {
            return processedAt;
        }

        public void setProcessedAt(LocalDateTime processedAt) {
            this.processedAt = processedAt;
        }
    }

    public static class AadhaarDetails {
        private String aadhaarNumber;
        private String name;
        private String fatherName;
        private String dateOfBirth;
        private String gender;
        private String address;
        private String mobileNumber;
        private String emailId;
        private boolean verified;

        // Getters and Setters
        public String getAadhaarNumber() {
            return aadhaarNumber;
        }

        public void setAadhaarNumber(String aadhaarNumber) {
            this.aadhaarNumber = aadhaarNumber;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getFatherName() {
            return fatherName;
        }

        public void setFatherName(String fatherName) {
            this.fatherName = fatherName;
        }

        public String getDateOfBirth() {
            return dateOfBirth;
        }

        public void setDateOfBirth(String dateOfBirth) {
            this.dateOfBirth = dateOfBirth;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getMobileNumber() {
            return mobileNumber;
        }

        public void setMobileNumber(String mobileNumber) {
            this.mobileNumber = mobileNumber;
        }

        public String getEmailId() {
            return emailId;
        }

        public void setEmailId(String emailId) {
            this.emailId = emailId;
        }

        public boolean isVerified() {
            return verified;
        }

        public void setVerified(boolean verified) {
            this.verified = verified;
        }
    }

    public static class PanDetails {
        private String panNumber;
        private String name;
        private String fatherName;
        private String dateOfBirth;
        private boolean verified;

        // Getters and Setters
        public String getPanNumber() {
            return panNumber;
        }

        public void setPanNumber(String panNumber) {
            this.panNumber = panNumber;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getFatherName() {
            return fatherName;
        }

        public void setFatherName(String fatherName) {
            this.fatherName = fatherName;
        }

        public String getDateOfBirth() {
            return dateOfBirth;
        }

        public void setDateOfBirth(String dateOfBirth) {
            this.dateOfBirth = dateOfBirth;
        }

        public boolean isVerified() {
            return verified;
        }

        public void setVerified(boolean verified) {
            this.verified = verified;
        }
    }
}
