package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.entites.SignedAgreement;
import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.entites.VerificationStatus;
import com.esign.legal_advisor.repository.SignedAgreementRepository;
import com.esign.legal_advisor.repository.UserRepository;
import com.esign.legal_advisor.repository.VerificationStatusRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class AdminService {

    private static final Logger logger = LoggerFactory.getLogger(AdminService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private VerificationStatusRepository verificationStatusRepository;

    @Autowired
    private SignedAgreementRepository signedAgreementRepository;

    /**
     * Get admin dashboard statistics
     */
    public Map<String, Object> getDashboardStatistics() {
        Map<String, Object> stats = new HashMap<>();

        try {
            // User statistics
            long totalUsers = userRepository.count();
            long individualUsers = userRepository.countByUserType("INDIVIDUAL");
            long companyUsers = userRepository.countByUserType("COMPANY");
            long verifiedUsers = userRepository.countByIsVerified(true);

            stats.put("users", Map.of(
                    "total", totalUsers,
                    "individual", individualUsers,
                    "company", companyUsers,
                    "verified", verifiedUsers,
                    "unverified", totalUsers - verifiedUsers));

            // Verification statistics
            long pendingVerifications = verificationStatusRepository.countByOverallStatus("PENDING");
            long completedVerifications = verificationStatusRepository.countByOverallStatus("COMPLETED");
            long partialVerifications = verificationStatusRepository.countByOverallStatus("PARTIAL");

            stats.put("verifications", Map.of(
                    "pending", pendingVerifications,
                    "completed", completedVerifications,
                    "partial", partialVerifications));

            // Agreement statistics
            long totalAgreements = signedAgreementRepository.count();
            long draftAgreements = signedAgreementRepository.countByStatus("DRAFT");
            long signedAgreements = signedAgreementRepository.countByStatus("SIGNED");
            long completedAgreements = signedAgreementRepository.countByStatus("COMPLETED");

            stats.put("agreements", Map.of(
                    "total", totalAgreements,
                    "draft", draftAgreements,
                    "signed", signedAgreements,
                    "completed", completedAgreements));

            // Recent activity
            LocalDateTime last24Hours = LocalDateTime.now().minusHours(24);
            long recentUsers = userRepository.countByCreatedAtAfter(last24Hours);
            long recentAgreements = signedAgreementRepository.countByCreatedAtAfter(last24Hours);

            stats.put("recentActivity", Map.of(
                    "newUsers24h", recentUsers,
                    "newAgreements24h", recentAgreements));

            stats.put("success", true);
            stats.put("timestamp", LocalDateTime.now());

        } catch (Exception e) {
            logger.error("Error getting dashboard statistics", e);
            stats.put("success", false);
            stats.put("error", e.getMessage());
        }

        return stats;
    }

    /**
     * Get all users with pagination and filtering
     */
    public Map<String, Object> getAllUsers(int page, int size, String sortBy, String sortDir,
            String userType, String verificationStatus) {
        Map<String, Object> response = new HashMap<>();

        try {
            Sort sort = sortDir.equalsIgnoreCase("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();

            Pageable pageable = PageRequest.of(page, size, sort);
            Page<User> userPage;

            if (userType != null && !userType.isEmpty()) {
                userPage = userRepository.findByUserType(userType, pageable);
            } else {
                userPage = userRepository.findAll(pageable);
            }

            // Filter by verification status if specified
            List<User> users = userPage.getContent();
            if (verificationStatus != null && !verificationStatus.isEmpty()) {
                users = users.stream()
                        .filter(user -> {
                            try {
                                Optional<VerificationStatus> status = verificationStatusRepository
                                        .findByUserId(user.getId());
                                if (status.isPresent()) {
                                    return verificationStatus.equalsIgnoreCase(status.get().getOverallStatus());
                                }
                                return "PENDING".equalsIgnoreCase(verificationStatus);
                            } catch (Exception e) {
                                return false;
                            }
                        })
                        .toList();
            }

            response.put("success", true);
            response.put("users", users);
            response.put("totalElements", userPage.getTotalElements());
            response.put("totalPages", userPage.getTotalPages());
            response.put("currentPage", page);
            response.put("size", size);

        } catch (Exception e) {
            logger.error("Error getting all users", e);
            response.put("success", false);
            response.put("error", e.getMessage());
        }

        return response;
    }

    /**
     * Get user by ID
     */
    public Optional<User> getUserById(String userId) {
        try {
            return userRepository.findById(userId);
        } catch (Exception e) {
            logger.error("Error getting user by ID: {}", userId, e);
            return Optional.empty();
        }
    }

    /**
     * Update user verification status
     */
    public MessageResponse updateUserVerification(String userId, String verificationType,
            String status, String notes) {
        try {
            Optional<VerificationStatus> verificationOpt = verificationStatusRepository.findByUserId(userId);
            if (verificationOpt.isEmpty()) {
                return new MessageResponse("Verification status not found for user");
            }

            VerificationStatus verification = verificationOpt.get();

            switch (verificationType.toUpperCase()) {
                case "PAN":
                    verification.setPanVerificationStatus(status);
                    verification.setPanVerificationDetails(notes);
                    if ("APPROVED".equals(status)) {
                        verification.setPanVerified(true);
                    }
                    break;
                case "AADHAR":
                    verification.setAadharVerificationStatus(status);
                    verification.setAadharVerificationDetails(notes);
                    if ("APPROVED".equals(status)) {
                        verification.setAadharVerified(true);
                    }
                    break;
                case "GST":
                    verification.setGstVerificationStatus(status);
                    verification.setGstVerificationDetails(notes);
                    if ("APPROVED".equals(status)) {
                        verification.setGstVerified(true);
                    }
                    break;
                case "VIDEO":
                    verification.setVideoVerificationStatus(status);
                    verification.setVideoVerificationNotes(notes);
                    if ("APPROVED".equals(status)) {
                        verification.setVideoVerified(true);
                    }
                    break;
                default:
                    return new MessageResponse("Invalid verification type");
            }

            verificationStatusRepository.save(verification);

            // Update user verification status
            Optional<User> userOpt = userRepository.findById(userId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                user.setVerified(verification.isFullyVerified());
                user.setVerificationLevel(verification.isFullyVerified() ? "FULL" : "PARTIAL");
                userRepository.save(user);
            }

            return new MessageResponse("Verification status updated successfully");

        } catch (Exception e) {
            logger.error("Error updating user verification", e);
            return new MessageResponse("Failed to update verification: " + e.getMessage());
        }
    }

    /**
     * Get all verification requests
     */
    public Map<String, Object> getAllVerificationRequests(int page, int size, String status, String type) {
        Map<String, Object> response = new HashMap<>();

        try {
            Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
            Page<VerificationStatus> verificationPage;

            if (status != null && !status.isEmpty()) {
                verificationPage = verificationStatusRepository.findByOverallStatus(status, pageable);
            } else {
                verificationPage = verificationStatusRepository.findAll(pageable);
            }

            response.put("success", true);
            response.put("verifications", verificationPage.getContent());
            response.put("totalElements", verificationPage.getTotalElements());
            response.put("totalPages", verificationPage.getTotalPages());
            response.put("currentPage", page);
            response.put("size", size);

        } catch (Exception e) {
            logger.error("Error getting verification requests", e);
            response.put("success", false);
            response.put("error", e.getMessage());
        }

        return response;
    }

    /**
     * Approve verification
     */
    public MessageResponse approveVerification(String userId, String verificationType, String notes) {
        return updateUserVerification(userId, verificationType, "APPROVED", notes);
    }

    /**
     * Reject verification
     */
    public MessageResponse rejectVerification(String userId, String verificationType, String reason) {
        return updateUserVerification(userId, verificationType, "REJECTED", reason);
    }

    /**
     * Get all agreements with pagination
     */
    public Map<String, Object> getAllAgreements(int page, int size, String status, String type) {
        Map<String, Object> response = new HashMap<>();

        try {
            Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
            Page<SignedAgreement> agreementPage;

            if (status != null && !status.isEmpty()) {
                agreementPage = signedAgreementRepository.findByStatus(status, pageable);
            } else {
                agreementPage = signedAgreementRepository.findAll(pageable);
            }

            response.put("success", true);
            response.put("agreements", agreementPage.getContent());
            response.put("totalElements", agreementPage.getTotalElements());
            response.put("totalPages", agreementPage.getTotalPages());
            response.put("currentPage", page);
            response.put("size", size);

        } catch (Exception e) {
            logger.error("Error getting agreements", e);
            response.put("success", false);
            response.put("error", e.getMessage());
        }

        return response;
    }

    /**
     * Get system statistics
     */
    public Map<String, Object> getSystemStatistics() {
        Map<String, Object> stats = new HashMap<>();

        try {
            // Database statistics
            long totalUsers = userRepository.count();
            long totalAgreements = signedAgreementRepository.count();
            long totalVerifications = verificationStatusRepository.count();

            stats.put("database", Map.of(
                    "totalUsers", totalUsers,
                    "totalAgreements", totalAgreements,
                    "totalVerifications", totalVerifications));

            // Performance metrics
            LocalDateTime last24Hours = LocalDateTime.now().minusHours(24);
            long activeUsers24h = userRepository.countByUpdatedAtAfter(last24Hours);
            long newAgreements24h = signedAgreementRepository.countByCreatedAtAfter(last24Hours);

            stats.put("performance", Map.of(
                    "activeUsers24h", activeUsers24h,
                    "newAgreements24h", newAgreements24h));

            // System health
            stats.put("systemHealth", Map.of(
                    "status", "HEALTHY",
                    "timestamp", LocalDateTime.now(),
                    "uptime", "System running normally"));

            stats.put("success", true);

        } catch (Exception e) {
            logger.error("Error getting system statistics", e);
            stats.put("success", false);
            stats.put("error", e.getMessage());
        }

        return stats;
    }
}



