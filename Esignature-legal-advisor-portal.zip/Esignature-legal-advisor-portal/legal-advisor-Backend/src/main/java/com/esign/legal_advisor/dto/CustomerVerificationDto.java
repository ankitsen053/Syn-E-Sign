package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class CustomerVerificationDto {

    @NotBlank(message = "Verification token is required")
    @Size(min = 32, max = 32, message = "Invalid verification token")
    private String verificationToken;

    @Pattern(regexp = "^[+]?[0-9]{10,15}$", message = "Please provide a valid mobile number")
    private String mobileNumber;

    @Pattern(regexp = "^[0-9]{6}$", message = "OTP must be 6 digits")
    private String otp;

    private boolean consentGiven = false;

    private String consentText;

    // For different verification steps
    private VerificationStep step = VerificationStep.MOBILE_ENTRY;

    public enum VerificationStep {
        MOBILE_ENTRY,    // Customer enters mobile number
        OTP_VERIFICATION, // Customer enters OTP
        CONSENT_REVIEW,   // Customer reviews consent
        PROCESSING       // Verification in progress
    }

    // Constructors
    public CustomerVerificationDto() {}

    public CustomerVerificationDto(String verificationToken) {
        this.verificationToken = verificationToken;
    }

    // Getters and Setters
    public String getVerificationToken() {
        return verificationToken;
    }

    public void setVerificationToken(String verificationToken) {
        this.verificationToken = verificationToken;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public boolean isConsentGiven() {
        return consentGiven;
    }

    public void setConsentGiven(boolean consentGiven) {
        this.consentGiven = consentGiven;
    }

    public String getConsentText() {
        return consentText;
    }

    public void setConsentText(String consentText) {
        this.consentText = consentText;
    }

    public VerificationStep getStep() {
        return step;
    }

    public void setStep(VerificationStep step) {
        this.step = step;
    }

    // Helper methods
    public String getMaskedMobileNumber() {
        if (mobileNumber == null || mobileNumber.length() < 4) {
            return "****";
        }
        return mobileNumber.substring(0, 2) + "****" + mobileNumber.substring(mobileNumber.length() - 2);
    }

    @Override
    public String toString() {
        return "CustomerVerificationDto{" +
                "verificationToken='" + (verificationToken != null ? verificationToken.substring(0, 8) + "****" : null) + '\'' +
                ", mobileNumber='" + getMaskedMobileNumber() + '\'' +
                ", otp='" + (otp != null ? "******" : null) + '\'' +
                ", consentGiven=" + consentGiven +
                ", step=" + step +
                '}';
    }
}
