package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.CustomerVerificationDto;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.service.CustomerVerificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.validation.Valid;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/customer/digilocker")
@CrossOrigin(origins = "*", maxAge = 3600)
public class CustomerVerificationController {

    private static final Logger logger = LoggerFactory.getLogger(CustomerVerificationController.class);

    @Autowired
    private CustomerVerificationService customerVerificationService;

    /**
     * Get verification request details by token (Customer opens the link)
     */
    @GetMapping("/verification/{verificationToken}")
    public ResponseEntity<?> getVerificationRequest(@PathVariable("verificationToken") String verificationToken) {
        try {
            logger.info("Customer accessing verification with token: {}",
                    verificationToken.substring(0, 8) + "****");

            Map<String, Object> response = customerVerificationService.getVerificationRequestByToken(verificationToken);

            if ((Boolean) response.getOrDefault("success", false)) {
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.badRequest().body(response);
            }

        } catch (Exception e) {
            logger.error("Error getting verification request by token", e);
            return ResponseEntity.badRequest()
                    .body(Map.of("success", false, "error", "Error accessing verification request"));
        }
    }

    /**
     * Send OTP to customer mobile number (Step 1)
     */
    @PostMapping("/verification/{verificationToken}/send-otp")
    public ResponseEntity<?> sendOtpToCustomer(@PathVariable("verificationToken") String verificationToken,
            @RequestBody Map<String, String> request) {
        try {
            String mobileNumber = request.get("mobileNumber");

            if (mobileNumber == null || mobileNumber.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Mobile number is required"));
            }

            logger.info("Sending OTP to customer mobile for token: {}",
                    verificationToken.substring(0, 8) + "****");

            MessageResponse response = customerVerificationService.sendOtpToCustomer(verificationToken, mobileNumber);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error sending OTP to customer", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error sending OTP. Please try again."));
        }
    }

    /**
     * Verify OTP entered by customer (Step 2)
     */
    @PostMapping("/verification/{verificationToken}/verify-otp")
    public ResponseEntity<?> verifyCustomerOtp(@PathVariable("verificationToken") String verificationToken,
            @Valid @RequestBody CustomerVerificationDto request,
            BindingResult bindingResult) {
        try {
            // Handle validation errors
            if (bindingResult.hasErrors()) {
                String errorMessages = bindingResult.getAllErrors().stream()
                        .map(error -> error.getDefaultMessage())
                        .collect(Collectors.joining("; "));
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Validation failed: " + errorMessages));
            }

            logger.info("Verifying OTP for customer with token: {}",
                    verificationToken.substring(0, 8) + "****");

            MessageResponse response = customerVerificationService.verifyCustomerOtp(
                    verificationToken, request.getMobileNumber(), request.getOtp());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error verifying customer OTP", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error verifying OTP. Please try again."));
        }
    }

    /**
     * Process customer consent and start verification (Step 3)
     */
    @PostMapping("/verification/{verificationToken}/consent")
    public ResponseEntity<?> processCustomerConsent(@PathVariable("verificationToken") String verificationToken,
            @RequestBody Map<String, Object> request) {
        try {
            Boolean consentGiven = (Boolean) request.get("consentGiven");
            String consentText = (String) request.get("consentText");

            if (consentGiven == null) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "error", "Consent decision is required"));
            }

            logger.info("Processing customer consent for token: {} - Consent: {}",
                    verificationToken.substring(0, 8) + "****", consentGiven);

            Map<String, Object> response = customerVerificationService.processCustomerConsent(
                    verificationToken, consentGiven, consentText);

            if ((Boolean) response.getOrDefault("success", false)) {
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.badRequest().body(response);
            }

        } catch (Exception e) {
            logger.error("Error processing customer consent", e);
            return ResponseEntity.badRequest()
                    .body(Map.of("success", false, "error", "Error processing consent. Please try again."));
        }
    }

    /**
     * Upload document for verification (Step 4 - Document Upload)
     */
    @PostMapping("/verification/{verificationToken}/upload-document")
    public ResponseEntity<?> uploadDocument(@PathVariable("verificationToken") String verificationToken,
            @RequestParam("documentType") String documentType,
            @RequestParam("documentFile") MultipartFile documentFile,
            @RequestParam("customerMobile") String customerMobile) {
        try {
            logger.info("Document upload initiated for token: {}, type: {}, file: {}",
                    verificationToken.substring(0, 8) + "****",
                    documentType,
                    documentFile.getOriginalFilename());

            // Validate inputs
            if (documentFile == null || documentFile.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "error", "No document file provided"));
            }

            if (documentType == null || documentType.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "error", "Document type is required"));
            }

            if (customerMobile == null || customerMobile.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("success", false, "error", "Customer mobile number is required"));
            }

            // Process document upload through customer verification service
            Map<String, Object> response = customerVerificationService.processDocumentUpload(
                    verificationToken, documentType, documentFile, customerMobile);

            if ((Boolean) response.getOrDefault("success", false)) {
                logger.info("Document upload completed successfully for token: {}",
                        verificationToken.substring(0, 8) + "****");
                return ResponseEntity.ok(response);
            } else {
                logger.warn("Document upload failed for token: {} - {}",
                        verificationToken.substring(0, 8) + "****",
                        response.get("error"));
                return ResponseEntity.badRequest().body(response);
            }

        } catch (Exception e) {
            logger.error("Error during document upload for token: {}",
                    verificationToken.substring(0, 8) + "****", e);
            return ResponseEntity.badRequest()
                    .body(Map.of("success", false, "error", "Document upload failed. Please try again."));
        }
    }

    /**
     * Get supported document types and upload guidelines
     */
    @GetMapping("/verification/{verificationToken}/upload-info")
    public ResponseEntity<?> getDocumentUploadInfo(@PathVariable("verificationToken") String verificationToken) {
        try {
            Map<String, Object> uploadInfo = Map.of(
                    "supported_document_types", java.util.Arrays.asList(
                            "AADHAAR", "PAN", "DRIVING_LICENSE", "PASSPORT", "VOTER_ID", "RATION_CARD"),
                    "allowed_file_types", java.util.Arrays.asList(
                            "pdf", "jpg", "jpeg", "png", "tiff", "bmp"),
                    "max_file_size", "10MB",
                    "upload_guidelines", java.util.Arrays.asList(
                            "Ensure document is clear and readable",
                            "All corners of the document should be visible",
                            "Document should not be blurred or damaged",
                            "File size should not exceed 10MB",
                            "Accepted formats: PDF, JPG, JPEG, PNG, TIFF, BMP"),
                    "document_requirements", Map.of(
                            "AADHAAR", "Clear photo of Aadhaar card (both sides if applicable)",
                            "PAN", "Clear photo of PAN card",
                            "DRIVING_LICENSE", "Clear photo of driving license (front and back)",
                            "PASSPORT", "Clear photo of passport (main page with photo)",
                            "VOTER_ID", "Clear photo of voter ID card",
                            "RATION_CARD", "Clear photo of ration card"));

            return ResponseEntity.ok(uploadInfo);

        } catch (Exception e) {
            logger.error("Error getting document upload info", e);
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Failed to get upload information"));
        }
    }

    /**
     * Get current verification status
     */
    @GetMapping("/verification/{verificationToken}/status")
    public ResponseEntity<?> getVerificationStatus(@PathVariable("verificationToken") String verificationToken) {
        try {
            logger.info("Getting verification status for token: {}",
                    verificationToken.substring(0, 8) + "****");

            Map<String, Object> response = customerVerificationService.getVerificationRequestByToken(verificationToken);

            if ((Boolean) response.getOrDefault("success", false)) {
                // Extract just the status information
                Map<String, Object> statusResponse = Map.of(
                        "success", true,
                        "status", response.get("status"),
                        "progress", response.get("progress"),
                        "currentStep", response.get("currentStep"));
                return ResponseEntity.ok(statusResponse);
            } else {
                return ResponseEntity.badRequest().body(response);
            }

        } catch (Exception e) {
            logger.error("Error getting verification status", e);
            return ResponseEntity.badRequest()
                    .body(Map.of("success", false, "error", "Error getting verification status"));
        }
    }

    /**
     * Resend OTP (if needed)
     */
    @PostMapping("/verification/{verificationToken}/resend-otp")
    public ResponseEntity<?> resendOtp(@PathVariable("verificationToken") String verificationToken,
            @RequestBody Map<String, String> request) {
        try {
            String mobileNumber = request.get("mobileNumber");

            if (mobileNumber == null || mobileNumber.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Mobile number is required"));
            }

            logger.info("Resending OTP to customer mobile for token: {}",
                    verificationToken.substring(0, 8) + "****");

            MessageResponse response = customerVerificationService.sendOtpToCustomer(verificationToken, mobileNumber);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error resending OTP to customer", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error resending OTP. Please try again."));
        }
    }

    /**
     * Validate verification token (before customer starts the process)
     */
    @GetMapping("/verification/{verificationToken}/validate")
    public ResponseEntity<?> validateVerificationToken(@PathVariable("verificationToken") String verificationToken) {
        try {
            Map<String, Object> response = customerVerificationService.getVerificationRequestByToken(verificationToken);

            if ((Boolean) response.getOrDefault("success", false)) {
                // Return minimal validation response
                Map<String, Object> validationResponse = Map.of(
                        "valid", true,
                        "requestedDocuments", response.get("requestedDocuments"),
                        "verificationPurpose", response.get("verificationPurpose"),
                        "expiresAt", response.get("expiresAt"));
                return ResponseEntity.ok(validationResponse);
            } else {
                return ResponseEntity.badRequest()
                        .body(Map.of("valid", false, "error", response.get("error")));
            }

        } catch (Exception e) {
            logger.error("Error validating verification token", e);
            return ResponseEntity.badRequest()
                    .body(Map.of("valid", false, "error", "Invalid verification token"));
        }
    }

    /**
     * Get verification flow steps information
     */
    @GetMapping("/verification-steps")
    public ResponseEntity<?> getVerificationSteps() {
        Map<String, Object> steps = Map.of(
                "steps", java.util.Arrays.asList(
                        Map.of(
                                "step", "MOBILE_ENTRY",
                                "title", "Enter Mobile Number",
                                "description", "Enter your Aadhaar-linked mobile number to receive OTP"),
                        Map.of(
                                "step", "OTP_VERIFICATION",
                                "title", "Verify OTP",
                                "description", "Enter the 6-digit OTP sent to your mobile number"),
                        Map.of(
                                "step", "CONSENT_REVIEW",
                                "title", "Review & Consent",
                                "description", "Review the consent and approve document sharing"),
                        Map.of(
                                "step", "PROCESSING",
                                "title", "Verification in Progress",
                                "description", "Your documents are being verified from DigiLocker")),
                "total_steps", 4);

        return ResponseEntity.ok(steps);
    }

    /**
     * Health check for customer verification service
     */
    @GetMapping("/health")
    public ResponseEntity<?> healthCheck() {
        Map<String, Object> health = Map.of(
                "service", "Customer DigiLocker Verification",
                "status", "UP",
                "timestamp", java.time.LocalDateTime.now(),
                "supported_steps", java.util.Arrays.asList(
                        "Mobile number entry",
                        "OTP verification",
                        "Consent management",
                        "Document verification"));

        return ResponseEntity.ok(health);
    }
}
