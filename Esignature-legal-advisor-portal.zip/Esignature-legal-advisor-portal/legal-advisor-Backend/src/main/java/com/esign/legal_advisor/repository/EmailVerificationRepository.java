package com.esign.legal_advisor.repository;

import com.esign.legal_advisor.entites.EmailVerification;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface EmailVerificationRepository extends MongoRepository<EmailVerification, String> {
    
    Optional<EmailVerification> findByEmail(String email);
    
    Optional<EmailVerification> findByEmailAndOtp(String email, String otp);
    
    void deleteByEmail(String email);
}
