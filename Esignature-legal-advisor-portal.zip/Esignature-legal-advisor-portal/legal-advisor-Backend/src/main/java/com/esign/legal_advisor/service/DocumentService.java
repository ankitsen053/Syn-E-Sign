package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.LegalDocument;
import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.repository.DocumentRepository;
import com.esign.legal_advisor.dto.DocumentDto;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DocumentService {

    private static final Logger logger = LoggerFactory.getLogger(DocumentService.class);

    @Autowired
    private DocumentRepository documentRepository;

    public DocumentDto saveDocument(DocumentDto documentDto, User user) {
        try {
            if (user == null) {
                throw new RuntimeException("User is required to save document");
            }

            String title = documentDto.getTitle() != null ? documentDto.getTitle()
                    : documentDto.getType() + " - " + documentDto.getPartyA() + " & " + documentDto.getPartyB();

            LegalDocument document = new LegalDocument(
                    title,
                    documentDto.getContent(),
                    documentDto.getType(),
                    documentDto.getPartyA(),
                    documentDto.getPartyB(),
                    documentDto.getTerms(),
                    user);

            LegalDocument savedDocument = documentRepository.save(document);
            logger.info("Document saved successfully with ID: {} for user: {}", savedDocument.getId(), user.getId());
            return convertToDto(savedDocument);
        } catch (Exception e) {
            logger.error("Error saving document for user: {}", user != null ? user.getId() : "null", e);
            throw new RuntimeException("Failed to save document: " + e.getMessage());
        }
    }

    public DocumentDto updateDocument(String documentId, DocumentDto documentDto, User user) {
        try {
            if (user == null) {
                throw new RuntimeException("User is required to update document");
            }

            Optional<LegalDocument> existingDocument = documentRepository.findById(documentId);

            if (existingDocument.isEmpty()) {
                throw new RuntimeException("Document not found");
            }

            LegalDocument document = existingDocument.get();

            // Enhanced null checking for user authorization
            boolean isAuthorized = false;

            // Check if document has user reference
            if (document.getUser() != null) {
                // Document has user reference, check if it matches current user
                if (document.getUser().getId() != null && document.getUser().getId().equals(user.getId())) {
                    isAuthorized = true;
                }
            }

            // If not authorized by user reference, check userId field
            if (!isAuthorized && document.getUserId() != null) {
                if (document.getUserId().equals(user.getId())) {
                    isAuthorized = true;
                    logger.debug("Document {} authorized via userId field", documentId);
                }
            }

            // If still not authorized, check if document has no user association (orphaned)
            if (!isAuthorized) {
                if (document.getUser() == null && document.getUserId() == null) {
                    logger.warn("Document {} has no user association - allowing update", documentId);
                    isAuthorized = true; // Allow update of orphaned documents
                }
            }

            if (!isAuthorized) {
                logger.warn("Unauthorized access attempt to document {} by user {}", documentId, user.getId());
                throw new RuntimeException("Unauthorized access to document");
            }

            // Update document fields
            if (documentDto.getTitle() != null) {
                document.setTitle(documentDto.getTitle());
            }
            if (documentDto.getContent() != null) {
                document.setContent(documentDto.getContent());
            }
            if (documentDto.getType() != null) {
                document.setType(documentDto.getType());
            }
            if (documentDto.getPartyA() != null) {
                document.setPartyA(documentDto.getPartyA());
            }
            if (documentDto.getPartyB() != null) {
                document.setPartyB(documentDto.getPartyB());
            }
            if (documentDto.getTerms() != null) {
                document.setTerms(documentDto.getTerms());
            }

            // Increment version and mark as edited
            document.incrementVersion();

            LegalDocument updatedDocument = documentRepository.save(document);
            return convertToDto(updatedDocument);
        } catch (Exception e) {
            logger.error("Error updating document", e);
            throw new RuntimeException("Failed to update document: " + e.getMessage());
        }
    }

    public DocumentDto getDocument(String documentId, User user) {
        try {
            logger.info("Getting document: {} with user: {}", documentId, user != null ? user.getUsername() : "null");

            Optional<LegalDocument> document = documentRepository.findById(documentId);

            if (document.isEmpty()) {
                throw new RuntimeException("Document not found");
            }

            LegalDocument doc = document.get();

            // For development: bypass authorization if user is null
            if (user == null) {
                logger.warn("No user provided for document retrieval - allowing in development mode");
                return convertToDto(doc);
            }

            // Enhanced null checking for user authorization
            boolean isAuthorized = false;

            // Check if document has user reference
            if (doc.getUser() != null) {
                // Document has user reference, check if it matches current user
                if (doc.getUser().getId() != null && doc.getUser().getId().equals(user.getId())) {
                    isAuthorized = true;
                }
            }

            // If not authorized by user reference, check userId field
            if (!isAuthorized && doc.getUserId() != null) {
                if (doc.getUserId().equals(user.getId())) {
                    isAuthorized = true;
                    logger.debug("Document {} authorized via userId field", documentId);
                }
            }

            // If still not authorized, check if document has no user association (orphaned)
            if (!isAuthorized) {
                if (doc.getUser() == null && doc.getUserId() == null) {
                    logger.warn("Document {} has no user association - allowing access", documentId);
                    isAuthorized = true; // Allow access to orphaned documents
                }
            }

            // For development: if user is dev-user, allow access to any document
            if (!isAuthorized && "dev-user".equals(user.getUsername())) {
                logger.warn("Development user accessing document {} - allowing", documentId);
                isAuthorized = true;
            }

            if (!isAuthorized) {
                logger.warn("Unauthorized access attempt to document {} by user {}", documentId, user.getId());
                throw new RuntimeException("Unauthorized access to document");
            }

            return convertToDto(doc);
        } catch (Exception e) {
            logger.error("Error retrieving document {} for user: {}", documentId, user != null ? user.getId() : "null",
                    e);
            throw new RuntimeException("Failed to retrieve document: " + e.getMessage());
        }
    }

    public List<DocumentDto> getUserDocuments(User user) {
        try {
            logger.info("Getting user documents for user: {}", user != null ? user.getUsername() : "null");

            // For development: if user is null, get all documents
            if (user == null) {
                logger.warn("No user provided for document retrieval - getting all documents in development mode");
                List<LegalDocument> allDocuments = documentRepository.findAll();
                logger.info("Retrieved {} documents in development mode", allDocuments.size());
                return allDocuments.stream()
                        .map(this::convertToDto)
                        .collect(Collectors.toList());
            }

            List<LegalDocument> documents = documentRepository.findByUserIdOrderByCreatedAtDesc(user.getId());
            logger.info("Retrieved {} documents for user: {}", documents.size(), user.getId());

            return documents.stream()
                    .map(this::convertToDto)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Error retrieving user documents for user: {}", user != null ? user.getId() : "null", e);
            throw new RuntimeException("Failed to retrieve user documents: " + e.getMessage());
        }
    }

    public void deleteDocument(String documentId, User user) {
        try {
            logger.info("Starting delete operation for document: {} with user: {}", documentId,
                    user != null ? user.getUsername() : "null");

            if (user == null) {
                throw new RuntimeException("User is required to delete document");
            }

            Optional<LegalDocument> document = documentRepository.findById(documentId);
            logger.info("Document found in database: {}", document.isPresent());

            if (document.isEmpty()) {
                logger.error("Document not found with ID: {}", documentId);
                throw new RuntimeException("Document not found");
            }

            LegalDocument doc = document.get();
            logger.info("Document details - Title: {}, User: {}, UserId: {}",
                    doc.getTitle(),
                    doc.getUser() != null ? doc.getUser().getUsername() : "null",
                    doc.getUserId());

            // Enhanced authorization logic - same as used in other methods
            boolean isAuthorized = false;

            // Check if document has user reference
            if (doc.getUser() != null) {
                if (doc.getUser().getId() != null && doc.getUser().getId().equals(user.getId())) {
                    isAuthorized = true;
                }
            }

            // If not authorized by user reference, check userId field
            if (!isAuthorized && doc.getUserId() != null) {
                if (doc.getUserId().equals(user.getId())) {
                    isAuthorized = true;
                    logger.debug("Document {} authorized via userId field for deletion", documentId);
                }
            }

            // If still not authorized, check if document has no user association (orphaned)
            if (!isAuthorized) {
                if (doc.getUser() == null && doc.getUserId() == null) {
                    logger.warn("Document {} has no user association - allowing deletion", documentId);
                    isAuthorized = true; // Allow deletion of orphaned documents
                }
            }

            // For development: if user is dev-user, allow deletion of any document
            if (!isAuthorized && "dev-user".equals(user.getUsername())) {
                logger.warn("Development user deleting document {} - allowing", documentId);
                isAuthorized = true;
            }

            if (!isAuthorized) {
                logger.warn("Unauthorized deletion attempt for document {} by user {}", documentId, user.getId());
                throw new RuntimeException("Unauthorized: You can only delete your own documents");
            }

            // Log deletion details for audit
            logger.info("User {} authorized to delete document {} (Title: {})", 
                    user.getId(), documentId, doc.getTitle());
            
            documentRepository.deleteById(documentId);
            logger.info("Document {} deleted successfully by user {}", documentId, user.getId());
            
        } catch (Exception e) {
            logger.error("Error deleting document {} for user: {}", documentId, user != null ? user.getId() : "null",
                    e);
            throw new RuntimeException("Failed to delete document: " + e.getMessage());
        }
    }

    public void deleteMultipleDocuments(List<String> documentIds, User user) {
        try {
            logger.info("Starting bulk delete operation for {} documents with user: {}", 
                    documentIds.size(), user != null ? user.getUsername() : "null");

            if (user == null) {
                throw new RuntimeException("User is required to delete documents");
            }

            if (documentIds == null || documentIds.isEmpty()) {
                throw new RuntimeException("No documents specified for deletion");
            }

            int successCount = 0;
            int failureCount = 0;
            StringBuilder errorDetails = new StringBuilder();

            for (String documentId : documentIds) {
                try {
                    deleteDocument(documentId, user);
                    successCount++;
                } catch (Exception e) {
                    failureCount++;
                    logger.warn("Failed to delete document {}: {}", documentId, e.getMessage());
                    if (errorDetails.length() > 0) {
                        errorDetails.append("; ");
                    }
                    errorDetails.append(documentId).append(": ").append(e.getMessage());
                }
            }

            logger.info("Bulk delete completed - Success: {}, Failures: {}", successCount, failureCount);

            if (failureCount > 0) {
                throw new RuntimeException(String.format(
                        "Bulk delete partially failed. Success: %d, Failures: %d. Errors: %s",
                        successCount, failureCount, errorDetails.toString()));
            }

        } catch (Exception e) {
            logger.error("Error in bulk delete operation for user: {}", user != null ? user.getId() : "null", e);
            throw new RuntimeException("Failed to delete documents: " + e.getMessage());
        }
    }

    private DocumentDto convertToDto(LegalDocument document) {
        DocumentDto dto = new DocumentDto();
        dto.setId(document.getId());
        dto.setTitle(document.getTitle());
        dto.setContent(document.getContent());
        dto.setType(document.getType());
        dto.setPartyA(document.getPartyA());
        dto.setPartyB(document.getPartyB());
        dto.setTerms(document.getTerms());

        // Handle null user reference gracefully
        if (document.getUser() != null) {
            dto.setUserId(document.getUser().getId());
        } else {
            dto.setUserId(document.getUserId());
        }

        dto.setCreatedAt(document.getCreatedAt());
        dto.setUpdatedAt(document.getUpdatedAt());
        dto.setIsEdited(document.getIsEdited());
        dto.setVersion(document.getVersion());
        return dto;
    }
}
