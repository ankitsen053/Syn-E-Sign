package com.esign.legal_advisor.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
public class LocalModelService {

    private static final Logger logger = LoggerFactory.getLogger(LocalModelService.class);

    @Value("${local.model.enabled:false}")
    private boolean localModelEnabled;

    @Value("${local.model.path:models/ChatGPT-2.V2-GGUF}")
    private String modelPath;

    @Value("${local.model.executable:llama.cpp/main}")
    private String executablePath;

    @Value("${local.model.max-tokens:4000}")
    private int maxTokens;

    @Value("${local.model.temperature:0.1}")
    private double temperature;

    @Value("${local.model.timeout.seconds:300}")
    private int timeoutSeconds;

    /**
     * Generate legal agreement using local ChatGPT-2.V2 model
     */
    public String generateLegalAgreement(String agreementType, String partyA, String partyB, String terms) {
        logger.info("Generating legal agreement using local ChatGPT-2.V2: {} between {} and {}", agreementType, partyA,
                partyB);

        String prompt = buildLegalAgreementPrompt(agreementType, partyA, partyB, terms);

        try {
            String response = callLocalModel(prompt);
            logger.info("Successfully generated legal agreement using local ChatGPT-2.V2");
            return response;
        } catch (Exception e) {
            logger.error("Error generating legal agreement with local model: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to generate legal agreement: " + e.getMessage());
        }
    }

    /**
     * Perform comprehensive legal document analysis using local ChatGPT-2.V2
     */
    public String analyzeLegalDocument(String documentContent) {
        logger.info("Performing comprehensive legal document analysis using local ChatGPT-2.V2");

        String prompt = buildLegalAnalysisPrompt(documentContent);

        try {
            String analysis = callLocalModel(prompt);
            logger.info("Successfully analyzed legal document using local ChatGPT-2.V2");
            return analysis;
        } catch (Exception e) {
            logger.error("Error analyzing legal document with local model: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to analyze legal document: " + e.getMessage());
        }
    }

    /**
     * Assess legal compliance using local ChatGPT-2.V2
     */
    public String assessLegalCompliance(String documentContent, String jurisdiction) {
        logger.info("Assessing legal compliance using local ChatGPT-2.V2 for jurisdiction: {}", jurisdiction);

        String prompt = buildCompliancePrompt(documentContent, jurisdiction);

        try {
            String assessment = callLocalModel(prompt);
            logger.info("Successfully assessed legal compliance using local ChatGPT-2.V2");
            return assessment;
        } catch (Exception e) {
            logger.error("Error assessing legal compliance with local model: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to assess legal compliance: " + e.getMessage());
        }
    }

    /**
     * Perform legal risk analysis using local ChatGPT-2.V2
     */
    public String performRiskAnalysis(String documentContent) {
        logger.info("Performing legal risk analysis using local ChatGPT-2.V2");

        String prompt = buildRiskAnalysisPrompt(documentContent);

        try {
            String riskAnalysis = callLocalModel(prompt);
            logger.info("Successfully performed legal risk analysis using local ChatGPT-2.V2");
            return riskAnalysis;
        } catch (Exception e) {
            logger.error("Error performing legal risk analysis with local model: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to perform legal risk analysis: " + e.getMessage());
        }
    }

    /**
     * Highlight legal issues using local ChatGPT-2.V2
     */
    public String highlightLegalIssues(String documentContent) {
        logger.info("Highlighting legal issues using local ChatGPT-2.V2");

        String prompt = buildIssueHighlightPrompt(documentContent);

        try {
            String issues = callLocalModel(prompt);
            logger.info("Successfully highlighted legal issues using local ChatGPT-2.V2");
            return issues;
        } catch (Exception e) {
            logger.error("Error highlighting legal issues with local model: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to highlight legal issues: " + e.getMessage());
        }
    }

    /**
     * Call local model with the given prompt
     */
    private String callLocalModel(String prompt) throws Exception {
        if (!localModelEnabled) {
            throw new RuntimeException("Local model is not enabled");
        }

        // Find the GGUF model file
        String modelFile = findModelFile();
        if (modelFile == null) {
            throw new RuntimeException("Model file not found in: " + modelPath);
        }

        // Create temporary input file
        File inputFile = File.createTempFile("prompt_", ".txt");
        try (FileWriter writer = new FileWriter(inputFile)) {
            writer.write(prompt);
        }

        // Create temporary output file
        File outputFile = File.createTempFile("response_", ".txt");

        try {
            // Build command for llama.cpp
            ProcessBuilder processBuilder = new ProcessBuilder(
                    executablePath,
                    "-m", modelFile,
                    "-f", inputFile.getAbsolutePath(),
                    "-n", String.valueOf(maxTokens),
                    "--temp", String.valueOf(temperature),
                    "--no-display-prompt",
                    "-o", outputFile.getAbsolutePath());

            logger.info("Executing local model with command: {}", String.join(" ", processBuilder.command()));

            Process process = processBuilder.start();

            // Wait for completion with timeout
            boolean finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);

            if (!finished) {
                process.destroyForcibly();
                throw new RuntimeException("Local model execution timed out after " + timeoutSeconds + " seconds");
            }

            int exitCode = process.exitValue();
            if (exitCode != 0) {
                // Read error output
                String errorOutput = readStream(process.getErrorStream());
                throw new RuntimeException(
                        "Local model execution failed with exit code " + exitCode + ": " + errorOutput);
            }

            // Read the response
            String response = Files.readString(outputFile.toPath());

            // Clean up temporary files
            inputFile.delete();
            outputFile.delete();

            return response.trim();

        } catch (Exception e) {
            // Clean up temporary files on error
            if (inputFile.exists())
                inputFile.delete();
            if (outputFile.exists())
                outputFile.delete();
            throw e;
        }
    }

    /**
     * Find the GGUF model file in the model directory
     */
    private String findModelFile() {
        try {
            Path modelDir = Paths.get(modelPath);
            if (!Files.exists(modelDir)) {
                logger.error("Model directory does not exist: {}", modelPath);
                return null;
            }

            // Look for GGUF files
            return Files.walk(modelDir)
                    .filter(path -> path.toString().toLowerCase().endsWith(".gguf"))
                    .findFirst()
                    .map(Path::toString)
                    .orElse(null);

        } catch (Exception e) {
            logger.error("Error finding model file: {}", e.getMessage(), e);
            return null;
        }
    }

    /**
     * Read stream content
     */
    private String readStream(InputStream stream) throws IOException {
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
        }
        return output.toString();
    }

    /**
     * Build professional legal agreement generation prompt for ChatGPT-2.V2
     */
    private String buildLegalAgreementPrompt(String agreementType, String partyA, String partyB, String terms) {
        return String.format(
                """
                        You are a professional legal expert and senior lawyer specializing in contract law and legal document drafting. You have extensive experience in creating comprehensive, legally sound agreements.

                        Generate a professional %s between:
                        - Party A: %s
                        - Party B: %s

                        Specific Terms: %s

                        Requirements for this legal agreement:
                        1. Use professional legal language and terminology appropriate for commercial settings
                        2. Include all essential clauses required for this type of agreement
                        3. Ensure compliance with standard legal practices and enforceability
                        4. Include appropriate dispute resolution mechanisms (arbitration, mediation, or litigation)
                        5. Add comprehensive termination and breach clauses
                        6. Include governing law and jurisdiction clauses
                        7. Ensure the document is legally binding and enforceable in courts
                        8. Use clear, precise language to avoid ambiguity and future disputes
                        9. Include proper signature blocks and execution requirements
                        10. Add confidentiality and non-disclosure provisions where appropriate
                        11. Include force majeure and business continuity clauses
                        12. Add liability limitations and indemnification provisions

                        Structure the agreement with:
                        - Title and parties identification
                        - Recitals/Background section
                        - Definitions section (if needed)
                        - Main terms and conditions
                        - Payment/consideration terms (if applicable)
                        - Duration and termination provisions
                        - Dispute resolution mechanisms
                        - General provisions and boilerplate clauses
                        - Execution/signature section

                        Generate a complete, professional legal agreement that would be acceptable in commercial and legal settings, suitable for enforcement in courts.
                        """,
                agreementType, partyA, partyB, terms);
    }

    /**
     * Build comprehensive legal document analysis prompt for ChatGPT-2.V2
     */
    private String buildLegalAnalysisPrompt(String documentContent) {
        return String.format(
                """
                        You are a senior legal counsel and partner at a top-tier law firm with 25+ years of experience in contract law, corporate law, and legal document review. You have handled complex commercial transactions, M&A deals, and high-stakes litigation.

                        Perform a comprehensive legal analysis of the following document with the depth and precision expected by senior legal professionals:

                        %s

                        Provide a detailed legal memorandum covering:

                        1. EXECUTIVE SUMMARY:
                        - Document type, purpose, and commercial context
                        - Parties involved, their roles, and business relationship
                        - Key commercial terms and financial implications
                        - Overall legal risk assessment and recommendation

                        2. LEGAL STRUCTURE ANALYSIS:
                        - Contract formation elements (offer, acceptance, consideration)
                        - Governing law and jurisdiction adequacy
                        - Dispute resolution mechanisms and enforceability
                        - Amendment and termination procedures
                        - Assignment and transfer restrictions

                        3. COMMERCIAL TERMS REVIEW:
                        - Payment terms and financial obligations
                        - Performance standards and deliverables
                        - Timeline and milestone provisions
                        - Intellectual property rights and ownership
                        - Confidentiality and non-disclosure obligations

                        4. RISK ASSESSMENT & LIABILITY:
                        - Liability limitations and indemnification adequacy
                        - Force majeure and business continuity provisions
                        - Insurance requirements and coverage gaps
                        - Regulatory compliance and industry standards
                        - Potential dispute scenarios and resolution costs

                        5. LEGAL STRENGTHS:
                        - Well-drafted protective clauses
                        - Clear performance standards and metrics
                        - Adequate dispute resolution mechanisms
                        - Proper legal formalities and execution requirements
                        - Industry best practices implementation

                        6. CRITICAL LEGAL WEAKNESSES:
                        - Ambiguous or unenforceable language
                        - Missing essential legal protections
                        - Inadequate liability and risk allocation
                        - Compliance gaps and regulatory risks
                        - Potential unconscionability or unfair terms

                        7. STRATEGIC RECOMMENDATIONS:
                        - Specific clause improvements with sample language
                        - Additional protective provisions needed
                        - Risk mitigation strategies and alternatives
                        - Negotiation priorities and fallback positions
                        - Implementation timeline and resource requirements

                        8. COMPLIANCE & REGULATORY ANALYSIS:
                        - Applicable laws and regulations compliance
                        - Industry-specific requirements adherence
                        - Data protection and privacy law compliance
                        - Anti-corruption and ethics requirements
                        - International law considerations (if applicable)

                        Provide professional, actionable legal insights with specific recommendations that would be valuable for senior legal decision-making and client advisory purposes.
                        """,
                documentContent);
    }

    /**
     * Build legal compliance assessment prompt for ChatGPT-2.V2
     */
    private String buildCompliancePrompt(String documentContent, String jurisdiction) {
        return String.format(
                """
                        You are a compliance specialist and legal expert with deep knowledge of %s law and regulations. You have extensive experience in regulatory compliance and legal risk management.

                        Assess the legal compliance of the following document for %s jurisdiction:

                        %s

                        Provide a detailed compliance assessment including:

                        1. REGULATORY COMPLIANCE:
                        - Applicable laws and regulations analysis
                        - Compliance status assessment
                        - Required disclosures presence
                        - Mandatory clause inclusion

                        2. JURISDICTIONAL REQUIREMENTS:
                        - Local law compatibility
                        - Court system recognition
                        - Enforcement mechanisms
                        - Legal formalities compliance

                        3. INDUSTRY STANDARDS:
                        - Sector-specific regulations
                        - Professional standards adherence
                        - Best practice implementation
                        - Industry code compliance

                        4. COMPLIANCE GAPS:
                        - Missing regulatory requirements
                        - Non-compliant provisions
                        - Risk areas identification
                        - Correction priorities

                        5. REMEDIATION PLAN:
                        - Specific actions required
                        - Timeline for compliance
                        - Resource requirements
                        - Implementation steps

                        Provide a professional compliance report with clear recommendations for achieving full legal compliance.
                        """,
                jurisdiction, jurisdiction, documentContent);
    }

    /**
     * Build legal risk analysis prompt for ChatGPT-2.V2
     */
    private String buildRiskAnalysisPrompt(String documentContent) {
        return String.format(
                """
                        You are a legal risk management expert specializing in contract risk assessment and mitigation. You have extensive experience in identifying and managing legal risks in commercial agreements.

                        Perform a comprehensive legal risk analysis of the following document:

                        %s

                        Provide a detailed risk assessment covering:

                        1. CONTRACTUAL RISKS:
                        - Performance risks and delivery/milestone risks
                        - Payment and financial risks
                        - Termination and breach risks
                        - Force majeure and business continuity risks

                        2. LIABILITY RISKS:
                        - Indemnification exposure
                        - Limitation of liability adequacy
                        - Insurance requirements
                        - Third-party claims exposure

                        3. OPERATIONAL RISKS:
                        - Business continuity risks
                        - Intellectual property risks
                        - Confidentiality breaches
                        - Regulatory compliance risks

                        4. LEGAL RISKS:
                        - Enforceability concerns
                        - Jurisdiction and governing law risks
                        - Dispute resolution adequacy
                        - Breach consequences

                        5. FINANCIAL RISKS:
                        - Cost overrun exposure
                        - Revenue recognition issues
                        - Currency/exchange risks
                        - Credit and collection risks

                        6. RISK MITIGATION:
                        - Recommended protective clauses
                        - Insurance requirements
                        - Performance guarantees
                        - Monitoring mechanisms

                        Provide a professional risk assessment with specific recommendations for risk mitigation and management.
                        """,
                documentContent);
    }

    /**
     * Build legal issue highlighting prompt for ChatGPT-2.V2
     */
    private String buildIssueHighlightPrompt(String documentContent) {
        return String.format(
                """
                        You are a senior legal counsel with 20+ years of experience in contract law, corporate law, and legal document review. You have expertise in identifying critical legal issues that could lead to disputes, enforceability problems, or regulatory violations.

                        Perform a comprehensive legal issue analysis of the following document:

                        %s

                        Analyze and categorize issues with the precision and detail expected by professional lawyers:

                        1. CRITICAL LEGAL ISSUES (Immediate legal attention required):
                        - Enforceability problems (unconscionable terms, illegal provisions)
                        - Missing essential legal elements (consideration, mutual assent, capacity)
                        - Conflicting or contradictory provisions
                        - Invalid clauses that violate public policy
                        - Missing governing law and jurisdiction clauses
                        - Inadequate dispute resolution mechanisms
                        - Breach of statutory requirements

                        2. HIGH-RISK ISSUES (Significant legal exposure):
                        - Ambiguous language creating interpretation disputes
                        - Inadequate liability protections and indemnification
                        - Unfair or unconscionable terms favoring one party
                        - Missing force majeure or termination clauses
                        - Inadequate intellectual property protections
                        - Compliance gaps with applicable regulations
                        - Missing confidentiality and non-disclosure provisions

                        3. MODERATE LEGAL ISSUES (Standard practice improvements):
                        - Suboptimal clause structure and organization
                        - Missing industry-standard provisions
                        - Unclear definitions and terminology
                        - Inadequate performance standards and metrics
                        - Missing change management procedures
                        - Insufficient record-keeping requirements

                        4. MINOR ISSUES (Drafting and style improvements):
                        - Formatting and numbering inconsistencies
                        - Non-standard legal language usage
                        - Redundant or unnecessary provisions
                        - Style and clarity improvements

                        For each issue identified, provide:
                        - EXACT clause/section reference with line numbers
                        - CLEAR legal problem description
                        - SPECIFIC potential legal consequences
                        - DETAILED recommended solution with sample language
                        - PRIORITY level and urgency
                        - RELEVANT case law or regulatory references (if applicable)
                        - ESTIMATED risk level (Low/Medium/High/Critical)

                        Present findings in a professional legal memorandum format suitable for senior counsel review, with executive summary and detailed analysis sections.
                        """,
                documentContent);
    }

    /**
     * Check if local model service is properly configured
     */
    public boolean isConfigured() {
        if (!localModelEnabled) {
            return false;
        }

        // Check if model directory exists
        Path modelDir = Paths.get(modelPath);
        if (!Files.exists(modelDir)) {
            logger.warn("Model directory does not exist: {}", modelPath);
            return false;
        }

        // Check if executable exists
        Path executable = Paths.get(executablePath);
        if (!Files.exists(executable)) {
            logger.warn("Model executable does not exist: {}", executablePath);
            return false;
        }

        // Check if model file exists
        String modelFile = findModelFile();
        if (modelFile == null) {
            logger.warn("No GGUF model file found in: {}", modelPath);
            return false;
        }

        return true;
    }

    /**
     * Test local model connectivity
     */
    public Map<String, Object> testConnection() {
        Map<String, Object> result = new HashMap<>();

        try {
            if (!isConfigured()) {
                result.put("success", false);
                result.put("message", "Local model not properly configured");
                return result;
            }

            String testResponse = callLocalModel(
                    "Test connection. Please respond with 'Local ChatGPT-2.V2 connection successful'.");

            result.put("success", true);
            result.put("message", "Local ChatGPT-2.V2 connection successful");
            result.put("model", "ChatGPT-2.V2-GGUF (Local)");
            result.put("response", testResponse);

        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "Local model connection failed: " + e.getMessage());
            logger.error("Local model connection test failed", e);
        }

        return result;
    }
}


















