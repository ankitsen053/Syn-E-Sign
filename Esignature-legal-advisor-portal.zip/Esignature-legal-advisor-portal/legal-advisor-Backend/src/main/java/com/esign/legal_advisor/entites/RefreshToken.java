//package com.esign.legal_advisor.entites;
//
//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;
//
//import java.time.Instant;
//
//
//@Document(collection = "refresh_tokens")
//public class RefreshToken {
//    @Id
//    private String id;
//    private String token;
//    private String userId;
//    private Instant expiryDate;
//	public void setToken(String string) {
//		// TODO Auto-generated method stub
//		
//	}
//	public void setUserId(String id2) {
//		// TODO Auto-generated method stub
//		
//	}
//	public void setExpiryDate(Instant plusSeconds) {
//		// TODO Auto-generated method stub
//		
//	}
//	public String getToken() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	public Instant getExpiryDate() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	public String getUserId() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//    // Getters/Setters
//}
package com.esign.legal_advisor.entites;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.Instant;

@Document(collection = "refresh_tokens")
public class RefreshToken {
  @Id
  private String id;
  private String token;
  private String userId;
  private Instant expiryDate;

  public String getId() { return id; }
  public void setId(String id) { this.id = id; }

  public String getToken() { return token; }
  public void setToken(String token) { this.token = token; }

  public String getUserId() { return userId; }
  public void setUserId(String userId) { this.userId = userId; }

  public Instant getExpiryDate() { return expiryDate; }
  public void setExpiryDate(Instant expiryDate) { this.expiryDate = expiryDate; }
}
