package com.esign.legal_advisor.service;

import lombok.extern.slf4j.Slf4j;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

@Service
@Slf4j
public class DocumentTextExtractionService {

    private final Tesseract tesseract;

    public DocumentTextExtractionService() {
        this.tesseract = new Tesseract();
        // Configure Tesseract (you may need to set the data path based on your system)
        // tesseract.setDatapath("/usr/share/tesseract-ocr/4.00/tessdata");
        tesseract.setLanguage("eng");
    }

    /**
     * Extract text from uploaded document (PDF or Image)
     */
    public String extractTextFromDocument(MultipartFile file) throws IOException {
        String contentType = file.getContentType();
        String originalFilename = file.getOriginalFilename();
        
        log.info("Extracting text from document: {} (type: {})", originalFilename, contentType);

        try {
            if (isPdfFile(contentType, originalFilename)) {
                return extractTextFromPdf(file.getInputStream());
            } else if (isImageFile(contentType, originalFilename)) {
                return extractTextFromImage(file.getBytes());
            } else {
                throw new IllegalArgumentException("Unsupported file type: " + contentType);
            }
        } catch (Exception e) {
            log.error("Error extracting text from document: {}", originalFilename, e);
            throw new IOException("Failed to extract text from document: " + e.getMessage(), e);
        }
    }

    /**
     * Extract text from PDF document
     */
    private String extractTextFromPdf(InputStream inputStream) throws IOException {
        try (PDDocument document = PDDocument.load(inputStream)) {
            PDFTextStripper textStripper = new PDFTextStripper();
            String extractedText = textStripper.getText(document);
            
            log.info("Successfully extracted {} characters from PDF", extractedText.length());
            return extractedText.trim();
        }
    }

    /**
     * Extract text from image using OCR
     */
    private String extractTextFromImage(byte[] imageBytes) throws IOException {
        try (ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes)) {
            BufferedImage image = ImageIO.read(bis);
            
            if (image == null) {
                throw new IOException("Unable to read image data");
            }

            String extractedText = tesseract.doOCR(image);
            
            log.info("Successfully extracted {} characters from image using OCR", extractedText.length());
            return extractedText.trim();
            
        } catch (TesseractException e) {
            log.error("OCR processing failed", e);
            throw new IOException("OCR processing failed: " + e.getMessage(), e);
        }
    }

    /**
     * Check if file is a PDF
     */
    private boolean isPdfFile(String contentType, String filename) {
        return (contentType != null && contentType.equals("application/pdf")) ||
               (filename != null && filename.toLowerCase().endsWith(".pdf"));
    }

    /**
     * Check if file is an image
     */
    private boolean isImageFile(String contentType, String filename) {
        if (contentType != null) {
            return contentType.startsWith("image/");
        }
        
        if (filename != null) {
            String lowerFilename = filename.toLowerCase();
            return lowerFilename.endsWith(".jpg") || 
                   lowerFilename.endsWith(".jpeg") || 
                   lowerFilename.endsWith(".png") || 
                   lowerFilename.endsWith(".tiff") || 
                   lowerFilename.endsWith(".tif") || 
                   lowerFilename.endsWith(".bmp");
        }
        
        return false;
    }

    /**
     * Clean and normalize extracted text
     */
    public String cleanExtractedText(String rawText) {
        if (rawText == null || rawText.trim().isEmpty()) {
            return "";
        }

        return rawText
                .replaceAll("\\s+", " ")  // Replace multiple spaces with single space
                .replaceAll("\\n+", "\n") // Replace multiple newlines with single newline
                .trim();
    }

    /**
     * Validate that meaningful text was extracted
     */
    public boolean isValidExtractedText(String text) {
        if (text == null || text.trim().length() < 10) {
            return false;
        }

        // Check if text contains some alphabetic characters (not just numbers/symbols)
        long alphabeticCount = text.chars()
                .filter(Character::isLetter)
                .count();

        // Require at least 20% alphabetic characters
        return alphabeticCount >= (text.length() * 0.2);
    }
}
