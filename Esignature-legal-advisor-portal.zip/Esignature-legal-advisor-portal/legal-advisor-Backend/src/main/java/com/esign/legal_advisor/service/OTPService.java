package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.OTP;
import com.esign.legal_advisor.repository.OTPRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Random;

@Service
public class OTPService {

    private static final Logger logger = LoggerFactory.getLogger(OTPService.class);

    @Autowired
    private OTPRepository otpRepository;

    @Autowired
    private EmailService emailService;

    public String generateAndSendOTP(String email, String purpose) {
        try {
            // Generate 6-digit OTP
            String otpCode = String.format("%06d", new Random().nextInt(1000000));

            // Save OTP to database
            OTP otp = new OTP();
            otp.setEmail(email);
            otp.setOtpCode(otpCode);
            otp.setPurpose(purpose);
            otp.setExpiresAt(LocalDateTime.now().plusMinutes(5));
            otp.setAttempts(0);

            otpRepository.save(otp);

            // Send OTP via email
            emailService.sendOtpEmail(email, otpCode);

            logger.info("OTP generated and sent to: {}", email);
            return otpCode;
        } catch (Exception e) {
            logger.error("Error generating OTP for: {}", email, e);
            throw new RuntimeException("Failed to generate OTP");
        }
    }

    public boolean verifyOTP(String email, String otpCode, String purpose) {
        try {
            OTP otp = otpRepository.findByEmailAndPurpose(email, purpose);

            if (otp == null) {
                logger.warn("No OTP found for email: {} and purpose: {}", email, purpose);
                return false;
            }

            if (otp.getAttempts() >= 3) {
                logger.warn("Max OTP attempts exceeded for email: {}", email);
                return false;
            }

            if (otp.getExpiresAt().isBefore(LocalDateTime.now())) {
                logger.warn("OTP expired for email: {}", email);
                return false;
            }

            if (!otp.getOtpCode().equals(otpCode)) {
                otp.setAttempts(otp.getAttempts() + 1);
                otpRepository.save(otp);
                logger.warn("Invalid OTP for email: {}", email);
                return false;
            }

            // OTP verified successfully
            otpRepository.delete(otp);
            logger.info("OTP verified successfully for email: {}", email);
            return true;
        } catch (Exception e) {
            logger.error("Error verifying OTP for: {}", email, e);
            return false;
        }
    }
}
