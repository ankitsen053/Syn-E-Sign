package com.esign.legal_advisor.entites;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.index.Indexed;
import java.time.LocalDateTime;
import java.util.List;

@Document(collection = "digilocker_verification_requests")
public class DigiLockerVerificationRequest {

    @Id
    private String id;

    @Indexed(unique = true)
    private String verificationToken; // Unique token for the verification link

    private String merchantUserId; // User who created the verification request
    private String customerEmail; // Customer's email (optional)
    private String customerMobile; // Customer's mobile number
    private String customerName; // Customer's name (optional)

    // Verification Configuration
    private List<String> requestedDocuments; // AADHAAR, PAN, DRIVING_LICENSE, etc.
    private String verificationPurpose; // Purpose of verification
    private boolean consentRequired = true;

    // Link Configuration
    private String verificationLink; // Generated link for customer
    private LocalDateTime linkExpiresAt; // Link expiration time
    private boolean linkActive = true;

    // Verification Status
    private VerificationRequestStatus status = VerificationRequestStatus.PENDING;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime completedAt;

    // Customer Journey Tracking
    private boolean linkOpened = false;
    private LocalDateTime linkOpenedAt;
    private boolean otpSent = false;
    private LocalDateTime otpSentAt;
    private boolean customerAuthenticated = false;
    private LocalDateTime customerAuthenticatedAt;
    private boolean consentGiven = false;
    private LocalDateTime consentGivenAt;

    // Verification Results
    private String digiLockerId; // Customer's DigiLocker ID (after authentication)
    private String verificationResult; // JSON string of verification results
    private String errorMessage;
    private int retryCount = 0;

    // Webhook Configuration
    private String webhookUrl; // URL to notify merchant of completion
    private boolean webhookSent = false;
    private LocalDateTime webhookSentAt;

    public enum VerificationRequestStatus {
        PENDING, // Request created, waiting for customer
        LINK_OPENED, // Customer opened the link
        OTP_SENT, // OTP sent to customer's mobile
        OTP_VERIFIED, // Customer verified OTP successfully
        AUTHENTICATED, // Customer authenticated with DigiLocker
        CONSENT_PENDING, // Waiting for customer consent
        CONSENT_GIVEN, // Customer gave consent for document sharing
        DOCUMENTS_UPLOADED, // Customer uploaded documents for verification
        IN_PROGRESS, // Verification in progress
        COMPLETED, // Verification completed successfully
        FAILED, // Verification failed
        EXPIRED, // Link expired
        CANCELLED // Request cancelled by merchant
    }

    // Constructors
    public DigiLockerVerificationRequest() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.linkExpiresAt = LocalDateTime.now().plusHours(24); // Default 24 hour expiry
    }

    public DigiLockerVerificationRequest(String merchantUserId, List<String> requestedDocuments) {
        this();
        this.merchantUserId = merchantUserId;
        this.requestedDocuments = requestedDocuments;
        this.verificationToken = generateVerificationToken();
    }

    // Generate unique verification token
    private String generateVerificationToken() {
        return java.util.UUID.randomUUID().toString().replace("-", "");
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVerificationToken() {
        return verificationToken;
    }

    public void setVerificationToken(String verificationToken) {
        this.verificationToken = verificationToken;
    }

    public String getMerchantUserId() {
        return merchantUserId;
    }

    public void setMerchantUserId(String merchantUserId) {
        this.merchantUserId = merchantUserId;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getCustomerMobile() {
        return customerMobile;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public List<String> getRequestedDocuments() {
        return requestedDocuments;
    }

    public void setRequestedDocuments(List<String> requestedDocuments) {
        this.requestedDocuments = requestedDocuments;
    }

    public String getVerificationPurpose() {
        return verificationPurpose;
    }

    public void setVerificationPurpose(String verificationPurpose) {
        this.verificationPurpose = verificationPurpose;
    }

    public boolean isConsentRequired() {
        return consentRequired;
    }

    public void setConsentRequired(boolean consentRequired) {
        this.consentRequired = consentRequired;
    }

    public String getVerificationLink() {
        return verificationLink;
    }

    public void setVerificationLink(String verificationLink) {
        this.verificationLink = verificationLink;
    }

    public LocalDateTime getLinkExpiresAt() {
        return linkExpiresAt;
    }

    public void setLinkExpiresAt(LocalDateTime linkExpiresAt) {
        this.linkExpiresAt = linkExpiresAt;
    }

    public boolean isLinkActive() {
        return linkActive;
    }

    public void setLinkActive(boolean linkActive) {
        this.linkActive = linkActive;
    }

    public VerificationRequestStatus getStatus() {
        return status;
    }

    public void setStatus(VerificationRequestStatus status) {
        this.status = status;
        this.updatedAt = LocalDateTime.now();

        if (status == VerificationRequestStatus.COMPLETED ||
                status == VerificationRequestStatus.FAILED) {
            this.completedAt = LocalDateTime.now();
        }
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    // Customer Journey Tracking Getters/Setters
    public boolean isLinkOpened() {
        return linkOpened;
    }

    public void setLinkOpened(boolean linkOpened) {
        this.linkOpened = linkOpened;
        if (linkOpened) {
            this.linkOpenedAt = LocalDateTime.now();
            if (this.status == VerificationRequestStatus.PENDING) {
                this.setStatus(VerificationRequestStatus.LINK_OPENED);
            }
        }
    }

    public LocalDateTime getLinkOpenedAt() {
        return linkOpenedAt;
    }

    public void setLinkOpenedAt(LocalDateTime linkOpenedAt) {
        this.linkOpenedAt = linkOpenedAt;
    }

    public boolean isOtpSent() {
        return otpSent;
    }

    public void setOtpSent(boolean otpSent) {
        this.otpSent = otpSent;
        if (otpSent) {
            this.otpSentAt = LocalDateTime.now();
            this.setStatus(VerificationRequestStatus.OTP_SENT);
        }
    }

    public LocalDateTime getOtpSentAt() {
        return otpSentAt;
    }

    public void setOtpSentAt(LocalDateTime otpSentAt) {
        this.otpSentAt = otpSentAt;
    }

    public boolean isCustomerAuthenticated() {
        return customerAuthenticated;
    }

    public void setCustomerAuthenticated(boolean customerAuthenticated) {
        this.customerAuthenticated = customerAuthenticated;
        if (customerAuthenticated) {
            this.customerAuthenticatedAt = LocalDateTime.now();
            this.setStatus(VerificationRequestStatus.AUTHENTICATED);
        }
    }

    public LocalDateTime getCustomerAuthenticatedAt() {
        return customerAuthenticatedAt;
    }

    public void setCustomerAuthenticatedAt(LocalDateTime customerAuthenticatedAt) {
        this.customerAuthenticatedAt = customerAuthenticatedAt;
    }

    public boolean isConsentGiven() {
        return consentGiven;
    }

    public void setConsentGiven(boolean consentGiven) {
        this.consentGiven = consentGiven;
        if (consentGiven) {
            this.consentGivenAt = LocalDateTime.now();
            this.setStatus(VerificationRequestStatus.IN_PROGRESS);
        }
    }

    public LocalDateTime getConsentGivenAt() {
        return consentGivenAt;
    }

    public void setConsentGivenAt(LocalDateTime consentGivenAt) {
        this.consentGivenAt = consentGivenAt;
    }

    public String getDigiLockerId() {
        return digiLockerId;
    }

    public void setDigiLockerId(String digiLockerId) {
        this.digiLockerId = digiLockerId;
    }

    public String getVerificationResult() {
        return verificationResult;
    }

    public void setVerificationResult(String verificationResult) {
        this.verificationResult = verificationResult;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public String getWebhookUrl() {
        return webhookUrl;
    }

    public void setWebhookUrl(String webhookUrl) {
        this.webhookUrl = webhookUrl;
    }

    public boolean isWebhookSent() {
        return webhookSent;
    }

    public void setWebhookSent(boolean webhookSent) {
        this.webhookSent = webhookSent;
        if (webhookSent) {
            this.webhookSentAt = LocalDateTime.now();
        }
    }

    public LocalDateTime getWebhookSentAt() {
        return webhookSentAt;
    }

    public void setWebhookSentAt(LocalDateTime webhookSentAt) {
        this.webhookSentAt = webhookSentAt;
    }

    // Helper methods
    public boolean isExpired() {
        return LocalDateTime.now().isAfter(linkExpiresAt);
    }

    public boolean isActive() {
        return linkActive && !isExpired() &&
                (status == VerificationRequestStatus.PENDING ||
                        status == VerificationRequestStatus.LINK_OPENED ||
                        status == VerificationRequestStatus.OTP_SENT ||
                        status == VerificationRequestStatus.AUTHENTICATED ||
                        status == VerificationRequestStatus.CONSENT_PENDING ||
                        status == VerificationRequestStatus.IN_PROGRESS);
    }

    public double getProgressPercentage() {
        switch (status) {
            case PENDING:
                return 0.0;
            case LINK_OPENED:
                return 20.0;
            case OTP_SENT:
                return 40.0;
            case AUTHENTICATED:
                return 60.0;
            case CONSENT_PENDING:
                return 70.0;
            case IN_PROGRESS:
                return 80.0;
            case COMPLETED:
                return 100.0;
            default:
                return 0.0;
        }
    }
}
