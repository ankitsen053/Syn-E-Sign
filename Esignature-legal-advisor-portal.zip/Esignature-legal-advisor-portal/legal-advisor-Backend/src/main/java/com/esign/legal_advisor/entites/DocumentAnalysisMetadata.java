package com.esign.legal_advisor.entites;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DBRef;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.List;

/**
 * Entity for storing document analysis metadata and results
 */
@Document(collection = "document_analysis_metadata")
public class DocumentAnalysisMetadata {

    @Id
    private String id;
    
    private String documentId;
    
    @DBRef(lazy = true)
    private User analyzedBy;
    
    private String analysisType; // PAN, AADHAAR, GENERAL, CONTRACT, etc.
    private String analysisStatus; // PENDING, IN_PROGRESS, COMPLETED, FAILED
    private LocalDateTime analysisStartedAt;
    private LocalDateTime analysisCompletedAt;
    
    // Analysis results
    private Double confidenceScore;
    private String documentQuality; // GOOD, MEDIUM, POOR
    private String riskLevel; // LOW, MEDIUM, HIGH
    private boolean isVerified;
    
    // Extracted data
    private Map<String, Object> extractedData;
    private Map<String, String> validationResults;
    private Map<String, Double> fieldConfidenceScores;
    
    // Compliance and risk assessment
    private boolean complianceCheckPassed;
    private Map<String, Boolean> complianceChecks;
    private Map<String, String> riskFactors;
    private List<String> recommendations;
    
    // AI insights
    private String summary;
    private Map<String, String> keyFindings;
    private String modelName; // Name of the AI model used
    private String modelVersion;
    
    // Error handling
    private String errorMessage;
    private String errorCode;
    private Map<String, String> errorDetails;
    
    // Metadata
    private Map<String, Object> metadata;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Constructors
    public DocumentAnalysisMetadata() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.analysisStatus = "PENDING";
    }

    public DocumentAnalysisMetadata(String documentId, String analysisType, User analyzedBy) {
        this();
        this.documentId = documentId;
        this.analysisType = analysisType;
        this.analyzedBy = analyzedBy;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public User getAnalyzedBy() {
        return analyzedBy;
    }

    public void setAnalyzedBy(User analyzedBy) {
        this.analyzedBy = analyzedBy;
    }

    public String getAnalysisType() {
        return analysisType;
    }

    public void setAnalysisType(String analysisType) {
        this.analysisType = analysisType;
    }

    public String getAnalysisStatus() {
        return analysisStatus;
    }

    public void setAnalysisStatus(String analysisStatus) {
        this.analysisStatus = analysisStatus;
    }

    public LocalDateTime getAnalysisStartedAt() {
        return analysisStartedAt;
    }

    public void setAnalysisStartedAt(LocalDateTime analysisStartedAt) {
        this.analysisStartedAt = analysisStartedAt;
    }

    public LocalDateTime getAnalysisCompletedAt() {
        return analysisCompletedAt;
    }

    public void setAnalysisCompletedAt(LocalDateTime analysisCompletedAt) {
        this.analysisCompletedAt = analysisCompletedAt;
    }

    public Double getConfidenceScore() {
        return confidenceScore;
    }

    public void setConfidenceScore(Double confidenceScore) {
        this.confidenceScore = confidenceScore;
    }

    public String getDocumentQuality() {
        return documentQuality;
    }

    public void setDocumentQuality(String documentQuality) {
        this.documentQuality = documentQuality;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public boolean isVerified() {
        return isVerified;
    }

    public void setVerified(boolean verified) {
        isVerified = verified;
    }

    public Map<String, Object> getExtractedData() {
        return extractedData;
    }

    public void setExtractedData(Map<String, Object> extractedData) {
        this.extractedData = extractedData;
    }

    public Map<String, String> getValidationResults() {
        return validationResults;
    }

    public void setValidationResults(Map<String, String> validationResults) {
        this.validationResults = validationResults;
    }

    public Map<String, Double> getFieldConfidenceScores() {
        return fieldConfidenceScores;
    }

    public void setFieldConfidenceScores(Map<String, Double> fieldConfidenceScores) {
        this.fieldConfidenceScores = fieldConfidenceScores;
    }

    public boolean isComplianceCheckPassed() {
        return complianceCheckPassed;
    }

    public void setComplianceCheckPassed(boolean complianceCheckPassed) {
        this.complianceCheckPassed = complianceCheckPassed;
    }

    public Map<String, Boolean> getComplianceChecks() {
        return complianceChecks;
    }

    public void setComplianceChecks(Map<String, Boolean> complianceChecks) {
        this.complianceChecks = complianceChecks;
    }

    public Map<String, String> getRiskFactors() {
        return riskFactors;
    }

    public void setRiskFactors(Map<String, String> riskFactors) {
        this.riskFactors = riskFactors;
    }

    public List<String> getRecommendations() {
        return recommendations;
    }

    public void setRecommendations(List<String> recommendations) {
        this.recommendations = recommendations;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Map<String, String> getKeyFindings() {
        return keyFindings;
    }

    public void setKeyFindings(Map<String, String> keyFindings) {
        this.keyFindings = keyFindings;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getModelVersion() {
        return modelVersion;
    }

    public void setModelVersion(String modelVersion) {
        this.modelVersion = modelVersion;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public Map<String, String> getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(Map<String, String> errorDetails) {
        this.errorDetails = errorDetails;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    // Helper methods
    public void startAnalysis() {
        this.analysisStatus = "IN_PROGRESS";
        this.analysisStartedAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public void completeAnalysis(Double confidenceScore, String documentQuality, String riskLevel) {
        this.analysisStatus = "COMPLETED";
        this.confidenceScore = confidenceScore;
        this.documentQuality = documentQuality;
        this.riskLevel = riskLevel;
        this.analysisCompletedAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public void failAnalysis(String errorMessage, String errorCode) {
        this.analysisStatus = "FAILED";
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
        this.analysisCompletedAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public void updateAnalysisResults(Map<String, Object> extractedData, Map<String, String> validationResults) {
        this.extractedData = extractedData;
        this.validationResults = validationResults;
        this.updatedAt = LocalDateTime.now();
    }

    public boolean isAnalysisComplete() {
        return "COMPLETED".equals(this.analysisStatus);
    }

    public boolean isAnalysisFailed() {
        return "FAILED".equals(this.analysisStatus);
    }

    public Long getAnalysisDurationInSeconds() {
        if (this.analysisStartedAt != null && this.analysisCompletedAt != null) {
            return java.time.Duration.between(this.analysisStartedAt, this.analysisCompletedAt).getSeconds();
        }
        return null;
    }
}
