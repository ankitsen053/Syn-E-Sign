package com.esign.legal_advisor.entites;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Document(collection = "users")
public class User implements UserDetails {
  /**
   * 
   */
  private static final long serialVersionUID = 8870538449441248700L;

  @Id
  private String id;

  @Indexed(unique = true)
  private String username;

  @Indexed(unique = true)
  private String email;

  private String password;

  private String fullName;
  private String profilePicture;
  private String googleId; // For Google OAuth

  // Additional profile fields
  private String phone;
  private String address;
  private String company;
  private String position;
  private String bio;
  private String website;
  private String timezone;
  private String dateOfBirth;

  // User Type and Verification
  private String userType; // INDIVIDUAL, COMPANY, LAWYER, LEGAL_FIRM, ADMIN
  private String panNumber; // For individuals
  private String gstNumber; // For companies
  private String companyName; // For companies
  private String businessAddress; // For companies
  private String contactNumber; // For companies
  private String companyEmail; // For companies
  private boolean isVerified; // Overall verification status
  private String verificationLevel; // BASIC, ENHANCED, FULL

  // Lawyer-specific fields
  private String barNumber; // Bar registration number
  private String barAssociation; // Bar association name
  private String practiceAreas; // Comma-separated practice areas
  private String lawSchool; // Law school attended
  private String yearOfAdmission; // Year admitted to bar
  private String licenseNumber; // Professional license number
  private String specialization; // Legal specialization
  private String experience; // Years of experience
  private String hourlyRate; // Hourly billing rate
  private String firmName; // Law firm name
  private String firmAddress; // Law firm address
  private String professionalBio; // Professional biography
  private String certifications; // Professional certifications
  private String languages; // Languages spoken
  private boolean isBarVerified; // Bar verification status
  private String verificationDocument; // Verification document URL

  @DBRef(lazy = true)
  private Set<Role> roles = new HashSet<>();

  private boolean accountNonExpired = true;
  private boolean accountNonLocked = true;
  private boolean credentialsNonExpired = true;
  private boolean enabled = true;
  private boolean emailVerified = false;

  // Timestamp fields
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;

  public User() {
    this.createdAt = LocalDateTime.now();
    this.updatedAt = LocalDateTime.now();
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  @Override
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  @Override
  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public Set<Role> getRoles() {
    return roles;
  }

  public void setRoles(Set<Role> roles) {
    this.roles = roles;
  }

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
    if (roles == null) {
      return new ArrayList<>();
    }
    return roles.stream()
        .filter(r -> r != null && r.getName() != null)
        .map(r -> new SimpleGrantedAuthority(r.getName().name()))
        .collect(Collectors.toList());
  }

  @Override
  public boolean isAccountNonExpired() {
    return accountNonExpired;
  }

  @Override
  public boolean isAccountNonLocked() {
    return accountNonLocked;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return credentialsNonExpired;
  }

  @Override
  public boolean isEnabled() {
    return enabled;
  }

  public void setAccountNonExpired(boolean v) {
    this.accountNonExpired = v;
  }

  public void setAccountNonLocked(boolean v) {
    this.accountNonLocked = v;
  }

  public void setCredentialsNonExpired(boolean v) {
    this.credentialsNonExpired = v;
  }

  public void setEnabled(boolean v) {
    this.enabled = v;
  }

  public boolean isEmailVerified() {
    return emailVerified;
  }

  public void setEmailVerified(boolean v) {
    this.emailVerified = v;
  }

  public String getFullName() {
    return fullName;
  }

  public void setFullName(String fullName) {
    this.fullName = fullName;
  }

  public String getProfilePicture() {
    return profilePicture;
  }

  public void setProfilePicture(String profilePicture) {
    this.profilePicture = profilePicture;
  }

  public String getGoogleId() {
    return googleId;
  }

  public void setGoogleId(String googleId) {
    this.googleId = googleId;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getCompany() {
    return company;
  }

  public void setCompany(String company) {
    this.company = company;
  }

  public String getPosition() {
    return position;
  }

  public void setPosition(String position) {
    this.position = position;
  }

  public String getBio() {
    return bio;
  }

  public void setBio(String bio) {
    this.bio = bio;
  }

  public String getWebsite() {
    return website;
  }

  public void setWebsite(String website) {
    this.website = website;
  }

  public String getTimezone() {
    return timezone;
  }

  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  public String getDateOfBirth() {
    return dateOfBirth;
  }

  public void setDateOfBirth(String dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
  }

  // User Type and Verification Getters and Setters
  public String getUserType() {
    return userType;
  }

  public void setUserType(String userType) {
    this.userType = userType;
  }

  public String getPanNumber() {
    return panNumber;
  }

  public void setPanNumber(String panNumber) {
    this.panNumber = panNumber;
  }

  public String getGstNumber() {
    return gstNumber;
  }

  public void setGstNumber(String gstNumber) {
    this.gstNumber = gstNumber;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public String getBusinessAddress() {
    return businessAddress;
  }

  public void setBusinessAddress(String businessAddress) {
    this.businessAddress = businessAddress;
  }

  public String getContactNumber() {
    return contactNumber;
  }

  public void setContactNumber(String contactNumber) {
    this.contactNumber = contactNumber;
  }

  public String getCompanyEmail() {
    return companyEmail;
  }

  public void setCompanyEmail(String companyEmail) {
    this.companyEmail = companyEmail;
  }

  public boolean isVerified() {
    return isVerified;
  }

  public void setVerified(boolean verified) {
    isVerified = verified;
  }

  public String getVerificationLevel() {
    return verificationLevel;
  }

  public void setVerificationLevel(String verificationLevel) {
    this.verificationLevel = verificationLevel;
  }

  public LocalDateTime getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(LocalDateTime createdAt) {
    this.createdAt = createdAt;
  }

  public LocalDateTime getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(LocalDateTime updatedAt) {
    this.updatedAt = updatedAt;
  }

  // Method to update the updatedAt field
  public void touch() {
    this.updatedAt = LocalDateTime.now();
  }

  // Lawyer-specific getters and setters
  public String getBarNumber() {
    return barNumber;
  }

  public void setBarNumber(String barNumber) {
    this.barNumber = barNumber;
  }

  public String getBarAssociation() {
    return barAssociation;
  }

  public void setBarAssociation(String barAssociation) {
    this.barAssociation = barAssociation;
  }

  public String getPracticeAreas() {
    return practiceAreas;
  }

  public void setPracticeAreas(String practiceAreas) {
    this.practiceAreas = practiceAreas;
  }

  public String getLawSchool() {
    return lawSchool;
  }

  public void setLawSchool(String lawSchool) {
    this.lawSchool = lawSchool;
  }

  public String getYearOfAdmission() {
    return yearOfAdmission;
  }

  public void setYearOfAdmission(String yearOfAdmission) {
    this.yearOfAdmission = yearOfAdmission;
  }

  public String getLicenseNumber() {
    return licenseNumber;
  }

  public void setLicenseNumber(String licenseNumber) {
    this.licenseNumber = licenseNumber;
  }

  public String getSpecialization() {
    return specialization;
  }

  public void setSpecialization(String specialization) {
    this.specialization = specialization;
  }

  public String getExperience() {
    return experience;
  }

  public void setExperience(String experience) {
    this.experience = experience;
  }

  public String getHourlyRate() {
    return hourlyRate;
  }

  public void setHourlyRate(String hourlyRate) {
    this.hourlyRate = hourlyRate;
  }

  public String getFirmName() {
    return firmName;
  }

  public void setFirmName(String firmName) {
    this.firmName = firmName;
  }

  public String getFirmAddress() {
    return firmAddress;
  }

  public void setFirmAddress(String firmAddress) {
    this.firmAddress = firmAddress;
  }

  public String getProfessionalBio() {
    return professionalBio;
  }

  public void setProfessionalBio(String professionalBio) {
    this.professionalBio = professionalBio;
  }

  public String getCertifications() {
    return certifications;
  }

  public void setCertifications(String certifications) {
    this.certifications = certifications;
  }

  public String getLanguages() {
    return languages;
  }

  public void setLanguages(String languages) {
    this.languages = languages;
  }

  public boolean isBarVerified() {
    return isBarVerified;
  }

  public void setBarVerified(boolean barVerified) {
    isBarVerified = barVerified;
  }

  public String getVerificationDocument() {
    return verificationDocument;
  }

  public void setVerificationDocument(String verificationDocument) {
    this.verificationDocument = verificationDocument;
  }
}
