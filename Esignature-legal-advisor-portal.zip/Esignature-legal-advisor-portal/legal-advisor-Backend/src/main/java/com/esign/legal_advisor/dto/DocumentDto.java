package com.esign.legal_advisor.dto;

import java.time.LocalDateTime;

public class DocumentDto {
    private String id;
    private String title;
    private String content;
    private String type;
    private String partyA;
    private String partyB;
    private String terms;
    private String userId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Boolean isEdited;
    private Integer version;
    
    // Constructors
    public DocumentDto() {}
    
    public DocumentDto(String title, String content, String type, String partyA, String partyB, String terms) {
        this.title = title;
        this.content = content;
        this.type = type;
        this.partyA = partyA;
        this.partyB = partyB;
        this.terms = terms;
    }
    
    // Getters and Setters
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getPartyA() {
        return partyA;
    }
    
    public void setPartyA(String partyA) {
        this.partyA = partyA;
    }
    
    public String getPartyB() {
        return partyB;
    }
    
    public void setPartyB(String partyB) {
        this.partyB = partyB;
    }
    
    public String getTerms() {
        return terms;
    }
    
    public void setTerms(String terms) {
        this.terms = terms;
    }
    
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public Boolean getIsEdited() {
        return isEdited;
    }
    
    public void setIsEdited(Boolean isEdited) {
        this.isEdited = isEdited;
    }
    
    public Integer getVersion() {
        return version;
    }
    
    public void setVersion(Integer version) {
        this.version = version;
    }
}
