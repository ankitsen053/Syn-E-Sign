package com.esign.legal_advisor.config;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import java.util.concurrent.TimeUnit;

@Configuration
@EnableMongoRepositories(basePackages = "com.esign.legal_advisor.repository")
public class MongoConfig extends AbstractMongoClientConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(MongoConfig.class);

    @Value("${spring.data.mongodb.uri}")
    private String mongoUri;

    @Value("${spring.data.mongodb.database}")
    private String databaseName;

    @Override
    protected String getDatabaseName() {
        return databaseName;
    }

    @Override
    @Bean
    public MongoClient mongoClient() {
        try {
            logger.info("Initializing MongoDB connection to: {}", mongoUri.replaceAll("//[^:]+:[^@]+@", "//***:***@"));

            ConnectionString connectionString = new ConnectionString(mongoUri);

            MongoClientSettings settings = MongoClientSettings.builder()
                    .applyConnectionString(connectionString)
                    .applyToClusterSettings(builder -> builder.serverSelectionTimeout(30, TimeUnit.SECONDS))
                    .applyToSocketSettings(builder -> builder.connectTimeout(30, TimeUnit.SECONDS)
                            .readTimeout(30, TimeUnit.SECONDS))
                    .applyToConnectionPoolSettings(builder -> builder.maxSize(10)
                            .minSize(1)
                            .maxWaitTime(30, TimeUnit.SECONDS)
                            .maxConnectionLifeTime(30, TimeUnit.SECONDS))
                    .applyToServerSettings(builder -> builder.heartbeatFrequency(10, TimeUnit.SECONDS))
                    .build();

            MongoClient mongoClient = MongoClients.create(settings);

            // Test the connection
            try {
                mongoClient.getDatabase(databaseName).runCommand(new org.bson.Document("ping", 1));
                logger.info("MongoDB connection established successfully");
            } catch (Exception e) {
                logger.error("Failed to establish MongoDB connection: {}", e.getMessage());
                throw new RuntimeException("MongoDB connection failed", e);
            }

            return mongoClient;

        } catch (Exception e) {
            logger.error("Error creating MongoDB client: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to create MongoDB client", e);
        }
    }

    @Bean
    public MongoTemplate mongoTemplate() throws Exception {
        return new MongoTemplate(mongoClient(), getDatabaseName());
    }
}
