package com.esign.legal_advisor.repository;

import com.esign.legal_advisor.entites.DocumentAnalysisMetadata;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository for DocumentAnalysisMetadata entity
 */
@Repository
public interface DocumentAnalysisMetadataRepository extends MongoRepository<DocumentAnalysisMetadata, String> {

    /**
     * Find analysis metadata by document ID
     */
    List<DocumentAnalysisMetadata> findByDocumentIdOrderByCreatedAtDesc(String documentId);

    /**
     * Find analysis metadata by document ID and analysis type
     */
    List<DocumentAnalysisMetadata> findByDocumentIdAndAnalysisTypeOrderByCreatedAtDesc(String documentId, String analysisType);

    /**
     * Find the latest analysis metadata for a document
     */
    Optional<DocumentAnalysisMetadata> findFirstByDocumentIdOrderByCreatedAtDesc(String documentId);

    /**
     * Find analysis metadata by analysis status
     */
    List<DocumentAnalysisMetadata> findByAnalysisStatusOrderByCreatedAtDesc(String analysisStatus);

    /**
     * Find analysis metadata by analysis type
     */
    List<DocumentAnalysisMetadata> findByAnalysisTypeOrderByCreatedAtDesc(String analysisType);

    /**
     * Find analysis metadata by confidence score range
     */
    List<DocumentAnalysisMetadata> findByConfidenceScoreBetweenOrderByConfidenceScoreDesc(Double minScore, Double maxScore);

    /**
     * Find analysis metadata by document quality
     */
    List<DocumentAnalysisMetadata> findByDocumentQualityOrderByCreatedAtDesc(String documentQuality);

    /**
     * Find analysis metadata by risk level
     */
    List<DocumentAnalysisMetadata> findByRiskLevelOrderByCreatedAtDesc(String riskLevel);

    /**
     * Find analysis metadata by verification status
     */
    List<DocumentAnalysisMetadata> findByIsVerifiedOrderByCreatedAtDesc(boolean isVerified);

    /**
     * Find analysis metadata by user who performed the analysis
     */
    List<DocumentAnalysisMetadata> findByAnalyzedByIdOrderByCreatedAtDesc(String analyzedById);

    /**
     * Find analysis metadata created within a date range
     */
    List<DocumentAnalysisMetadata> findByCreatedAtBetweenOrderByCreatedAtDesc(LocalDateTime startDate, LocalDateTime endDate);

    /**
     * Find analysis metadata completed within a date range
     */
    List<DocumentAnalysisMetadata> findByAnalysisCompletedAtBetweenOrderByAnalysisCompletedAtDesc(LocalDateTime startDate, LocalDateTime endDate);

    /**
     * Count analysis metadata by document ID
     */
    long countByDocumentId(String documentId);

    /**
     * Count analysis metadata by analysis status
     */
    long countByAnalysisStatus(String analysisStatus);

    /**
     * Count analysis metadata by analysis type
     */
    long countByAnalysisType(String analysisType);

    /**
     * Count analysis metadata by verification status
     */
    long countByIsVerified(boolean isVerified);

    /**
     * Find documents with high confidence scores (above threshold)
     */
    @Query("{'confidenceScore': {$gte: ?0}}")
    List<DocumentAnalysisMetadata> findHighConfidenceAnalyses(Double confidenceThreshold);

    /**
     * Find documents with low confidence scores (below threshold)
     */
    @Query("{'confidenceScore': {$lte: ?0}}")
    List<DocumentAnalysisMetadata> findLowConfidenceAnalyses(Double confidenceThreshold);

    /**
     * Find analysis metadata by multiple criteria
     */
    @Query("{'documentId': ?0, 'analysisType': ?1, 'analysisStatus': ?2}")
    List<DocumentAnalysisMetadata> findByDocumentIdAndAnalysisTypeAndStatus(String documentId, String analysisType, String analysisStatus);

    /**
     * Find failed analyses within a date range
     */
    @Query("{'analysisStatus': 'FAILED', 'createdAt': {$gte: ?0, $lte: ?1}}")
    List<DocumentAnalysisMetadata> findFailedAnalysesInDateRange(LocalDateTime startDate, LocalDateTime endDate);

    /**
     * Find analyses that need review (low confidence or failed)
     */
    @Query("{'$or': [{'confidenceScore': {$lte: ?0}}, {'analysisStatus': 'FAILED'}]}")
    List<DocumentAnalysisMetadata> findAnalysesNeedingReview(Double confidenceThreshold);

    /**
     * Delete analysis metadata by document ID
     */
    void deleteByDocumentId(String documentId);

    /**
     * Delete analysis metadata older than specified date
     */
    void deleteByCreatedAtBefore(LocalDateTime date);
}
