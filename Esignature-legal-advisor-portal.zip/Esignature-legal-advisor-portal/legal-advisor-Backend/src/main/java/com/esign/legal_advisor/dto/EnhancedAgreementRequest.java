package com.esign.legal_advisor.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.Map;

/**
 * Enhanced request for generating comprehensive legal agreements
 * with detailed terms and conditions
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EnhancedAgreementRequest {

    @NotBlank(message = "Agreement title is required")
    @Size(max = 200, message = "Title cannot exceed 200 characters")
    private String title;

    @NotBlank(message = "Agreement type is required")
    @Size(max = 100, message = "Type cannot exceed 100 characters")
    private String type;

    @NotBlank(message = "Party A name is required")
    @Size(max = 200, message = "Party A name cannot exceed 200 characters")
    private String partyA;

    @NotBlank(message = "Party B name is required")
    @Size(max = 200, message = "Party B name cannot exceed 200 characters")
    private String partyB;

    @Size(max = 2000, message = "Terms cannot exceed 2000 characters")
    private String terms;

    @Size(max = 1000, message = "Prompt cannot exceed 1000 characters")
    private String prompt;

    // Enhanced legal details
    @Size(max = 500, message = "Jurisdiction cannot exceed 500 characters")
    private String jurisdiction;

    @Size(max = 1000, message = "Governing law cannot exceed 1000 characters")
    private String governingLaw;

    @Size(max = 1000, message = "Dispute resolution cannot exceed 1000 characters")
    private String disputeResolution;

    @Size(max = 1000, message = "Termination clauses cannot exceed 1000 characters")
    private String terminationClauses;

    @Size(max = 1000, message = "Liability limitations cannot exceed 1000 characters")
    private String liabilityLimitations;

    @Size(max = 1000, message = "Confidentiality terms cannot exceed 1000 characters")
    private String confidentialityTerms;

    @Size(max = 1000, message = "Intellectual property terms cannot exceed 1000 characters")
    private String intellectualPropertyTerms;

    @Size(max = 1000, message = "Data protection terms cannot exceed 1000 characters")
    private String dataProtectionTerms;

    @Size(max = 1000, message = "Force majeure terms cannot exceed 1000 characters")
    private String forceMajeureTerms;

    @Size(max = 1000, message = "Assignment terms cannot exceed 1000 characters")
    private String assignmentTerms;

    @Size(max = 1000, message = "Amendment terms cannot exceed 1000 characters")
    private String amendmentTerms;

    @Size(max = 1000, message = "Severability terms cannot exceed 1000 characters")
    private String severabilityTerms;

    @Size(max = 1000, message = "Entire agreement terms cannot exceed 1000 characters")
    private String entireAgreementTerms;

    // Additional specifications
    @Size(max = 1000, message = "Additional details cannot exceed 1000 characters")
    private String additionalDetails;

    @Size(max = 1000, message = "Special conditions cannot exceed 1000 characters")
    private String specialConditions;

    @Size(max = 1000, message = "Performance metrics cannot exceed 1000 characters")
    private String performanceMetrics;

    @Size(max = 1000, message = "Payment terms cannot exceed 1000 characters")
    private String paymentTerms;

    @Size(max = 1000, message = "Delivery terms cannot exceed 1000 characters")
    private String deliveryTerms;

    @Size(max = 1000, message = "Warranty terms cannot exceed 1000 characters")
    private String warrantyTerms;

    @Size(max = 1000, message = "Insurance requirements cannot exceed 1000 characters")
    private String insuranceRequirements;

    // Compliance and regulatory requirements
    private List<String> complianceRequirements;

    private Map<String, String> regulatoryStandards;

    private List<String> industryStandards;

    // Risk management
    private String riskAssessment;

    private List<String> riskMitigationStrategies;

    private String insuranceCoverage;

    // Document preferences
    private boolean includeStandardClauses;

    private boolean includeCustomClauses;

    private boolean includeComplianceChecklist;

    private boolean includeRiskAssessment;

    private String preferredFormat; // "COMPREHENSIVE", "STANDARD", "MINIMAL"

    // Validation methods
    public boolean isValidForGeneration() {
        return title != null && !title.trim().isEmpty() &&
               type != null && !type.trim().isEmpty() &&
               partyA != null && !partyA.trim().isEmpty() &&
               partyB != null && !partyB.trim().isEmpty();
    }

    public int getTotalContentLength() {
        int total = 0;
        total += title != null ? title.length() : 0;
        total += type != null ? type.length() : 0;
        total += partyA != null ? partyA.length() : 0;
        total += partyB != null ? partyB.length() : 0;
        total += terms != null ? terms.length() : 0;
        total += prompt != null ? prompt.length() : 0;
        total += jurisdiction != null ? jurisdiction.length() : 0;
        total += governingLaw != null ? governingLaw.length() : 0;
        total += disputeResolution != null ? disputeResolution.length() : 0;
        total += terminationClauses != null ? terminationClauses.length() : 0;
        total += liabilityLimitations != null ? liabilityLimitations.length() : 0;
        total += confidentialityTerms != null ? confidentialityTerms.length() : 0;
        total += intellectualPropertyTerms != null ? intellectualPropertyTerms.length() : 0;
        total += dataProtectionTerms != null ? dataProtectionTerms.length() : 0;
        total += forceMajeureTerms != null ? forceMajeureTerms.length() : 0;
        total += assignmentTerms != null ? assignmentTerms.length() : 0;
        total += amendmentTerms != null ? amendmentTerms.length() : 0;
        total += severabilityTerms != null ? severabilityTerms.length() : 0;
        total += entireAgreementTerms != null ? entireAgreementTerms.length() : 0;
        total += additionalDetails != null ? additionalDetails.length() : 0;
        total += specialConditions != null ? specialConditions.length() : 0;
        total += performanceMetrics != null ? performanceMetrics.length() : 0;
        total += paymentTerms != null ? paymentTerms.length() : 0;
        total += deliveryTerms != null ? deliveryTerms.length() : 0;
        total += warrantyTerms != null ? warrantyTerms.length() : 0;
        total += insuranceRequirements != null ? insuranceRequirements.length() : 0;
        total += riskAssessment != null ? riskAssessment.length() : 0;
        total += insuranceCoverage != null ? insuranceCoverage.length() : 0;
        
        return total;
    }

    public boolean isWithinContentLimits() {
        return getTotalContentLength() <= 5000; // 5KB limit
    }
}
