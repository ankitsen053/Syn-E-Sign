package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.service.DocxService;
import com.esign.legal_advisor.service.HuggingFaceService;
import com.esign.legal_advisor.service.LocalModelService;
import com.esign.legal_advisor.service.ProfessionalLegalAnalysisService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@CrossOrigin(origins = "*")
public class AiController {

    private static final Logger logger = LoggerFactory.getLogger(AiController.class);

    @Autowired
    private com.esign.legal_advisor.service.AiService aiService;

    @Autowired
    private HuggingFaceService huggingFaceService;

    @Autowired
    private LocalModelService localModelService;

    @Autowired
    private DocxService docxService;

    @Autowired
    private ProfessionalLegalAnalysisService professionalLegalAnalysisService;

    @Value("${ai.service.timeout.seconds:300}")
    private int timeoutSeconds;

    @Value("${ai.service.max-retries:5}")
    private int maxRetries;

    @Value("${gemini.api.key}")
    private String apiKey;

    /**
     * Document analysis endpoint
     */
    @PostMapping("/analyze")
    public ResponseEntity<?> analyzeDocument(@RequestParam("file") MultipartFile file) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting document analysis for file: {} ({} bytes)",
                file.getOriginalFilename(), file.getSize());

        try {
            // Extract text and analyze
            String extractedText = aiService.extractTextFromFile(file);
            String analysis = aiService.analyzeDocument(extractedText);

            long endTime = System.currentTimeMillis();
            logger.info("Document analysis completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("analysis", analysis);
            response.put("processingTime", (endTime - startTime));
            response.put("documentSize", file.getSize());
            response.put("textLength", extractedText.length());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in document analysis", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Document analysis failed: " + e.getMessage()));
        }
    }

    /**
     * Text-based document analysis endpoint
     */
    @PostMapping("/analyze-text")
    public ResponseEntity<?> analyzeDocumentText(@RequestBody Map<String, String> request) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting text-based document analysis");

        try {
            String content = request.get("content");
            if (content == null || content.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Document content is required"));
            }

            String analysis = aiService.analyzeDocument(content);

            long endTime = System.currentTimeMillis();
            logger.info("Text-based document analysis completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("analysis", analysis);
            response.put("processingTime", (endTime - startTime));
            response.put("textLength", content.length());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in text-based document analysis", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Document analysis failed: " + e.getMessage()));
        }
    }

    /**
     * Agreement creation endpoint
     */
    @PostMapping("/create")
    public ResponseEntity<?> createAgreement(@RequestBody Map<String, String> request) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting agreement creation with parameters: {}", request);

        try {
            String type = request.get("type");
            String partyA = request.get("partyA");
            String partyB = request.get("partyB");
            String terms = request.get("terms");

            if (type == null || type.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Agreement type is required"));
            }

            String document = aiService.generateAgreement(type, partyA, partyB, terms);

            long endTime = System.currentTimeMillis();
            logger.info("Agreement creation completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("document", document);
            response.put("processingTime", (endTime - startTime));
            response.put("documentLength", document.length());

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {
            logger.warn("Invalid request parameters: {}", e.getMessage());
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Invalid request: " + e.getMessage()));
        } catch (Exception e) {
            logger.error("Error in agreement creation", e);

            // Provide user-friendly error messages
            String userMessage = "Agreement creation failed. Please try again.";
            if (e.getMessage().contains("timeout")) {
                userMessage = "Request timed out. Please try again with a shorter request.";
            } else if (e.getMessage().contains("API key")) {
                userMessage = "AI service configuration issue. Please try again later.";
            } else if (e.getMessage().contains("rate limit")) {
                userMessage = "Service is busy. Please wait a moment and try again.";
            }

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse(userMessage));
        }
    }

    /**
     * Agreement creation and download endpoint
     */
    @PostMapping("/create-and-download")
    public ResponseEntity<?> createAndDownloadAgreement(@RequestBody Map<String, String> request) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting agreement creation and download with parameters: {}", request);

        try {
            String type = request.get("type");
            String partyA = request.get("partyA");
            String partyB = request.get("partyB");
            String terms = request.get("terms");

            if (type == null || type.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Agreement type is required"));
            }

            String documentContent = aiService.generateAgreement(type, partyA, partyB, terms);

            // Generate DOCX
            byte[] docxBytes = docxService.generateDocx(type, partyA, partyB, documentContent);

            long endTime = System.currentTimeMillis();
            logger.info("Agreement creation and download completed successfully in {}ms, DOCX size: {} bytes",
                    (endTime - startTime), docxBytes.length);

            // Set response headers for file download
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment",
                    String.format("%s_Agreement_%s_%s.docx",
                            type.replaceAll("\\s+", "_"),
                            partyA != null ? partyA.replaceAll("\\s+", "_") : "PartyA",
                            partyB != null ? partyB.replaceAll("\\s+", "_") : "PartyB"));
            headers.setContentLength(docxBytes.length);

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(docxBytes);

        } catch (Exception e) {
            logger.error("Error in agreement creation and download", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Agreement creation and download failed: " + e.getMessage()));
        }
    }

    /**
     * Download agreement as TXT file
     */
    @PostMapping("/download-txt")
    public ResponseEntity<?> downloadAgreementAsTxt(@RequestBody Map<String, String> request) {
        logger.info("Downloading agreement as TXT with parameters: {}", request);

        try {
            String type = request.get("type");
            String partyA = request.get("partyA");
            String partyB = request.get("partyB");
            String terms = request.get("terms");
            String content = request.get("content");

            // Validate input parameters
            if (content == null || content.trim().isEmpty()) {
                throw new IllegalArgumentException("Agreement content is required");
            }

            if (content.length() > 1000000) { // 1MB limit
                throw new IllegalArgumentException("Document content too large (max 1MB)");
            }

            if (type != null && type.length() > 500) {
                throw new IllegalArgumentException("Agreement type too long (max 500 characters)");
            }

            // Format the content for TXT download
            StringBuilder formattedContent = new StringBuilder();
            formattedContent.append("=".repeat(80)).append("\n");
            formattedContent.append("LEGAL AGREEMENT\n");
            formattedContent.append("=".repeat(80)).append("\n\n");

            if (type != null) {
                formattedContent.append("Agreement Type: ").append(type).append("\n");
            }
            if (partyA != null) {
                formattedContent.append("Party A: ").append(partyA).append("\n");
            }
            if (partyB != null) {
                formattedContent.append("Party B: ").append(partyB).append("\n");
            }
            if (terms != null && !terms.trim().isEmpty()) {
                formattedContent.append("Terms: ").append(terms).append("\n");
            }

            formattedContent.append("Generated: ").append(java.time.LocalDateTime.now().format(
                    java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("\n\n");
            formattedContent.append("-".repeat(80)).append("\n");
            formattedContent.append("AGREEMENT CONTENT\n");
            formattedContent.append("-".repeat(80)).append("\n\n");
            formattedContent.append(content);
            formattedContent.append("\n\n").append("=".repeat(80)).append("\n");
            formattedContent.append("END OF AGREEMENT\n");
            formattedContent.append("=".repeat(80));

            byte[] txtBytes = formattedContent.toString().getBytes("UTF-8");

            // Set response headers for file download
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_PLAIN);
            headers.setContentDispositionFormData("attachment",
                    String.format("%s_Agreement_%s_%s.txt",
                            type != null ? type.replaceAll("\\s+", "_") : "Legal",
                            partyA != null ? partyA.replaceAll("\\s+", "_") : "PartyA",
                            partyB != null ? partyB.replaceAll("\\s+", "_") : "PartyB"));
            headers.setContentLength(txtBytes.length);

            logger.info("TXT download completed successfully, size: {} bytes", txtBytes.length);
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(txtBytes);

        } catch (IllegalArgumentException e) {
            logger.warn("Invalid download request: {}", e.getMessage());
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Invalid download request: " + e.getMessage()));
        } catch (Exception e) {
            logger.error("Error downloading agreement as TXT", e);

            String userMessage = "Download failed. Please try again.";
            if (e.getMessage().contains("content")) {
                userMessage = "Document content is missing or invalid. Please generate a document first.";
            } else if (e.getMessage().contains("encoding")) {
                userMessage = "Text encoding error. Please try again.";
            }

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse(userMessage));
        }
    }

    /**
     * Download agreement as DOCX file with custom content
     */
    @PostMapping("/download-docx")
    public ResponseEntity<?> downloadAgreementAsDocx(@RequestBody Map<String, String> request) {
        logger.info("Downloading agreement as DOCX with parameters: {}", request);

        try {
            String type = request.get("type");
            String partyA = request.get("partyA");
            String partyB = request.get("partyB");
            String terms = request.get("terms");
            String content = request.get("content");

            // Validate input parameters
            if (content == null || content.trim().isEmpty()) {
                throw new IllegalArgumentException("Agreement content is required");
            }

            if (content.length() > 500000) { // 500KB limit for DOCX (smaller due to conversion overhead)
                throw new IllegalArgumentException("Document content too large for DOCX conversion (max 500KB)");
            }

            if (type != null && type.length() > 500) {
                throw new IllegalArgumentException("Agreement type too long (max 500 characters)");
            }

            // Generate DOCX with custom content
            byte[] docxBytes = docxService.generateDocx(
                    type != null ? type : "Legal Agreement",
                    partyA != null ? partyA : "Party A",
                    partyB != null ? partyB : "Party B",
                    content);

            // Set response headers for file download
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment",
                    String.format("%s_Agreement_%s_%s.docx",
                            type != null ? type.replaceAll("\\s+", "_") : "Legal",
                            partyA != null ? partyA.replaceAll("\\s+", "_") : "PartyA",
                            partyB != null ? partyB.replaceAll("\\s+", "_") : "PartyB"));
            headers.setContentLength(docxBytes.length);

            logger.info("DOCX download completed successfully, size: {} bytes", docxBytes.length);
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(docxBytes);

        } catch (IllegalArgumentException e) {
            logger.warn("Invalid DOCX download request: {}", e.getMessage());
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Invalid download request: " + e.getMessage()));
        } catch (Exception e) {
            logger.error("Error downloading agreement as DOCX", e);

            String userMessage = "DOCX download failed. Please try again.";
            if (e.getMessage().contains("content")) {
                userMessage = "Document content is missing or invalid. Please generate a document first.";
            } else if (e.getMessage().contains("memory") || e.getMessage().contains("OutOfMemory")) {
                userMessage = "Document too large for DOCX conversion. Try downloading as TXT instead.";
            } else if (e.getMessage().contains("format")) {
                userMessage = "Document format error. Please regenerate the document.";
            }

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse(userMessage));
        }
    }

    /**
     * Generate and save agreement endpoint
     */
    @PostMapping("/generate-and-save")
    public ResponseEntity<?> generateAndSaveAgreement(@RequestBody Map<String, String> request) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting agreement generation and save with parameters: {}", request);

        try {
            String type = request.get("type");
            String partyA = request.get("partyA");
            String partyB = request.get("partyB");
            String terms = request.get("terms");

            if (type == null || type.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Agreement type is required"));
            }

            String document = aiService.generateAgreement(type, partyA, partyB, terms);

            long endTime = System.currentTimeMillis();
            logger.info("Agreement generation and save completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("document", document);
            response.put("processingTime", (endTime - startTime));
            response.put("documentLength", document.length());
            response.put("message", "Agreement generated and ready for saving");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in agreement generation and save", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Agreement generation and save failed: " + e.getMessage()));
        }
    }

    /**
     * Highlight issues endpoint
     */
    @PostMapping("/highlight-issues")
    public ResponseEntity<?> highlightIssues(@RequestParam("file") MultipartFile file) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting issue highlighting for file: {} ({} bytes)",
                file.getOriginalFilename(), file.getSize());

        try {
            String extractedText = aiService.extractTextFromFile(file);
            String issues = aiService.highlightIssues(extractedText);

            long endTime = System.currentTimeMillis();
            logger.info("Issue highlighting completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("issues", issues);
            response.put("processingTime", (endTime - startTime));
            response.put("documentSize", file.getSize());
            response.put("textLength", extractedText.length());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in issue highlighting", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Issue highlighting failed: " + e.getMessage()));
        }
    }

    /**
     * Risk analysis endpoint
     */
    @PostMapping("/risk-analysis")
    public ResponseEntity<?> performRiskAnalysis(@RequestParam("file") MultipartFile file) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting risk analysis for file: {} ({} bytes)",
                file.getOriginalFilename(), file.getSize());

        try {
            String extractedText = aiService.extractTextFromFile(file);
            String riskAnalysis = aiService.performRiskAnalysis(extractedText);

            long endTime = System.currentTimeMillis();
            logger.info("Risk analysis completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("riskAnalysis", riskAnalysis);
            response.put("processingTime", (endTime - startTime));
            response.put("documentSize", file.getSize());
            response.put("textLength", extractedText.length());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in risk analysis", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Risk analysis failed: " + e.getMessage()));
        }
    }

    /**
     * Compliance assessment endpoint
     */
    @PostMapping("/compliance-assessment")
    public ResponseEntity<?> assessCompliance(@RequestParam("file") MultipartFile file,
            @RequestParam("jurisdiction") String jurisdiction) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting compliance assessment for file: {} ({} bytes) in jurisdiction: {}",
                file.getOriginalFilename(), file.getSize(), jurisdiction);

        try {
            String extractedText = aiService.extractTextFromFile(file);
            String complianceAssessment = aiService.assessCompliance(extractedText, jurisdiction);

            long endTime = System.currentTimeMillis();
            logger.info("Compliance assessment completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("complianceAssessment", complianceAssessment);
            response.put("processingTime", (endTime - startTime));
            response.put("documentSize", file.getSize());
            response.put("textLength", extractedText.length());
            response.put("jurisdiction", jurisdiction);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in compliance assessment", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Compliance assessment failed: " + e.getMessage()));
        }
    }

    /**
     * Text-based issue highlighting endpoint
     */
    @PostMapping("/highlight-issues-text")
    public ResponseEntity<?> highlightIssuesText(@RequestBody Map<String, String> request) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting text-based issue highlighting");

        try {
            String content = request.get("content");
            if (content == null || content.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Document content is required"));
            }

            String issues = aiService.highlightIssues(content);

            long endTime = System.currentTimeMillis();
            logger.info("Text-based issue highlighting completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("issues", issues);
            response.put("processingTime", (endTime - startTime));
            response.put("textLength", content.length());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in text-based issue highlighting", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Issue highlighting failed: " + e.getMessage()));
        }
    }

    /**
     * Text-based risk analysis endpoint
     */
    @PostMapping("/risk-analysis-text")
    public ResponseEntity<?> performRiskAnalysisText(@RequestBody Map<String, String> request) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting text-based risk analysis");

        try {
            String content = request.get("content");
            if (content == null || content.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Document content is required"));
            }

            String riskAnalysis = aiService.performRiskAnalysis(content);

            long endTime = System.currentTimeMillis();
            logger.info("Text-based risk analysis completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("riskAnalysis", riskAnalysis);
            response.put("processingTime", (endTime - startTime));
            response.put("textLength", content.length());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in text-based risk analysis", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Risk analysis failed: " + e.getMessage()));
        }
    }

    /**
     * Text-based compliance assessment endpoint
     */
    @PostMapping("/compliance-assessment-text")
    public ResponseEntity<?> assessComplianceText(@RequestBody Map<String, Object> request) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting text-based compliance assessment");

        try {
            String content = (String) request.get("content");
            String jurisdiction = (String) request.get("jurisdiction");

            if (content == null || content.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Document content is required"));
            }

            if (jurisdiction == null || jurisdiction.trim().isEmpty()) {
                jurisdiction = "IN"; // Default jurisdiction
            }

            String complianceAssessment = aiService.assessCompliance(content, jurisdiction);

            long endTime = System.currentTimeMillis();
            logger.info("Text-based compliance assessment completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("complianceAssessment", complianceAssessment);
            response.put("processingTime", (endTime - startTime));
            response.put("textLength", content.length());
            response.put("jurisdiction", jurisdiction);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in text-based compliance assessment", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Compliance assessment failed: " + e.getMessage()));
        }
    }

    /**
     * Comprehensive legal analysis endpoint
     */
    @PostMapping("/comprehensive-analysis")
    public ResponseEntity<?> performComprehensiveAnalysis(@RequestBody Map<String, String> request) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting comprehensive legal analysis");

        try {
            String content = request.get("content");
            if (content == null || content.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Document content is required"));
            }

            Map<String, Object> analysis = aiService.performComprehensiveLegalAnalysis(content);

            long endTime = System.currentTimeMillis();
            logger.info("Comprehensive legal analysis completed successfully in {}ms", (endTime - startTime));

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("analysis", analysis);
            response.put("processingTime", (endTime - startTime));
            response.put("textLength", content.length());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error in comprehensive legal analysis", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Comprehensive analysis failed: " + e.getMessage()));
        }
    }

    /**
     * AI service status endpoint
     */
    @GetMapping("/status")
    public ResponseEntity<?> getAiServiceStatus() {
        logger.info("Checking AI service status");

        try {
            long startTime = System.currentTimeMillis();

            // Get comprehensive status from AiService
            Map<String, Object> status = aiService.getServiceStatus();

            long endTime = System.currentTimeMillis();
            status.put("responseTime", (endTime - startTime));
            status.put("timeout", timeoutSeconds);
            status.put("maxRetries", maxRetries);
            status.put("timestamp", System.currentTimeMillis());

            // Check if primary service (OpenAI) is available
            Map<String, Object> openAIStatus = (Map<String, Object>) status.get("openai");
            boolean isOpenAIAvailable = openAIStatus != null && (Boolean) openAIStatus.getOrDefault("success", false);

            if (isOpenAIAvailable) {
                status.put("message", "OpenAI service is available and providing professional legal analysis");
                return ResponseEntity.ok(status);
            } else {
                boolean fallbackEnabled = (Boolean) status.getOrDefault("fallbackEnabled", false);
                if (fallbackEnabled) {
                    status.put("message", "OpenAI unavailable, using fallback service");
                } else {
                    status.put("message", "OpenAI service not configured - please set your API key");
                }
                return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(status);
            }

        } catch (Exception e) {
            logger.error("Error checking AI service status", e);
            Map<String, Object> errorStatus = new HashMap<>();
            errorStatus.put("available", false);
            errorStatus.put("configured", false);
            errorStatus.put("apiTestResult", "Error: " + e.getMessage());
            errorStatus.put("error", e.getMessage());
            errorStatus.put("timestamp", System.currentTimeMillis());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorStatus);
        }
    }

    /**
     * Professional legal analysis endpoint for lawyers
     */
    @PostMapping("/professional-analyze")
    public ResponseEntity<?> performProfessionalAnalysis(@RequestParam("file") MultipartFile file) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting professional legal analysis for file: {}", file.getOriginalFilename());

        try {
            // Get user authentication
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userType = "USER"; // Default user type

            if (authentication != null && authentication.isAuthenticated()) {
                // Get user type from authentication (you might need to implement this)
                userType = getUserTypeFromAuthentication(authentication);
            }

            // Extract text from file
            String documentContent = aiService.extractTextFromFile(file);
            if (documentContent == null || documentContent.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Could not extract text from the uploaded file"));
            }

            // Perform professional analysis
            Map<String, Object> analysis = professionalLegalAnalysisService
                    .performProfessionalLegalAnalysis(documentContent, userType);

            long processingTime = System.currentTimeMillis() - startTime;
            analysis.put("processingTime", processingTime);
            analysis.put("fileName", file.getOriginalFilename());
            analysis.put("fileSize", file.getSize());

            logger.info("Professional legal analysis completed in {}ms", processingTime);
            return ResponseEntity.ok(analysis);

        } catch (Exception e) {
            logger.error("Error in professional legal analysis: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Professional analysis failed: " + e.getMessage()));
        }
    }

    /**
     * Professional text-based analysis endpoint
     */
    @PostMapping("/professional-analyze-text")
    public ResponseEntity<?> performProfessionalTextAnalysis(@RequestBody Map<String, String> request) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting professional text-based legal analysis");

        try {
            String content = request.get("content");
            if (content == null || content.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Content is required for analysis"));
            }

            // Get user authentication
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userType = "USER"; // Default user type

            if (authentication != null && authentication.isAuthenticated()) {
                userType = getUserTypeFromAuthentication(authentication);
            }

            // Perform professional analysis
            Map<String, Object> analysis = professionalLegalAnalysisService
                    .performProfessionalLegalAnalysis(content, userType);

            long processingTime = System.currentTimeMillis() - startTime;
            analysis.put("processingTime", processingTime);

            logger.info("Professional text analysis completed in {}ms", processingTime);
            return ResponseEntity.ok(analysis);

        } catch (Exception e) {
            logger.error("Error in professional text analysis: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Professional text analysis failed: " + e.getMessage()));
        }
    }

    /**
     * Test HuggingFace ChatGPT-2.V2 connection
     */
    @GetMapping("/test-huggingface")
    public ResponseEntity<?> testHuggingFaceConnection() {
        logger.info("Testing HuggingFace ChatGPT-2.V2 connection");

        try {
            Map<String, Object> result = huggingFaceService.testConnection();
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("Error testing HuggingFace connection: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "HuggingFace connection test failed: " + e.getMessage()));
        }
    }

    /**
     * Test local ChatGPT-2.V2 model connection
     */
    @GetMapping("/test-local-model")
    public ResponseEntity<?> testLocalModelConnection() {
        logger.info("Testing local ChatGPT-2.V2 model connection");

        try {
            Map<String, Object> result = localModelService.testConnection();
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("Error testing local model connection: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Local model connection test failed: " + e.getMessage()));
        }
    }

    /**
     * Get user type from authentication (placeholder implementation)
     */
    private String getUserTypeFromAuthentication(Authentication authentication) {
        // This is a placeholder - you would implement this based on your user system
        // For now, return a default type
        return "LAWYER"; // Assume lawyer for professional analysis
    }
}
