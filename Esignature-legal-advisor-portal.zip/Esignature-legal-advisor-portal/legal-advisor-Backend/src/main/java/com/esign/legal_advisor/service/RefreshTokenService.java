package com.esign.legal_advisor.service;

import org.springframework.stereotype.Service;

@Service
public class RefreshTokenService {
    public String createRefreshToken(String username) {
        return java.util.UUID.randomUUID().toString();
    }

    public String validateAndGetUsername(String refreshToken) {
        // TODO: map token->username storage/validation
        return null;
    }
}