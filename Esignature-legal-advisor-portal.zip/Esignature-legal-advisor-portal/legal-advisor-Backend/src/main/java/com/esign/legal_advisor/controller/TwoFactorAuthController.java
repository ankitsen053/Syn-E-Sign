package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.TwoFactorAuthDto;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.service.AuthService;
import com.esign.legal_advisor.service.TwoFactorAuthService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/2fa")
@CrossOrigin(origins = "*", maxAge = 3600)
public class TwoFactorAuthController {

    private static final Logger logger = LoggerFactory.getLogger(TwoFactorAuthController.class);

    private final AuthService authService;
    private final TwoFactorAuthService twoFactorAuthService;

    public TwoFactorAuthController(AuthService authService, TwoFactorAuthService twoFactorAuthService) {
        this.authService = authService;
        this.twoFactorAuthService = twoFactorAuthService;
    }

    @PostMapping("/verify-login")
    public ResponseEntity<MessageResponse> verifyLoginOtp(@Valid @RequestBody TwoFactorAuthDto twoFactorAuthDto) {
        logger.info("Login 2FA verification attempt");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("Error: Authentication required"));
            }

            // Get user ID from authentication (you might need to modify this based on your JWT structure)
            String userId = authentication.getName(); // This might need to be adjusted
            
            MessageResponse response = authService.verifyTwoFactorAuth(userId, twoFactorAuthDto.getOtp(), "LOGIN_VERIFICATION");
            
            if (response.getMessage().contains("Error:")) {
                return ResponseEntity.badRequest().body(response);
            }
            
            logger.info("Login 2FA verified successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error during login 2FA verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to verify login 2FA. Please try again later."));
        }
    }

    @PostMapping("/verify-file")
    public ResponseEntity<MessageResponse> verifyFileOtp(@Valid @RequestBody TwoFactorAuthDto twoFactorAuthDto) {
        logger.info("File 2FA verification attempt for file: {}", twoFactorAuthDto.getFileName());

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new MessageResponse("Error: Authentication required"));
            }

            String userId = authentication.getName();
            
            MessageResponse response = authService.verifyTwoFactorAuth(userId, twoFactorAuthDto.getOtp(), "FILE_VERIFICATION");
            
            if (response.getMessage().contains("Error:")) {
                return ResponseEntity.badRequest().body(response);
            }
            
            logger.info("File 2FA verified successfully for file: {}", twoFactorAuthDto.getFileName());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error during file 2FA verification", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error: Failed to verify file 2FA. Please try again later."));
        }
    }

    @PostMapping("/generate-file-otp")
    public ResponseEntity<Map<String, Object>> generateFileOtp(@RequestParam("file") MultipartFile file) {
        logger.info("File OTP generation request for file: {}", file.getOriginalFilename());

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                Map<String, Object> error = new HashMap<>();
                error.put("error", "Authentication required");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            }

            String userId = authentication.getName();
            String fileName = file.getOriginalFilename();
            
            // Get user email (you might need to fetch this from user service)
            // For now, we'll use a placeholder - you should implement this properly
            String userEmail = "anshtalreja025@gmail.com"; // This should be fetched from user service
            
            String otp = twoFactorAuthService.generateAndSendFileOtp(userId, userEmail, fileName);
            
            Map<String, Object> response = new HashMap<>();
            response.put("message", "File OTP generated and sent successfully");
            response.put("fileName", fileName);
            response.put("otp", otp); // For testing purposes - remove in production
            
            logger.info("File OTP generated successfully for file: {}", fileName);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error generating file OTP", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Failed to generate file OTP: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getTwoFactorAuthStatus() {
        logger.info("Getting 2FA status");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                Map<String, Object> error = new HashMap<>();
                error.put("error", "Authentication required");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            }

            String userId = authentication.getName();
            
            Map<String, Object> status = new HashMap<>();
            status.put("loginVerified", authService.isTwoFactorAuthVerified(userId, "LOGIN_VERIFICATION"));
            status.put("fileVerified", authService.isTwoFactorAuthVerified(userId, "FILE_VERIFICATION"));
            status.put("timestamp", System.currentTimeMillis());
            
            return ResponseEntity.ok(status);
        } catch (Exception e) {
            logger.error("Error getting 2FA status", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Failed to get 2FA status: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }
}
