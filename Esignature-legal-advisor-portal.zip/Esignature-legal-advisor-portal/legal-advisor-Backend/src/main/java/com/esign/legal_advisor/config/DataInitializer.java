package com.esign.legal_advisor.config;

import com.esign.legal_advisor.entites.ERole;
import com.esign.legal_advisor.entites.Role;
import com.esign.legal_advisor.repository.RoleRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);
    private final RoleRepository roleRepository;

    public DataInitializer(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        try {
            // Initialize default roles if they don't exist
            initializeRoles();
        } catch (Exception e) {
            logger.warn("Database initialization failed - MongoDB may not be running. Application will continue without database initialization: {}", e.getMessage());
            logger.debug("Full database initialization error:", e);
        }
    }

    private void initializeRoles() {
        try {
            for (ERole role : ERole.values()) {
                if (!roleRepository.findByName(role).isPresent()) {
                    Role newRole = new Role(role);
                    roleRepository.save(newRole);
                    logger.info("Created role: {}", role.name());
                }
            }
            logger.info("Database roles initialization completed successfully");
        } catch (Exception e) {
            logger.error("Failed to initialize roles: {}", e.getMessage());
            throw e; // Re-throw to be caught by the main try-catch
        }
    }
}
