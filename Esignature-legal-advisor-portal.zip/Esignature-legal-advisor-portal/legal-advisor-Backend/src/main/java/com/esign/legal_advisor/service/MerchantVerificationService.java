package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.CreateVerificationRequestDto;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.entites.DigiLockerVerificationRequest;
import com.esign.legal_advisor.entites.DigiLockerVerificationRequest.VerificationRequestStatus;
import com.esign.legal_advisor.repository.DigiLockerVerificationRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;

@Service
public class MerchantVerificationService {

    private static final Logger logger = LoggerFactory.getLogger(MerchantVerificationService.class);

    @Autowired
    private DigiLockerVerificationRequestRepository verificationRequestRepository;

    @Autowired
    private EmailService emailService;

    @Value("${app.base-url:http://localhost:8081}")
    private String baseUrl;

    @Value("${app.frontend-url:http://localhost:3000}")
    private String frontendUrl;

    /**
     * Create a new DigiLocker verification request (Merchant Dashboard)
     */
    public Map<String, Object> createVerificationRequest(String merchantUserId, CreateVerificationRequestDto requestDto) {
        try {
            logger.info("Creating DigiLocker verification request for merchant: {} with documents: {}", 
                       merchantUserId, requestDto.getRequestedDocuments());

            // Validate document types
            if (!requestDto.hasValidDocumentTypes()) {
                throw new IllegalArgumentException("Invalid document types provided");
            }

            // Check for existing pending verifications for the same customer
            if (requestDto.getCustomerMobile() != null) {
                List<DigiLockerVerificationRequest> pendingRequests = 
                    verificationRequestRepository.findPendingVerificationsByMobile(requestDto.getCustomerMobile());
                
                if (!pendingRequests.isEmpty()) {
                    logger.warn("Customer {} already has pending verification requests", 
                               requestDto.getCustomerMobile());
                    throw new IllegalArgumentException("Customer already has a pending verification request");
                }
            }

            // Create verification request
            DigiLockerVerificationRequest request = new DigiLockerVerificationRequest(
                merchantUserId, requestDto.getRequestedDocuments());
            
            request.setCustomerEmail(requestDto.getCustomerEmail());
            request.setCustomerMobile(requestDto.getCustomerMobile());
            request.setCustomerName(requestDto.getCustomerName());
            request.setVerificationPurpose(requestDto.getVerificationPurpose());
            request.setConsentRequired(requestDto.isConsentRequired());
            request.setWebhookUrl(requestDto.getWebhookUrl());
            
            // Set link expiry
            request.setLinkExpiresAt(LocalDateTime.now().plusHours(requestDto.getLinkExpiryHours()));
            
            // Generate verification link
            String verificationLink = generateVerificationLink(request.getVerificationToken());
            request.setVerificationLink(verificationLink);

            // Save request
            request = verificationRequestRepository.save(request);

            logger.info("Created verification request with ID: {} and token: {}", 
                       request.getId(), request.getVerificationToken());

            // Send email to customer if email provided
            if (requestDto.getCustomerEmail() != null && !requestDto.getCustomerEmail().isEmpty()) {
                sendVerificationEmail(request);
            }

            // Prepare response
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("verificationRequestId", request.getId());
            response.put("verificationToken", request.getVerificationToken());
            response.put("verificationLink", verificationLink);
            response.put("status", request.getStatus().toString());
            response.put("expiresAt", request.getLinkExpiresAt());
            response.put("requestedDocuments", request.getRequestedDocuments());
            response.put("message", "Verification request created successfully. Share the link with your customer.");

            return response;

        } catch (Exception e) {
            logger.error("Error creating verification request for merchant: {}", merchantUserId, e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", e.getMessage());
            return errorResponse;
        }
    }

    /**
     * Get merchant's verification requests dashboard
     */
    public Map<String, Object> getMerchantDashboard(String merchantUserId) {
        try {
            logger.info("Fetching dashboard data for merchant: {}", merchantUserId);

            // Get all requests
            List<DigiLockerVerificationRequest> allRequests = 
                verificationRequestRepository.findByMerchantUserIdOrderByCreatedAtDesc(merchantUserId);

            // Get statistics
            long totalRequests = verificationRequestRepository.countByMerchantUserId(merchantUserId);
            long pendingRequests = verificationRequestRepository.countByMerchantUserIdAndStatus(
                merchantUserId, VerificationRequestStatus.PENDING);
            long completedRequests = verificationRequestRepository.countByMerchantUserIdAndStatus(
                merchantUserId, VerificationRequestStatus.COMPLETED);
            long failedRequests = verificationRequestRepository.countByMerchantUserIdAndStatus(
                merchantUserId, VerificationRequestStatus.FAILED);

            // Calculate success rate
            double successRate = totalRequests > 0 ? 
                (double) completedRequests / totalRequests * 100 : 0.0;

            // Get recent requests (last 10)
            List<DigiLockerVerificationRequest> recentRequests = allRequests.stream()
                .limit(10)
                .toList();

            // Prepare dashboard response
            Map<String, Object> dashboard = new HashMap<>();
            dashboard.put("merchantUserId", merchantUserId);
            dashboard.put("totalRequests", totalRequests);
            dashboard.put("pendingRequests", pendingRequests);
            dashboard.put("completedRequests", completedRequests);
            dashboard.put("failedRequests", failedRequests);
            dashboard.put("successRate", Math.round(successRate * 100.0) / 100.0);
            dashboard.put("recentRequests", recentRequests);

            // Status breakdown
            Map<String, Long> statusBreakdown = new HashMap<>();
            for (VerificationRequestStatus status : VerificationRequestStatus.values()) {
                long count = verificationRequestRepository.countByMerchantUserIdAndStatus(merchantUserId, status);
                if (count > 0) {
                    statusBreakdown.put(status.toString(), count);
                }
            }
            dashboard.put("statusBreakdown", statusBreakdown);

            return dashboard;

        } catch (Exception e) {
            logger.error("Error fetching dashboard for merchant: {}", merchantUserId, e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to fetch dashboard data");
            errorResponse.put("message", e.getMessage());
            return errorResponse;
        }
    }

    /**
     * Get specific verification request details
     */
    public Optional<DigiLockerVerificationRequest> getVerificationRequest(String merchantUserId, String requestId) {
        try {
            Optional<DigiLockerVerificationRequest> request = verificationRequestRepository.findById(requestId);
            
            if (request.isPresent() && !request.get().getMerchantUserId().equals(merchantUserId)) {
                logger.warn("Merchant {} attempted to access request {} belonging to another merchant", 
                           merchantUserId, requestId);
                return Optional.empty();
            }
            
            return request;
        } catch (Exception e) {
            logger.error("Error fetching verification request {} for merchant {}", requestId, merchantUserId, e);
            return Optional.empty();
        }
    }

    /**
     * Cancel verification request
     */
    public MessageResponse cancelVerificationRequest(String merchantUserId, String requestId) {
        try {
            Optional<DigiLockerVerificationRequest> requestOpt = getVerificationRequest(merchantUserId, requestId);
            
            if (requestOpt.isEmpty()) {
                return new MessageResponse("Verification request not found");
            }

            DigiLockerVerificationRequest request = requestOpt.get();
            
            if (request.getStatus() == VerificationRequestStatus.COMPLETED ||
                request.getStatus() == VerificationRequestStatus.FAILED ||
                request.getStatus() == VerificationRequestStatus.CANCELLED) {
                return new MessageResponse("Cannot cancel request in current status: " + request.getStatus());
            }

            request.setStatus(VerificationRequestStatus.CANCELLED);
            request.setLinkActive(false);
            verificationRequestRepository.save(request);

            logger.info("Cancelled verification request {} for merchant {}", requestId, merchantUserId);
            return new MessageResponse("Verification request cancelled successfully");

        } catch (Exception e) {
            logger.error("Error cancelling verification request {} for merchant {}", requestId, merchantUserId, e);
            return new MessageResponse("Error: Failed to cancel verification request");
        }
    }

    /**
     * Resend verification link to customer
     */
    public MessageResponse resendVerificationLink(String merchantUserId, String requestId) {
        try {
            Optional<DigiLockerVerificationRequest> requestOpt = getVerificationRequest(merchantUserId, requestId);
            
            if (requestOpt.isEmpty()) {
                return new MessageResponse("Verification request not found");
            }

            DigiLockerVerificationRequest request = requestOpt.get();
            
            if (!request.isActive()) {
                return new MessageResponse("Cannot resend link for inactive or expired request");
            }

            if (request.getCustomerEmail() == null || request.getCustomerEmail().isEmpty()) {
                return new MessageResponse("No customer email available to resend link");
            }

            // Send verification email
            sendVerificationEmail(request);

            logger.info("Resent verification link for request {} to customer {}", 
                       requestId, request.getCustomerEmail());
            return new MessageResponse("Verification link resent successfully to " + request.getCustomerEmail());

        } catch (Exception e) {
            logger.error("Error resending verification link for request {} and merchant {}", requestId, merchantUserId, e);
            return new MessageResponse("Error: Failed to resend verification link");
        }
    }

    /**
     * Generate verification link for customer
     */
    private String generateVerificationLink(String verificationToken) {
        return frontendUrl + "/verify/" + verificationToken;
    }

    /**
     * Send verification email to customer
     */
    private void sendVerificationEmail(DigiLockerVerificationRequest request) {
        try {
            String subject = "Document Verification Request - Legal Advisor";
            String body = buildVerificationEmailBody(request);
            
            emailService.sendHtmlEmail(request.getCustomerEmail(), subject, body);
            logger.info("Sent verification email to customer: {}", request.getCustomerEmail());
            
        } catch (Exception e) {
            logger.error("Failed to send verification email to customer: {}", request.getCustomerEmail(), e);
        }
    }

    /**
     * Build verification email body
     */
    private String buildVerificationEmailBody(DigiLockerVerificationRequest request) {
        StringBuilder html = new StringBuilder();
        html.append("<html><body>");
        html.append("<h2>Document Verification Request</h2>");
        html.append("<p>Hello ").append(request.getCustomerName() != null ? request.getCustomerName() : "Valued Customer").append(",</p>");
        html.append("<p>You have been requested to verify the following documents:</p>");
        html.append("<ul>");
        for (String doc : request.getRequestedDocuments()) {
            html.append("<li>").append(doc).append("</li>");
        }
        html.append("</ul>");
        html.append("<p><strong>Purpose:</strong> ").append(request.getVerificationPurpose()).append("</p>");
        html.append("<p>To complete the verification process, please click the link below:</p>");
        html.append("<p><a href=\"").append(request.getVerificationLink()).append("\" style=\"background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;\">Start Verification</a></p>");
        html.append("<p><strong>Important:</strong> This link will expire on ").append(request.getLinkExpiresAt()).append("</p>");
        html.append("<p>If you have any questions, please contact our support team.</p>");
        html.append("<p>Best regards,<br>Legal Advisor Team</p>");
        html.append("</body></html>");
        return html.toString();
    }

    /**
     * Cleanup expired verification requests
     */
    public void cleanupExpiredRequests() {
        try {
            List<DigiLockerVerificationRequest> expiredRequests = 
                verificationRequestRepository.findExpiredRequests(LocalDateTime.now());
            
            for (DigiLockerVerificationRequest request : expiredRequests) {
                request.setStatus(VerificationRequestStatus.EXPIRED);
                request.setLinkActive(false);
                verificationRequestRepository.save(request);
            }
            
            if (!expiredRequests.isEmpty()) {
                logger.info("Cleaned up {} expired verification requests", expiredRequests.size());
            }
            
        } catch (Exception e) {
            logger.error("Error during cleanup of expired verification requests", e);
        }
    }
}
