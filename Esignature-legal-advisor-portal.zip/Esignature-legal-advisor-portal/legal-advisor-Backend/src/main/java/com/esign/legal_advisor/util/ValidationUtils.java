package com.esign.legal_advisor.util;

import com.esign.legal_advisor.exception.BusinessLogicException;

public class ValidationUtils {

    public static void validateNotEmpty(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new BusinessLogicException(fieldName + " is required");
        }
    }

    public static void validateMaxLength(String value, int maxLength, String fieldName) {
        if (value != null && value.length() > maxLength) {
            throw new BusinessLogicException(
                fieldName + " is too long (maximum " + maxLength + " characters)"
            );
        }
    }

    public static void validateContentSize(String content, int maxSizeBytes, String operation) {
        if (content != null && content.getBytes().length > maxSizeBytes) {
            String sizeStr = formatBytes(maxSizeBytes);
            throw new BusinessLogicException(
                "Content too large for " + operation + " (maximum " + sizeStr + ")"
            );
        }
    }

    public static void validateEmail(String email) {
        if (email == null || !email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            throw new BusinessLogicException("Invalid email format");
        }
    }

    public static void validateNotNull(Object value, String fieldName) {
        if (value == null) {
            throw new BusinessLogicException(fieldName + " cannot be null");
        }
    }

    public static void validatePositive(Number value, String fieldName) {
        if (value == null || value.doubleValue() <= 0) {
            throw new BusinessLogicException(fieldName + " must be positive");
        }
    }

    public static void validateRange(Number value, Number min, Number max, String fieldName) {
        if (value == null) {
            throw new BusinessLogicException(fieldName + " cannot be null");
        }
        
        double val = value.doubleValue();
        double minVal = min.doubleValue();
        double maxVal = max.doubleValue();
        
        if (val < minVal || val > maxVal) {
            throw new BusinessLogicException(
                fieldName + " must be between " + minVal + " and " + maxVal
            );
        }
    }

    public static String sanitizeInput(String input) {
        if (input == null) return null;
        
        // Remove potential HTML/script tags and normalize whitespace
        return input.replaceAll("<[^>]*>", "")
                   .replaceAll("\\s+", " ")
                   .trim();
    }

    public static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format("%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    // Agreement-specific validations
    public static void validateAgreementContent(String content) {
        validateNotEmpty(content, "Agreement content");
        validateContentSize(content, 1000000, "document processing"); // 1MB limit
        
        // Check for minimum content length
        if (content.trim().length() < 50) {
            throw new BusinessLogicException("Agreement content too short (minimum 50 characters)");
        }
    }

    public static void validateAgreementType(String type) {
        validateNotEmpty(type, "Agreement type");
        validateMaxLength(type, 200, "Agreement type");
    }

    public static void validatePartyName(String partyName, String partyLabel) {
        if (partyName != null) {
            validateMaxLength(partyName, 200, partyLabel);
        }
    }

    public static void validateTerms(String terms) {
        if (terms != null) {
            validateMaxLength(terms, 5000, "Terms and conditions");
        }
    }
}
