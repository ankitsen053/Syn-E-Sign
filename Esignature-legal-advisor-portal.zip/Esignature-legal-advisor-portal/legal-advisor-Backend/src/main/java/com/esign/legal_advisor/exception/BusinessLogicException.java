package com.esign.legal_advisor.exception;

import org.springframework.http.HttpStatus;

public class BusinessLogicException extends RuntimeException {
    
    private final String errorCode;
    private final HttpStatus httpStatus;

    public BusinessLogicException(String message, String errorCode, HttpStatus httpStatus) {
        super(message);
        this.errorCode = errorCode;
        this.httpStatus = httpStatus;
    }

    public BusinessLogicException(String message, String errorCode) {
        this(message, errorCode, HttpStatus.BAD_REQUEST);
    }

    public BusinessLogicException(String message) {
        this(message, "BUSINESS_ERROR", HttpStatus.BAD_REQUEST);
    }

    public String getErrorCode() {
        return errorCode;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    // Common business exceptions
    public static BusinessLogicException userNotFound(String identifier) {
        return new BusinessLogicException(
            "User not found: " + identifier, 
            "USER_NOT_FOUND", 
            HttpStatus.NOT_FOUND
        );
    }

    public static BusinessLogicException agreementNotFound(String agreementId) {
        return new BusinessLogicException(
            "Agreement not found: " + agreementId, 
            "AGREEMENT_NOT_FOUND", 
            HttpStatus.NOT_FOUND
        );
    }

    public static BusinessLogicException invalidSignature() {
        return new BusinessLogicException(
            "Invalid or corrupted signature data", 
            "INVALID_SIGNATURE", 
            HttpStatus.BAD_REQUEST
        );
    }

    public static BusinessLogicException aiServiceUnavailable(String service) {
        return new BusinessLogicException(
            "AI service temporarily unavailable: " + service, 
            "AI_SERVICE_UNAVAILABLE", 
            HttpStatus.SERVICE_UNAVAILABLE
        );
    }

    public static BusinessLogicException documentGenerationFailed(String reason) {
        return new BusinessLogicException(
            "Document generation failed: " + reason, 
            "DOCUMENT_GENERATION_FAILED", 
            HttpStatus.INTERNAL_SERVER_ERROR
        );
    }

    public static BusinessLogicException authenticationRequired() {
        return new BusinessLogicException(
            "Authentication required to access this resource", 
            "AUTHENTICATION_REQUIRED", 
            HttpStatus.UNAUTHORIZED
        );
    }

    public static BusinessLogicException insufficientPermissions() {
        return new BusinessLogicException(
            "Insufficient permissions to perform this action", 
            "INSUFFICIENT_PERMISSIONS", 
            HttpStatus.FORBIDDEN
        );
    }
}
