package com.esign.legal_advisor.dto;

public class VerificationStatusDto {
    private String email;
    private boolean verified;
    private boolean enabled;
    private String message;
    private String status;

    // Constructors
    public VerificationStatusDto() {
    }

    public VerificationStatusDto(String email, boolean verified, boolean enabled, String message, String status) {
        this.email = email;
        this.verified = verified;
        this.enabled = enabled;
        this.message = message;
        this.status = status;
    }

    // Getters and Setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isVerified() {
        return verified;
    }

    public void setVerified(boolean verified) {
        this.verified = verified;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
