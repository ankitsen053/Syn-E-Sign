package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.TwoFactorAuth;
import com.esign.legal_advisor.repository.TwoFactorAuthRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

@Service
public class TwoFactorAuthService {
    
    private static final Logger logger = LoggerFactory.getLogger(TwoFactorAuthService.class);
    
    @Autowired
    private TwoFactorAuthRepository twoFactorAuthRepository;
    
    @Autowired
    private EmailService emailService;
    
    public String generateAndSendLoginOtp(String userId, String email) {
        try {
            // Generate 6-digit OTP
            String otp = generateOtp();
            
            // Delete any existing 2FA for this user
            twoFactorAuthRepository.deleteByUserId(userId);
            
            // Create new 2FA record
            TwoFactorAuth twoFactorAuth = new TwoFactorAuth();
            twoFactorAuth.setUserId(userId);
            twoFactorAuth.setEmail(email);
            twoFactorAuth.setOtp(otp);
            twoFactorAuth.setType("LOGIN_VERIFICATION");
            twoFactorAuth.setExpiresAt(LocalDateTime.now().plusMinutes(10)); // 10 minutes expiry
            twoFactorAuth.setVerified(false);
            twoFactorAuth.setAttempts(0);
            
            twoFactorAuthRepository.save(twoFactorAuth);
            
            // Send OTP email
            emailService.sendLoginOtpEmail(email, otp);
            
            logger.info("Login OTP generated and sent for user: {} to email: {}", userId, email);
            return otp;
        } catch (Exception e) {
            logger.error("Failed to generate and send login OTP for user: {}", userId, e);
            throw new RuntimeException("Failed to send login OTP: " + e.getMessage());
        }
    }
    
    public String generateAndSendFileOtp(String userId, String email, String fileName) {
        try {
            // Generate 6-digit OTP
            String otp = generateOtp();
            
            // Delete any existing file 2FA for this user
            twoFactorAuthRepository.deleteByUserIdAndType(userId, "FILE_VERIFICATION");
            
            // Create new file 2FA record
            TwoFactorAuth twoFactorAuth = new TwoFactorAuth();
            twoFactorAuth.setUserId(userId);
            twoFactorAuth.setEmail(email);
            twoFactorAuth.setOtp(otp);
            twoFactorAuth.setType("FILE_VERIFICATION");
            twoFactorAuth.setFileName(fileName);
            twoFactorAuth.setExpiresAt(LocalDateTime.now().plusMinutes(15)); // 15 minutes expiry
            twoFactorAuth.setVerified(false);
            twoFactorAuth.setAttempts(0);
            
            twoFactorAuthRepository.save(twoFactorAuth);
            
            // Send file OTP email
            emailService.sendFileOtpEmail(email, otp, fileName);
            
            logger.info("File OTP generated and sent for user: {} to email: {} for file: {}", userId, email, fileName);
            return otp;
        } catch (Exception e) {
            logger.error("Failed to generate and send file OTP for user: {}", userId, e);
            throw new RuntimeException("Failed to send file OTP: " + e.getMessage());
        }
    }
    
    public boolean verifyOtp(String userId, String otp, String type) {
        try {
            Optional<TwoFactorAuth> twoFactorAuthOpt = twoFactorAuthRepository.findByUserIdAndType(userId, type);
            
            if (twoFactorAuthOpt.isEmpty()) {
                logger.warn("No 2FA record found for user: {} and type: {}", userId, type);
                return false;
            }
            
            TwoFactorAuth twoFactorAuth = twoFactorAuthOpt.get();
            
            // Check if OTP is expired
            if (LocalDateTime.now().isAfter(twoFactorAuth.getExpiresAt())) {
                logger.warn("Expired 2FA OTP for user: {}", userId);
                twoFactorAuthRepository.delete(twoFactorAuth);
                return false;
            }
            
            // Check if max attempts reached (5 attempts)
            if (twoFactorAuth.getAttempts() >= 5) {
                logger.warn("Max attempts reached for 2FA user: {}", userId);
                twoFactorAuthRepository.delete(twoFactorAuth);
                return false;
            }
            
            // Increment attempts
            twoFactorAuth.setAttempts(twoFactorAuth.getAttempts() + 1);
            
            if (twoFactorAuth.getOtp().equals(otp)) {
                // OTP is correct
                twoFactorAuth.setVerified(true);
                twoFactorAuthRepository.save(twoFactorAuth);
                logger.info("2FA OTP verified successfully for user: {}", userId);
                return true;
            } else {
                // OTP is incorrect
                twoFactorAuthRepository.save(twoFactorAuth);
                logger.warn("Incorrect 2FA OTP attempt for user: {}", userId);
                return false;
            }
        } catch (Exception e) {
            logger.error("Error verifying 2FA OTP for user: {}", userId, e);
            return false;
        }
    }
    
    public boolean isOtpVerified(String userId, String type) {
        try {
            Optional<TwoFactorAuth> twoFactorAuthOpt = twoFactorAuthRepository.findByUserIdAndType(userId, type);
            return twoFactorAuthOpt.isPresent() && twoFactorAuthOpt.get().isVerified();
        } catch (Exception e) {
            logger.error("Error checking 2FA verification status for user: {}", userId, e);
            return false;
        }
    }
    
    public void cleanupExpiredOtp() {
        try {
            twoFactorAuthRepository.deleteByExpiresAtBefore(LocalDateTime.now());
            logger.info("Cleanup of expired 2FA OTPs completed");
        } catch (Exception e) {
            logger.error("Error during cleanup of expired 2FA OTPs", e);
        }
    }
    
    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000); // Generate 6-digit number
        return String.valueOf(otp);
    }
}
