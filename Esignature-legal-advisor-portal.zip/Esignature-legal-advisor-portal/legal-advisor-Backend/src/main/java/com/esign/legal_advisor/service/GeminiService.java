package com.esign.legal_advisor.service;

import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@Service
public class GeminiService {
    private static final Logger logger = LoggerFactory.getLogger(GeminiService.class);

    @Value("${gemini.api.key}")
    private String apiKey;

    private final Tika tika = new Tika();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30))
            .build();

    @Value("${gemini.api.url}")
    private String geminiApiUrl;

    /**
     * Extract text from uploaded document
     */
    public String extractTextFromDocument(MultipartFile file) throws IOException, TikaException {
        logger.info("Extracting text from document: {}", file.getOriginalFilename());
        return tika.parseToString(file.getInputStream());
    }

    /**
     * Analyze legal document with comprehensive legal insights
     */
    public String analyzeDocument(String content) {
        String prompt = String.format(
                """
                        You are an expert legal advisor and contract analyst. Analyze this legal document and provide comprehensive insights:

                        DOCUMENT TO ANALYZE:
                        %s

                        Please provide a detailed analysis including:

                        1. **DOCUMENT TYPE IDENTIFICATION**: What type of legal agreement is this?
                        2. **OVERALL ASSESSMENT**: Legal soundness and completeness evaluation
                        3. **STRUCTURE ANALYSIS**: Organization, flow, and logical structure
                        4. **KEY TERMS ANALYSIS**: Important terms, conditions, and their implications
                        5. **LEGAL COMPLIANCE**: Regulatory compliance issues and requirements
                        6. **RISK ASSESSMENT**: Potential legal risks and their severity levels
                        7. **MISSING ELEMENTS**: Critical clauses or provisions that may be missing
                        8. **SPECIFIC RECOMMENDATIONS**: Actionable suggestions for improvements
                        9. **EDITING SUGGESTIONS**: Specific text changes and additions
                        10. **ENFORCEABILITY**: Assessment of document enforceability

                        Provide professional, actionable legal advice with specific examples and recommendations.
                        """,
                content);

        return callGeminiAPI(prompt);
    }

    /**
     * Generate legal agreement based on type and parameters
     */
    public String generateAgreement(String type, String partyA, String partyB, String terms) {
        String prompt = String.format(
                """
                        You are an expert legal document drafter. Create a comprehensive %s agreement with the following specifications:

                        PARTY A: %s
                        PARTY B: %s
                        SPECIFIC TERMS: %s

                        Please create a complete, legally sound agreement that includes:

                        1. **PROPER HEADER**: Document title, date, and parties
                        2. **RECITALS**: Background and purpose
                        3. **DEFINITIONS**: Clear definition of key terms
                        4. **OBLIGATIONS**: Detailed responsibilities of each party
                        5. **PAYMENT TERMS**: Financial arrangements (if applicable)
                        6. **TERM AND TERMINATION**: Duration and termination conditions
                        7. **CONFIDENTIALITY**: Data protection and privacy clauses
                        8. **INTELLECTUAL PROPERTY**: IP rights and ownership
                        9. **LIABILITY AND INDEMNIFICATION**: Risk allocation
                        10. **DISPUTE RESOLUTION**: Arbitration or litigation procedures
                        11. **GOVERNING LAW**: Jurisdiction and applicable law
                        12. **MISCELLANEOUS**: Severability, amendments, notices
                        13. **SIGNATURES**: Proper signature blocks

                        Make this agreement comprehensive, legally enforceable, and tailored to the specific requirements provided.
                        """,
                type, partyA, partyB, terms);

        return callGeminiAPI(prompt);
    }

    /**
     * Highlight legal issues and provide specific editing suggestions
     */
    public String highlightIssues(String content) {
        String prompt = String.format("""
                You are a legal expert reviewing this document for potential issues and improvements:

                DOCUMENT:
                %s

                Please provide a detailed analysis focusing on:

                1. **CRITICAL ISSUES**: Major legal problems that need immediate attention
                2. **MODERATE CONCERNS**: Issues that should be addressed
                3. **MINOR SUGGESTIONS**: Improvements for clarity and completeness
                4. **SPECIFIC EDITS**: Exact text changes with before/after examples
                5. **MISSING CLAUSES**: Important provisions that should be added
                6. **AMBIGUOUS LANGUAGE**: Unclear terms that need clarification
                7. **ENFORCEABILITY ISSUES**: Problems that could affect legal validity
                8. **COMPLIANCE GAPS**: Regulatory requirements that are missing

                For each issue, provide:
                - Specific location in the document
                - Exact text to change
                - Recommended replacement
                - Legal reasoning for the change

                Be specific and actionable in your recommendations.
                """, content);

        return callGeminiAPI(prompt);
    }

    /**
     * Perform comprehensive risk analysis
     */
    public String performRiskAnalysis(String content) {
        String prompt = String.format("""
                You are a legal risk analyst. Conduct a comprehensive risk assessment of this document:

                DOCUMENT:
                %s

                Please analyze and categorize risks as follows:

                **CONTRACTUAL RISKS**:
                - Performance risks
                - Payment risks
                - Termination risks
                - Liability risks

                **LEGAL RISKS**:
                - Regulatory compliance
                - Statutory violations
                - Jurisdictional issues
                - Enforceability concerns

                **OPERATIONAL RISKS**:
                - Implementation challenges
                - Resource requirements
                - Timeline risks
                - Technical dependencies

                **REPUTATIONAL RISKS**:
                - Public perception
                - Stakeholder impact
                - Brand protection

                **TECHNICAL RISKS**:
                - Data security
                - Intellectual property
                - Technology dependencies

                For each risk category, provide:
                - Risk level (LOW/MEDIUM/HIGH)
                - Probability assessment
                - Potential impact
                - Mitigation strategies
                - Specific recommendations

                Provide an overall risk score (1-10) and prioritized action plan.
                """, content);

        return callGeminiAPI(prompt);
    }

    /**
     * Assess compliance for specific jurisdiction
     */
    public String assessCompliance(String content, String jurisdiction) {
        String prompt = String.format("""
                You are a legal compliance expert. Assess this document for compliance with %s laws and regulations:

                DOCUMENT:
                %s

                Please evaluate compliance in the following areas:

                **CONTRACT LAW COMPLIANCE**:
                - Essential elements of contract
                - Offer, acceptance, and consideration
                - Legal capacity requirements
                - Statute of frauds compliance

                **DATA PROTECTION COMPLIANCE**:
                - Privacy law requirements
                - Data processing agreements
                - Consent mechanisms
                - Cross-border data transfer

                **CONSUMER PROTECTION COMPLIANCE**:
                - Fair terms and conditions
                - Pricing transparency
                - Dispute resolution mechanisms
                - Cooling-off periods

                **EMPLOYMENT LAW COMPLIANCE** (if applicable):
                - Labor law requirements
                - Working conditions
                - Termination procedures
                - Benefits and compensation

                **INTELLECTUAL PROPERTY COMPLIANCE**:
                - IP protection requirements
                - Licensing compliance
                - Infringement prevention
                - Assignment provisions

                **TAX AND FINANCIAL COMPLIANCE**:
                - Tax obligations
                - Financial reporting
                - Payment regulations
                - Currency requirements

                For each area, provide:
                - Compliance status (COMPLIANT/PARTIAL/NON-COMPLIANT)
                - Specific requirements
                - Missing elements
                - Recommendations for compliance

                Provide an overall compliance score and prioritized action plan.
                """, jurisdiction, content);

        return callGeminiAPI(prompt);
    }

    /**
     * Call Gemini API with the given prompt
     */
    private String callGeminiAPI(String prompt) {
        try {
            logger.info("Calling Gemini API for legal analysis");
            logger.info("API URL: {}", geminiApiUrl);
            logger.info("API Key configured: {}", apiKey != null && !apiKey.trim().isEmpty());

            // Properly escape the prompt for JSON
            String escapedPrompt = prompt
                    .replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");

            // Build JSON request body properly
            String requestBody = "{"
                    + "\"contents\":[{"
                    + "\"parts\":[{"
                    + "\"text\":\"" + escapedPrompt + "\""
                    + "}]"
                    + "}],"
                    + "\"generationConfig\":{"
                    + "\"temperature\":0.3,"
                    + "\"maxOutputTokens\":4000"
                    + "}"
                    + "}";

            logger.info("Request body prepared, length: {}", requestBody.length());

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(geminiApiUrl + "?key=" + apiKey))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .timeout(Duration.ofSeconds(60))
                    .build();

            logger.info("Sending request to Gemini API...");
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            logger.info("Gemini API response status: {}", response.statusCode());

            if (response.statusCode() == 200) {
                // Parse the response to extract the generated text
                String responseBody = response.body();
                logger.info("Gemini API call successful, response length: {}", responseBody.length());

                try {
                    // More robust JSON parsing for Gemini API response
                    if (responseBody.contains("\"candidates\"")) {
                        // Parse Gemini API response structure
                        String candidatesSection = responseBody.split("\"candidates\"")[1];
                        if (candidatesSection.contains("\"content\"")) {
                            String contentSection = candidatesSection.split("\"content\"")[1];
                            if (contentSection.contains("\"parts\"")) {
                                String partsSection = contentSection.split("\"parts\"")[1];
                                if (partsSection.contains("\"text\"")) {
                                    String textContent = partsSection.split("\"text\"\\s*:\\s*\"")[1];
                                    int endIndex = textContent.indexOf("\"");
                                    if (endIndex > 0) {
                                        textContent = textContent.substring(0, endIndex);
                                        // Unescape JSON characters
                                        textContent = textContent
                                                .replace("\\n", "\n")
                                                .replace("\\r", "\r")
                                                .replace("\\t", "\t")
                                                .replace("\\\"", "\"")
                                                .replace("\\\\", "\\");
                                        logger.info("Successfully extracted text content, length: {}", textContent.length());
                                        return textContent;
                                    }
                                }
                            }
                        }
                    }
                    
                    logger.warn("Unexpected response format from Gemini API: {}",
                            responseBody.substring(0, Math.min(responseBody.length(), 500)));
                    return generateEnhancedFallbackResponse(prompt, "Unexpected response format");
                    
                } catch (Exception e) {
                    logger.error("Error parsing Gemini API response", e);
                    return generateEnhancedFallbackResponse(prompt, "Response parsing error: " + e.getMessage());
                }
            } else {
                logger.error("Gemini API call failed with status: {}", response.statusCode());
                logger.error("Response body: {}", response.body());
                return generateEnhancedFallbackResponse(prompt,
                        "API call failed with status: " + response.statusCode());
            }

        } catch (Exception e) {
            logger.error("Error calling Gemini API", e);
            return generateEnhancedFallbackResponse(prompt, "Exception: " + e.getMessage());
        }
    }

    /**
     * Generate enhanced fallback response when API is unavailable
     */
    private String generateEnhancedFallbackResponse(String prompt, String errorReason) {
        logger.warn("Generating enhanced fallback response due to: {}", errorReason);

        // Analyze the prompt to provide more specific fallback content
        String analysisType = "general";
        if (prompt.contains("analyze") || prompt.contains("analysis")) {
            analysisType = "document_analysis";
        } else if (prompt.contains("generate") || prompt.contains("agreement")) {
            analysisType = "agreement_generation";
        } else if (prompt.contains("risk")) {
            analysisType = "risk_analysis";
        } else if (prompt.contains("compliance")) {
            analysisType = "compliance_assessment";
        }

        switch (analysisType) {
            case "document_analysis":
                return """
                        📋 LEGAL DOCUMENT ANALYSIS (Enhanced Fallback Mode)

                        ⚠️ AI Service Status: Currently using enhanced fallback analysis
                        🔍 Analysis Type: Document Review and Legal Assessment

                        📊 DOCUMENT ASSESSMENT:
                        • Document Type: Legal Agreement/Contract
                        • Structure: Standard legal document format
                        • Key Elements: Parties, terms, obligations, payment terms

                        ⚖️ LEGAL RECOMMENDATIONS:
                        1. **Review Essential Elements**: Ensure all parties are clearly identified
                        2. **Verify Terms**: Check that all terms are specific and enforceable
                        3. **Payment Clauses**: Confirm payment terms are clearly defined
                        4. **Termination**: Include termination conditions and notice periods
                        5. **Dispute Resolution**: Add arbitration or litigation procedures
                        6. **Governing Law**: Specify jurisdiction and applicable law
                        7. **Confidentiality**: Include data protection and privacy clauses
                        8. **Intellectual Property**: Define IP rights and ownership

                        🚨 CRITICAL CHECKS:
                        • All signatures and dates are present
                        • Terms are legally enforceable
                        • Compliance with local regulations
                        • Clear dispute resolution process

                        💡 NEXT STEPS:
                        1. Review with qualified legal professional
                        2. Ensure compliance with applicable laws
                        3. Verify all essential contract elements
                        4. Consider adding standard legal protections

                        ⚠️ Note: This is an enhanced fallback analysis. For comprehensive AI-powered legal insights, please try again when the service is available.
                        """;

            case "agreement_generation":
                return """
                        📄 LEGAL AGREEMENT GENERATION (Enhanced Fallback Mode)

                        ⚠️ AI Service Status: Currently using enhanced fallback generation
                        📋 Generated: Service Agreement Template

                        📄 AGREEMENT TEMPLATE:

                        SERVICE AGREEMENT

                        This Service Agreement (the "Agreement") is entered into on [DATE] by and between:

                        [PARTY A NAME] ("Service Provider"), and
                        [PARTY B NAME] ("Client")

                        WHEREAS, the Service Provider provides [SERVICE TYPE] services;
                        WHEREAS, the Client desires to engage the Service Provider for such services;

                        NOW, THEREFORE, the parties agree as follows:

                        1. SERVICES
                        The Service Provider shall provide [DETAILED SERVICE DESCRIPTION] in accordance with the terms of this Agreement.

                        2. TERM
                        This Agreement shall commence on [START DATE] and continue until [END DATE] unless terminated earlier.

                        3. COMPENSATION
                        The Client shall pay the Service Provider [PAYMENT AMOUNT] for services rendered, payable [PAYMENT TERMS].

                        4. CONFIDENTIALITY
                        Both parties agree to maintain the confidentiality of any proprietary information shared during the term of this Agreement.

                        5. TERMINATION
                        Either party may terminate this Agreement with [NOTICE PERIOD] written notice to the other party.

                        6. GOVERNING LAW
                        This Agreement shall be governed by and construed in accordance with the laws of [JURISDICTION].

                        IN WITNESS WHEREOF, the parties have executed this Agreement as of the date first written above.

                        [PARTY A NAME]                    [PARTY B NAME]
                        _________________                 _________________
                        Signature                         Signature

                        ⚠️ Note: This is a template. Please customize with specific terms and have reviewed by legal counsel.
                        """;

            case "risk_analysis":
                return """
                        ⚠️ RISK ANALYSIS (Enhanced Fallback Mode)

                        🔍 RISK ASSESSMENT SUMMARY:

                        🚨 HIGH RISK AREAS:
                        • Unclear payment terms
                        • Missing termination clauses
                        • Inadequate dispute resolution
                        • Vague service descriptions

                        🟡 MEDIUM RISK AREAS:
                        • Intellectual property rights
                        • Confidentiality provisions
                        • Liability limitations
                        • Force majeure clauses

                        🟢 LOW RISK AREAS:
                        • Standard legal language
                        • Clear party identification
                        • Proper signature blocks

                        💡 RISK MITIGATION RECOMMENDATIONS:
                        1. Add specific payment schedules and late payment penalties
                        2. Include detailed termination procedures
                        3. Specify dispute resolution mechanisms
                        4. Define clear service deliverables
                        5. Add comprehensive liability clauses
                        6. Include force majeure provisions

                        ⚠️ Note: This is an enhanced fallback analysis. For detailed AI-powered risk assessment, please try again when the service is available.
                        """;

            case "compliance_assessment":
                return """
                        📋 COMPLIANCE ASSESSMENT (Enhanced Fallback Mode)

                        ⚖️ COMPLIANCE CHECKLIST:

                        ✅ BASIC COMPLIANCE:
                        • Proper legal structure
                        • Clear party identification
                        • Valid consideration
                        • Mutual agreement

                        ⚠️ AREAS FOR REVIEW:
                        • Industry-specific regulations
                        • Data protection requirements
                        • Employment law compliance
                        • Tax implications

                        🔍 RECOMMENDED ACTIONS:
                        1. Review with industry-specific legal expert
                        2. Verify data protection compliance
                        3. Check employment law requirements
                        4. Confirm tax obligations
                        5. Validate regulatory requirements

                        ⚠️ Note: This is an enhanced fallback assessment. For comprehensive compliance analysis, please try again when the service is available.
                        """;

            default:
                return """
                        📋 LEGAL ANALYSIS (Enhanced Fallback Mode)

                        ⚠️ AI Service Status: Currently using enhanced fallback analysis

                        📊 GENERAL ASSESSMENT:
                        • Document appears to be a legal agreement
                        • Standard legal structure detected
                        • Key elements are present

                        💡 RECOMMENDATIONS:
                        1. Review with qualified legal professional
                        2. Ensure all essential contract elements are present
                        3. Verify compliance with applicable laws and regulations
                        4. Consider adding standard legal clauses for protection
                        5. Have the document reviewed by legal counsel before execution

                        ⚠️ Note: This is an enhanced fallback analysis. For comprehensive AI-powered legal analysis, please try again when the service is available.
                        """;
        }
    }

    /**
     * Check if Gemini service is available
     */
    public boolean isGeminiAvailable() {
        try {
            String testPrompt = "Respond with 'OK' if you can process this request.";
            String response = callGeminiAPI(testPrompt);
            return !response.contains("Enhanced Fallback Mode");
        } catch (Exception e) {
            logger.warn("Gemini service is not available: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Get detailed service status information
     */
    public Map<String, Object> getServiceStatus() {
        Map<String, Object> status = new HashMap<>();

        try {
            // Check API key configuration
            boolean isConfigured = apiKey != null && !apiKey.trim().isEmpty()
                    && !apiKey.contains("YOUR_GEMINI_API_KEY");

            status.put("configured", isConfigured);
            status.put("apiKeyPresent", apiKey != null && !apiKey.trim().isEmpty());
            status.put("apiUrl", geminiApiUrl);

            if (isConfigured) {
                // Test API connectivity
                try {
                    String testResponse = callGeminiAPI("Test");
                    boolean isWorking = !testResponse.contains("Enhanced Fallback Mode");
                    status.put("available", isWorking);
                    status.put("testResult", isWorking ? "API responding successfully" : "API returning fallback mode");
                } catch (Exception e) {
                    status.put("available", false);
                    status.put("testResult", "API test failed: " + e.getMessage());
                    status.put("error", e.getMessage());
                }
            } else {
                status.put("available", false);
                status.put("testResult", "API key not properly configured");
            }

        } catch (Exception e) {
            status.put("available", false);
            status.put("configured", false);
            status.put("testResult", "Error checking status: " + e.getMessage());
            status.put("error", e.getMessage());
        }

        return status;
    }
}
