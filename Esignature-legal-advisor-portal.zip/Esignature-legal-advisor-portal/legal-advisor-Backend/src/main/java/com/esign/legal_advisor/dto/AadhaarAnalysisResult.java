package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AadhaarAnalysisResult {
    
    private String aadhaarNumber;
    private String name;
    private String fatherName;
    private String dateOfBirth;
    private String gender;
    private String address;
    private String mobileNumber;
    
    // Validation flags
    private boolean aadhaarNumberValid;
    private boolean nameExtracted;
    private boolean fatherNameExtracted;
    private boolean dobExtracted;
    private boolean genderExtracted;
    private boolean addressExtracted;
    private boolean mobileExtracted;
    
    // Confidence scores for each field
    private Double aadhaarNumberConfidence;
    private Double nameConfidence;
    private Double fatherNameConfidence;
    private Double dobConfidence;
    private Double genderConfidence;
    private Double addressConfidence;
    private Double mobileConfidence;
    
    // Overall document authenticity
    private Double documentAuthenticityScore;
    private String documentQuality; // EXCELLENT, GOOD, FAIR, POOR
    
    // Security features detected
    private boolean hologramDetected;
    private boolean securityPrintingDetected;
    private boolean digitalSignatureVerified;
}
