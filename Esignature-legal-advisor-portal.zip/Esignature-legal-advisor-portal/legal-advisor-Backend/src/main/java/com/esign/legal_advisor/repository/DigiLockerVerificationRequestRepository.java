package com.esign.legal_advisor.repository;

import com.esign.legal_advisor.entites.DigiLockerVerificationRequest;
import com.esign.legal_advisor.entites.DigiLockerVerificationRequest.VerificationRequestStatus;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface DigiLockerVerificationRequestRepository extends MongoRepository<DigiLockerVerificationRequest, String> {

    // Find by verification token (for customer access)
    Optional<DigiLockerVerificationRequest> findByVerificationToken(String verificationToken);

    // Find by merchant user ID (for dashboard)
    List<DigiLockerVerificationRequest> findByMerchantUserIdOrderByCreatedAtDesc(String merchantUserId);

    // Find by merchant user ID and status
    List<DigiLockerVerificationRequest> findByMerchantUserIdAndStatusOrderByCreatedAtDesc(String merchantUserId, VerificationRequestStatus status);

    // Find active requests (not expired, not completed)
    @Query("{ 'linkActive': true, 'linkExpiresAt': { $gt: ?0 }, 'status': { $in: ['PENDING', 'LINK_OPENED', 'OTP_SENT', 'AUTHENTICATED', 'CONSENT_PENDING', 'IN_PROGRESS'] } }")
    List<DigiLockerVerificationRequest> findActiveRequests(LocalDateTime currentTime);

    // Find expired requests that need cleanup
    @Query("{ 'linkExpiresAt': { $lt: ?0 }, 'status': { $in: ['PENDING', 'LINK_OPENED', 'OTP_SENT', 'AUTHENTICATED', 'CONSENT_PENDING', 'IN_PROGRESS'] } }")
    List<DigiLockerVerificationRequest> findExpiredRequests(LocalDateTime currentTime);

    // Find requests by customer mobile
    List<DigiLockerVerificationRequest> findByCustomerMobileOrderByCreatedAtDesc(String customerMobile);

    // Find requests by customer email
    List<DigiLockerVerificationRequest> findByCustomerEmailOrderByCreatedAtDesc(String customerEmail);

    // Find requests that need webhook notification
    @Query("{ 'status': { $in: ['COMPLETED', 'FAILED'] }, 'webhookSent': false, 'webhookUrl': { $exists: true, $ne: null } }")
    List<DigiLockerVerificationRequest> findRequestsNeedingWebhook();

    // Count requests by merchant and status
    long countByMerchantUserIdAndStatus(String merchantUserId, VerificationRequestStatus status);

    // Count total requests by merchant
    long countByMerchantUserId(String merchantUserId);

    // Find requests created within a date range
    List<DigiLockerVerificationRequest> findByMerchantUserIdAndCreatedAtBetweenOrderByCreatedAtDesc(
            String merchantUserId, LocalDateTime startDate, LocalDateTime endDate);

    // Find requests by status and date range (for analytics)
    List<DigiLockerVerificationRequest> findByStatusAndCreatedAtBetween(
            VerificationRequestStatus status, LocalDateTime startDate, LocalDateTime endDate);

    // Check if customer has pending verification
    @Query("{ 'customerMobile': ?0, 'status': { $in: ['PENDING', 'LINK_OPENED', 'OTP_SENT', 'AUTHENTICATED', 'CONSENT_PENDING', 'IN_PROGRESS'] } }")
    List<DigiLockerVerificationRequest> findPendingVerificationsByMobile(String customerMobile);

    // Find recent completed verifications by customer
    @Query("{ 'customerMobile': ?0, 'status': 'COMPLETED', 'completedAt': { $gt: ?1 } }")
    List<DigiLockerVerificationRequest> findRecentCompletedVerificationsByMobile(String customerMobile, LocalDateTime since);
}
