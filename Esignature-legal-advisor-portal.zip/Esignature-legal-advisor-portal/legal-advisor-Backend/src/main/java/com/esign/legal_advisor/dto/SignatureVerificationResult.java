package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;

/**
 * DTO for signature verification results
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SignatureVerificationResult {
    
    private boolean documentIntegrityValid;
    private boolean signatureIntegrityValid;
    private boolean timestampValid;
    private boolean signerIdentityVerified;
    private boolean overallValid;
    
    private String documentHash;
    private String signatureHash;
    private LocalDateTime verifiedAt;
    
    private String verificationMethod;
    private String certificateDetails;
    private String verificationMessage;
}
