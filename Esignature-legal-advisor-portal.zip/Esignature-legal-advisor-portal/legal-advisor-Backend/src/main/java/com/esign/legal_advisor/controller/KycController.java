package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.AadharVerificationDto;
import com.esign.legal_advisor.dto.GstVerificationDto;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.dto.PanVerificationDto;
import com.esign.legal_advisor.service.KycService;
import com.esign.legal_advisor.service.KycService.KycVerificationResult;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/kyc")
@CrossOrigin(origins = "*", maxAge = 3600)
public class KycController {

    private static final Logger logger = LoggerFactory.getLogger(KycController.class);

    @Autowired
    private KycService kycService;

    /**
     * Real-time PAN verification endpoint
     */
    @PostMapping("/verify/pan")
    public ResponseEntity<?> verifyPan(@Valid @RequestBody PanVerificationDto panDto) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userId = authentication.getName();

            logger.info("PAN verification requested by user: {} for PAN: {}", userId, maskPan(panDto.getPanNumber()));

            // Perform real-time verification
            KycVerificationResult result = kycService.verifyPan(panDto.getPanNumber());

            if (result.isSuccess()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "PAN verification completed successfully");
                response.put("apiProvider", result.getApiProvider());
                response.put("verificationData", result);
                response.put("documentFile",
                        panDto.getDocumentFile() != null ? panDto.getDocumentFile().getOriginalFilename() : null);

                logger.info("PAN verification successful for user: {} using API: {}", userId, result.getApiProvider());
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "PAN verification failed: " + result.getErrorMessage());

                logger.warn("PAN verification failed for user: {}", userId);
                return ResponseEntity.badRequest().body(response);
            }

        } catch (Exception e) {
            logger.error("Error during PAN verification for user: {}",
                    SecurityContextHolder.getContext().getAuthentication().getName(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Error: Failed to verify PAN. Please try again.");

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Real-time Aadhaar verification endpoint
     */
    @PostMapping("/verify/aadhaar")
    public ResponseEntity<?> verifyAadhaar(@Valid @RequestBody AadharVerificationDto aadhaarDto) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userId = authentication.getName();

            logger.info("Aadhaar verification requested by user: {} for Aadhaar: {}", userId,
                    maskAadhaar(aadhaarDto.getAadharNumber()));

            // Perform real-time verification
            KycVerificationResult result = kycService.verifyAadhaar(aadhaarDto.getAadharNumber());

            if (result.isSuccess()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "Aadhaar verification completed successfully");
                response.put("apiProvider", result.getApiProvider());
                response.put("verificationData", result);
                response.put("documentFile",
                        aadhaarDto.getDocumentFile() != null ? aadhaarDto.getDocumentFile().getOriginalFilename()
                                : null);

                logger.info("Aadhaar verification successful for user: {} using API: {}", userId,
                        result.getApiProvider());
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "Aadhaar verification failed: " + result.getErrorMessage());

                logger.warn("Aadhaar verification failed for user: {}", userId);
                return ResponseEntity.badRequest().body(response);
            }

        } catch (Exception e) {
            logger.error("Error during Aadhaar verification for user: {}",
                    SecurityContextHolder.getContext().getAuthentication().getName(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Error: Failed to verify Aadhaar. Please try again.");

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Real-time GST verification endpoint
     */
    @PostMapping("/verify/gst")
    public ResponseEntity<?> verifyGst(@Valid @RequestBody GstVerificationDto gstDto) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userId = authentication.getName();

            logger.info("GST verification requested by user: {} for GST: {}", userId,
                    maskGst(gstDto.getGstNumber()));

            // Perform real-time verification
            KycVerificationResult result = kycService.verifyGst(gstDto.getGstNumber());

            if (result.isSuccess()) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "GST verification completed successfully");
                response.put("apiProvider", result.getApiProvider());
                response.put("verificationData", result);
                response.put("uploadation", gstDto.getUploadation());
                response.put("companyName", gstDto.getCompanyName());

                logger.info("GST verification successful for user: {} using API: {}", userId,
                        result.getApiProvider());
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "GST verification failed: " + result.getErrorMessage());

                logger.warn("GST verification failed for user: {}", userId);
                return ResponseEntity.badRequest().body(response);
            }

        } catch (Exception e) {
            logger.error("Error during GST verification for user: {}",
                    SecurityContextHolder.getContext().getAuthentication().getName(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Error: Failed to verify GST. Please try again.");

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Bulk verification endpoint for PAN, Aadhaar, and GST
     */
    @PostMapping("/verify/bulk")
    public ResponseEntity<?> verifyBulk(@RequestBody Map<String, Object> request) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String userId = authentication.getName();

            String panNumber = (String) request.get("panNumber");
            String aadhaarNumber = (String) request.get("aadhaarNumber");
            String gstNumber = (String) request.get("gstNumber");
            String panDocumentUrl = (String) request.get("panDocumentUrl");
            String aadhaarDocumentUrl = (String) request.get("aadhaarDocumentUrl");
            String gstDocumentUrl = (String) request.get("gstDocumentUrl");

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Bulk verification completed");

            // Verify PAN if provided
            if (panNumber != null && !panNumber.trim().isEmpty()) {
                logger.info("Bulk verification - PAN requested by user: {} for PAN: {}", userId, maskPan(panNumber));
                KycVerificationResult panResult = kycService.verifyPan(panNumber);
                response.put("panVerification", panResult);
            }

            // Verify Aadhaar if provided
            if (aadhaarNumber != null && !aadhaarNumber.trim().isEmpty()) {
                logger.info("Bulk verification - Aadhaar requested by user: {} for Aadhaar: {}", userId,
                        maskAadhaar(aadhaarNumber));
                KycVerificationResult aadhaarResult = kycService.verifyAadhaar(aadhaarNumber);
                response.put("aadhaarVerification", aadhaarResult);
            }

            // Verify GST if provided
            if (gstNumber != null && !gstNumber.trim().isEmpty()) {
                logger.info("Bulk verification - GST requested by user: {} for GST: {}", userId, maskGst(gstNumber));
                KycVerificationResult gstResult = kycService.verifyGst(gstNumber);
                response.put("gstVerification", gstResult);
            }

            logger.info("Bulk verification completed successfully for user: {}", userId);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error during bulk verification for user: {}",
                    SecurityContextHolder.getContext().getAuthentication().getName(), e);

            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "Error: Failed to perform bulk verification. Please try again.");

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Health check endpoint for KYC service
     */
    @GetMapping("/health")
    public ResponseEntity<?> healthCheck() {
        try {
            Map<String, Object> response = new HashMap<>();
            response.put("status", "UP");
            response.put("service", "KYC Verification Service");
            response.put("timestamp", System.currentTimeMillis());
            response.put("message", "KYC service is operational");

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Health check failed", e);

            Map<String, Object> response = new HashMap<>();
            response.put("status", "DOWN");
            response.put("service", "KYC Verification Service");
            response.put("timestamp", System.currentTimeMillis());
            response.put("message", "KYC service is not operational");

            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
        }
    }

    /**
     * Get available API providers
     */
    @GetMapping("/providers")
    public ResponseEntity<?> getAvailableProviders() {
        Map<String, Object> response = new HashMap<>();
        response.put("providers", new String[] { "Surepass", "Karza", "Signzy", "Setu" });
        response.put("message", "Available KYC API providers");
        response.put("note", "Mock verification is used when APIs are not configured");

        return ResponseEntity.ok(response);
    }

    /**
     * Mask PAN number for logging
     */
    private String maskPan(String pan) {
        if (pan == null || pan.length() < 4)
            return "****";
        return pan.substring(0, 2) + "****" + pan.substring(pan.length() - 2);
    }

    /**
     * Mask Aadhaar number for logging
     */
    private String maskAadhaar(String aadhaar) {
        if (aadhaar == null || aadhaar.length() < 4)
            return "****";
        return aadhaar.substring(0, 4) + "****" + aadhaar.substring(aadhaar.length() - 4);
    }

    private String maskGst(String gst) {
        if (gst == null || gst.length() < 4)
            return "****";
        return gst.substring(0, 2) + "****" + gst.substring(gst.length() - 2);
    }
}
