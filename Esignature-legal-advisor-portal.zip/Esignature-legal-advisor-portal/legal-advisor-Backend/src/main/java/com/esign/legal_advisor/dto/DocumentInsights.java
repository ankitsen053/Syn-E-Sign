package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.util.List;
import java.util.Map;

/**
 * DTO for document insights and analytics
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentInsights {
    
    // Overview statistics
    private long totalDocuments;
    private long signedDocuments;
    private long analyzedDocuments;
    private long pendingDocuments;
    
    // Document breakdown
    private Map<String, Long> documentsByType;
    private Map<String, Long> documentsByStatus;
    private Map<String, Long> documentsByMonth;
    
    // Signing insights
    private double signingCompletionRate;
    private double averageSigningTime; // in hours
    private List<String> pendingSignatures;
    
    // Analysis insights
    private double averageConfidenceScore;
    private Map<String, Integer> analysisTypeBreakdown;
    private List<String> documentsNeedingReview;
    
    // Compliance metrics
    private double complianceScore;
    private Map<String, Boolean> complianceChecks;
    private List<String> complianceIssues;
    
    // Activity timeline
    private List<DocumentActivity> recentActivity;
    
    // Document specific insights
    private String documentId;
    private String documentTitle;
    private String documentType;
    private List<DocumentActivity> analysisHistory;
    private List<DocumentActivity> signingHistory;
    private Map<String, Object> analytics;
    private java.time.LocalDateTime lastUpdated;
    
    // Recommendations
    private List<String> recommendations;
    private List<String> alerts;
}
