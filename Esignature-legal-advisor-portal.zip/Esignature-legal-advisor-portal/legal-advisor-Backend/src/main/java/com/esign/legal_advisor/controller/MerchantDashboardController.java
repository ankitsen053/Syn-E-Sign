package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.CreateVerificationRequestDto;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.entites.DigiLockerVerificationRequest;
import com.esign.legal_advisor.service.MerchantVerificationService;
import com.esign.legal_advisor.service.WebhookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.validation.Valid;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/merchant/digilocker")
@CrossOrigin(origins = "*", maxAge = 3600)
public class MerchantDashboardController {

    private static final Logger logger = LoggerFactory.getLogger(MerchantDashboardController.class);

    @Autowired
    private MerchantVerificationService merchantVerificationService;

    @Autowired
    private WebhookService webhookService;

    /**
     * Merchant Dashboard - Get overview and statistics
     */
    @GetMapping("/dashboard")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getMerchantDashboard(Authentication authentication) {
        try {
            String merchantUserId = authentication.getName();
            logger.info("Fetching dashboard for merchant: {}", merchantUserId);

            Map<String, Object> dashboard = merchantVerificationService.getMerchantDashboard(merchantUserId);
            
            return ResponseEntity.ok(dashboard);

        } catch (Exception e) {
            logger.error("Error fetching merchant dashboard", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to fetch dashboard data. " + e.getMessage()));
        }
    }

    /**
     * Create new DigiLocker verification request
     */
    @PostMapping("/verification-request")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> createVerificationRequest(@Valid @RequestBody CreateVerificationRequestDto request,
                                                      BindingResult bindingResult,
                                                      Authentication authentication) {
        try {
            // Handle validation errors
            if (bindingResult.hasErrors()) {
                String errorMessages = bindingResult.getAllErrors().stream()
                        .map(error -> error.getDefaultMessage())
                        .collect(Collectors.joining("; "));
                logger.warn("Validation failed for verification request: {}", errorMessages);
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Validation failed: " + errorMessages));
            }

            String merchantUserId = authentication.getName();
            logger.info("Creating verification request for merchant: {} with documents: {}", 
                       merchantUserId, request.getRequestedDocuments());

            Map<String, Object> response = merchantVerificationService.createVerificationRequest(merchantUserId, request);
            
            if ((Boolean) response.get("success")) {
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.badRequest().body(response);
            }

        } catch (Exception e) {
            logger.error("Error creating verification request", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to create verification request. " + e.getMessage()));
        }
    }

    /**
     * Get specific verification request details
     */
    @GetMapping("/verification-request/{requestId}")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getVerificationRequest(@PathVariable("requestId") String requestId,
                                                   Authentication authentication) {
        try {
            String merchantUserId = authentication.getName();
            
            Optional<DigiLockerVerificationRequest> request = 
                merchantVerificationService.getVerificationRequest(merchantUserId, requestId);

            if (request.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            return ResponseEntity.ok(request.get());

        } catch (Exception e) {
            logger.error("Error fetching verification request: {}", requestId, e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to fetch verification request. " + e.getMessage()));
        }
    }

    /**
     * Cancel verification request
     */
    @PostMapping("/verification-request/{requestId}/cancel")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> cancelVerificationRequest(@PathVariable("requestId") String requestId,
                                                      Authentication authentication) {
        try {
            String merchantUserId = authentication.getName();
            logger.info("Cancelling verification request: {} for merchant: {}", requestId, merchantUserId);

            MessageResponse response = merchantVerificationService.cancelVerificationRequest(merchantUserId, requestId);
            
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error cancelling verification request: {}", requestId, e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to cancel verification request. " + e.getMessage()));
        }
    }

    /**
     * Resend verification link to customer
     */
    @PostMapping("/verification-request/{requestId}/resend")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> resendVerificationLink(@PathVariable("requestId") String requestId,
                                                   Authentication authentication) {
        try {
            String merchantUserId = authentication.getName();
            logger.info("Resending verification link for request: {} by merchant: {}", requestId, merchantUserId);

            MessageResponse response = merchantVerificationService.resendVerificationLink(merchantUserId, requestId);
            
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error resending verification link for request: {}", requestId, e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to resend verification link. " + e.getMessage()));
        }
    }

    /**
     * Test webhook endpoint
     */
    @PostMapping("/webhook/test")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> testWebhookEndpoint(@RequestBody Map<String, String> request,
                                                Authentication authentication) {
        try {
            String webhookUrl = request.get("webhookUrl");
            
            if (webhookUrl == null || webhookUrl.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Webhook URL is required"));
            }

            logger.info("Testing webhook endpoint: {} for merchant: {}", webhookUrl, authentication.getName());

            boolean success = webhookService.testWebhookEndpoint(webhookUrl);
            
            if (success) {
                return ResponseEntity.ok(new MessageResponse("Webhook endpoint test successful"));
            } else {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Webhook endpoint test failed"));
            }

        } catch (Exception e) {
            logger.error("Error testing webhook endpoint", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to test webhook endpoint. " + e.getMessage()));
        }
    }

    /**
     * Get supported document types
     */
    @GetMapping("/document-types")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getSupportedDocumentTypes() {
        Map<String, Object> documentTypes = Map.of(
            "supported_documents", java.util.Arrays.asList("AADHAAR", "PAN", "DRIVING_LICENSE", "PASSPORT"),
            "document_descriptions", Map.of(
                "AADHAAR", "Aadhaar Card - National Identity Document",
                "PAN", "Permanent Account Number - Tax Identification",
                "DRIVING_LICENSE", "Driving License - Vehicle Operation Permit",
                "PASSPORT", "Passport - International Travel Document"
            )
        );
        
        return ResponseEntity.ok(documentTypes);
    }

    /**
     * Get verification statistics
     */
    @GetMapping("/statistics")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getVerificationStatistics(Authentication authentication,
                                                       @RequestParam(value = "period", required = false) String period) {
        try {
            String merchantUserId = authentication.getName();
            
            // This would typically include date-range filtering
            Map<String, Object> dashboard = merchantVerificationService.getMerchantDashboard(merchantUserId);
            
            // Extract statistics portion
            Map<String, Object> statistics = Map.of(
                "total_requests", dashboard.get("totalRequests"),
                "completed_requests", dashboard.get("completedRequests"),
                "pending_requests", dashboard.get("pendingRequests"),
                "failed_requests", dashboard.get("failedRequests"),
                "success_rate", dashboard.get("successRate"),
                "status_breakdown", dashboard.get("statusBreakdown")
            );
            
            return ResponseEntity.ok(statistics);

        } catch (Exception e) {
            logger.error("Error fetching verification statistics", e);
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Error: Failed to fetch statistics. " + e.getMessage()));
        }
    }

    /**
     * Service health check
     */
    @GetMapping("/health")
    public ResponseEntity<?> healthCheck() {
        Map<String, Object> health = Map.of(
            "service", "Merchant DigiLocker Dashboard",
            "status", "UP",
            "timestamp", java.time.LocalDateTime.now(),
            "features", java.util.Arrays.asList(
                "Verification request creation",
                "Customer link generation",
                "Real-time status tracking",
                "Webhook notifications",
                "Dashboard analytics"
            )
        );
        
        return ResponseEntity.ok(health);
    }
}
