package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;

/**
 * DTO for document activity events
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentActivity {
    
    private String activityId;
    private String documentId;
    private String documentTitle;
    private String activityType; // CREATED, EDITED, SIGNED, ANALYZED, VIEWED, SHARED
    private String description;
    private String performedBy;
    private String performedByEmail;
    private LocalDateTime timestamp;
    private String status;
    private java.util.Map<String, Object> details;
    
    // Additional context
    private String ipAddress;
    private String userAgent;
    private String location;
    
    // Activity details
    private String previousValue;
    private String newValue;
    private String changesSummary;
}
