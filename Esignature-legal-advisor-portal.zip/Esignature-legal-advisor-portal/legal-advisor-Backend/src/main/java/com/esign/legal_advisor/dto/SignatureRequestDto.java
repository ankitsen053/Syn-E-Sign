package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class SignatureRequestDto {

    @NotBlank(message = "Agreement title is required")
    private String agreementTitle;

    @NotBlank(message = "Agreement content is required")
    private String agreementContent;

    @NotBlank(message = "Agreement type is required")
    private String agreementType;

    private String partyA;
    private String partyB;
    private String terms;

    @NotBlank(message = "Signature image is required")
    private String signatureImageBase64;

    private String signatureData; // JSON string containing signature coordinates

    @NotBlank(message = "Signer name is required")
    private String signerName;

    @NotBlank(message = "Signer email is required")
    private String signerEmail;

    private String signerIpAddress;

    // Constructors
    public SignatureRequestDto() {
    }

    public SignatureRequestDto(String agreementTitle, String agreementContent, String agreementType,
                              String partyA, String partyB, String terms, String signatureImageBase64,
                              String signatureData, String signerName, String signerEmail, String signerIpAddress) {
        this.agreementTitle = agreementTitle;
        this.agreementContent = agreementContent;
        this.agreementType = agreementType;
        this.partyA = partyA;
        this.partyB = partyB;
        this.terms = terms;
        this.signatureImageBase64 = signatureImageBase64;
        this.signatureData = signatureData;
        this.signerName = signerName;
        this.signerEmail = signerEmail;
        this.signerIpAddress = signerIpAddress;
    }

    // Getters and Setters
    public String getAgreementTitle() {
        return agreementTitle;
    }

    public void setAgreementTitle(String agreementTitle) {
        this.agreementTitle = agreementTitle;
    }

    public String getAgreementContent() {
        return agreementContent;
    }

    public void setAgreementContent(String agreementContent) {
        this.agreementContent = agreementContent;
    }

    public String getAgreementType() {
        return agreementType;
    }

    public void setAgreementType(String agreementType) {
        this.agreementType = agreementType;
    }

    public String getPartyA() {
        return partyA;
    }

    public void setPartyA(String partyA) {
        this.partyA = partyA;
    }

    public String getPartyB() {
        return partyB;
    }

    public void setPartyB(String partyB) {
        this.partyB = partyB;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public String getSignatureImageBase64() {
        return signatureImageBase64;
    }

    public void setSignatureImageBase64(String signatureImageBase64) {
        this.signatureImageBase64 = signatureImageBase64;
    }

    public String getSignatureData() {
        return signatureData;
    }

    public void setSignatureData(String signatureData) {
        this.signatureData = signatureData;
    }

    public String getSignerName() {
        return signerName;
    }

    public void setSignerName(String signerName) {
        this.signerName = signerName;
    }

    public String getSignerEmail() {
        return signerEmail;
    }

    public void setSignerEmail(String signerEmail) {
        this.signerEmail = signerEmail;
    }

    public String getSignerIpAddress() {
        return signerIpAddress;
    }

    public void setSignerIpAddress(String signerIpAddress) {
        this.signerIpAddress = signerIpAddress;
    }
}
