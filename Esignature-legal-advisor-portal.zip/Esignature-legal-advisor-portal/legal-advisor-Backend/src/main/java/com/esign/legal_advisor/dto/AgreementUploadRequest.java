package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

/**
 * DTO for uploading and analyzing legal agreements
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AgreementUploadRequest {

    @NotBlank(message = "Agreement title is required")
    @Size(max = 200, message = "Title cannot exceed 200 characters")
    private String title;

    @NotBlank(message = "Agreement type is required")
    @Size(max = 100, message = "Type cannot exceed 100 characters")
    private String type;

    @Size(max = 500, message = "Description cannot exceed 500 characters")
    private String description;

    @NotNull(message = "Agreement document file is required")
    private MultipartFile documentFile;

    // Analysis preferences
    private boolean analyzeForLegalCompliance = true;
    private boolean analyzeForRiskAssessment = true;
    private boolean analyzeForClarityAndStructure = true;
    private boolean generateSummary = true;
    private boolean highlightIssues = true;
    private boolean suggestImprovements = true;

    // Optional metadata
    private String jurisdiction;
    private String governingLaw;
    private String industry;
    private String contractValue;
    private String urgency; // LOW, MEDIUM, HIGH
}
