package com.esign.legal_advisor.exception;

import com.esign.legal_advisor.dto.MessageResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handle validation errors
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationErrors(
            MethodArgumentNotValidException ex, WebRequest request) {

        logger.warn("Validation error in request: {}", request.getDescription(false));

        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });

        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", "Validation failed");
        response.put("errors", errors);
        response.put("timestamp", LocalDateTime.now());
        response.put("path", request.getDescription(false));

        return ResponseEntity.badRequest().body(response);
    }

    /**
     * Handle authentication errors
     */
    @ExceptionHandler({ AuthenticationException.class, BadCredentialsException.class })
    public ResponseEntity<Map<String, Object>> handleAuthenticationErrors(
            Exception ex, WebRequest request) {

        logger.warn("Authentication error: {} for request: {}", ex.getMessage(), request.getDescription(false));

        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", "Authentication failed: Invalid credentials");
        response.put("error", "AUTHENTICATION_FAILED");
        response.put("timestamp", LocalDateTime.now());
        response.put("path", request.getDescription(false));

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
    }

    /**
     * Handle access denied errors
     */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<Map<String, Object>> handleAccessDeniedErrors(
            AccessDeniedException ex, WebRequest request) {

        logger.warn("Access denied: {} for request: {}", ex.getMessage(), request.getDescription(false));

        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", "Access denied: Insufficient permissions");
        response.put("error", "ACCESS_DENIED");
        response.put("timestamp", LocalDateTime.now());
        response.put("path", request.getDescription(false));

        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
    }

    /**
     * Handle file upload size exceeded
     */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Map<String, Object>> handleMaxUploadSizeExceeded(
            MaxUploadSizeExceededException ex, WebRequest request) {

        logger.warn("File upload size exceeded: {} for request: {}", ex.getMessage(), request.getDescription(false));

        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", "File size too large. Maximum allowed size is 10MB");
        response.put("error", "FILE_SIZE_EXCEEDED");
        response.put("timestamp", LocalDateTime.now());
        response.put("path", request.getDescription(false));

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    /**
     * Handle illegal argument exceptions
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleIllegalArgumentException(
            IllegalArgumentException ex, WebRequest request) {

        logger.warn("Invalid argument: {} for request: {}", ex.getMessage(), request.getDescription(false));

        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", "Invalid request: " + ex.getMessage());
        response.put("error", "INVALID_ARGUMENT");
        response.put("timestamp", LocalDateTime.now());
        response.put("path", request.getDescription(false));

        return ResponseEntity.badRequest().body(response);
    }

    /**
     * Handle runtime exceptions
     */
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, Object>> handleRuntimeException(
            RuntimeException ex, WebRequest request) {

        logger.error("Runtime error: {} for request: {}", ex.getMessage(), request.getDescription(false), ex);

        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", "Service temporarily unavailable. Please try again later.");
        response.put("error", "RUNTIME_ERROR");
        response.put("timestamp", LocalDateTime.now());
        response.put("path", request.getDescription(false));

        // In development, include more details
        if (isDevelopmentMode()) {
            response.put("details", ex.getMessage());
            response.put("cause", ex.getCause() != null ? ex.getCause().getMessage() : null);
        }

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }

    /**
     * Handle all other exceptions
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGlobalException(
            Exception ex, WebRequest request) {

        logger.error("Unexpected error: {} for request: {}", ex.getMessage(), request.getDescription(false), ex);

        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", "An unexpected error occurred. Please try again later.");
        response.put("error", "INTERNAL_SERVER_ERROR");
        response.put("timestamp", LocalDateTime.now());
        response.put("path", request.getDescription(false));

        // In development, include more details
        if (isDevelopmentMode()) {
            response.put("details", ex.getMessage());
            response.put("exceptionType", ex.getClass().getSimpleName());
        }

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }

    /**
     * Handle custom business logic exceptions
     */
    @ExceptionHandler(BusinessLogicException.class)
    public ResponseEntity<Map<String, Object>> handleBusinessLogicException(
            BusinessLogicException ex, WebRequest request) {

        logger.warn("Business logic error: {} for request: {}", ex.getMessage(), request.getDescription(false));

        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", ex.getMessage());
        response.put("error", ex.getErrorCode());
        response.put("timestamp", LocalDateTime.now());
        response.put("path", request.getDescription(false));

        return ResponseEntity.status(ex.getHttpStatus()).body(response);
    }

    /**
     * Check if running in development mode
     */
    private boolean isDevelopmentMode() {
        String profile = System.getProperty("spring.profiles.active", "dev");
        return "dev".equals(profile) || "development".equals(profile);
    }
}
