package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.service.DashboardService;
import com.esign.legal_advisor.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*", maxAge = 3600)
public class DashboardController {

    private static final Logger logger = LoggerFactory.getLogger(DashboardController.class);

    private final DashboardService dashboardService;
    private final UserRepository userRepository;

    public DashboardController(DashboardService dashboardService, UserRepository userRepository) {
        this.dashboardService = dashboardService;
        this.userRepository = userRepository;
    }

    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getDashboardStats() {
        logger.info("Getting dashboard stats");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                Map<String, Object> error = new HashMap<>();
                error.put("error", "Authentication required");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            }

            // Get user ID from authentication
            String username = authentication.getName();

            // Get user from repository to get the actual user ID
            com.esign.legal_advisor.entites.User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            String userId = user.getId();

            Map<String, Object> dashboardStats = dashboardService.getDashboardStats(userId);

            logger.info("Dashboard stats retrieved successfully for user: {}", userId);
            return ResponseEntity.ok(dashboardStats);

        } catch (Exception e) {
            logger.error("Error getting dashboard stats", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Failed to get dashboard stats: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    @GetMapping("/metrics")
    public ResponseEntity<Map<String, Object>> getDashboardMetrics() {
        logger.info("Getting dashboard metrics");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                Map<String, Object> error = new HashMap<>();
                error.put("error", "Authentication required");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            }

            String username = authentication.getName();

            // Get user from repository to get the actual user ID
            com.esign.legal_advisor.entites.User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            String userId = user.getId();

            // Get basic metrics
            Map<String, Object> metrics = new HashMap<>();

            // Add timestamp
            metrics.put("timestamp", System.currentTimeMillis());
            metrics.put("userId", userId);

            logger.info("Dashboard metrics retrieved successfully for user: {}", userId);
            return ResponseEntity.ok(metrics);

        } catch (Exception e) {
            logger.error("Error getting dashboard metrics", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Failed to get dashboard metrics: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    @GetMapping("/activity")
    public ResponseEntity<Map<String, Object>> getRecentActivity() {
        logger.info("Getting recent activity");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                Map<String, Object> error = new HashMap<>();
                error.put("error", "Authentication required");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            }

            String username = authentication.getName();

            // Get user from repository to get the actual user ID
            com.esign.legal_advisor.entites.User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            String userId = user.getId();

            // Get dashboard stats which includes recent activities
            Map<String, Object> dashboardStats = dashboardService.getDashboardStats(userId);
            Map<String, Object> activity = new HashMap<>();

            if (dashboardStats.containsKey("recentActivities")) {
                activity.put("activities", dashboardStats.get("recentActivities"));
            }

            activity.put("timestamp", System.currentTimeMillis());

            logger.info("Recent activity retrieved successfully for user: {}", userId);
            return ResponseEntity.ok(activity);

        } catch (Exception e) {
            logger.error("Error getting recent activity", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Failed to get recent activity: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    @GetMapping("/progress")
    public ResponseEntity<Map<String, Object>> getProgressOverview() {
        logger.info("Getting progress overview");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                Map<String, Object> error = new HashMap<>();
                error.put("error", "Authentication required");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            }

            String username = authentication.getName();

            // Get user from repository to get the actual user ID
            com.esign.legal_advisor.entites.User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            String userId = user.getId();

            // Get dashboard stats which includes progress overview
            Map<String, Object> dashboardStats = dashboardService.getDashboardStats(userId);
            Map<String, Object> progress = new HashMap<>();

            if (dashboardStats.containsKey("progressOverview")) {
                progress.put("progress", dashboardStats.get("progressOverview"));
            }

            progress.put("timestamp", System.currentTimeMillis());

            logger.info("Progress overview retrieved successfully for user: {}", userId);
            return ResponseEntity.ok(progress);

        } catch (Exception e) {
            logger.error("Error getting progress overview", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Failed to get progress overview: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    @GetMapping("/preferences")
    public ResponseEntity<Map<String, Object>> getUserPreferences() {
        logger.info("Getting user preferences");

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                Map<String, Object> error = new HashMap<>();
                error.put("error", "Authentication required");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            }

            String username = authentication.getName();

            // Get user from repository to get the actual user ID
            com.esign.legal_advisor.entites.User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            String userId = user.getId();

            // Get dashboard stats which includes user preferences
            Map<String, Object> dashboardStats = dashboardService.getDashboardStats(userId);
            Map<String, Object> preferences = new HashMap<>();

            if (dashboardStats.containsKey("userPreferences")) {
                preferences.put("preferences", dashboardStats.get("userPreferences"));
            }

            preferences.put("timestamp", System.currentTimeMillis());

            logger.info("User preferences retrieved successfully for user: {}", userId);
            return ResponseEntity.ok(preferences);

        } catch (Exception e) {
            logger.error("Error getting user preferences", e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Failed to get user preferences: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }
}
