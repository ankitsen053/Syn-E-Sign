package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.CustomerVerificationDto;
import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.entites.DigiLockerVerificationRequest;
import com.esign.legal_advisor.entites.DigiLockerVerificationRequest.VerificationRequestStatus;
import com.esign.legal_advisor.repository.DigiLockerVerificationRequestRepository;
import com.esign.legal_advisor.service.DigiLockerService.DigiLockerVerificationResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Random;

@Service
public class CustomerVerificationService {

    private static final Logger logger = LoggerFactory.getLogger(CustomerVerificationService.class);

    @Autowired
    private DigiLockerVerificationRequestRepository verificationRequestRepository;

    @Autowired
    private DigiLockerService digiLockerService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private WebhookService webhookService;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Map<String, String> otpStorage = new HashMap<>(); // In production, use Redis
    private final Random random = new Random();

    /**
     * Get verification request details by token (Customer opens link)
     */
    public Map<String, Object> getVerificationRequestByToken(String verificationToken) {
        try {
            logger.info("Customer accessing verification request with token: {}",
                    verificationToken.substring(0, 8) + "****");

            Optional<DigiLockerVerificationRequest> requestOpt = verificationRequestRepository
                    .findByVerificationToken(verificationToken);

            if (requestOpt.isEmpty()) {
                return createErrorResponse("Invalid verification link");
            }

            DigiLockerVerificationRequest request = requestOpt.get();

            // Check if link is expired
            if (request.isExpired()) {
                request.setStatus(VerificationRequestStatus.EXPIRED);
                request.setLinkActive(false);
                verificationRequestRepository.save(request);
                return createErrorResponse("Verification link has expired");
            }

            // Check if link is still active
            if (!request.isActive()) {
                return createErrorResponse("Verification link is no longer active");
            }

            // Mark link as opened if not already
            if (!request.isLinkOpened()) {
                request.setLinkOpened(true);
                verificationRequestRepository.save(request);
            }

            // Prepare response
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("verificationToken", verificationToken);
            response.put("requestedDocuments", request.getRequestedDocuments());
            response.put("verificationPurpose", request.getVerificationPurpose());
            response.put("consentRequired", request.isConsentRequired());
            response.put("customerName", request.getCustomerName());
            response.put("expiresAt", request.getLinkExpiresAt());
            response.put("status", request.getStatus().toString());
            response.put("progress", request.getProgressPercentage());

            // Determine current step
            CustomerVerificationDto.VerificationStep currentStep = determineCurrentStep(request);
            response.put("currentStep", currentStep.toString());

            return response;

        } catch (Exception e) {
            logger.error("Error getting verification request by token", e);
            return createErrorResponse("Error accessing verification request");
        }
    }

    /**
     * Send OTP to customer mobile (Step 1)
     */
    public MessageResponse sendOtpToCustomer(String verificationToken, String mobileNumber) {
        try {
            logger.info("Sending OTP to customer mobile: {} for token: {}",
                    maskMobile(mobileNumber), verificationToken.substring(0, 8) + "****");

            Optional<DigiLockerVerificationRequest> requestOpt = verificationRequestRepository
                    .findByVerificationToken(verificationToken);

            if (requestOpt.isEmpty()) {
                return new MessageResponse("Invalid verification link");
            }

            DigiLockerVerificationRequest request = requestOpt.get();

            if (!request.isActive()) {
                return new MessageResponse("Verification link is no longer active");
            }

            // Validate mobile number format
            if (!isValidMobileNumber(mobileNumber)) {
                return new MessageResponse("Please provide a valid mobile number");
            }

            // Store customer mobile if not already set
            if (request.getCustomerMobile() == null) {
                request.setCustomerMobile(mobileNumber);
            }

            // Generate and store OTP
            String otp = generateOtp();
            String otpKey = verificationToken + "_" + mobileNumber;
            otpStorage.put(otpKey, otp);

            // Send OTP via SMS (mock implementation)
            boolean otpSent = sendOtpSms(mobileNumber, otp);

            if (otpSent) {
                request.setOtpSent(true);
                verificationRequestRepository.save(request);

                logger.info("OTP sent successfully to mobile: {}", maskMobile(mobileNumber));
                return new MessageResponse("OTP sent to your mobile number ending with " +
                        mobileNumber.substring(mobileNumber.length() - 4));
            } else {
                return new MessageResponse("Failed to send OTP. Please try again.");
            }

        } catch (Exception e) {
            logger.error("Error sending OTP to customer", e);
            return new MessageResponse("Error sending OTP. Please try again.");
        }
    }

    /**
     * Verify OTP entered by customer (Step 2)
     */
    public MessageResponse verifyCustomerOtp(String verificationToken, String mobileNumber, String otp) {
        try {
            logger.info("Verifying OTP for customer mobile: {} and token: {}",
                    maskMobile(mobileNumber), verificationToken.substring(0, 8) + "****");

            Optional<DigiLockerVerificationRequest> requestOpt = verificationRequestRepository
                    .findByVerificationToken(verificationToken);

            if (requestOpt.isEmpty()) {
                return new MessageResponse("Invalid verification link");
            }

            DigiLockerVerificationRequest request = requestOpt.get();

            if (!request.isActive()) {
                return new MessageResponse("Verification link is no longer active");
            }

            // Verify OTP
            String otpKey = verificationToken + "_" + mobileNumber;
            String storedOtp = otpStorage.get(otpKey);

            if (storedOtp == null) {
                return new MessageResponse("OTP not found. Please request a new OTP.");
            }

            if (!storedOtp.equals(otp)) {
                request.setRetryCount(request.getRetryCount() + 1);
                verificationRequestRepository.save(request);

                if (request.getRetryCount() >= 3) {
                    request.setStatus(VerificationRequestStatus.FAILED);
                    request.setErrorMessage("Too many failed OTP attempts");
                    verificationRequestRepository.save(request);
                    return new MessageResponse("Too many failed attempts. Verification failed.");
                }

                return new MessageResponse("Invalid OTP. Please try again.");
            }

            // OTP verified successfully
            otpStorage.remove(otpKey); // Remove used OTP
            request.setCustomerAuthenticated(true);
            request.setCustomerMobile(mobileNumber);
            verificationRequestRepository.save(request);

            logger.info("Customer OTP verified successfully for token: {}",
                    verificationToken.substring(0, 8) + "****");
            return new MessageResponse("OTP verified successfully. Please proceed to consent.");

        } catch (Exception e) {
            logger.error("Error verifying customer OTP", e);
            return new MessageResponse("Error verifying OTP. Please try again.");
        }
    }

    /**
     * Process customer consent and start document verification (Step 3)
     */
    public Map<String, Object> processCustomerConsent(String verificationToken, boolean consentGiven,
            String consentText) {
        try {
            logger.info("Processing customer consent for token: {} - Consent: {}",
                    verificationToken.substring(0, 8) + "****", consentGiven);

            Optional<DigiLockerVerificationRequest> requestOpt = verificationRequestRepository
                    .findByVerificationToken(verificationToken);

            if (requestOpt.isEmpty()) {
                return createErrorResponse("Invalid verification link");
            }

            DigiLockerVerificationRequest request = requestOpt.get();

            if (!request.isActive() || !request.isCustomerAuthenticated()) {
                return createErrorResponse("Please complete previous steps first");
            }

            if (!consentGiven) {
                request.setStatus(VerificationRequestStatus.FAILED);
                request.setErrorMessage("Customer consent not provided");
                verificationRequestRepository.save(request);
                return createErrorResponse("Consent is required to proceed with verification");
            }

            // Record consent
            request.setConsentGiven(true);
            verificationRequestRepository.save(request);

            // Start document verification process
            return startDocumentVerification(request);

        } catch (Exception e) {
            logger.error("Error processing customer consent", e);
            return createErrorResponse("Error processing consent. Please try again.");
        }
    }

    /**
     * Start document verification using mock DigiLocker data
     */
    private Map<String, Object> startDocumentVerification(DigiLockerVerificationRequest request) {
        try {
            logger.info("Starting document verification for request: {}", request.getId());

            // Generate mock DigiLocker ID for the customer
            String mockDigiLockerId = generateMockDigiLockerId();
            request.setDigiLockerId(mockDigiLockerId);

            // Perform verification using DigiLocker service
            DigiLockerVerificationResult verificationResult = digiLockerService.verifyDigiLockerId(mockDigiLockerId);

            if (verificationResult.isSuccess()) {
                // Store verification results
                String resultJson = objectMapper.writeValueAsString(verificationResult);
                request.setVerificationResult(resultJson);
                request.setStatus(VerificationRequestStatus.COMPLETED);

                logger.info("Document verification completed successfully for request: {}", request.getId());

                // Send webhook notification to merchant
                if (request.getWebhookUrl() != null) {
                    webhookService.sendVerificationWebhook(request, verificationResult);
                }

            } else {
                request.setStatus(VerificationRequestStatus.FAILED);
                request.setErrorMessage("Document verification failed: " + verificationResult.getErrorMessage());
                logger.warn("Document verification failed for request: {} - Error: {}",
                        request.getId(), verificationResult.getErrorMessage());
            }

            verificationRequestRepository.save(request);

            // Prepare response
            Map<String, Object> response = new HashMap<>();
            response.put("success", verificationResult.isSuccess());
            response.put("status", request.getStatus().toString());
            response.put("progress", request.getProgressPercentage());

            if (verificationResult.isSuccess()) {
                response.put("message", "Document verification completed successfully!");
                response.put("verifiedDocuments", request.getRequestedDocuments());
                response.put("verificationTime", LocalDateTime.now());
            } else {
                response.put("error", request.getErrorMessage());
            }

            return response;

        } catch (Exception e) {
            logger.error("Error starting document verification for request: {}", request.getId(), e);
            request.setStatus(VerificationRequestStatus.FAILED);
            request.setErrorMessage("Verification process failed: " + e.getMessage());
            verificationRequestRepository.save(request);

            return createErrorResponse("Verification process failed. Please try again.");
        }
    }

    /**
     * Helper methods
     */
    private CustomerVerificationDto.VerificationStep determineCurrentStep(DigiLockerVerificationRequest request) {
        if (!request.isOtpSent()) {
            return CustomerVerificationDto.VerificationStep.MOBILE_ENTRY;
        } else if (!request.isCustomerAuthenticated()) {
            return CustomerVerificationDto.VerificationStep.OTP_VERIFICATION;
        } else if (!request.isConsentGiven() && request.isConsentRequired()) {
            return CustomerVerificationDto.VerificationStep.CONSENT_REVIEW;
        } else {
            return CustomerVerificationDto.VerificationStep.PROCESSING;
        }
    }

    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("error", message);
        return response;
    }

    /**
     * Process document upload for verification
     */
    public Map<String, Object> processDocumentUpload(String verificationToken, String documentType,
            MultipartFile documentFile, String customerMobile) {
        Map<String, Object> response = new HashMap<>();

        try {
            logger.info("Processing document upload for token: {}, type: {}, mobile: {}",
                    verificationToken.substring(0, 8) + "****", documentType,
                    customerMobile.substring(0, 2) + "****" + customerMobile.substring(customerMobile.length() - 2));

            // Find verification request
            Optional<DigiLockerVerificationRequest> requestOpt = verificationRequestRepository
                    .findByVerificationToken(verificationToken);

            if (requestOpt.isEmpty()) {
                response.put("success", false);
                response.put("error", "Invalid verification token");
                return response;
            }

            DigiLockerVerificationRequest request = requestOpt.get();

            // Validate request status
            if (request.getStatus() != VerificationRequestStatus.OTP_VERIFIED) {
                response.put("success", false);
                response.put("error", "Customer must complete OTP verification before uploading documents");
                return response;
            }

            // Check if consent was given
            if (!request.isConsentGiven()) {
                response.put("success", false);
                response.put("error", "Customer consent is required before document upload");
                return response;
            }

            // Validate document type is requested
            if (!request.getRequestedDocuments().contains(documentType.toUpperCase())) {
                response.put("success", false);
                response.put("error", "Document type '" + documentType + "' was not requested for this verification");
                return response;
            }

            // Process document upload using DigiLocker service
            DigiLockerVerificationResult verificationResult = digiLockerService.processUploadedDocument(
                    documentType, documentFile, customerMobile, verificationToken);

            if (verificationResult.isSuccess()) {
                // Update verification request with document results
                request.setDigiLockerId(verificationResult.getDigiLockerId());
                // The following fields are not present in DigiLockerVerificationRequest, so we
                // skip setting them:
                // - setDocumentsVerified
                // - setDocumentsVerifiedAt
                // - setVerificationResults
                request.setStatus(VerificationRequestStatus.DOCUMENTS_UPLOADED);
                request.setUpdatedAt(LocalDateTime.now());

                // Save updated request
                verificationRequestRepository.save(request);

                // Prepare success response
                response.put("success", true);
                response.put("message", "Document uploaded and verified successfully");
                response.put("document_type", documentType);
                response.put("verification_status", "VERIFIED");
                // Use reflection to safely get metadata if available
                try {
                    Object firstDoc = verificationResult.getDocuments().get(0);
                    Object metadata = firstDoc.getClass().getMethod("getMetadata").invoke(firstDoc);
                    response.put("extracted_data", metadata != null ? metadata : new HashMap<>());
                } catch (Exception e) {
                    response.put("extracted_data", new HashMap<>());
                }
                response.put("next_step", "VERIFICATION_COMPLETE");

                // Trigger webhook notification to merchant
                try {
                    webhookService.sendVerificationWebhook(request, verificationResult);
                } catch (Exception e) {
                    logger.warn("Failed to send webhook notification for document verification: {}", e.getMessage());
                }

                logger.info("Document upload processing completed successfully for token: {}",
                        verificationToken.substring(0, 8) + "****");

            } else {
                response.put("success", false);
                response.put("error", verificationResult.getErrorMessage());
                response.put("document_type", documentType);
                response.put("verification_status", "FAILED");

                logger.warn("Document upload processing failed for token: {} - {}",
                        verificationToken.substring(0, 8) + "****", verificationResult.getErrorMessage());
            }

        } catch (Exception e) {
            logger.error("Error processing document upload for token: {}",
                    verificationToken.substring(0, 8) + "****", e);
            response.put("success", false);
            response.put("error", "Document processing failed: " + e.getMessage());
        }

        return response;
    }

    /**
     * Convert DigiLocker verification result to map for storage
     */
    private Map<String, Object> convertVerificationResultToMap(DigiLockerVerificationResult result) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", result.isSuccess());
        resultMap.put("digilocker_id", result.getDigiLockerId());
        resultMap.put("total_documents", result.getTotalDocuments());
        resultMap.put("verification_time", result.getVerificationTime().toString());

        if (result.getErrorMessage() != null) {
            resultMap.put("error_message", result.getErrorMessage());
        }

        // Add document details
        if (result.getDocuments() != null && !result.getDocuments().isEmpty()) {
            List<Map<String, Object>> documentsList = new ArrayList<>();
            for (Object docObj : result.getDocuments()) {
                // Use reflection to access fields/methods since DigiLockerDocument may not have
                // the required methods
                try {
                    Object doc = docObj;
                    Map<String, Object> docMap = new HashMap<>();
                    // document_id
                    docMap.put("document_id", doc.getClass().getMethod("getDocumentId").invoke(doc));
                    // document_type
                    docMap.put("document_type", doc.getClass().getMethod("getDocumentType").invoke(doc));
                    // document_name
                    docMap.put("document_name", doc.getClass().getMethod("getDocumentName").invoke(doc));
                    // verified
                    docMap.put("verified", doc.getClass().getMethod("isVerified").invoke(doc));
                    // verification_status (if method exists)
                    try {
                        docMap.put("verification_status",
                                doc.getClass().getMethod("getVerificationStatus").invoke(doc));
                    } catch (NoSuchMethodException nsme) {
                        docMap.put("verification_status", null);
                    }
                    // metadata (if method exists)
                    try {
                        Object metadata = doc.getClass().getMethod("getMetadata").invoke(doc);
                        docMap.put("metadata", metadata != null ? metadata : new HashMap<>());
                    } catch (NoSuchMethodException nsme) {
                        docMap.put("metadata", new HashMap<>());
                    }
                    documentsList.add(docMap);
                } catch (Exception e) {
                    // If any error occurs, skip this document
                    continue;
                }
            }
            resultMap.put("documents", documentsList);
        }

        return resultMap;
    }

    private boolean isValidMobileNumber(String mobile) {
        return mobile != null && mobile.matches("^[+]?[0-9]{10,15}$");
    }

    private String generateOtp() {
        return String.format("%06d", random.nextInt(1000000));
    }

    private boolean sendOtpSms(String mobile, String otp) {
        // Mock SMS sending - In production, integrate with SMS service
        logger.info("Sending OTP {} to mobile: {}", otp, maskMobile(mobile));
        return true; // Always return true for mock
    }

    private String generateMockDigiLockerId() {
        // Generate a mock 32-character hex string and format as UUID
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 32; i++) {
            sb.append(Integer.toHexString(random.nextInt(16)));
        }
        String hex = sb.toString();
        return String.format("%s-%s-%s-%s-%s",
                hex.substring(0, 8),
                hex.substring(8, 12),
                hex.substring(12, 16),
                hex.substring(16, 20),
                hex.substring(20, 32));
    }

    private String maskMobile(String mobile) {
        if (mobile == null || mobile.length() < 4)
            return "****";
        return mobile.substring(0, 2) + "****" + mobile.substring(mobile.length() - 2);
    }
}
