package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.SignedAgreement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

@Service
public class PdfService {

    private static final Logger logger = LoggerFactory.getLogger(PdfService.class);

    /**
     * Generate enhanced HTML-based PDF for signed agreement with embedded signature
     */
    public byte[] generateSignedAgreementPdf(SignedAgreement agreement) {
        logger.info("Generating enhanced PDF for signed agreement: {}", agreement.getId());

        try {
            // Generate HTML content with signature for better presentation
            String htmlContent = generateEnhancedHtmlContent(agreement);

            // For now, return HTML as bytes (can be enhanced with HTML-to-PDF library
            // later)
            // This provides a much better format than raw PDF construction
            return htmlContent.getBytes("UTF-8");

        } catch (Exception e) {
            logger.error("Error generating PDF for signed agreement", e);
            throw new RuntimeException("Failed to generate PDF: " + e.getMessage());
        }
    }

    /**
     * Generate page content for the PDF
     */
    private String generatePageContent(SignedAgreement agreement) {
        StringBuilder content = new StringBuilder();

        // Add text content
        content.append("BT\n");
        content.append("/F1 12 Tf\n");
        content.append("50 750 Td\n");
        content.append("(").append(escapeString(agreement.getAgreementTitle())).append(") Tj\n");
        content.append("0 -20 Td\n");
        content.append("(").append(escapeString("Agreement Type: " + agreement.getAgreementType())).append(") Tj\n");
        content.append("0 -20 Td\n");
        content.append("(").append(escapeString("Party A: " + agreement.getPartyA())).append(") Tj\n");
        content.append("0 -20 Td\n");
        content.append("(").append(escapeString("Party B: " + agreement.getPartyB())).append(") Tj\n");
        content.append("0 -20 Td\n");
        content.append("(").append(escapeString("Signed by: " + agreement.getSignerName())).append(") Tj\n");
        content.append("0 -20 Td\n");
        content.append("(").append(escapeString("Signed on: " +
                agreement.getSignedAt().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))).append(") Tj\n");
        content.append("0 -40 Td\n");
        content.append("(").append(escapeString("Document Hash: " + agreement.getDocumentHash())).append(") Tj\n");
        content.append("0 -20 Td\n");
        content.append("(").append(escapeString("Signature Hash: " + agreement.getSignatureHash())).append(") Tj\n");
        content.append("0 -40 Td\n");
        content.append("(").append(escapeString("Agreement Content:")).append(") Tj\n");
        content.append("0 -20 Td\n");

        // Add agreement content (truncated for PDF)
        String agreementText = agreement.getAgreementContent();
        if (agreementText.length() > 500) {
            agreementText = agreementText.substring(0, 500) + "...";
        }
        content.append("(").append(escapeString(agreementText)).append(") Tj\n");

        content.append("ET\n");

        return content.toString();
    }

    /**
     * Escape special characters in PDF strings
     */
    private String escapeString(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("\\", "\\\\")
                .replace("(", "\\(")
                .replace(")", "\\)")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    /**
     * Generate a simple text-based document (fallback when PDF generation fails)
     */
    public String generateSignedAgreementText(SignedAgreement agreement) {
        StringBuilder text = new StringBuilder();

        text.append("SIGNED AGREEMENT\n");
        text.append("================\n\n");
        text.append("Title: ").append(agreement.getAgreementTitle()).append("\n");
        text.append("Type: ").append(agreement.getAgreementType()).append("\n");
        text.append("Party A: ").append(agreement.getPartyA()).append("\n");
        text.append("Party B: ").append(agreement.getPartyB()).append("\n");
        text.append("Terms: ").append(agreement.getTerms()).append("\n\n");
        text.append("SIGNATURE DETAILS\n");
        text.append("=================\n");
        text.append("Signer Name: ").append(agreement.getSignerName()).append("\n");
        text.append("Signer Email: ").append(agreement.getSignerEmail()).append("\n");
        text.append("Signed At: ")
                .append(agreement.getSignedAt().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
                .append("\n");
        text.append("IP Address: ").append(agreement.getSignerIpAddress()).append("\n");
        text.append("Status: ").append(agreement.getStatus()).append("\n");
        text.append("Version: ").append(agreement.getVersion()).append("\n\n");
        text.append("INTEGRITY VERIFICATION\n");
        text.append("======================\n");
        text.append("Document Hash: ").append(agreement.getDocumentHash()).append("\n");
        text.append("Signature Hash: ").append(agreement.getSignatureHash()).append("\n\n");
        text.append("AGREEMENT CONTENT\n");
        text.append("=================\n");
        text.append(agreement.getAgreementContent()).append("\n\n");
        text.append("SIGNATURE IMAGE (Base64)\n");
        text.append("========================\n");
        text.append(agreement.getSignatureImageBase64()).append("\n");

        return text.toString();
    }

    /**
     * Generate enhanced HTML content with embedded signature
     */
    private String generateEnhancedHtmlContent(SignedAgreement agreement) {
        StringBuilder html = new StringBuilder();

        html.append("<!DOCTYPE html>\n");
        html.append("<html>\n");
        html.append("<head>\n");
        html.append("<meta charset='UTF-8'>\n");
        html.append("<title>Signed Agreement - ").append(escapeHtml(agreement.getAgreementTitle()))
                .append("</title>\n");
        html.append("<style>\n");
        html.append("body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; color: #333; }\n");
        html.append(
                ".header { text-align: center; border-bottom: 3px solid #007bff; padding-bottom: 20px; margin-bottom: 30px; }\n");
        html.append(".title { font-size: 24px; font-weight: bold; color: #007bff; margin-bottom: 10px; }\n");
        html.append(".subtitle { font-size: 16px; color: #666; }\n");
        html.append(".section { margin-bottom: 25px; }\n");
        html.append(
                ".section-title { font-size: 18px; font-weight: bold; color: #007bff; border-bottom: 1px solid #ddd; padding-bottom: 5px; margin-bottom: 15px; }\n");
        html.append(".info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }\n");
        html.append(".info-item { background: #f8f9fa; padding: 10px; border-radius: 5px; }\n");
        html.append(".info-label { font-weight: bold; color: #495057; }\n");
        html.append(
                ".content-box { background: #ffffff; border: 1px solid #ddd; padding: 20px; border-radius: 5px; white-space: pre-wrap; }\n");
        html.append(
                ".signature-section { background: #f8f9fa; border: 2px solid #007bff; padding: 20px; border-radius: 10px; margin-top: 30px; }\n");
        html.append(
                ".signature-image { max-width: 300px; max-height: 150px; border: 1px solid #ddd; border-radius: 5px; background: white; }\n");
        html.append(
                ".verification-box { background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin-top: 20px; }\n");
        html.append(".hash-text { font-family: monospace; font-size: 12px; word-break: break-all; color: #495057; }\n");
        html.append(
                ".status-badge { display: inline-block; padding: 5px 10px; border-radius: 15px; font-size: 12px; font-weight: bold; }\n");
        html.append(".status-signed { background: #d4edda; color: #155724; }\n");
        html.append(
                ".watermark { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-45deg); font-size: 100px; color: rgba(0,123,255,0.1); z-index: -1; font-weight: bold; }\n");
        html.append("@media print { body { margin: 20px; } .watermark { display: block; } }\n");
        html.append("</style>\n");
        html.append("</head>\n");
        html.append("<body>\n");

        // Add watermark
        html.append("<div class='watermark'>DIGITALLY SIGNED</div>\n");

        // Header
        html.append("<div class='header'>\n");
        html.append("<div class='title'>").append(escapeHtml(agreement.getAgreementTitle())).append("</div>\n");
        html.append("<div class='subtitle'>Digitally Signed Legal Agreement</div>\n");
        html.append("</div>\n");

        // Agreement Information
        html.append("<div class='section'>\n");
        html.append("<div class='section-title'>Agreement Information</div>\n");
        html.append("<div class='info-grid'>\n");
        html.append("<div class='info-item'>\n");
        html.append("<div class='info-label'>Agreement Type:</div>\n");
        html.append("<div>").append(escapeHtml(agreement.getAgreementType())).append("</div>\n");
        html.append("</div>\n");
        html.append("<div class='info-item'>\n");
        html.append("<div class='info-label'>Status:</div>\n");
        html.append("<div><span class='status-badge status-signed'>").append(escapeHtml(agreement.getStatus()))
                .append("</span></div>\n");
        html.append("</div>\n");
        html.append("<div class='info-item'>\n");
        html.append("<div class='info-label'>Party A:</div>\n");
        html.append("<div>").append(escapeHtml(agreement.getPartyA())).append("</div>\n");
        html.append("</div>\n");
        html.append("<div class='info-item'>\n");
        html.append("<div class='info-label'>Party B:</div>\n");
        html.append("<div>").append(escapeHtml(agreement.getPartyB())).append("</div>\n");
        html.append("</div>\n");
        html.append("</div>\n");
        html.append("</div>\n");

        // Agreement Content
        html.append("<div class='section'>\n");
        html.append("<div class='section-title'>Agreement Terms and Conditions</div>\n");
        html.append("<div class='content-box'>").append(escapeHtml(agreement.getAgreementContent())).append("</div>\n");
        html.append("</div>\n");

        // Signature Section
        html.append("<div class='signature-section'>\n");
        html.append("<div class='section-title'>Digital Signature</div>\n");
        html.append("<div class='info-grid'>\n");
        html.append("<div class='info-item'>\n");
        html.append("<div class='info-label'>Signer Name:</div>\n");
        html.append("<div>").append(escapeHtml(agreement.getSignerName())).append("</div>\n");
        html.append("</div>\n");
        html.append("<div class='info-item'>\n");
        html.append("<div class='info-label'>Signer Email:</div>\n");
        html.append("<div>").append(escapeHtml(agreement.getSignerEmail())).append("</div>\n");
        html.append("</div>\n");
        html.append("<div class='info-item'>\n");
        html.append("<div class='info-label'>Signed Date:</div>\n");
        html.append("<div>")
                .append(agreement.getSignedAt().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy 'at' HH:mm:ss")))
                .append("</div>\n");
        html.append("</div>\n");
        html.append("<div class='info-item'>\n");
        html.append("<div class='info-label'>IP Address:</div>\n");
        html.append("<div>").append(escapeHtml(agreement.getSignerIpAddress())).append("</div>\n");
        html.append("</div>\n");
        html.append("</div>\n");

        // Signature Image
        if (agreement.getSignatureImageBase64() != null && !agreement.getSignatureImageBase64().isEmpty()) {
            html.append("<div style='margin-top: 20px;'>\n");
            html.append("<div class='info-label'>Digital Signature:</div>\n");
            html.append("<img src='").append(agreement.getSignatureImageBase64())
                    .append("' class='signature-image' alt='Digital Signature' />\n");
            html.append("</div>\n");
        }

        html.append("</div>\n");

        // Verification Section
        html.append("<div class='verification-box'>\n");
        html.append("<div class='section-title'>Document Integrity Verification</div>\n");
        html.append("<div class='info-item'>\n");
        html.append("<div class='info-label'>Document Hash (SHA-256):</div>\n");
        html.append("<div class='hash-text'>").append(escapeHtml(agreement.getDocumentHash())).append("</div>\n");
        html.append("</div>\n");
        html.append("<div class='info-item' style='margin-top: 10px;'>\n");
        html.append("<div class='info-label'>Signature Hash (SHA-256):</div>\n");
        html.append("<div class='hash-text'>").append(escapeHtml(agreement.getSignatureHash())).append("</div>\n");
        html.append("</div>\n");
        html.append("<div style='margin-top: 15px; font-size: 14px; color: #155724;'>\n");
        html.append(
                "✓ This document has been digitally signed and verified. Any modifications to the content will invalidate the signature.\n");
        html.append("</div>\n");
        html.append("</div>\n");

        // Footer
        html.append(
                "<div style='margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #666; font-size: 12px;'>\n");
        html.append("Generated by Legal Advisor System | Document ID: ").append(escapeHtml(agreement.getId()))
                .append("\n");
        html.append("<br>This is a digitally signed legal document with cryptographic verification.\n");
        html.append("</div>\n");

        html.append("</body>\n");
        html.append("</html>");

        return html.toString();
    }

    /**
     * Escape HTML special characters
     */
    private String escapeHtml(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    /**
     * Convert base64 signature to image bytes
     */
    public byte[] convertBase64ToImageBytes(String base64String) {
        try {
            // Remove data URL prefix if present
            if (base64String.contains(",")) {
                base64String = base64String.split(",")[1];
            }
            return Base64.getDecoder().decode(base64String);
        } catch (Exception e) {
            logger.error("Error converting base64 to image bytes", e);
            throw new RuntimeException("Failed to convert base64 to image: " + e.getMessage());
        }
    }
}
