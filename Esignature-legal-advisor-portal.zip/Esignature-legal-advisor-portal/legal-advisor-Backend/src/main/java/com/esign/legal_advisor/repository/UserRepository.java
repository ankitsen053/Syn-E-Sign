package com.esign.legal_advisor.repository;

import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.esign.legal_advisor.entites.User;

public interface UserRepository extends MongoRepository<User, String> {
  Optional<User> findByUsername(String username);

  Optional<User> findByEmail(String email);

  Optional<User> findByGoogleId(String googleId);

  Boolean existsByUsername(String username);

  Boolean existsByEmail(String email);

  // Count methods for admin statistics
  long countByUserType(String userType);

  long countByIsVerified(boolean isVerified);

  long countByCreatedAtAfter(LocalDateTime date);

  long countByUpdatedAtAfter(LocalDateTime date);

  // Pagination methods
  Page<User> findByUserType(String userType, Pageable pageable);
}

// package com.esign.legal_advisor.repositaries;
//
// import org.springframework.data.mongodb.repository.MongoRepository;
// import org.springframework.stereotype.Repository;
//
// import com.esign.legal_advisor.entites.User;
//
// @Repository
// public interface UserRepository extends MongoRepository<User, String> {
// // Optional: custom query methods here
// }
