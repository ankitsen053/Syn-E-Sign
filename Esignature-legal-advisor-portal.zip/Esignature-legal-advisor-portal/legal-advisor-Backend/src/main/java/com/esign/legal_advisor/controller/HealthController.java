package com.esign.legal_advisor.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/health")
@CrossOrigin(origins = "*")
public class HealthController {

    @Autowired
    private MongoTemplate mongoTemplate;

    @GetMapping
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> health = new HashMap<>();
        
        try {
            // Check application status
            health.put("status", "UP");
            health.put("timestamp", LocalDateTime.now());
            health.put("application", "Legal Advisor API");
            health.put("version", "1.0.0");
            
            // Check database connectivity
            Map<String, Object> database = new HashMap<>();
            try {
                mongoTemplate.execute("test", collection -> {
                    collection.countDocuments();
                    return null;
                });
                database.put("status", "UP");
                database.put("type", "MongoDB");
            } catch (Exception e) {
                database.put("status", "DOWN");
                database.put("error", "Database connection failed: " + e.getMessage());
                health.put("status", "DEGRADED");
            }
            health.put("database", database);
            
            // Check memory usage
            Runtime runtime = Runtime.getRuntime();
            Map<String, Object> memory = new HashMap<>();
            memory.put("totalMemory", formatBytes(runtime.totalMemory()));
            memory.put("freeMemory", formatBytes(runtime.freeMemory()));
            memory.put("usedMemory", formatBytes(runtime.totalMemory() - runtime.freeMemory()));
            memory.put("maxMemory", formatBytes(runtime.maxMemory()));
            health.put("memory", memory);
            
            // Check disk space
            Map<String, Object> disk = new HashMap<>();
            java.io.File root = new java.io.File("/");
            disk.put("totalSpace", formatBytes(root.getTotalSpace()));
            disk.put("freeSpace", formatBytes(root.getFreeSpace()));
            disk.put("usableSpace", formatBytes(root.getUsableSpace()));
            health.put("disk", disk);
            
            return ResponseEntity.ok(health);
            
        } catch (Exception e) {
            health.put("status", "DOWN");
            health.put("error", "Health check failed: " + e.getMessage());
            return ResponseEntity.status(503).body(health);
        }
    }

    @GetMapping("/simple")
    public ResponseEntity<Map<String, Object>> simpleHealthCheck() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("timestamp", LocalDateTime.now());
        response.put("message", "Service is running");
        return ResponseEntity.ok(response);
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format("%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }
}
