package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PanAnalysisResult {
    
    private String panNumber;
    private String name;
    private String fatherName;
    private String dateOfBirth;
    private String panCardType; // Individual, Company, etc.
    
    // Validation flags
    private boolean panNumberValid;
    private boolean nameExtracted;
    private boolean fatherNameExtracted;
    private boolean dobExtracted;
    
    // Confidence scores for each field
    private Double panNumberConfidence;
    private Double nameConfidence;
    private Double fatherNameConfidence;
    private Double dobConfidence;
    
    // Overall document authenticity
    private Double documentAuthenticityScore;
    private String documentQuality; // EXCELLENT, GOOD, FAIR, POOR
}
