package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.*;
import com.esign.legal_advisor.entites.*;
import com.esign.legal_advisor.repository.*;
import com.esign.legal_advisor.dto.UserDto;
import com.esign.legal_advisor.security.JwtUtils;
// import com.esign.legal_advisor.service.EmailVerificationService;
// import com.esign.legal_advisor.service.EmailService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import java.util.stream.Collectors;

import java.time.Instant;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class AuthService {

    private static final Logger logger = LoggerFactory.getLogger(AuthService.class);

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;
    private final RefreshTokenRepository refreshTokenRepository;
    private final EmailVerificationService emailVerificationService;
    private final EmailService emailService;
    private final VerificationService verificationService;
    private final TwoFactorAuthService twoFactorAuthService;

    @Value("${app.development-mode:false}")
    private boolean developmentMode;

    public AuthService(AuthenticationManager authenticationManager,
            UserRepository userRepository,
            RoleRepository roleRepository,
            PasswordEncoder passwordEncoder,
            JwtUtils jwtUtils,
            RefreshTokenRepository refreshTokenRepository,
            EmailVerificationService emailVerificationService,
            EmailService emailService,
            VerificationService verificationService,
            TwoFactorAuthService twoFactorAuthService) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
        this.refreshTokenRepository = refreshTokenRepository;
        this.emailVerificationService = emailVerificationService;
        this.emailService = emailService;
        this.verificationService = verificationService;
        this.twoFactorAuthService = twoFactorAuthService;
    }

    public MessageResponse registerUser(SignupRequest signUpRequest) {
        if (userRepository.existsByUsername(signUpRequest.getUsername())) {
            return new MessageResponse("Error: Username is already taken!");
        }
        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
            return new MessageResponse("Error: Email is already in use!");
        }

        User user = new User();
        user.setUsername(signUpRequest.getUsername());
        user.setEmail(signUpRequest.getEmail());
        user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
        user.setFullName(signUpRequest.getFullName()); // Set full name if provided
        user.setEmailVerified(true); // Email verification moved to login process
        user.setEnabled(true); // Enable user immediately after signup

        Set<Role> roles = new HashSet<>();
        if (signUpRequest.getRoles() == null || signUpRequest.getRoles().isEmpty()) {
            // Default role if none specified
            Role userRole = roleRepository.findByName(ERole.ROLE_USER)
                    .orElseGet(() -> roleRepository.save(new Role(ERole.ROLE_USER)));
            roles.add(userRole);
        } else {
            signUpRequest.getRoles().forEach(role -> {
                ERole erole = ERole.valueOf("ROLE_" + role.toUpperCase());
                Role r = roleRepository.findByName(erole)
                        .orElseGet(() -> roleRepository.save(new Role(erole)));
                roles.add(r);
            });
        }
        user.setRoles(roles);
        userRepository.save(user);

        // Create verification status for the user
        verificationService.getOrCreateVerificationStatus(user.getId(), user.getEmail());

        return new MessageResponse("User registered successfully! You can now login with your credentials.");
    }

    public JwtResponse authenticateUser(LoginRequest loginRequest) {
        // Determine if the login identifier is username or email
        String loginIdentifier = loginRequest.getUsername(); // This field can contain either username or email
        String password = loginRequest.getPassword();

        // Try to find user by username first, then by email
        Optional<User> userOpt = userRepository.findByUsername(loginIdentifier);
        if (userOpt.isEmpty()) {
            // If not found by username, try by email
            userOpt = userRepository.findByEmail(loginIdentifier);
        }

        if (userOpt.isEmpty()) {
            throw new RuntimeException("User not found with username or email: " + loginIdentifier);
        }

        User user = userOpt.get();

        // Check if account is enabled
        if (!user.isEnabled()) {
            throw new RuntimeException("Account is disabled. Please contact support.");
        }

        // Authenticate user credentials using the actual username
        var authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        user.getUsername(), password));

        // Generate and send 2FA OTP for login verification
        try {
            twoFactorAuthService.generateAndSendLoginOtp(user.getId(), user.getEmail());
            logger.info("Login 2FA OTP sent to user: {} for verification", user.getUsername());
        } catch (Exception e) {
            logger.warn("Failed to send login 2FA OTP for user: {}, proceeding without 2FA", user.getUsername());
        }

        String jwt = jwtUtils.generateJwtToken(authentication);

        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setToken(UUID.randomUUID().toString());
        refreshToken.setUserId(user.getId());
        refreshToken.setExpiryDate(Instant.now().plusSeconds(60 * 60 * 24 * 7)); // 7 days
        refreshTokenRepository.save(refreshToken);

        return new JwtResponse(
                jwt,
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getRoles().stream().map(r -> r.getName().name()).toList(),
                refreshToken.getToken());
    }

    public MessageResponse verifyEmail(String email, String otp) {
        try {
            // Check if user exists
            Optional<User> userOpt = userRepository.findByEmail(email);
            if (userOpt.isEmpty()) {
                return new MessageResponse("Error: User not found!");
            }

            User user = userOpt.get();

            // Check if email is already verified
            if (user.isEmailVerified()) {
                return new MessageResponse("Error: Email is already verified!");
            }

            // Verify OTP
            if (emailVerificationService.verifyOtp(email, otp)) {
                // Mark email as verified and enable account
                user.setEmailVerified(true);
                user.setEnabled(true);
                userRepository.save(user);

                // Update verification status
                verificationService.updateEmailVerificationStatus(user.getId(), true);

                // Send welcome email
                emailService.sendWelcomeEmail(email, user.getUsername());

                return new MessageResponse("Email verified successfully! Your account is now active.");
            } else {
                return new MessageResponse("Error: Invalid or expired OTP!");
            }
        } catch (Exception e) {
            return new MessageResponse("Error: Failed to verify email. Please try again.");
        }
    }

    public MessageResponse resendOtp(String email) {
        try {
            // Check if user exists
            Optional<User> userOpt = userRepository.findByEmail(email);
            if (userOpt.isEmpty()) {
                return new MessageResponse("Error: User not found!");
            }

            User user = userOpt.get();

            // Check if email is already verified
            if (user.isEmailVerified()) {
                return new MessageResponse("Error: Email is already verified!");
            }

            // Resend OTP
            emailVerificationService.resendOtp(email);
            return new MessageResponse("OTP resent successfully! Please check your email.");
        } catch (Exception e) {
            return new MessageResponse("Error: Failed to resend OTP. Please try again.");
        }
    }

    public JwtResponse refreshAccessToken(String refreshToken) {
        Optional<RefreshToken> optionalToken = refreshTokenRepository.findByToken(refreshToken);
        if (optionalToken.isEmpty()) {
            throw new RuntimeException("Invalid refresh token");
        }
        RefreshToken token = optionalToken.get();
        if (token.getExpiryDate() == null || token.getExpiryDate().isBefore(Instant.now())) {
            refreshTokenRepository.delete(token);
            throw new RuntimeException("Refresh token expired");
        }

        User user = userRepository.findById(token.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        String newJwt = jwtUtils.generateJwtToken(user.getUsername());

        return new JwtResponse(
                newJwt,
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getRoles().stream().map(r -> r.getName().name()).toList(),
                refreshToken);
    }

    public MessageResponse logoutUser(String refreshToken) {
        Optional<RefreshToken> optionalToken = refreshTokenRepository.findByToken(refreshToken);
        if (optionalToken.isPresent()) {
            refreshTokenRepository.delete(optionalToken.get());
        }
        return new MessageResponse("Logged out successfully");
    }

    public boolean isEmailVerified(String email) {
        try {
            Optional<User> userOpt = userRepository.findByEmail(email);
            return userOpt.isPresent() && userOpt.get().isEmailVerified();
        } catch (Exception e) {
            return false;
        }
    }

    public VerificationStatusDto getVerificationStatus(String email) {
        try {
            Optional<User> userOpt = userRepository.findByEmail(email);
            if (userOpt.isEmpty()) {
                return new VerificationStatusDto(email, false, false, "User not found", "NOT_FOUND");
            }

            User user = userOpt.get();
            if (user.isEmailVerified() && user.isEnabled()) {
                return new VerificationStatusDto(email, true, true, "Email is verified. You can now log in.",
                        "VERIFIED");
            } else if (user.isEmailVerified() && !user.isEnabled()) {
                return new VerificationStatusDto(email, true, false,
                        "Email is verified but account is disabled. Please contact support.", "DISABLED");
            } else {
                return new VerificationStatusDto(email, false, false,
                        "Email is not verified. Please check your email for the verification code.", "UNVERIFIED");
            }
        } catch (Exception e) {
            return new VerificationStatusDto(email, false, false, "Failed to check verification status", "ERROR");
        }
    }

    public UserDto getCurrentUserProfile(Authentication authentication) {
        try {
            String username = authentication.getName();
            return getCurrentUserProfile(username);
        } catch (Exception e) {
            throw new RuntimeException("Failed to get user profile: " + e.getMessage());
        }
    }

    public UserDto getCurrentUserProfile(String username) {
        try {
            Optional<User> userOpt = userRepository.findByUsername(username);

            if (userOpt.isEmpty()) {
                throw new RuntimeException("User not found");
            }

            User user = userOpt.get();
            UserDto userDto = new UserDto();

            // Basic user information
            userDto.setId(user.getId());
            userDto.setUsername(user.getUsername());
            userDto.setEmail(user.getEmail());
            userDto.setFullName(user.getFullName());
            userDto.setProfilePicture(user.getProfilePicture());
            userDto.setEmailVerified(user.isEmailVerified());
            userDto.setEnabled(user.isEnabled());
            userDto.setGoogleId(user.getGoogleId());
            userDto.setRoles(user.getRoles().stream()
                    .map(role -> role.getName().name())
                    .collect(Collectors.toList()));

            // Additional profile fields
            userDto.setPhone(user.getPhone());
            userDto.setAddress(user.getAddress());
            userDto.setCompany(user.getCompany());
            userDto.setPosition(user.getPosition());
            userDto.setBio(user.getBio());
            userDto.setWebsite(user.getWebsite());
            userDto.setTimezone(user.getTimezone());
            userDto.setDateOfBirth(user.getDateOfBirth());

            // User type and verification fields
            userDto.setUserType(user.getUserType());
            userDto.setPanNumber(user.getPanNumber());
            userDto.setGstNumber(user.getGstNumber());
            userDto.setCompanyName(user.getCompanyName());
            userDto.setBusinessAddress(user.getBusinessAddress());
            userDto.setContactNumber(user.getContactNumber());
            userDto.setCompanyEmail(user.getCompanyEmail());
            userDto.setVerified(user.isVerified());
            userDto.setVerificationLevel(user.getVerificationLevel());

            // Lawyer-specific fields
            userDto.setBarNumber(user.getBarNumber());
            userDto.setBarAssociation(user.getBarAssociation());
            userDto.setPracticeAreas(user.getPracticeAreas());
            userDto.setLawSchool(user.getLawSchool());
            userDto.setYearOfAdmission(user.getYearOfAdmission());
            userDto.setLicenseNumber(user.getLicenseNumber());
            userDto.setSpecialization(user.getSpecialization());
            userDto.setExperience(user.getExperience());
            userDto.setHourlyRate(user.getHourlyRate());
            userDto.setFirmName(user.getFirmName());
            userDto.setFirmAddress(user.getFirmAddress());
            userDto.setProfessionalBio(user.getProfessionalBio());
            userDto.setCertifications(user.getCertifications());
            userDto.setLanguages(user.getLanguages());
            userDto.setBarVerified(user.isBarVerified());
            userDto.setVerificationDocument(user.getVerificationDocument());

            return userDto;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get user profile: " + e.getMessage());
        }
    }

    public boolean isDevelopmentMode() {
        return developmentMode;
    }

    public boolean isEmailServiceEnabled() {
        try {
            // Test email service by trying to send a test email
            emailService.sendOtpEmail("test@example.com", "123456");
            return true;
        } catch (Exception e) {
            logger.warn("Email service test failed: {}", e.getMessage());
            return false;
        }
    }

    public boolean isVerificationServiceEnabled() {
        try {
            // Test verification service by checking if it can generate OTP
            emailVerificationService.generateAndSendOtp("test@example.com");
            return true;
        } catch (Exception e) {
            logger.warn("Verification service test failed: {}", e.getMessage());
            return false;
        }
    }

    public void testEmailService() {
        try {
            logger.info("Testing email service configuration");
            emailService.sendOtpEmail("test@example.com", "123456");
            logger.info("Email service test successful");
        } catch (Exception e) {
            logger.error("Email service test failed: {}", e.getMessage());
            throw new RuntimeException("Email service test failed: " + e.getMessage());
        }
    }

    public UserDto updateUserProfile(String username, Map<String, Object> profileData) {
        try {
            Optional<User> userOpt = userRepository.findByUsername(username);

            if (userOpt.isEmpty()) {
                throw new RuntimeException("User not found");
            }

            User user = userOpt.get();

            // Update basic user fields
            if (profileData.containsKey("fullName")) {
                user.setFullName((String) profileData.get("fullName"));
            }
            if (profileData.containsKey("email")) {
                String newEmail = (String) profileData.get("email");
                // Check if email is already taken by another user
                Optional<User> existingUser = userRepository.findByEmail(newEmail);
                if (existingUser.isPresent() && !existingUser.get().getId().equals(user.getId())) {
                    throw new RuntimeException("Email is already taken");
                }
                user.setEmail(newEmail);
            }
            if (profileData.containsKey("username")) {
                String newUsername = (String) profileData.get("username");
                // Check if username is already taken by another user
                Optional<User> existingUser = userRepository.findByUsername(newUsername);
                if (existingUser.isPresent() && !existingUser.get().getId().equals(user.getId())) {
                    throw new RuntimeException("Username is already taken");
                }
                user.setUsername(newUsername);
            }

            // Update additional profile fields
            if (profileData.containsKey("phone")) {
                user.setPhone((String) profileData.get("phone"));
            }
            if (profileData.containsKey("address")) {
                user.setAddress((String) profileData.get("address"));
            }
            if (profileData.containsKey("company")) {
                user.setCompany((String) profileData.get("company"));
            }
            if (profileData.containsKey("position")) {
                user.setPosition((String) profileData.get("position"));
            }
            if (profileData.containsKey("bio")) {
                user.setBio((String) profileData.get("bio"));
            }
            if (profileData.containsKey("website")) {
                user.setWebsite((String) profileData.get("website"));
            }
            if (profileData.containsKey("timezone")) {
                user.setTimezone((String) profileData.get("timezone"));
            }
            if (profileData.containsKey("dateOfBirth")) {
                user.setDateOfBirth((String) profileData.get("dateOfBirth"));
            }
            if (profileData.containsKey("profilePicture")) {
                user.setProfilePicture((String) profileData.get("profilePicture"));
            }

            // Update user type and verification fields
            if (profileData.containsKey("userType")) {
                user.setUserType((String) profileData.get("userType"));
            }
            if (profileData.containsKey("panNumber")) {
                user.setPanNumber((String) profileData.get("panNumber"));
            }
            if (profileData.containsKey("gstNumber")) {
                user.setGstNumber((String) profileData.get("gstNumber"));
            }
            if (profileData.containsKey("companyName")) {
                user.setCompanyName((String) profileData.get("companyName"));
            }
            if (profileData.containsKey("businessAddress")) {
                user.setBusinessAddress((String) profileData.get("businessAddress"));
            }
            if (profileData.containsKey("contactNumber")) {
                user.setContactNumber((String) profileData.get("contactNumber"));
            }
            if (profileData.containsKey("companyEmail")) {
                user.setCompanyEmail((String) profileData.get("companyEmail"));
            }

            // Update lawyer-specific fields
            if (profileData.containsKey("barNumber")) {
                user.setBarNumber((String) profileData.get("barNumber"));
            }
            if (profileData.containsKey("barAssociation")) {
                user.setBarAssociation((String) profileData.get("barAssociation"));
            }
            if (profileData.containsKey("practiceAreas")) {
                user.setPracticeAreas((String) profileData.get("practiceAreas"));
            }
            if (profileData.containsKey("lawSchool")) {
                user.setLawSchool((String) profileData.get("lawSchool"));
            }
            if (profileData.containsKey("yearOfAdmission")) {
                user.setYearOfAdmission((String) profileData.get("yearOfAdmission"));
            }
            if (profileData.containsKey("licenseNumber")) {
                user.setLicenseNumber((String) profileData.get("licenseNumber"));
            }
            if (profileData.containsKey("specialization")) {
                user.setSpecialization((String) profileData.get("specialization"));
            }
            if (profileData.containsKey("experience")) {
                user.setExperience((String) profileData.get("experience"));
            }
            if (profileData.containsKey("hourlyRate")) {
                user.setHourlyRate((String) profileData.get("hourlyRate"));
            }
            if (profileData.containsKey("firmName")) {
                user.setFirmName((String) profileData.get("firmName"));
            }
            if (profileData.containsKey("firmAddress")) {
                user.setFirmAddress((String) profileData.get("firmAddress"));
            }
            if (profileData.containsKey("professionalBio")) {
                user.setProfessionalBio((String) profileData.get("professionalBio"));
            }
            if (profileData.containsKey("certifications")) {
                user.setCertifications((String) profileData.get("certifications"));
            }
            if (profileData.containsKey("languages")) {
                user.setLanguages((String) profileData.get("languages"));
            }
            if (profileData.containsKey("isBarVerified")) {
                user.setBarVerified((Boolean) profileData.get("isBarVerified"));
            }
            if (profileData.containsKey("verificationDocument")) {
                user.setVerificationDocument((String) profileData.get("verificationDocument"));
            }

            // Update timestamp
            user.touch();
            userRepository.save(user);
            logger.info("Profile updated successfully for user: {}", username);

            return getCurrentUserProfile(username);
        } catch (Exception e) {
            logger.error("Error updating user profile: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to update user profile: " + e.getMessage());
        }
    }

    public Map<String, Object> getUserPreferences(String username) {
        try {
            Optional<User> userOpt = userRepository.findByUsername(username);
            if (userOpt.isEmpty()) {
                throw new RuntimeException("User not found");
            }

            User user = userOpt.get();
            Map<String, Object> preferences = new HashMap<>();

            // For now, we'll return default preferences
            // In a real implementation, you'd store these in a separate preferences table
            preferences.put("notificationSettings", Map.of(
                    "emailNotifications", true,
                    "documentUpdates", true,
                    "agreementAlerts", true,
                    "systemUpdates", false,
                    "marketingEmails", false,
                    "smsNotifications", false));

            preferences.put("agreementPreferences", Map.of(
                    "defaultPartyName", user.getFullName() != null ? user.getFullName() : "",
                    "defaultCompany", user.getCompany() != null ? user.getCompany() : "",
                    "defaultAddress", user.getAddress() != null ? user.getAddress() : "",
                    "preferredLanguage", "English",
                    "defaultCurrency", "USD",
                    "autoSaveDocuments", true,
                    "requireDigitalSignature", true,
                    "defaultDocumentType", "General Agreement",
                    "legalJurisdiction", "",
                    "witnessRequired", false));

            preferences.put("securitySettings", Map.of(
                    "twoFactorAuth", false,
                    "sessionTimeout", 30,
                    "loginAlerts", true,
                    "deviceTracking", true,
                    "autoLogout", true));

            return preferences;
        } catch (Exception e) {
            logger.error("Error getting user preferences: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to get user preferences: " + e.getMessage());
        }
    }

    public Map<String, Object> updateUserPreferences(String username, Map<String, Object> preferencesData) {
        try {
            Optional<User> userOpt = userRepository.findByUsername(username);
            if (userOpt.isEmpty()) {
                throw new RuntimeException("User not found");
            }

            User user = userOpt.get();

            // Update user fields based on preferences
            if (preferencesData.containsKey("agreementPreferences")) {
                @SuppressWarnings("unchecked")
                Map<String, Object> agreementPrefs = (Map<String, Object>) preferencesData.get("agreementPreferences");
                if (agreementPrefs.containsKey("defaultPartyName")) {
                    user.setFullName((String) agreementPrefs.get("defaultPartyName"));
                }
                if (agreementPrefs.containsKey("defaultCompany")) {
                    user.setCompany((String) agreementPrefs.get("defaultCompany"));
                }
                if (agreementPrefs.containsKey("defaultAddress")) {
                    user.setAddress((String) agreementPrefs.get("defaultAddress"));
                }
            }

            user.touch();
            userRepository.save(user);
            logger.info("User preferences updated successfully for user: {}", username);

            return getUserPreferences(username);
        } catch (Exception e) {
            logger.error("Error updating user preferences: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to update user preferences: " + e.getMessage());
        }
    }

    public boolean changePassword(String username, String currentPassword, String newPassword) {
        try {
            Optional<User> userOpt = userRepository.findByUsername(username);

            if (userOpt.isEmpty()) {
                throw new RuntimeException("User not found");
            }

            User user = userOpt.get();

            // Verify current password
            if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
                logger.warn("Invalid current password for user: {}", username);
                return false;
            }

            // Encode and set new password
            String encodedNewPassword = passwordEncoder.encode(newPassword);
            user.setPassword(encodedNewPassword);

            userRepository.save(user);
            logger.info("Password changed successfully for user: {}", username);

            return true;
        } catch (Exception e) {
            logger.error("Error changing password: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to change password: " + e.getMessage());
        }
    }

    public MessageResponse verifyTwoFactorAuth(String userId, String otp, String type) {
        try {
            boolean isValid = twoFactorAuthService.verifyOtp(userId, otp, type);

            if (isValid) {
                return new MessageResponse("Two-factor authentication verified successfully!");
            } else {
                return new MessageResponse("Error: Invalid or expired OTP. Please try again.");
            }
        } catch (Exception e) {
            logger.error("Error during 2FA verification for user: {}", userId, e);
            return new MessageResponse("Error: Failed to verify two-factor authentication. Please try again.");
        }
    }

    public boolean isTwoFactorAuthVerified(String userId, String type) {
        return twoFactorAuthService.isOtpVerified(userId, type);
    }
}
