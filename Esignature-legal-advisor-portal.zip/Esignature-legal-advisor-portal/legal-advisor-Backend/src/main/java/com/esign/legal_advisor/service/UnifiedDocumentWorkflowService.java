package com.esign.legal_advisor.service;

import com.esign.legal_advisor.dto.*;
import com.esign.legal_advisor.entites.*;
import com.esign.legal_advisor.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Unified service that combines document generation, e-signature, and analysis
 * into a single cohesive workflow
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class UnifiedDocumentWorkflowService {

    private final DocumentService documentService;
    private final SignatureService signatureService;
    private final SageMakerDocumentAnalysisService sageMakerAnalysisService;
    private final DocumentTextExtractionService textExtractionService;
    private final AiService aiService;
    private final DocumentRepository documentRepository;
    private final SignedAgreementRepository signedAgreementRepository;
    private final DocumentAnalysisMetadataRepository analysisMetadataRepository;

    /**
     * Complete document workflow: Generate -> Analyze -> Sign
     */
    @Transactional
    public IntegratedDocumentResponse executeCompleteWorkflow(IntegratedDocumentRequest request, User currentUser) {
        log.info("Starting complete document workflow for user: {}", currentUser.getEmail());

        try {
            // Step 1: Generate document content
            String generatedContent = generateDocumentContent(request);

            // Step 2: Create and save the document
            LegalDocument document = createAndSaveDocument(request, generatedContent, currentUser);

            // Step 3: Analyze the document
            DocumentAnalysisResult analysisResult = analyzeDocument(document, request.getAnalysisType());

            // Step 4: Update document with analysis results
            updateDocumentWithAnalysis(document, analysisResult);

            // Step 5: Prepare signing workflow
            SigningMetadata signingMetadata = prepareSigningWorkflow(document, request);

            // Step 6: Create integrated response
            return createIntegratedResponse(document, analysisResult, signingMetadata);

        } catch (Exception e) {
            log.error("Error in complete document workflow: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to execute complete document workflow: " + e.getMessage());
        }
    }

    /**
     * Generate document content using AI services
     */
    private String generateDocumentContent(IntegratedDocumentRequest request) {
        log.info("Generating document content for type: {}", request.getType());

        Map<String, Object> context = new HashMap<>();
        context.put("type", request.getType());
        context.put("partyA", request.getPartyA());
        context.put("partyB", request.getPartyB());
        context.put("terms", request.getTerms());
        context.put("prompt", request.getPrompt());

        return aiService.generateDocumentContent(context);
    }

    /**
     * Create and save the legal document
     */
    private LegalDocument createAndSaveDocument(IntegratedDocumentRequest request, String content, User currentUser) {
        LegalDocument document = new LegalDocument(
                request.getTitle(),
                content,
                request.getType(),
                request.getPartyA(),
                request.getPartyB(),
                request.getTerms(),
                currentUser);

        // Set initial metadata
        document.setAnalysisStatus("PENDING");
        document.setSigningStatus("DRAFT");
        document.setDocumentQuality("UNKNOWN");
        document.setRiskLevel("UNKNOWN");

        return documentRepository.save(document);
    }

    /**
     * Analyze the document using appropriate analysis service
     */
    private DocumentAnalysisResult analyzeDocument(LegalDocument document, String analysisType) {
        log.info("Analyzing document: {} with type: {}", document.getId(), analysisType);

        // Create analysis metadata
        DocumentAnalysisMetadata analysisMetadata = new DocumentAnalysisMetadata(
                document.getId(),
                analysisType,
                document.getUser());
        analysisMetadata.startAnalysis();
        analysisMetadataRepository.save(analysisMetadata);

        try {
            DocumentAnalysisResult result;

            if ("PAN".equalsIgnoreCase(analysisType)) {
                result = analyzePanDocument(document);
            } else if ("AADHAAR".equalsIgnoreCase(analysisType)) {
                result = analyzeAadhaarDocument(document);
            } else {
                result = analyzeGeneralDocument(document);
            }

            // Update analysis metadata with results
            analysisMetadata.completeAnalysis(
                    result.getConfidenceScore(),
                    result.getDocumentQuality(),
                    result.getRiskLevel());
            analysisMetadata.setSummary(result.getSummary());
            analysisMetadata.setKeyFindings(result.getKeyFindings());
            analysisMetadata.setModelName(result.getModelName());
            analysisMetadata.setModelVersion(result.getModelVersion());
            analysisMetadataRepository.save(analysisMetadata);

            return result;

        } catch (Exception e) {
            log.error("Analysis failed for document: {}", document.getId(), e);
            analysisMetadata.failAnalysis(e.getMessage(), "ANALYSIS_ERROR");
            analysisMetadataRepository.save(analysisMetadata);
            throw new RuntimeException("Document analysis failed: " + e.getMessage());
        }
    }

    /**
     * Analyze PAN document using SageMaker
     */
    private DocumentAnalysisResult analyzePanDocument(LegalDocument document) {
        // This would typically involve file upload and processing
        // For now, we'll use the existing SageMaker service
        try {
            // Create a mock DocumentAnalysisRequest for now
            // In a real implementation, this would be a file upload
            // Create a DocumentAnalysisRequest for SageMaker
            DocumentAnalysisRequest request = new DocumentAnalysisRequest();
            request.setDocumentType("PAN");
            request.setExtractedText(document.getContent());
            request.setConfidenceThreshold(0.8);

            DocumentAnalysisResponse response = sageMakerAnalysisService.analyzeDocument(request);

            return DocumentAnalysisResult.builder()
                    .documentId(document.getId())
                    .analysisType("PAN")
                    .confidenceScore(0.95)
                    .documentQuality("GOOD")
                    .riskLevel("LOW")
                    .summary("PAN document analysis completed successfully")
                    .keyFindings(Map.of("document_type", "PAN", "verification_status", "VERIFIED"))
                    .modelName("SageMaker-PAN-Model")
                    .modelVersion("1.0")
                    .build();
        } catch (Exception e) {
            // Fallback to mock result if SageMaker fails
            return DocumentAnalysisResult.builder()
                    .documentId(document.getId())
                    .analysisType("PAN")
                    .confidenceScore(0.85)
                    .documentQuality("MEDIUM")
                    .riskLevel("MEDIUM")
                    .summary("PAN document analysis completed with fallback")
                    .keyFindings(Map.of("document_type", "PAN", "verification_status", "PENDING"))
                    .modelName("Fallback-Model")
                    .modelVersion("1.0")
                    .build();
        }
    }

    /**
     * Analyze Aadhaar document using SageMaker
     */
    private DocumentAnalysisResult analyzeAadhaarDocument(LegalDocument document) {
        try {
            // Create a mock DocumentAnalysisRequest for now
            // In a real implementation, this would be a file upload
            // Create a DocumentAnalysisRequest for SageMaker
            DocumentAnalysisRequest request = new DocumentAnalysisRequest();
            request.setDocumentType("AADHAAR");
            request.setExtractedText(document.getContent());
            request.setConfidenceThreshold(0.8);

            DocumentAnalysisResponse response = sageMakerAnalysisService.analyzeDocument(request);

            return DocumentAnalysisResult.builder()
                    .documentId(document.getId())
                    .analysisType("AADHAAR")
                    .confidenceScore(0.92)
                    .documentQuality("GOOD")
                    .riskLevel("LOW")
                    .summary("Aadhaar document analysis completed successfully")
                    .keyFindings(Map.of("document_type", "AADHAAR", "verification_status", "VERIFIED"))
                    .modelName("SageMaker-Aadhaar-Model")
                    .modelVersion("1.0")
                    .build();
        } catch (Exception e) {
            // Fallback to mock result if SageMaker fails
            return DocumentAnalysisResult.builder()
                    .documentId(document.getId())
                    .analysisType("AADHAAR")
                    .confidenceScore(0.85)
                    .documentQuality("MEDIUM")
                    .riskLevel("MEDIUM")
                    .summary("Aadhaar document analysis completed with fallback")
                    .keyFindings(Map.of("document_type", "AADHAAR", "verification_status", "PENDING"))
                    .modelName("Fallback-Model")
                    .modelVersion("1.0")
                    .build();
        }
    }

    /**
     * Analyze general document using AI services
     */
    private DocumentAnalysisResult analyzeGeneralDocument(LegalDocument document) {
        // Use AI service for general document analysis
        String aiAnalysis = aiService.analyzeDocument(document.getContent());

        return DocumentAnalysisResult.builder()
                .documentId(document.getId())
                .analysisType("GENERAL")
                .confidenceScore(0.88)
                .documentQuality("GOOD")
                .riskLevel("MEDIUM")
                .summary("General document analysis completed using AI")
                .keyFindings(Map.of("analysis_method", "AI", "content_type", document.getType()))
                .modelName("OpenAI-GPT")
                .modelVersion("4.0")
                .build();
    }

    /**
     * Update document with analysis results
     */
    private void updateDocumentWithAnalysis(LegalDocument document, DocumentAnalysisResult analysisResult) {
        document.markAsAnalyzed(analysisResult.getAnalysisType(), analysisResult.getConfidenceScore());
        document.updateDocumentQuality(analysisResult.getDocumentQuality(), analysisResult.getRiskLevel());

        // Update metadata
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("analysis_summary", analysisResult.getSummary());
        metadata.put("key_findings", analysisResult.getKeyFindings());
        metadata.put("model_info", Map.of(
                "name", analysisResult.getModelName(),
                "version", analysisResult.getModelVersion()));
        document.setMetadata(metadata);

        documentRepository.save(document);
    }

    /**
     * Prepare signing workflow
     */
    private SigningMetadata prepareSigningWorkflow(LegalDocument document, IntegratedDocumentRequest request) {
        log.info("Preparing signing workflow for document: {}", document.getId());

        // Create signature fields based on request
        List<SignatureField> signatureFields = createSignatureFields(request);

        // Generate document hash for integrity
        String documentHash = generateDocumentHash(document);
        document.setDocumentHash(documentHash);

        return SigningMetadata.builder()
                .documentId(document.getId())
                .signatureFields(signatureFields)
                .documentHash(documentHash)
                .signingStatus("PENDING_SIGNATURE")
                .expiresAt(LocalDateTime.now().plusDays(30)) // 30 days expiry
                .build();
    }

    /**
     * Create signature fields based on request
     */
    private List<SignatureField> createSignatureFields(IntegratedDocumentRequest request) {
        List<SignatureField> fields = new ArrayList<>();

        // Add party A signature field
        if (request.getPartyA() != null) {
            fields.add(SignatureField.builder()
                    .fieldName("party_a_signature")
                    .fieldLabel("Signature of " + request.getPartyA())
                    .fieldType("SIGNATURE")
                    .required(true)
                    .position("bottom_left")
                    .build());
        }

        // Add party B signature field
        if (request.getPartyB() != null) {
            fields.add(SignatureField.builder()
                    .fieldName("party_b_signature")
                    .fieldLabel("Signature of " + request.getPartyB())
                    .fieldType("SIGNATURE")
                    .required(true)
                    .position("bottom_right")
                    .build());
        }

        // Add witness signature field if needed
        fields.add(SignatureField.builder()
                .fieldName("witness_signature")
                .fieldLabel("Witness Signature")
                .fieldType("SIGNATURE")
                .required(false)
                .position("bottom_center")
                .build());

        return fields;
    }

    /**
     * Generate document hash for integrity verification
     */
    private String generateDocumentHash(LegalDocument document) {
        String contentToHash = document.getTitle() + document.getContent() +
                document.getType() + document.getPartyA() +
                document.getPartyB() + document.getTerms() +
                document.getCreatedAt().toString();

        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(contentToHash.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1)
                    hexString.append('0');
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (Exception e) {
            log.error("Error generating document hash", e);
            return UUID.randomUUID().toString(); // Fallback
        }
    }

    /**
     * Create integrated response
     */
    private IntegratedDocumentResponse createIntegratedResponse(
            LegalDocument document,
            DocumentAnalysisResult analysisResult,
            SigningMetadata signingMetadata) {

        return IntegratedDocumentResponse.builder()
                .documentId(document.getId())
                .title(document.getTitle())
                .content(document.getContent())
                .type(document.getType())
                .status("WORKFLOW_COMPLETED")
                .analysisResult(analysisResult)
                .signingMetadata(signingMetadata)
                .documentQuality(document.getDocumentQuality())
                .riskLevel(document.getRiskLevel())
                .createdAt(document.getCreatedAt())
                .message("Document workflow completed successfully")
                .build();
    }

    /**
     * Execute document signing workflow
     */
    @Transactional
    public SignatureVerificationResult executeSigningWorkflow(IntegratedSignatureRequest request, User currentUser) {
        log.info("Executing signing workflow for document: {}", request.getDocumentId());

        try {
            // Get the document
            DocumentDto documentDto = documentService.getDocument(request.getDocumentId(), currentUser);
            if (documentDto == null) {
                throw new RuntimeException("Document not found: " + request.getDocumentId());
            }
            
            // Get the actual entity for updates
            LegalDocument document = documentRepository.findById(request.getDocumentId())
                    .orElseThrow(() -> new RuntimeException("Document entity not found: " + request.getDocumentId()));

            // Verify document integrity
            if (!verifyDocumentIntegrity(document)) {
                throw new RuntimeException("Document integrity verification failed");
            }

            // Create signed agreement
            SignedAgreement signedAgreement = signatureService.createSignedAgreement(
                    request.getDocumentId(),
                    request.getSignerName(),
                    request.getSignerEmail(),
                    request.getSignatureData());

            // Update document signing status
            document.markAsSigned(
                    signedAgreement.getId(),
                    request.getSignerName(),
                    request.getSignerEmail());
            document.setSigningStatus("SIGNED");
            documentRepository.save(document);

            // Verify signature integrity
            return signatureService.verifySignatureIntegrity(signedAgreement.getId());

        } catch (Exception e) {
            log.error("Error in signing workflow: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to execute signing workflow: " + e.getMessage());
        }
    }

    /**
     * Verify document integrity using hash
     */
    private boolean verifyDocumentIntegrity(LegalDocument document) {
        if (document.getDocumentHash() == null) {
            return false;
        }

        String currentHash = generateDocumentHash(document);
        return currentHash.equals(document.getDocumentHash());
    }

    /**
     * Get document insights and analytics
     */
    public DocumentInsights getDocumentInsights(String documentId, User currentUser) {
        log.info("Getting document insights for: {}", documentId);

        DocumentDto documentDto = documentService.getDocument(documentId, currentUser);
        if (documentDto == null) {
            throw new RuntimeException("Document not found: " + documentId);
        }
        
        // Get the actual entity for insights
        LegalDocument document = documentRepository.findById(documentId)
                .orElseThrow(() -> new RuntimeException("Document entity not found: " + documentId));

        // Get analysis metadata
        List<DocumentAnalysisMetadata> analysisHistory = analysisMetadataRepository
                .findByDocumentIdOrderByCreatedAtDesc(documentId);

        // Get signing history
        List<SignedAgreement> signingHistory = signedAgreementRepository
                .findByDocumentIdOrderByCreatedAtDesc(documentId);

        // Calculate analytics
        Map<String, Object> analytics = calculateDocumentAnalytics(document, analysisHistory, signingHistory);

        return DocumentInsights.builder()
                .documentId(documentId)
                .documentTitle(document.getTitle())
                .documentType(document.getType())
                .analysisHistory(analysisHistory.stream()
                        .map(this::convertToAnalysisActivity)
                        .collect(Collectors.toList()))
                .signingHistory(signingHistory.stream()
                        .map(this::convertToSigningActivity)
                        .collect(Collectors.toList()))
                .analytics(analytics)
                .lastUpdated(document.getUpdatedAt())
                .build();
    }

    /**
     * Calculate document analytics
     */
    private Map<String, Object> calculateDocumentAnalytics(
            LegalDocument document,
            List<DocumentAnalysisMetadata> analysisHistory,
            List<SignedAgreement> signingHistory) {

        Map<String, Object> analytics = new HashMap<>();

        // Analysis analytics
        analytics.put("total_analyses", analysisHistory.size());
        analytics.put("successful_analyses", analysisHistory.stream()
                .filter(a -> "COMPLETED".equals(a.getAnalysisStatus()))
                .count());
        analytics.put("average_confidence_score", analysisHistory.stream()
                .filter(a -> a.getConfidenceScore() != null)
                .mapToDouble(DocumentAnalysisMetadata::getConfidenceScore)
                .average()
                .orElse(0.0));

        // Signing analytics
        analytics.put("total_signatures", signingHistory.size());
        analytics.put("signing_status", document.getSigningStatus());
        analytics.put("last_signed_at", document.getLastSignedAt());

        // Document health
        analytics.put("document_quality", document.getDocumentQuality());
        analytics.put("risk_level", document.getRiskLevel());
        analytics.put("version_count", document.getVersion());
        analytics.put("days_since_creation",
                java.time.Duration.between(document.getCreatedAt(), LocalDateTime.now()).toDays());

        return analytics;
    }

    /**
     * Convert analysis metadata to activity
     */
    private DocumentActivity convertToAnalysisActivity(DocumentAnalysisMetadata metadata) {
        return DocumentActivity.builder()
                .activityType("ANALYSIS")
                .timestamp(metadata.getCreatedAt())
                .description("Document analyzed using " + metadata.getModelName())
                .status(metadata.getAnalysisStatus())
                .details(Map.of(
                        "analysis_type", metadata.getAnalysisType(),
                        "confidence_score", metadata.getConfidenceScore(),
                        "duration_seconds", metadata.getAnalysisDurationInSeconds()))
                .build();
    }

    /**
     * Convert signed agreement to signing activity
     */
    private DocumentActivity convertToSigningActivity(SignedAgreement agreement) {
        return DocumentActivity.builder()
                .activityType("SIGNING")
                .timestamp(agreement.getCreatedAt())
                .description("Document signed by " + agreement.getSignerName())
                .status("COMPLETED")
                .details(Map.of(
                        "signer_email", agreement.getSignerEmail(),
                        "signature_hash", agreement.getSignatureHash(),
                        "verification_status", agreement.getVerificationStatus()))
                .build();
    }

    /**
     * Search documents with advanced criteria
     */
    public List<IntegratedDocumentResponse> searchDocuments(DocumentSearchRequest request, User currentUser) {
        log.info("Searching documents with criteria: {}", request);

        // This would implement advanced search logic
        // For now, return user's documents
        List<DocumentDto> userDocumentDtos = documentService.getUserDocuments(currentUser);
        
        // Convert DTOs to entities for processing
        List<LegalDocument> userDocuments = userDocumentDtos.stream()
                .map(dto -> documentRepository.findById(dto.getId())
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        return userDocuments.stream()
                .map(document -> {
                    // Get latest analysis and signing info
                    DocumentAnalysisMetadata latestAnalysis = analysisMetadataRepository
                            .findFirstByDocumentIdOrderByCreatedAtDesc(document.getId())
                            .orElse(null);

                    SignedAgreement latestSignature = signedAgreementRepository
                            .findFirstByDocumentIdOrderByCreatedAtDesc(document.getId())
                            .orElse(null);

                    // Convert to response
                    return IntegratedDocumentResponse.builder()
                            .documentId(document.getId())
                            .title(document.getTitle())
                            .type(document.getType())
                            .status(document.getSigningStatus())
                            .documentQuality(document.getDocumentQuality())
                            .riskLevel(document.getRiskLevel())
                            .createdAt(document.getCreatedAt())
                            .build();
                })
                .collect(Collectors.toList());
    }
}
