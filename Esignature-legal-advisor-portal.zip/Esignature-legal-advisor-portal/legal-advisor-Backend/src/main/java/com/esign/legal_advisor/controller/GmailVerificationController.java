package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.MessageResponse;
import com.esign.legal_advisor.service.GmailVerificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth/gmail-verification")
@CrossOrigin(origins = "*", maxAge = 3600)
public class GmailVerificationController {

    private static final Logger logger = LoggerFactory.getLogger(GmailVerificationController.class);

    @Autowired
    private GmailVerificationService gmailVerificationService;

    @GetMapping("/verify-email/{email}")
    public ResponseEntity<?> verifyGmailEmail(@PathVariable String email) {
        try {
            logger.info("Verifying Gmail email: {}", email);

            boolean isValid = gmailVerificationService.isValidGmailEmail(email);

            if (isValid) {
                return ResponseEntity.ok(new MessageResponse("Gmail email is valid: " + email));
            } else {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Invalid Gmail email format: " + email));
            }
        } catch (Exception e) {
            logger.error("Error verifying Gmail email: {}", email, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error verifying Gmail email: " + e.getMessage()));
        }
    }

    @GetMapping("/verify-google-id/{googleId}")
    public ResponseEntity<?> verifyGoogleId(@PathVariable String googleId) {
        try {
            logger.info("Verifying Google ID: {}", googleId);

            boolean isValid = gmailVerificationService.isValidGoogleId(googleId);

            if (isValid) {
                return ResponseEntity.ok(new MessageResponse("Google ID is valid: " + googleId));
            } else {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Invalid Google ID format: " + googleId));
            }
        } catch (Exception e) {
            logger.error("Error verifying Google ID: {}", googleId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error verifying Google ID: " + e.getMessage()));
        }
    }

    @PostMapping("/validate-oauth-data")
    public ResponseEntity<?> validateOAuthData(@RequestParam String email,
            @RequestParam String googleId,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String picture) {
        try {
            logger.info("Validating Gmail OAuth data for email: {}", email);

            GmailVerificationService.GmailVerificationResult result = gmailVerificationService
                    .validateGmailOAuthData(email, googleId, name, picture);

            if (result.isValid()) {
                return ResponseEntity.ok(new MessageResponse("Gmail OAuth data is valid"));
            } else {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("Gmail OAuth data validation failed: " + result.getErrorMessage()));
            }
        } catch (Exception e) {
            logger.error("Error validating Gmail OAuth data", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error validating Gmail OAuth data: " + e.getMessage()));
        }
    }

    @GetMapping("/test-email/{email}")
    public ResponseEntity<?> testGmailEmail(@PathVariable String email) {
        try {
            logger.info("Testing Gmail email validation: {}", email);

            boolean isValid = gmailVerificationService.isValidGmailEmail(email);
            boolean isGmailDomain = email != null && email.toLowerCase().endsWith("@gmail.com");

            String response = String.format(
                    "Email: %s\n" +
                            "Valid Gmail format: %s\n" +
                            "Is Gmail domain: %s\n" +
                            "Length: %d",
                    email,
                    isValid,
                    isGmailDomain,
                    email != null ? email.length() : 0);

            return ResponseEntity.ok(new MessageResponse(response));
        } catch (Exception e) {
            logger.error("Error testing Gmail email: {}", email, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new MessageResponse("Error testing Gmail email: " + e.getMessage()));
        }
    }
}




