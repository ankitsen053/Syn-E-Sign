package com.esign.legal_advisor.entites;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DBRef;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "signed_agreements")
public class SignedAgreement {

    @Id
    private String id;

    private String agreementTitle;
    private String agreementContent;
    private String agreementType;
    private String partyA;
    private String partyB;
    private String terms;

    // Multi-party signature data
    private List<SignatureData> signatures = new ArrayList<>();
    private String signatureImageBase64; // Legacy field for backward compatibility
    private String signatureData; // Legacy field for backward compatibility
    private LocalDateTime signedAt;
    private String signerName; // Legacy field for backward compatibility
    private String signerEmail; // Legacy field for backward compatibility
    private String signerIpAddress; // Legacy field for backward compatibility

    // Multi-party workflow
    private String workflowStatus; // DRAFT, PENDING_SIGNATURES, PARTIALLY_SIGNED, FULLY_SIGNED, COMPLETED,
                                   // CANCELLED
    private List<String> requiredSigners = new ArrayList<>(); // List of signer emails
    private List<String> completedSigners = new ArrayList<>(); // List of completed signer emails
    private String initiatorId; // User who initiated the agreement
    private LocalDateTime expiresAt; // Agreement expiration date
    private String signingInstructions; // Instructions for signers

    // Document metadata
    private String documentHash;
    private String signatureHash;
    private String status; // DRAFT, SIGNED, COMPLETED, CANCELLED
    private String version;

    @DBRef(lazy = true)
    private User signer;

    private String signerId; // For easier querying

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Constructors
    public SignedAgreement() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.status = "DRAFT";
        this.version = "1.0";
    }

    public SignedAgreement(String agreementTitle, String agreementContent, String agreementType,
            String partyA, String partyB, String terms, User signer) {
        this();
        this.agreementTitle = agreementTitle;
        this.agreementContent = agreementContent;
        this.agreementType = agreementType;
        this.partyA = partyA;
        this.partyB = partyB;
        this.terms = terms;
        this.signer = signer;
        this.signerId = signer != null ? signer.getId() : null;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAgreementTitle() {
        return agreementTitle;
    }

    public void setAgreementTitle(String agreementTitle) {
        this.agreementTitle = agreementTitle;
    }

    public String getAgreementContent() {
        return agreementContent;
    }

    public void setAgreementContent(String agreementContent) {
        this.agreementContent = agreementContent;
    }

    public String getAgreementType() {
        return agreementType;
    }

    public void setAgreementType(String agreementType) {
        this.agreementType = agreementType;
    }

    public String getPartyA() {
        return partyA;
    }

    public void setPartyA(String partyA) {
        this.partyA = partyA;
    }

    public String getPartyB() {
        return partyB;
    }

    public void setPartyB(String partyB) {
        this.partyB = partyB;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public String getSignatureImageBase64() {
        return signatureImageBase64;
    }

    public void setSignatureImageBase64(String signatureImageBase64) {
        this.signatureImageBase64 = signatureImageBase64;
    }

    public String getSignatureData() {
        return signatureData;
    }

    public void setSignatureData(String signatureData) {
        this.signatureData = signatureData;
    }

    public LocalDateTime getSignedAt() {
        return signedAt;
    }

    public void setSignedAt(LocalDateTime signedAt) {
        this.signedAt = signedAt;
    }

    public String getSignerName() {
        return signerName;
    }

    public void setSignerName(String signerName) {
        this.signerName = signerName;
    }

    public String getSignerEmail() {
        return signerEmail;
    }

    public void setSignerEmail(String signerEmail) {
        this.signerEmail = signerEmail;
    }

    public String getSignerIpAddress() {
        return signerIpAddress;
    }

    public void setSignerIpAddress(String signerIpAddress) {
        this.signerIpAddress = signerIpAddress;
    }

    public String getDocumentHash() {
        return documentHash;
    }

    public void setDocumentHash(String documentHash) {
        this.documentHash = documentHash;
    }

    public String getSignatureHash() {
        return signatureHash;
    }

    public void setSignatureHash(String signatureHash) {
        this.signatureHash = signatureHash;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public User getSigner() {
        return signer;
    }

    public void setSigner(User signer) {
        this.signer = signer;
        this.signerId = signer != null ? signer.getId() : null;
    }

    public String getSignerId() {
        return signerId;
    }

    public void setSignerId(String signerId) {
        this.signerId = signerId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    // Helper methods
    public void markAsSigned() {
        this.status = "SIGNED";
        this.signedAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public void markAsCompleted() {
        this.status = "COMPLETED";
        this.updatedAt = LocalDateTime.now();
    }

    public boolean isSigned() {
        return "SIGNED".equals(this.status) || "COMPLETED".equals(this.status);
    }

    public boolean isDraft() {
        return "DRAFT".equals(this.status);
    }

    // Additional methods for workflow integration
    public String getVerificationStatus() {
        return this.status;
    }

    public String getDocumentId() {
        // This would typically be a reference to the original document
        // For now, return a placeholder
        return "DOC_" + this.id;
    }

    // Multi-party signature getters and setters
    public List<SignatureData> getSignatures() {
        return signatures;
    }

    public void setSignatures(List<SignatureData> signatures) {
        this.signatures = signatures;
    }

    public String getWorkflowStatus() {
        return workflowStatus;
    }

    public void setWorkflowStatus(String workflowStatus) {
        this.workflowStatus = workflowStatus;
    }

    public List<String> getRequiredSigners() {
        return requiredSigners;
    }

    public void setRequiredSigners(List<String> requiredSigners) {
        this.requiredSigners = requiredSigners;
    }

    public List<String> getCompletedSigners() {
        return completedSigners;
    }

    public void setCompletedSigners(List<String> completedSigners) {
        this.completedSigners = completedSigners;
    }

    public String getInitiatorId() {
        return initiatorId;
    }

    public void setInitiatorId(String initiatorId) {
        this.initiatorId = initiatorId;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(LocalDateTime expiresAt) {
        this.expiresAt = expiresAt;
    }

    public String getSigningInstructions() {
        return signingInstructions;
    }

    public void setSigningInstructions(String signingInstructions) {
        this.signingInstructions = signingInstructions;
    }

    // Helper methods for multi-party workflow
    public void addSignature(SignatureData signature) {
        if (this.signatures == null) {
            this.signatures = new ArrayList<>();
        }
        this.signatures.add(signature);

        if (!this.completedSigners.contains(signature.getSignerEmail())) {
            this.completedSigners.add(signature.getSignerEmail());
        }

        updateWorkflowStatus();
    }

    public void updateWorkflowStatus() {
        if (this.requiredSigners == null || this.requiredSigners.isEmpty()) {
            this.workflowStatus = "COMPLETED";
            return;
        }

        if (this.completedSigners == null) {
            this.completedSigners = new ArrayList<>();
        }

        if (this.completedSigners.size() == 0) {
            this.workflowStatus = "PENDING_SIGNATURES";
        } else if (this.completedSigners.size() < this.requiredSigners.size()) {
            this.workflowStatus = "PARTIALLY_SIGNED";
        } else {
            this.workflowStatus = "FULLY_SIGNED";
        }
    }

    public boolean isFullySigned() {
        return "FULLY_SIGNED".equals(this.workflowStatus) || "COMPLETED".equals(this.workflowStatus);
    }

    public boolean isExpired() {
        return this.expiresAt != null && LocalDateTime.now().isAfter(this.expiresAt);
    }

    public int getRemainingSignatures() {
        if (this.requiredSigners == null)
            return 0;
        if (this.completedSigners == null)
            return this.requiredSigners.size();
        return this.requiredSigners.size() - this.completedSigners.size();
    }
}
