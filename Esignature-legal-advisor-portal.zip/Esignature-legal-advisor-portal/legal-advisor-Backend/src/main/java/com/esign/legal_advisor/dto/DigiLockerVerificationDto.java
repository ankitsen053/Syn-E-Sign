package com.esign.legal_advisor.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class DigiLockerVerificationDto {

    @NotBlank(message = "DigiLocker ID is required")
    @Size(min = 32, max = 36, message = "DigiLocker ID must be 32-36 characters (with or without hyphens)")
    @Pattern(regexp = "^[a-fA-F0-9]{8}-?[a-fA-F0-9]{4}-?[a-fA-F0-9]{4}-?[a-fA-F0-9]{4}-?[a-fA-F0-9]{12}$", 
             message = "Invalid DigiLocker ID format. Expected: 32 hexadecimal characters with optional hyphens")
    private String digiLockerId;

    private boolean fetchAadhaar = true;
    private boolean fetchPan = true;
    private boolean fetchDrivingLicense = false;
    private boolean fetchPassport = false;

    private String consent = "Y";

    private String consentText = "I hereby give my consent to fetch my documents from DigiLocker for verification purposes";

    public DigiLockerVerificationDto() {}

    public DigiLockerVerificationDto(String digiLockerId) {
        this.digiLockerId = digiLockerId;
    }

    // Getters and Setters
    public String getDigiLockerId() {
        return digiLockerId;
    }

    public void setDigiLockerId(String digiLockerId) {
        this.digiLockerId = digiLockerId;
    }

    public boolean isFetchAadhaar() {
        return fetchAadhaar;
    }

    public void setFetchAadhaar(boolean fetchAadhaar) {
        this.fetchAadhaar = fetchAadhaar;
    }

    public boolean isFetchPan() {
        return fetchPan;
    }

    public void setFetchPan(boolean fetchPan) {
        this.fetchPan = fetchPan;
    }

    public boolean isFetchDrivingLicense() {
        return fetchDrivingLicense;
    }

    public void setFetchDrivingLicense(boolean fetchDrivingLicense) {
        this.fetchDrivingLicense = fetchDrivingLicense;
    }

    public boolean isFetchPassport() {
        return fetchPassport;
    }

    public void setFetchPassport(boolean fetchPassport) {
        this.fetchPassport = fetchPassport;
    }

    public String getConsent() {
        return consent;
    }

    public void setConsent(String consent) {
        this.consent = consent;
    }

    public String getConsentText() {
        return consentText;
    }

    public void setConsentText(String consentText) {
        this.consentText = consentText;
    }

    /**
     * Mask DigiLocker ID for logging purposes
     */
    public String getMaskedDigiLockerId() {
        if (digiLockerId == null || digiLockerId.length() < 8) {
            return "****";
        }
        return digiLockerId.substring(0, 8) + "****" + digiLockerId.substring(digiLockerId.length() - 4);
    }

    @Override
    public String toString() {
        return "DigiLockerVerificationDto{" +
                "digiLockerId='" + getMaskedDigiLockerId() + '\'' +
                ", fetchAadhaar=" + fetchAadhaar +
                ", fetchPan=" + fetchPan +
                ", fetchDrivingLicense=" + fetchDrivingLicense +
                ", fetchPassport=" + fetchPassport +
                ", consent='" + consent + '\'' +
                '}';
    }
}
