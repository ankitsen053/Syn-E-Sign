package com.esign.legal_advisor.security;

import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Encoders;
import io.jsonwebtoken.security.Keys;

public class KeyGenerator {
	 public static void main(String[] args) {
	        // Generate a secure key for HS256 algorithm
	        byte[] keyBytes = Keys.secretKeyFor(SignatureAlgorithm.HS256).getEncoded();
	        // Encode the key to a Base64 string that is safe for URLs
	        String base64UrlEncodedKey = Encoders.BASE64.encode(keyBytes);
	        System.out.println("Generated Base64-encoded Secret Key:");
	        System.out.println(base64UrlEncodedKey);
}
	 }