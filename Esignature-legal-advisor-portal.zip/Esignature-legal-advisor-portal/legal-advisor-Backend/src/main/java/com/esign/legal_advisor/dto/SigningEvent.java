package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;

/**
 * DTO for signing event in audit trail
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SigningEvent {
    
    private String eventType; // DOCUMENT_OPENED, SIGNATURE_STARTED, SIGNATURE_COMPLETED, DOCUMENT_DOWNLOADED
    private String eventDescription;
    private LocalDateTime eventTime;
    private String performedBy;
    private String ipAddress;
    private String deviceInfo;
    private boolean successful;
    private String errorMessage;
}
