package com.esign.legal_advisor.service;

import com.esign.legal_advisor.entites.LegalDocument;
import com.esign.legal_advisor.entites.User;
import com.esign.legal_advisor.repository.DocumentRepository;
import com.esign.legal_advisor.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DashboardService {
    
    private static final Logger logger = LoggerFactory.getLogger(DashboardService.class);
    
    @Autowired
    private DocumentRepository documentRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    public Map<String, Object> getDashboardStats(String userId) {
        try {
            Map<String, Object> dashboard = new HashMap<>();
            
            // Get user
            Optional<User> userOpt = userRepository.findById(userId);
            if (userOpt.isEmpty()) {
                throw new RuntimeException("User not found");
            }
            
            User user = userOpt.get();
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime lastWeek = now.minus(7, ChronoUnit.DAYS);
            LocalDateTime lastMonth = now.minus(30, ChronoUnit.DAYS);
            
            // Documents Generated - with error handling
            long documentsGenerated = 0;
            long documentsGeneratedLastWeek = 0;
            long documentsGeneratedLastMonth = 0;
            try {
                documentsGenerated = documentRepository.countByUserIdAndType(userId, "GENERATED");
                documentsGeneratedLastWeek = documentRepository.countByUserIdAndTypeAndCreatedAtAfter(userId, "GENERATED", lastWeek);
                documentsGeneratedLastMonth = documentRepository.countByUserIdAndTypeAndCreatedAtAfter(userId, "GENERATED", lastMonth);
            } catch (Exception e) {
                logger.warn("Error counting generated documents for user: {}", userId, e);
            }
            
            // Documents Analyzed - with error handling
            long documentsAnalyzed = 0;
            long documentsAnalyzedLastWeek = 0;
            long documentsAnalyzedLastMonth = 0;
            try {
                documentsAnalyzed = documentRepository.countByUserIdAndType(userId, "ANALYZED");
                documentsAnalyzedLastWeek = documentRepository.countByUserIdAndTypeAndCreatedAtAfter(userId, "ANALYZED", lastWeek);
                documentsAnalyzedLastMonth = documentRepository.countByUserIdAndTypeAndCreatedAtAfter(userId, "ANALYZED", lastMonth);
            } catch (Exception e) {
                logger.warn("Error counting analyzed documents for user: {}", userId, e);
            }
            
            // Active Sessions (simplified - just return 1 for now)
            long activeSessions = 1;
            long activeSessionsLastWeek = 1;
            
            // Verification Status
            boolean isVerified = user.isEmailVerified();
            String verificationStatus = isVerified ? "Verified" : "Pending";
            String verificationSubStatus = isVerified ? "Active" : "Inactive";
            
            // Calculate percentage changes
            double generatedChange = calculatePercentageChange(documentsGeneratedLastMonth, documentsGeneratedLastWeek);
            double analyzedChange = calculatePercentageChange(documentsAnalyzedLastMonth, documentsAnalyzedLastWeek);
            double sessionsChange = 0.0; // No change for now
            
            // Build dashboard data
            Map<String, Object> documentsGeneratedCard = new HashMap<>();
            documentsGeneratedCard.put("title", "Documents Generated");
            documentsGeneratedCard.put("value", documentsGenerated);
            documentsGeneratedCard.put("change", String.format("%+.0f%%", generatedChange));
            documentsGeneratedCard.put("changeType", generatedChange >= 0 ? "positive" : "negative");
            documentsGeneratedCard.put("icon", "document");
            documentsGeneratedCard.put("color", "blue");
            
            Map<String, Object> documentsAnalyzedCard = new HashMap<>();
            documentsAnalyzedCard.put("title", "Documents Analyzed");
            documentsAnalyzedCard.put("value", documentsAnalyzed);
            documentsAnalyzedCard.put("change", String.format("%+.0f%%", analyzedChange));
            documentsAnalyzedCard.put("changeType", analyzedChange >= 0 ? "positive" : "negative");
            documentsAnalyzedCard.put("icon", "analyze");
            documentsAnalyzedCard.put("color", "green");
            
            Map<String, Object> activeSessionsCard = new HashMap<>();
            activeSessionsCard.put("title", "Active Sessions");
            activeSessionsCard.put("value", activeSessions);
            activeSessionsCard.put("change", String.format("%+.0f", sessionsChange));
            activeSessionsCard.put("changeType", sessionsChange >= 0 ? "positive" : "negative");
            activeSessionsCard.put("icon", "session");
            activeSessionsCard.put("color", "orange");
            
            Map<String, Object> verificationStatusCard = new HashMap<>();
            verificationStatusCard.put("title", "Verification Status");
            verificationStatusCard.put("status", verificationStatus);
            verificationStatusCard.put("subStatus", verificationSubStatus);
            verificationStatusCard.put("changeType", isVerified ? "positive" : "negative");
            verificationStatusCard.put("icon", "verified");
            verificationStatusCard.put("color", isVerified ? "green" : "red");
            
            dashboard.put("documentsGenerated", documentsGeneratedCard);
            dashboard.put("documentsAnalyzed", documentsAnalyzedCard);
            dashboard.put("activeSessions", activeSessionsCard);
            dashboard.put("verificationStatus", verificationStatusCard);
            
            // Add summary stats
            Map<String, Object> summary = new HashMap<>();
            summary.put("totalDocuments", documentsGenerated + documentsAnalyzed);
            summary.put("totalGenerated", documentsGenerated);
            summary.put("totalAnalyzed", documentsAnalyzed);
            summary.put("isVerified", isVerified);
            summary.put("lastUpdated", System.currentTimeMillis());
            
            dashboard.put("summary", summary);
            
            logger.info("Dashboard stats generated successfully for user: {}", userId);
            return dashboard;
            
        } catch (Exception e) {
            logger.error("Error generating dashboard stats for user: {}", userId, e);
            throw new RuntimeException("Failed to generate dashboard stats: " + e.getMessage());
        }
    }
    
    private Map<String, Object> getProgressOverview(String userId) {
        Map<String, Object> progress = new HashMap<>();
        
        try {
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime startOfMonth = now.withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
            
            // Monthly goals and progress
            long monthlyGeneratedGoal = 20; // Example goal
            long monthlyAnalyzedGoal = 15; // Example goal
            
            long monthlyGenerated = documentRepository.countByUserIdAndTypeAndCreatedAtAfter(userId, "GENERATED", startOfMonth);
            long monthlyAnalyzed = documentRepository.countByUserIdAndTypeAndCreatedAtAfter(userId, "ANALYZED", startOfMonth);
            
            double generatedProgress = (double) monthlyGenerated / monthlyGeneratedGoal * 100;
            double analyzedProgress = (double) monthlyAnalyzed / monthlyAnalyzedGoal * 100;
            
            progress.put("monthlyGeneratedGoal", monthlyGeneratedGoal);
            progress.put("monthlyGenerated", monthlyGenerated);
            progress.put("generatedProgress", Math.min(generatedProgress, 100));
            
            progress.put("monthlyAnalyzedGoal", monthlyAnalyzedGoal);
            progress.put("monthlyAnalyzed", monthlyAnalyzed);
            progress.put("analyzedProgress", Math.min(analyzedProgress, 100));
            
            // Weekly activity trend
            List<Map<String, Object>> weeklyTrend = getWeeklyActivityTrend(userId);
            progress.put("weeklyTrend", weeklyTrend);
            
        } catch (Exception e) {
            logger.error("Error getting progress overview for user: {}", userId, e);
        }
        
        return progress;
    }
    
    private List<Map<String, Object>> getRecentActivities(String userId) {
        List<Map<String, Object>> activities = new ArrayList<>();
        
        try {
            // Get recent documents
            List<LegalDocument> recentDocuments = documentRepository.findTop10ByUserIdOrderByCreatedAtDesc(userId);
            
            for (LegalDocument doc : recentDocuments) {
                Map<String, Object> activity = new HashMap<>();
                activity.put("id", doc.getId());
                activity.put("type", doc.getType());
                activity.put("title", doc.getTitle());
                activity.put("description", getActivityDescription(doc));
                activity.put("timestamp", doc.getCreatedAt());
                activity.put("icon", getActivityIcon(doc.getType()));
                activity.put("color", getActivityColor(doc.getType()));
                
                activities.add(activity);
            }
            
            // Add login activities (if you have a login tracking system)
            Map<String, Object> loginActivity = new HashMap<>();
            loginActivity.put("id", "login-" + System.currentTimeMillis());
            loginActivity.put("type", "LOGIN");
            loginActivity.put("title", "User Login");
            loginActivity.put("description", "Successfully logged into the system");
            loginActivity.put("timestamp", LocalDateTime.now());
            loginActivity.put("icon", "login");
            loginActivity.put("color", "blue");
            
            activities.add(0, loginActivity);
            
        } catch (Exception e) {
            logger.error("Error getting recent activities for user: {}", userId, e);
        }
        
        return activities;
    }
    
    private Map<String, Object> getUserPreferences(User user) {
        Map<String, Object> preferences = new HashMap<>();
        
        try {
            // Get user's preferred document types
            List<String> preferredTypes = documentRepository.findTopDocumentTypesByUserId(user.getId());
            preferences.put("preferredDocumentTypes", preferredTypes);
            
            // Get user's activity patterns
            Map<String, Object> activityPatterns = getActivityPatterns(user.getId());
            preferences.put("activityPatterns", activityPatterns);
            
            // Get user's usage statistics
            Map<String, Object> usageStats = getUsageStatistics(user.getId());
            preferences.put("usageStats", usageStats);
            
        } catch (Exception e) {
            logger.error("Error getting user preferences for user: {}", user.getId(), e);
        }
        
        return preferences;
    }
    
    private long getActiveSessions(String userId) {
        // This would typically come from a session tracking system
        // For now, we'll simulate based on recent document activity
        LocalDateTime lastHour = LocalDateTime.now().minus(1, ChronoUnit.HOURS);
        return documentRepository.countByUserIdAndCreatedAtAfter(userId, lastHour);
    }
    
    private long getActiveSessionsLastWeek(String userId) {
        LocalDateTime lastWeek = LocalDateTime.now().minus(7, ChronoUnit.DAYS);
        LocalDateTime twoWeeksAgo = LocalDateTime.now().minus(14, ChronoUnit.DAYS);
        return documentRepository.countByUserIdAndCreatedAtBetween(userId, twoWeeksAgo, lastWeek);
    }
    
    private double calculatePercentageChange(long oldValue, long newValue) {
        if (oldValue == 0) {
            return newValue > 0 ? 100.0 : 0.0;
        }
        return ((double)(newValue - oldValue) / oldValue) * 100;
    }
    
    private List<Map<String, Object>> getWeeklyActivityTrend(String userId) {
        List<Map<String, Object>> trend = new ArrayList<>();
        
        try {
            LocalDateTime now = LocalDateTime.now();
            
            for (int i = 6; i >= 0; i--) {
                LocalDateTime day = now.minus(i, ChronoUnit.DAYS);
                LocalDateTime nextDay = day.plus(1, ChronoUnit.DAYS);
                
                long generated = documentRepository.countByUserIdAndTypeAndCreatedAtBetween(userId, "GENERATED", day, nextDay);
                long analyzed = documentRepository.countByUserIdAndTypeAndCreatedAtBetween(userId, "ANALYZED", day, nextDay);
                
                Map<String, Object> dayData = new HashMap<>();
                dayData.put("date", day.toLocalDate().toString());
                dayData.put("generated", generated);
                dayData.put("analyzed", analyzed);
                dayData.put("total", generated + analyzed);
                
                trend.add(dayData);
            }
            
        } catch (Exception e) {
            logger.error("Error getting weekly activity trend for user: {}", userId, e);
        }
        
        return trend;
    }
    
    private String getActivityDescription(LegalDocument doc) {
        switch (doc.getType()) {
            case "GENERATED":
                return "Generated new legal document: " + doc.getTitle();
            case "ANALYZED":
                return "Analyzed document: " + doc.getTitle();
            default:
                return "Document operation: " + doc.getTitle();
        }
    }
    
    private String getActivityIcon(String type) {
        switch (type) {
            case "GENERATED":
                return "document";
            case "ANALYZED":
                return "analyze";
            case "LOGIN":
                return "login";
            default:
                return "activity";
        }
    }
    
    private String getActivityColor(String type) {
        switch (type) {
            case "GENERATED":
                return "blue";
            case "ANALYZED":
                return "green";
            case "LOGIN":
                return "purple";
            default:
                return "gray";
        }
    }
    
    private Map<String, Object> getActivityPatterns(String userId) {
        Map<String, Object> patterns = new HashMap<>();
        
        try {
            // Get most active hours
            List<Integer> activeHours = documentRepository.findMostActiveHoursByUserId(userId);
            patterns.put("mostActiveHours", activeHours);
            
            // Get most active days
            List<String> activeDays = documentRepository.findMostActiveDaysByUserId(userId);
            patterns.put("mostActiveDays", activeDays);
            
        } catch (Exception e) {
            logger.error("Error getting activity patterns for user: {}", userId, e);
        }
        
        return patterns;
    }
    
    private Map<String, Object> getUsageStatistics(String userId) {
        Map<String, Object> stats = new HashMap<>();
        
        try {
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime lastMonth = now.minus(30, ChronoUnit.DAYS);
            
            long totalDocuments = documentRepository.countByUserId(userId);
            long monthlyDocuments = documentRepository.countByUserIdAndCreatedAtAfter(userId, lastMonth);
            
            stats.put("totalDocuments", totalDocuments);
            stats.put("monthlyDocuments", monthlyDocuments);
            stats.put("averagePerMonth", monthlyDocuments);
            
        } catch (Exception e) {
            logger.error("Error getting usage statistics for user: {}", userId, e);
        }
        
        return stats;
    }
}
