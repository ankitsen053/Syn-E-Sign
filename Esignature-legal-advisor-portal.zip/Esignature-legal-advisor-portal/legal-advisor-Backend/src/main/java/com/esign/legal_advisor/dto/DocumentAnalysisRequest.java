package com.esign.legal_advisor.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocumentAnalysisRequest {
    
    private String documentType; // "PAN" or "AADHAAR"
    private String extractedText;
    private String customerMobile;
    private String documentBase64; // Optional: base64 encoded document for additional processing
    private Double confidenceThreshold = 0.8; // Minimum confidence for verification
}
