package com.esign.legal_advisor.controller;

import com.esign.legal_advisor.dto.DocumentAnalysisRequest;
import com.esign.legal_advisor.dto.DocumentAnalysisResponse;
import com.esign.legal_advisor.service.DocumentTextExtractionService;
import com.esign.legal_advisor.service.SageMakerDocumentAnalysisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;
import java.util.Base64;

@RestController
@RequestMapping("/api/document-verification")
@RequiredArgsConstructor
@Slf4j
public class DocumentVerificationController {

    private final DocumentTextExtractionService textExtractionService;
    private final SageMakerDocumentAnalysisService sageMakerAnalysisService;

    /**
     * Analyze uploaded PAN or Aadhaar document using SageMaker AI models
     * JWT secured endpoint
     */
    @PostMapping("/analyze/{documentType}")
    @PreAuthorize("hasRole('USER') or hasRole('MERCHANT')")
    public ResponseEntity<Map<String, Object>> analyzeDocument(
            @PathVariable String documentType,
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "customerMobile", required = false) String customerMobile,
            @RequestParam(value = "confidenceThreshold", defaultValue = "0.8") Double confidenceThreshold) {

        log.info("Document analysis request - Type: {}, File: {}, Size: {}",
                documentType, file.getOriginalFilename(), file.getSize());

        Map<String, Object> response = new HashMap<>();

        try {
            // Validate document type
            if (!isValidDocumentType(documentType)) {
                response.put("success", false);
                response.put("error", "Unsupported document type. Supported types: PAN, AADHAAR");
                return ResponseEntity.badRequest().body(response);
            }

            // Validate file
            if (file.isEmpty()) {
                response.put("success", false);
                response.put("error", "No file uploaded");
                return ResponseEntity.badRequest().body(response);
            }

            // Extract text from document
            String extractedText = textExtractionService.extractTextFromDocument(file);

            if (!textExtractionService.isValidExtractedText(extractedText)) {
                response.put("success", false);
                response.put("error", "Unable to extract meaningful text from document");
                return ResponseEntity.badRequest().body(response);
            }

            // Prepare SageMaker analysis request
            DocumentAnalysisRequest analysisRequest = new DocumentAnalysisRequest();
            analysisRequest.setDocumentType(documentType.toUpperCase());
            analysisRequest.setExtractedText(extractedText);
            analysisRequest.setCustomerMobile(customerMobile);
            analysisRequest.setConfidenceThreshold(confidenceThreshold);

            // Include base64 encoded document for advanced analysis
            byte[] fileBytes = file.getBytes();
            String base64Document = Base64.getEncoder().encodeToString(fileBytes);
            analysisRequest.setDocumentBase64(base64Document);

            // Analyze using SageMaker
            DocumentAnalysisResponse analysisResponse = sageMakerAnalysisService.analyzeDocument(analysisRequest);

            // Prepare API response
            response.put("success", analysisResponse.isSuccess());
            response.put("verified", analysisResponse.isVerified());
            response.put("document_type", analysisResponse.getDocumentType());
            response.put("confidence_score", analysisResponse.getConfidenceScore());
            response.put("processed_at", analysisResponse.getProcessedAt());
            response.put("extracted_data", analysisResponse.getExtractedData());
            response.put("validation_results", analysisResponse.getValidationResults());
            response.put("model_info", Map.of(
                    "model_name",
                    analysisResponse.getModelName() != null ? analysisResponse.getModelName()
                            : "sagemaker-document-analyzer",
                    "model_version",
                    analysisResponse.getModelVersion() != null ? analysisResponse.getModelVersion() : "1.0"));

            if (!analysisResponse.isSuccess()) {
                response.put("error", analysisResponse.getErrorMessage());
                return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(response);
            }

            log.info("Document analysis completed - Type: {}, Verified: {}, Confidence: {}",
                    documentType, analysisResponse.isVerified(), analysisResponse.getConfidenceScore());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Error analyzing document", e);
            response.put("success", false);
            response.put("error", "Document analysis failed: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Batch analyze multiple documents
     * JWT secured endpoint
     */
    @PostMapping("/batch-analyze")
    @PreAuthorize("hasRole('USER') or hasRole('MERCHANT')")
    public ResponseEntity<Map<String, Object>> batchAnalyzeDocuments(
            @RequestParam("files") MultipartFile[] files,
            @RequestParam("documentTypes") String[] documentTypes,
            @RequestParam(value = "customerMobile", required = false) String customerMobile,
            @RequestParam(value = "confidenceThreshold", defaultValue = "0.8") Double confidenceThreshold) {

        log.info("Batch document analysis request - Files: {}", files.length);

        Map<String, Object> response = new HashMap<>();

        try {
            if (files.length != documentTypes.length) {
                response.put("success", false);
                response.put("error", "Number of files must match number of document types");
                return ResponseEntity.badRequest().body(response);
            }

            Map<String, Object> results = new HashMap<>();
            boolean allSuccessful = true;
            int successCount = 0;

            for (int i = 0; i < files.length; i++) {
                MultipartFile file = files[i];
                String documentType = documentTypes[i];

                try {
                    // Analyze individual document
                    ResponseEntity<Map<String, Object>> individualResponse = analyzeDocument(documentType, file,
                            customerMobile, confidenceThreshold);

                    Map<String, Object> individualResult = individualResponse.getBody();
                    results.put("document_" + (i + 1) + "_" + documentType.toLowerCase(), individualResult);

                    if (individualResult != null && Boolean.TRUE.equals(individualResult.get("success"))) {
                        successCount++;
                    } else {
                        allSuccessful = false;
                    }

                } catch (Exception e) {
                    log.error("Error analyzing document {} of type {}", file.getOriginalFilename(), documentType, e);
                    results.put("document_" + (i + 1) + "_" + documentType.toLowerCase(), Map.of(
                            "success", false,
                            "error", "Analysis failed: " + e.getMessage()));
                    allSuccessful = false;
                }
            }

            response.put("success", allSuccessful);
            response.put("total_documents", files.length);
            response.put("successful_analyses", successCount);
            response.put("results", results);

            log.info("Batch analysis completed - Total: {}, Successful: {}", files.length, successCount);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Error in batch document analysis", e);
            response.put("success", false);
            response.put("error", "Batch analysis failed: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Get supported document types and formats
     */
    @GetMapping("/supported-types")
    public ResponseEntity<Map<String, Object>> getSupportedTypes() {
        Map<String, Object> response = new HashMap<>();

        response.put("supported_document_types", new String[] { "PAN", "AADHAAR" });
        response.put("supported_file_formats", new String[] { "PDF", "JPG", "JPEG", "PNG", "TIFF", "BMP" });
        response.put("max_file_size_mb", 10);
        response.put("min_confidence_threshold", 0.1);
        response.put("max_confidence_threshold", 1.0);
        response.put("default_confidence_threshold", 0.8);

        Map<String, Object> extractionInfo = new HashMap<>();
        extractionInfo.put("pdf_text_extraction", "Apache PDFBox");
        extractionInfo.put("image_ocr", "Tesseract OCR");
        extractionInfo.put("ai_analysis", "AWS SageMaker");
        response.put("processing_methods", extractionInfo);

        return ResponseEntity.ok(response);
    }

    /**
     * Health check for document verification services
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> response = new HashMap<>();

        try {
            // Check text extraction service
            boolean textExtractionHealthy = true; // You could add actual health check

            // Check SageMaker service
            boolean sageMakerHealthy = true; // You could add actual health check

            response.put("status", "healthy");
            response.put("services", Map.of(
                    "text_extraction", textExtractionHealthy ? "healthy" : "unhealthy",
                    "sagemaker_analysis", sageMakerHealthy ? "healthy" : "unhealthy"));
            response.put("timestamp", System.currentTimeMillis());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("status", "unhealthy");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
        }
    }

    /**
     * Validate document type
     */
    private boolean isValidDocumentType(String documentType) {
        if (documentType == null)
            return false;
        String upperType = documentType.toUpperCase();
        return "PAN".equals(upperType) || "AADHAAR".equals(upperType);
    }
}
