# Test User Profile Endpoint
Write-Host "Testing User Profile Endpoint..." -ForegroundColor Green

# Test login first to get a token
Write-Host "`n1. Testing login to get authentication token..." -ForegroundColor Yellow
$loginResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/login" -Method POST -ContentType "application/json" -Body '{
    "username": "testuser",
    "password": "testpass123"
}' -ErrorAction SilentlyContinue

if ($loginResponse) {
    Write-Host "Login successful!" -ForegroundColor Green
    $token = $loginResponse.token
    
    # Test the profile endpoint
    Write-Host "`n2. Testing user profile endpoint..." -ForegroundColor Yellow
    try {
        $profileResponse = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/profile" -Method GET -Headers @{
            "Authorization" = "Bearer $token"
            "Content-Type" = "application/json"
        }
        
        Write-Host "Profile endpoint successful!" -ForegroundColor Green
        Write-Host "User Profile Data:" -ForegroundColor Cyan
        $profileResponse | ConvertTo-Json -Depth 3
        
    } catch {
        Write-Host "Profile endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
        if ($_.Exception.Response) {
            $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            $responseBody = $reader.ReadToEnd()
            Write-Host "Response: $responseBody" -ForegroundColor Red
        }
    }
} else {
    Write-Host "Login failed. Please make sure the backend is running and you have a test user." -ForegroundColor Red
}

Write-Host "`nTest completed!" -ForegroundColor Green
